BELOW ROUTE 9 - Windows
=======================

A first-person Backrooms horror game. No combat: listen, stay quiet,
follow the painted arrows, and run when something finds you.

Needs a GPU with OpenGL 3.3 (anything from roughly 2010 on). If the game
says "OpenGL 3.3 is required", update your graphics driver.

CONTROLS            Keyboard / mouse     Gamepad
  Move              WASD                 Left stick
  Look              Mouse                Right stick
  Run               Shift                L3 / LT
  Jump              Space                X
  Crouch (quiet)    Ctrl or C            B (hold)
  Flashlight        F or right mouse     LB
  Use / read / hide E or left mouse      A
  Put Ray down      G                    Y
  Pause             Esc                  Start

SAVES AND SETTINGS
  Saves:     %LOCALAPPDATA%\below-route-9
  Settings:  %APPDATA%\below-route-9
Uninstalling keeps these, so you can reinstall without losing progress.

LOW FRAME RATE?  Options -> Graphics -> Medium or Low.

Command-line options (run from a terminal):
  below-route-9.exe --windowed --size 1920x1080
  below-route-9.exe --quality 0
  below-route-9.exe --no-audio
(This build has no console window, so --help / --version print nothing.)

Original game by rxvy (MIT license): https://github.com/rxvy-dev/Below-Route-9
