#!/usr/bin/env bash
# Build BELOW ROUTE 9 for 64-bit Windows from Linux, then package it.
#
#   ./packaging/windows/build-windows.sh
#
# Produces, in ./dist/:
#   Below-Route-9-Setup-<version>.exe          GUI installer (setup wizard)
#   Below-Route-9-<version>-windows-portable.zip   unzip-and-play version
#
# Fedora setup (one time):
#   sudo dnf install mingw64-gcc-c++ mingw64-winpthreads-static cmake make mingw32-nsis curl python3
# Debian/Ubuntu:
#   sudo apt install mingw-w64 cmake make nsis curl python3
#
# SDL2 for Windows is downloaded once (official release, checksum-verified) and cached.
# To use a system package instead:  SDL2_PREFIX=/usr/x86_64-w64-mingw32/sys-root/mingw ./build-windows.sh
# Optional:  PUBLISHER="Your Name"  sets the publisher shown in Windows' "Apps & features".
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
BUILD="$ROOT/build-win"
DIST="$ROOT/dist"
STAGE="$BUILD/stage"

SDL_VER=2.30.9
SDL_URL="https://github.com/libsdl-org/SDL/releases/download/release-$SDL_VER/SDL2-devel-$SDL_VER-mingw.tar.gz"
SDL_SHA256=b188d165dc4a0372042bff3d0c18e9bb90772581e92a7b8b47b521b47714f75c

die() { echo "error: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "'$1' not found. $2"; }

need cmake "Install cmake."
need makensis "Fedora: sudo dnf install mingw32-nsis    Debian/Ubuntu: sudo apt install nsis"
need python3 "Install python3."
CXX="$(command -v x86_64-w64-mingw32-g++-posix || command -v x86_64-w64-mingw32-g++ || true)"
[ -n "$CXX" ] || die "MinGW-w64 compiler not found. Fedora: sudo dnf install mingw64-gcc-c++ mingw64-winpthreads-static"
CXXV="$("$CXX" -v 2>&1)"; [[ "$CXXV" == *"Thread model: posix"* ]] || die "$CXX is not using the posix thread model (needed for std::thread)."

VERSION="$(sed -n 's/^project(below-route-9 VERSION \([0-9.]*\).*/\1/p' "$ROOT/CMakeLists.txt")"
[ -n "$VERSION" ] || die "couldn't read the version from CMakeLists.txt"
echo "==> BELOW ROUTE 9 $VERSION  (compiler: $CXX)"

# ---- SDL2 ----
if [ -n "${SDL2_PREFIX:-}" ]; then
  SDL="$SDL2_PREFIX"
else
  CACHE="$BUILD/_deps"; mkdir -p "$CACHE"
  SDL="$CACHE/SDL2-$SDL_VER/x86_64-w64-mingw32"
  if [ ! -d "$SDL" ]; then
    need curl "Install curl."
    echo "==> downloading SDL2 $SDL_VER for Windows"
    curl -fsSL -o "$CACHE/sdl2.tar.gz" "$SDL_URL"
    echo "$SDL_SHA256  $CACHE/sdl2.tar.gz" | sha256sum -c - >/dev/null || die "SDL2 download failed its checksum"
    tar -xzf "$CACHE/sdl2.tar.gz" -C "$CACHE"
  fi
fi
[ -f "$SDL/bin/SDL2.dll" ] || die "SDL2.dll not found under $SDL/bin"

# ---- compile ----
echo "==> compiling"
cmake -S "$ROOT" -B "$BUILD" \
  -DCMAKE_TOOLCHAIN_FILE="$HERE/mingw-w64-x86_64.cmake" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$SDL" \
  -DCMAKE_EXE_LINKER_FLAGS_RELEASE="-s" >/dev/null
cmake --build "$BUILD" -j"$(nproc)"

# ---- stage ----
echo "==> staging"
rm -rf "$STAGE"; mkdir -p "$STAGE" "$DIST"
cp "$BUILD/below-route-9.exe" "$SDL/bin/SDL2.dll" "$STAGE/"
cp -r "$ROOT/assets/textures" "$STAGE/textures"   # photo-scanned surfaces, read from next to the .exe
# Text files get Windows line endings so old Notepad shows them properly.
crlf() { sed 's/\r$//; s/$/\r/' "$1" > "$STAGE/$2"; }
crlf "$ROOT/LICENSE"                 LICENSE.txt
crlf "$HERE/THIRD_PARTY_NOTICES.txt" THIRD_PARTY_NOTICES.txt
crlf "$HERE/README.txt"              README.txt

# ---- installer ----
echo "==> building installer"
SETUP="$DIST/Below-Route-9-Setup-$VERSION.exe"
( cd "$HERE" && makensis -V2 -DVERSION="$VERSION" -DSTAGE="$STAGE" -DOUTFILE="$SETUP" \
    ${PUBLISHER:+-DPUBLISHER="$PUBLISHER"} installer.nsi )

# ---- portable zip ----
echo "==> building portable zip"
ZIP="$DIST/Below-Route-9-$VERSION-windows-portable.zip"
python3 - "$STAGE" "$ZIP" "Below Route 9" <<'PY'
import sys, zipfile, pathlib
stage, out, top = pathlib.Path(sys.argv[1]), sys.argv[2], sys.argv[3]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in sorted(stage.rglob("*")):
        if f.is_file():
            z.write(f, f"{top}/{f.relative_to(stage).as_posix()}")
PY

echo
echo "Done:"
ls -lh "$SETUP" "$ZIP" | awk '{print "  " $5 "  " $9}'
