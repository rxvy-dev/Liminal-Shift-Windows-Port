#include "game.h"
#include "logo_data.h"
#include "mural_data.h"
#include "signs_data.h"
#include "texload.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>
#ifndef BR9_VERSION
#define BR9_VERSION "dev"
#endif
#ifndef BR9_COMMIT
#define BR9_COMMIT "source"
#endif

StalkerParams stiltParams();  // game_party.cpp
StalkerParams partyParams();

namespace {

constexpr int kLevelSize = 48;  // tiles; the world wraps every 96 m
constexpr float kPlayerRadius = 0.3f;

float wrapPi(float a) { return std::remainder(a, 2.0f * kPi); }

StalkerParams tenantParams() { return StalkerParams{}; }
StalkerParams lifeguardParams() {
  StalkerParams p;
  p.hearing = 1.5f;
  p.sight = 0.6f;
  p.wanderSpeed = 1.1f;
  p.chaseBase = 3.4f;
  p.chaseMax = 4.6f;
  return p;
}
StalkerParams houndParams() {
  StalkerParams p;
  p.blind = true;
  p.sight = 0;
  p.hearing = 1.6f;
  p.wanderSpeed = 1.0f;
  p.investigateSpeed = 2.6f;
  p.searchSpeed = 1.4f;
  p.chaseBase = 5.0f;
  p.chaseMax = 5.8f;
  p.chaseAccel = 0.5f;
  p.giveUp = 2.2f;
  p.catchDist = 1.05f;
  p.radius = 0.36f;
  p.stride = 1.15f;
  return p;
}

mat4 basis(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}

struct SurfaceLook { float rough, bump; };
SurfaceLook look(Surf s) {
  switch (s) {
    case Surf::Tile: return {0.18f, 0.004f};
    case Surf::Brick: return {0.85f, 0.012f};
    case Surf::Concrete: return {0.75f, 0.008f};
    case Surf::ConcreteFloor: return {0.45f, 0.006f};
    case Surf::CeilingConcrete: return {0.85f, 0.008f};
    case Surf::Carpet: case Surf::DarkCarpet: return {0.9f, 0.010f};
    case Surf::CeilingTiles: return {0.9f, 0.010f};
    case Surf::Painted: return {0.6f, 0.009f};
    case Surf::Vinyl: return {0.3f, 0.003f};
    case Surf::Wood: return {0.45f, 0.005f};
    case Surf::Plaster: return {0.85f, 0.003f};
    case Surf::HotelCarpet: return {0.92f, 0.01f};
    case Surf::PoolTile: return {0.07f, 0.003f};  // glazed tile, wet: close to a mirror
    case Surf::PartyCarpet: return {0.92f, 0.01f};
    case Surf::PartyWall: case Surf::PartyWall2: return {0.55f, 0.003f};
    case Surf::PartyCeiling: return {0.9f, 0.012f};
    case Surf::PoolMosaic: return {0.22f, 0.006f};
    case Surf::Corrugated: return {0.45f, 0.012f};
    case Surf::ParkingFloor: return {0.55f, 0.006f};
    case Surf::OfficeWall: return {0.7f, 0.002f};
    case Surf::OfficeCarpet: return {0.92f, 0.008f};
    case Surf::BallPit: return {0.3f, 0.012f};
    case Surf::PlayWall: return {0.5f, 0.012f};
    case Surf::PlayCeiling: return {0.9f, 0.008f};
    case Surf::Grass: return {0.92f, 0.01f};
    case Surf::ParkWall: return {0.55f, 0.01f};
    case Surf::ParkCeiling: return {0.95f, 0.004f};
    case Surf::ArcadeCarpet: return {0.92f, 0.01f};
    default: return {0.8f, 0.006f};
  }
}

int gTexRes = 512;  // surface texture size: 1024 on high quality
const char* photoName(Surf s, bool ceiling) {
  switch (s) {
    case Surf::Wallpaper: return "wallpaper";
    case Surf::DarkWallpaper: return "dark_wallpaper";
    case Surf::Concrete: return "concrete";
    case Surf::Brick: return "brick";
    case Surf::Tile: return ceiling ? "ceiling_tile" : "tile";
    case Surf::Carpet: return "carpet";
    case Surf::DarkCarpet: return "dark_carpet";
    case Surf::ConcreteFloor: return "concrete_floor";
    case Surf::CeilingTiles: return "ceiling_tiles";
    case Surf::CeilingConcrete: return "concrete_ceiling";
    case Surf::Painted: return "painted_block";
    case Surf::Vinyl: return "vinyl";
    case Surf::Wood: return "wood";
    case Surf::Plaster: return "plaster";
    case Surf::HotelCarpet: return "hotel_carpet";
    case Surf::OfficeWall: return "office_wall";
    case Surf::OfficeCarpet: return "office_carpet";
    case Surf::ParkingFloor: return "parking_floor";
    case Surf::Corrugated: return "corrugated";
    case Surf::PoolTile: return "pool_tile";
    default: return nullptr;
  }
}

Image surfaceImage(Surf s, uint32_t seed, bool ceiling) {
  const int R = gTexRes;
  if (const char* pn = photoName(s, ceiling)) {  // a scanned texture dropped in the textures folder wins
    Image im;
    if (loadPhotoTexture(pn, R, im)) return im;
    // the dark variants fall back to the plain photo, darkened
    if (s == Surf::DarkWallpaper && loadPhotoTexture("wallpaper", R, im)) { texgen::tint(im, 0.42f, 0.4f, 0.36f); return im; }
    if (s == Surf::DarkCarpet && loadPhotoTexture("carpet", R, im)) { texgen::tint(im, 0.5f, 0.46f, 0.42f); return im; }
  }
  switch (s) {
    case Surf::Wallpaper: return texgen::wallpaper(R, seed);
    case Surf::DarkWallpaper: { Image im = texgen::wallpaper(R, seed); texgen::tint(im, 0.42f, 0.4f, 0.36f); return im; }
    case Surf::Concrete: return texgen::concreteWall(R, seed);
    case Surf::Brick: return texgen::brick(R, seed);
    case Surf::Tile: return texgen::tiles(R, seed, ceiling ? 4 : 8);
    case Surf::Carpet: return texgen::carpet(R, seed);
    case Surf::DarkCarpet: { Image im = texgen::carpet(R, seed); texgen::tint(im, 0.5f, 0.46f, 0.42f); return im; }
    case Surf::ConcreteFloor: return texgen::concreteFloor(R, seed);
    case Surf::CeilingTiles: return texgen::ceilingTiles(R, seed);
    case Surf::CeilingConcrete: return texgen::concreteCeiling(R, seed);
    case Surf::Painted: return texgen::paintedBlock(R, seed);
    case Surf::Vinyl: return texgen::vinyl(R, seed);
    case Surf::Wood: return texgen::woodFloor(R, seed);
    case Surf::Plaster: return texgen::plaster(R, seed);
    case Surf::HotelCarpet: { Image im = texgen::carpet(R, seed); texgen::tint(im, 0.82f, 0.62f, 0.7f); return im; }
    case Surf::PoolTile: return texgen::poolTile(R, seed, ceiling ? 3 : 4);
    case Surf::PoolMosaic: return texgen::poolMosaic(R, seed);
    case Surf::PartyCarpet: return texgen::partyCarpet(R, seed);
    case Surf::PartyWall: return texgen::partyWall(R, seed, 0.92f, 0.42f, 0.1f);
    case Surf::PartyWall2: return texgen::partyWall(R, seed, 0.96f, 0.76f, 0.12f);
    case Surf::PartyCeiling: { Image im = texgen::plaster(R, seed); texgen::tint(im, 0.95f, 0.55f, 0.36f); return im; }
    case Surf::Corrugated: return texgen::corrugated(R, seed);
    case Surf::ParkingFloor: return texgen::parkingFloor(R, seed);
    case Surf::OfficeWall: return texgen::officeWall(R, seed);
    case Surf::OfficeCarpet: return texgen::officeCarpet(R, seed);
    case Surf::BallPit: return texgen::ballPit(R, seed);
    case Surf::PlayWall: return texgen::playWall(R, seed);
    case Surf::PlayCeiling: { Image im = texgen::plaster(R, seed); texgen::tint(im, 0.36f, 0.37f, 0.4f); return im; }
    case Surf::Grass: return texgen::grass(R, seed);
    case Surf::ParkWall: return texgen::parkWall(R, seed);
    case Surf::ArcadeCarpet: return texgen::arcadeCarpet(R, seed);
    case Surf::ParkCeiling: { Image im = texgen::plaster(R, seed); texgen::tint(im, 0.13f, 0.13f, 0.14f); return im; }  // open roof deck, painted black
  }
  return texgen::solid(128, 128, 128);
}

}  // namespace

// ================================================================ setup

bool Game::init(SDL_Window* win, Renderer* r, Audio* a, const Options& o, std::string& err) {
  win_ = win; R_ = r; A_ = a; opt_ = o;
  (void)err;
  loadSettings();
  loadVoices();
  saveSettings();  // writes the vhs_look migration so it only happens once
  loadEndingFlag();
  loadProfile();
  {  // title logo: 4-bit cream/red masks, run-length encoded
    std::vector<uint8_t> px((size_t)kLogoW * kLogoH * 4);
    size_t o = 0;
    for (size_t i = 0; i + 1 < sizeof(kLogoRLE); i += 2)
      for (int k = 0; k < kLogoRLE[i] && o < (size_t)kLogoW * kLogoH; ++k, ++o) {
        float c = (kLogoRLE[i + 1] >> 4) / 15.0f, rd = (kLogoRLE[i + 1] & 15) / 15.0f;
        float a = std::max(c, rd);
        float r = (240 * c * (1 - rd) + 230 * rd), g = (234 * c * (1 - rd) + 36 * rd), b = (216 * c * (1 - rd) + 36 * rd);
        float inv = a > 0 ? 1.0f / a : 0;
        px[o * 4] = (uint8_t)clampf(r * inv, 0, 255); px[o * 4 + 1] = (uint8_t)clampf(g * inv, 0, 255);
        px[o * 4 + 2] = (uint8_t)clampf(b * inv, 0, 255); px[o * 4 + 3] = (uint8_t)(a * 255);
      }
    Image logo;
    logo.w = kLogoW; logo.h = kLogoH; logo.px = std::move(px);
    R_->logoTex = makeTexture(logo, false, false);
    R_->logoW = kLogoW; R_->logoH = kLogoH;
  }
  if (o.quality >= 0) settings.quality = std::clamp(o.quality, 0, 2);
  R_->quality = qualityPreset(settings.quality);
  gTexRes = settings.quality >= 2 ? 1024 : 512;

  texPanel_ = makeTexture(texgen::lightPanel(128), true, true);
  texPaper_ = makeTexture(texgen::paper(256, 1999), true, false);
  texGrime_ = makeTexture(texgen::grime(256, 2000), true, true);
  texWhite_ = makeTexture(texgen::solid(255, 255, 255), false, true);
  creatures::setProgress([](float p, void* u) { static_cast<Game*>(u)->drawLoading(p, "BUILDING THE BACKROOMS"); }, this);
  drawLoading(0.0f, "BUILDING THE BACKROOMS");
  {  // finer models on the higher quality settings (they're meshed on every core)
    static const float kModelQ[4] = {0.7f, 1.0f, 1.25f, 1.45f};
    float mq = kModelQ[std::clamp(settings.quality, 0, 3)];
    if (const char* e = std::getenv("BR9_MODELQ")) mq = (float)std::atof(e);
    creatures::build(mq);
  }
  creatures::setProgress(nullptr, nullptr);
  drawLoading(1.0f, "BUILDING THE BACKROOMS");

  {  // unit cube for small items, unit quad for decals
    Mesh m;
    const vec3 n[6] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    for (auto nn : n) {
      vec3 up = std::fabs(nn.y) > 0.5f ? vec3{0, 0, -1} : vec3{0, 1, 0};
      vec3 rt = cross(up, nn);
      vec3 c = nn * 0.5f;
      m.quad(c - rt * 0.5f - up * 0.5f, c + rt * 0.5f - up * 0.5f, c + rt * 0.5f + up * 0.5f, c - rt * 0.5f + up * 0.5f, nn,
             {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1);
    }
    cube_.upload(m);
    Mesh q;
    q.quad({-0.5f, -0.5f, 0}, {0.5f, -0.5f, 0}, {0.5f, 0.5f, 0}, {-0.5f, 0.5f, 0}, {0, 0, 1}, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1);
    quad_.upload(q);
  }

  glGenTextures(1, &texLightState_);
  glBindTexture(GL_TEXTURE_2D, texLightState_);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, 64, 64, 0, GL_RED, GL_FLOAT, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  lightState_.assign(64 * 64, 1.0f);

  int n = SDL_NumJoysticks();
  for (int i = 0; i < n && !pad_; ++i)
    if (SDL_IsGameController(i)) pad_ = SDL_GameControllerOpen(i);

  platform::KeyValueFile save;
  save.load(platform::dataDir() + "/save.ini");
  uint32_t seed = o.seed ? o.seed : (uint32_t)save.geti("seed", 0);
  if (!seed) seed = (uint32_t)std::time(nullptr) ^ 0x5EED;
  int level = o.level >= 0 ? o.level : (o.scene.empty() ? save.geti("level", 0) : 0);
  loadLevel(std::max(0, level), seed);
  screen_ = Screen::Title;

  if (!o.scene.empty() && o.scene != "title") setupScene(o.scene);
  setMouseCapture(screen_ == Screen::Playing);
  return true;
}

// Deterministic setups for screenshots and automated checks.
void Game::setupScene(const std::string& sc) {
  if (sc == "fun") {  // fun mode in Level 0, the Tenant a few metres ahead (BR9_FIREAT: shoot at that time)
    startFunMode();
    if (!stalkers_.empty()) {
      Stalker& s = stalkers_[0];
      vec3 f{-std::sin(yaw_), 0, -std::cos(yaw_)};
      vec3 p = pos_;
      for (int k = 0; k < 10; ++k) { vec3 q = pos_ + f * (0.5f * k); if (!level_.lineOfSight(pos_.x, pos_.z, q.x, q.z, true)) break; p = q; }
      s.pos = level_.wrap(p);
      s.yaw = yaw_ + kPi;
      s.state = Stalker::Idle;
    }
    pitch_ = 0.05f;
    return;
  }
  if (sc.rfind("ending", 0) == 0) {  // endingA, endingB<n> (slide index into the go-home path)
    startNewGame();
    // endingA<n>: brought-him-home slide n; endingB<n>: go-home slide n; endingC<n>: go-back slide n
    char path = sc.size() > 6 ? sc[6] : 'A';
    int n = std::atoi(sc.c_str() + 7);
    rayState_ = (path == 'A' || path == 'R') ? 2 : 3;
    leftRay_ = path != 'R';
    wentBack_ = path == 'R';
    chooseYellow_ = path == 'Y';
    beginEnding();
    if (path == 'B' || path == 'C') buildEndingB(path == 'C');
    slide_ = (path == 'A' || path == 'R' || path == 'Y') ? n : 3 + n;
    startSlide();
    slideT_ = std::getenv("BR9_SLIDET") ? (float)std::atof(std::getenv("BR9_SLIDET")) : 20.0f;
    if (slide_ < (int)slides_.size() && slides_[slide_].autoAdvance > 0) slideT_ = 0.3f;
    return;
  }
  startNewGame();
  if (sc == "phone" && phoneState_ == 1) {  // stand in front of the ringing phone
    resetPlayer(level_.wrap(phonePos_ + phoneNormal_ * 1.3f - vec3{0, 1.45f, 0}), std::atan2(phoneNormal_.x, phoneNormal_.z));
    return;
  }
  if (sc == "phoneanswer" && phoneState_ == 1) {
    resetPlayer(level_.wrap(phonePos_ + phoneNormal_ * 1.0f - vec3{0, 1.45f, 0}), std::atan2(phoneNormal_.x, phoneNormal_.z));
    shockInteract();
    return;
  }
  if (sc == "ghost") { playTime_ = 36.0f; return; }
  if (sc == "plunge") { startPlunge(); return; }
  if (sc == "drop") { startPlunge(); plungeT_ = 3.39f; return; }
  if (sc == "birthday") { partyT_ = 0.3f; return; }  // the song starts almost at once
  if (sc == "desk") {  // under the nearest party table
    int best = -1; float bd = 1e9f;
    for (size_t i = 0; i < level_.props.size(); ++i) {
      if (level_.props[i].type != PR_DESK) continue;
      vec3 d = level_.delta(pos_, level_.props[i].pos);
      float dl = d.x * d.x + d.z * d.z;
      if (dl < bd) { bd = dl; best = (int)i; }
    }
    if (best >= 0) {
      const PropInstance& p = level_.props[best];
      vec3 front{-std::sin(p.yaw), 0, -std::cos(p.yaw)};
      resetPlayer(p.pos + front * 1.2f, p.yaw);
      enterLocker(best);
      partyT_ = 0.3f;
    }
    return;
  }
  if (sc == "endnear") {  // facing THE END IS NEAR
    for (const Decal& d : level_.decals) {
      if (d.kind != DECAL_ENDNEAR) continue;
      vec3 p = d.pos + d.n * 3.6f;
      p.y = 0;
      level_.collide(p, 0.3f);
      resetPlayer(level_.wrap(p), std::atan2(d.n.x, d.n.z));
      pitch_ = 0.2f;
      return;
    }
  }
  if (sc == "district") {  // inside a district of kind BR9_DISTRICT, looking along its longest open line
    int want = std::getenv("BR9_DISTRICT") ? std::atoi(std::getenv("BR9_DISTRICT")) : (int)Level::D_DARK;
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int x = i % level_.W, z = i / level_.W;
      if (level_.districtAt(x, z) != want || level_.isPit(x, z) || level_.hasPillar(x, z)) continue;
      for (int d = 0; d < 4; ++d) {
        int run = 0, cx = x, cz = z;
        while (run < 8 && !level_.blocked(cx, cz, d)) { cx += kDX[d]; cz += kDZ[d]; ++run; }
        if (run < 6) continue;
        resetPlayer(level_.tileCenter(x, z), std::atan2(-(float)kDX[d], -(float)kDZ[d]));
        pitch_ = 0.18f;
        return;
      }
    }
  }
  if (sc == "shop") {  // down an aisle of the closing-down bookstore
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int x = i % level_.W, z = i / level_.W;
      if (z % 2 == 0) continue;
      bool ok = true;
      for (int k = 0; k < 7 && ok; ++k) ok = level_.districtAt(x + k, z) == Level::D_SHOP && level_.districtAt(x + k, z - 1) == Level::D_SHOP && !level_.hasPillar(x + k, z);
      if (!ok) continue;
      resetPlayer(level_.tileCenter(x, z) + vec3{0, 0, -0.6f}, -kPi * 0.5f + 0.25f);
      pitch_ = 0.02f;
      return;
    }
  }
  if (sc == "pillars") {  // in a pillared hall, a couple of tiles off a pillar, looking past it down the hall
    int skip = std::getenv("BR9_HALL") ? std::atoi(std::getenv("BR9_HALL")) : 0;
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int x = i % level_.W, z = i / level_.W;
      if (!level_.hasPillar(x, z) || level_.districtAt(x, z) != Level::D_HALL) continue;
      if (!level_.hasPillar(x + 3, z + 3) || level_.isPit(x - 1, z - 2)) continue;
      if (skip-- > 0) continue;
      vec3 from = level_.tileCenter(x - 1, z - 2), to = level_.tileCenter(x + 2, z + 4);
      vec3 dd = level_.delta(from, to);
      resetPlayer(from, std::atan2(-dd.x, -dd.z));
      pitch_ = -0.06f;
      return;
    }
  }
  if (sc == "clark" && clarkOn_) {  // Captain Clark a few metres ahead (BR9_DIST), side on or (BR9_KIDTURN) facing you
    float dd = std::getenv("BR9_DIST") ? (float)std::atof(std::getenv("BR9_DIST")) : 5.0f;
    vec3 f{-std::sin(yaw_), 0, -std::cos(yaw_)};
    clarkPos_ = level_.wrap(pos_ + f * dd);
    clarkYaw_ = yaw_ + kPi * (std::getenv("BR9_KIDTURN") ? (float)std::atof(std::getenv("BR9_KIDTURN")) : 1.0f);
    clarkPhase_ = 0.3f;
    pitch_ = 0.05f;
    return;
  }
  if (sc == "tower") {  // the Suburbs' water tower on its hill, from a way off
    for (const PropInstance& p : level_.props) {
      if (p.type != PR_WTOWER) continue;
      vec3 from = level_.wrap(p.pos + vec3{-26.0f, 0, 18.0f});
      vec3 dd = level_.delta(from, p.pos);
      resetPlayer(from, std::atan2(-dd.x, -dd.z));
      pitch_ = 0.12f;
      return;
    }
  }
  if (sc == "poolwin") {  // in the Poolrooms, a few metres from one of the glowing windows, looking along the wall at it
    int k = std::getenv("BR9_HALL") ? std::atoi(std::getenv("BR9_HALL")) : 0;
    if ((int)level_.glowWin.size() > k) {
      vec3 c = level_.glowWin[k], n = level_.glowWinN[k];
      vec3 r = cross(vec3{0, 1, 0}, n);
      vec3 from = c + n * 3.2f + r * 2.2f;
      from.y = 0;
      vec3 dd = level_.delta(from, c);
      resetPlayer(level_.wrap(from), std::atan2(-dd.x, -dd.z));
      pitch_ = -0.05f;
      return;
    }
  }
  if (sc == "darkhall") {  // at the mouth of one of the dark hallways on the route, looking down it
    if (!level_.darkHalls.empty()) {
      int t = level_.darkHalls[std::min((int)level_.darkHalls.size() - 1, std::getenv("BR9_HALL") ? std::atoi(std::getenv("BR9_HALL")) : 0)];
      const auto& rp = level_.routePath;
      for (size_t k = 1; k + 1 < rp.size(); ++k)
        if (rp[k] == t) {
          vec3 a = level_.tileCenter(rp[k - 1] % level_.W, rp[k - 1] / level_.W), b = level_.tileCenter(rp[k + 1] % level_.W, rp[k + 1] / level_.W);
          vec3 d = level_.delta(a, b);
          float in = std::getenv("BR9_HALLIN") ? (float)std::atof(std::getenv("BR9_HALLIN")) : 0.0f;  // metres into the hall
          resetPlayer(level_.wrap(a + normalize(d) * in), std::atan2(-d.x, -d.z));
          pitch_ = 0.0f;
          if (std::getenv("BR9_ROUTEDBG"))
            for (int s = 0; s < 14; ++s) {
              vec3 q = level_.wrap(a + normalize(d) * (float)s);
              int tx, tz; level_.tileOf(q.x, q.z, tx, tz);
              int li = level_.lightAtTile[level_.idx(tx, tz)];
              std::fprintf(stderr, "[hall] %2d m  light %.3f  tile light %d kind %d  gi %.2f\n", s, level_.lightAt(q.x, q.z, lightState_), li,
                           li >= 0 ? level_.lights[li].kind : -1, level_.hallDark.empty() ? -1.0f : level_.hallDark[level_.idx(tx, tz)]);
            }
          return;
        }
    }
  }
  if (sc == "stairs") {  // at the foot of the stairs to nowhere
    for (const PropInstance& p : level_.props) {
      if (p.type != PR_STAIRS) continue;
      vec3 f{-std::sin(p.yaw), 0, -std::cos(p.yaw)};
      resetPlayer(level_.wrap(p.pos - f * 3.0f), p.yaw);
      pitch_ = 0.22f;
      return;
    }
  }
  if (sc == "pits") {  // at the edge of the pit floor, looking across it
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int x = i % level_.W, z = i / level_.W;
      if (!level_.isPit(x, z) || !level_.isPit(x + 1, z) || !level_.isPit(x + 2, z) || level_.isPit(x - 1, z)) continue;
      vec3 c = level_.tileCenter(x - 1, z);
      resetPlayer(c + vec3{-0.3f, 0, 0}, -kPi * 0.5f);
      pitch_ = -0.28f;
      return;
    }
  }
  if (sc == "landmark") {  // a few metres from a district landmark (BR9_PROP: prop id, default the couch)
    int want = std::getenv("BR9_PROP") ? std::atoi(std::getenv("BR9_PROP")) : (int)PR_COUCH;
    for (const PropInstance& p : level_.props) {
      if (p.type != want) continue;
      for (int d = 0; d < 48; ++d) {
        float a = (d % 16) * 0.3927f;
        vec3 q = p.pos + vec3{std::sin(a), 0, std::cos(a)} * (d < 16 ? 4.2f : d < 32 ? 3.0f : 2.4f);
        q.y = 0;
        if (!level_.lineOfSight(q.x, q.z, p.pos.x, p.pos.z, false)) continue;
        vec3 dd = level_.delta(q, p.pos);
        resetPlayer(level_.wrap(q), std::atan2(-dd.x, -dd.z));
        pitch_ = -0.1f;
        return;
      }
    }
  }
  if (sc == "ending") {  // BR9_ENDING: 1 brought him home, 2 went back, 3 default, 4 yellow; BR9_SLIDE: which slide
    int e = std::getenv("BR9_ENDING") ? std::atoi(std::getenv("BR9_ENDING")) : 3;
    rayState_ = (e == 1 || e == 2) ? 2 : 0;
    wentBack_ = e == 2;
    chooseYellow_ = e == 4;
    beginEnding();
    slide_ = std::getenv("BR9_SLIDE") ? std::atoi(std::getenv("BR9_SLIDE")) : 1;
    startSlide();
    if (std::getenv("BR9_SLIDET")) slideT_ = (float)std::atof(std::getenv("BR9_SLIDET"));
    return;
  }
  if (sc == "interlude") {  // one of the cutscenes between levels (BR9_STEP 0..9)
    pending_.level = 1; pending_.seed = level_.seed;
    beginInterlude(std::getenv("BR9_STEP") ? std::atoi(std::getenv("BR9_STEP")) : 3);
    return;
  }
  if (sc == "park" || sc == "parkgap" || sc == "parents" || sc == "kidbed" || sc == "kidface") {  // the start: the trampoline park (parkgap: right by the gap)
    loadLevel(kParkLevel, level_.seed ? level_.seed : 4242u);
    screen_ = Screen::Playing;
    exposure_ = 0.62f;  // (as if the camera had already settled)
    if (sc == "kidface" && !level_.park.kids.empty()) {  // face to face with a kid on the nearest bed (BR9_KIDFACE poses them)
      const Level::ParkSpots& pk = level_.park;
      vec3 best = pk.kids[0];
      for (const vec3& k : pk.kids) if (k.z > best.z) best = k;
      float dist = std::getenv("BR9_DIST") ? (float)std::atof(std::getenv("BR9_DIST")) : 0.85f;
      float side = std::getenv("BR9_SIDE") ? (float)std::atof(std::getenv("BR9_SIDE")) : 0.0f;
      vec3 at = best + vec3{std::sin(side) * dist, 0, std::cos(side) * dist};
      resetPlayer(at, std::atan2(-(best.x - at.x), -(best.z - at.z)));
      pitch_ = std::getenv("BR9_PITCH") ? (float)std::atof(std::getenv("BR9_PITCH")) : -0.05f;
    }
    if (sc == "kidbed" && !level_.park.kids.empty()) {  // at the edge of the court, a kid bouncing on the nearest bed
      const Level::ParkSpots& pk = level_.park;
      vec3 best = pk.kids[0];
      for (const vec3& k : pk.kids) if (k.z > best.z) best = k;
      vec3 at = best + vec3{0.9f, 0, 2.3f};
      resetPlayer(at, std::atan2(-(best.x - at.x), -(best.z - at.z)));
      pitch_ = std::getenv("BR9_PITCH") ? (float)std::atof(std::getenv("BR9_PITCH")) : -0.32f;
      if (std::getenv("BR9_KIDT")) time_ = (float)std::atof(std::getenv("BR9_KIDT"));
    }
    if (sc == "parents") {  // up close to Dad, looking up at his face (BR9_DIST metres away)
      const Level::ParkSpots& pk = level_.park;
      float dist = std::getenv("BR9_DIST") ? (float)std::atof(std::getenv("BR9_DIST")) : 1.1f;
      vec3 facing{-std::sin(pk.dadYaw), 0, -std::cos(pk.dadYaw)};
      resetPlayer(level_.wrap(pk.dad + facing * dist + vec3{0.25f, 0, 0}), pk.dadYaw + kPi + 0.2f);
      pitch_ = std::getenv("BR9_PITCH") ? (float)std::atof(std::getenv("BR9_PITCH")) : 0.32f;
    }
    if (sc == "parkgap") {
      vec3 c = level_.tileCenter(level_.park.crevX, level_.park.crevZ + 1) + vec3{0.0f, 0, 0.4f};
      resetPlayer(c, 0.0f);
      pitch_ = std::getenv("BR9_PITCH") ? (float)std::atof(std::getenv("BR9_PITCH")) : -0.5f;
    }
    if (std::getenv("BR9_PARKT")) parkT_ = (float)std::atof(std::getenv("BR9_PARKT"));
    if (std::getenv("BR9_WALK")) keys_[SDL_SCANCODE_W] = true;
    return;
  }
  if (sc == "trail" && level_.routePath.size() > 4) {  // standing on the way out, BR9_TRAILF of the way along
    const auto& rp = level_.routePath;
    float f = std::getenv("BR9_TRAILF") ? (float)std::atof(std::getenv("BR9_TRAILF")) : 0.6f;
    int k = std::clamp((int)(f * (rp.size() - 1)), 0, (int)rp.size() - 4);
    vec3 a = level_.tileCenter(rp[k] % level_.W, rp[k] / level_.W), b = level_.tileCenter(rp[k + 3] % level_.W, rp[k + 3] / level_.W);
    vec3 d = level_.delta(a, b);
    resetPlayer(a, std::atan2(-d.x, -d.z));
    pitch_ = -0.22f;
    return;
  }
  if (sc == "signs" && !level_.exitSigns.empty()) {  // a few metres before the first EXIT sign, looking at it
    const Level::ExitSign& sg = level_.exitSigns.front();
    vec3 p = sg.pos + sg.n * 3.5f;
    p.y = 0;
    level_.collide(p, 0.3f);
    resetPlayer(level_.wrap(p), std::atan2(sg.n.x, sg.n.z));
    pitch_ = 0.12f;
    return;
  }
  if (sc == "blood") {  // looking at the end of a blood trail
    for (const Decal& d : level_.decals) {
      if (d.kind != DECAL_BLOOD_POOL) continue;
      vec3 p = d.pos + vec3{2.2f, 0, 1.2f};
      p.y = 0;
      level_.collide(p, 0.3f);
      vec3 to = level_.delta(p, d.pos);
      resetPlayer(level_.wrap(p), std::atan2(-to.x, -to.z));
      pitch_ = -0.42f;
      break;
    }
    return;
  }
  if (sc == "scare") { scareT_ = scareAt_ = 0.0f; playTime_ = 100.0f; return; }  // BR9_SCARE picks which
  if (sc == "endless") { startEndless(false); screen_ = Screen::Noclip; screenTime_ = 2.7f; return; }
  if (sc == "tapeview") { readingTape_ = 5; screen_ = Screen::Reading; screenTime_ = 9.0f; return; }
  if (sc == "badges" || sc == "endings" || sc == "archive") {
    profile_.badges = 0x0A0Bu; profile_.endings = 1; profile_.tapes = 0x0025u; profile_.bestDepth = 9;
    screen_ = Screen::Title; archiveOpen_ = true; archiveView_ = sc == "badges" ? 2 : sc == "endings" ? 3 : 0; archiveSel_ = 2;
    return;
  }
  if (sc == "titlemeta") { profile_.badges = 0x0A0Bu; profile_.endings = 1; profile_.tapes = 0x0025u; profile_.bestDepth = 9; profile_.dailyBest = 4; screen_ = Screen::Title; return; }
  if (sc == "runover") {
    profile_.badges = 0x0A0Bu; profile_.endings = 1; profile_.bestDepth = 7; profile_.dailyBest = 3; profile_.runs = 12;
    runOverDepth_ = 7; runOverRecord_ = true; runOverShow_ = true; screen_ = Screen::Title; screenTime_ = 2; return;
  }
  if (sc == "badgepop") { endless_ = true; depth_ = 6; profile_.bestDepth = 9; unlockBadge(13); badgeT_ = 1.0f; return; }
  if (sc == "tapeitem") {
    for (Item& it : items_) if (it.type == ITEM_TAPE) {
      vec3 at = it.pos + vec3{1.1f, 0, 0.3f};
      level_.collide(at, 0.3f);
      resetPlayer(at, 0);
      vec3 d = level_.delta(pos_, it.pos);
      yaw_ = std::atan2(-d.x, -d.z); pitch_ = -0.6f;
      break;
    }
    return;
  }
  if (sc == "theo") { hazmat_ = true; suitState_ = 0; loreAt_ = 0.0f; loreT_ = 0; return; }
  if (sc == "unit3" && hasUnit_) {
    vec3 at = unitPos_ + vec3{2.2f, 0, 1.4f};
    resetPlayer(at, 0);
    vec3 d = level_.delta(pos_, unitPos_);
    yaw_ = std::atan2(-d.x, -d.z); pitch_ = -0.35f;
    return;
  }
  if (sc == "echo" && level_.court.on) {  // facing across the atrium at her
    vec3 d = level_.delta(pos_, echoPos_);
    yaw_ = std::atan2(-d.x, -d.z); pitch_ = 0.0f;
    loreT_ = 0;
    return;
  }
  if (sc == "partyguest" || sc == "stilt") {  // one of them, a few metres down the hall, looking at you
    int kind = sc == "stilt" ? CR_STILT : CR_PARTYGOER;
    vec3 f = forward();
    int best = -1;
    for (int tries = 0; tries < 4; ++tries) {
      // find the longest open view from here
      float bestLen = 0;
      for (int d = 0; d < 4; ++d) {
        int x, z;
        level_.tileOf(pos_.x, pos_.z, x, z);
        int n = 0;
        while (n < 6 && !level_.blocked(x, z, d)) { x += kDX[d]; z += kDZ[d]; ++n; }
        if (n > bestLen) { bestLen = (float)n; best = d; }
      }
    }
    if (best >= 0) { yaw_ = std::atan2(-(float)kDX[best], -(float)kDZ[best]); f = forward(); }
    pitch_ = kind == CR_STILT ? 0.12f : 0.0f;
    for (Stalker& s : stalkers_) s.state = Stalker::Dormant;
    Stalker s;
    s.kind = kind;
    s.P = kind == CR_STILT ? stiltParams() : partyParams();
    s.pos = pos_ + vec3{f.x, 0, f.z} * (kind == CR_STILT ? 5.5f : 3.6f);
    s.yaw = std::atan2(f.x, f.z);
    s.state = Stalker::Idle;
    stalkers_.push_back(s);
    spawnAt_.push_back(0);
    return;
  }
  if (sc == "suit") {  // the suit at the bottom of the fall
    hazmat_ = false; suitReset();
    vec3 d = level_.delta(pos_, suitPos_);
    yaw_ = std::atan2(-d.x, -d.z); pitch_ = -0.45f;
    return;
  }
  if (sc == "suitworn" || sc == "team") {
    hazmat_ = true; suitState_ = 0; flashOn_ = false; battery_ = 1;
    if (sc == "team") { teamAt_ = 0.0f; teamT_ = 0; }
    return;
  }
  if (sc == "slide") { loadLevel(kChoiceLevel, level_.seed); enterSlide(2); return; }
  if (sc == "choice" || sc == "choicewalls") {
    loadLevel(kChoiceLevel, level_.seed);
    screen_ = Screen::Playing;
    if (sc == "choicewalls") resetPlayer(level_.tileCenter(5, 5), 0.0f);
    return;
  }
  if (sc == "splash") {
    int best = -1; float bd = 1e9f;
    for (int i = 0; i < level_.W * level_.H; ++i) {
      if (!level_.pool[i]) continue;
      vec3 c = level_.tileCenter(i % level_.W, i / level_.W);
      vec3 d = level_.delta(pos_, c);
      float dl = d.x * d.x + d.z * d.z;
      if (dl < bd) { bd = dl; best = i; }
    }
    if (best >= 0) {
      vec3 c = level_.tileCenter(best % level_.W, best / level_.W);
      resetPlayer(c, yaw_);
      footY_ = level_.floorAt(c.x, c.z);
      grounded_ = false; jumpY_ = 0.9f; vy_ = 0.5f;
      pitch_ = -0.45f;
    }
    return;
  }
  if (sc == "raything") {
    leftRay_ = true;
    resetEntities();
    for (Stalker& s : stalkers_)
      if (s.kind == CR_HUMAN) {
        vec3 f = forward();
        vec3 p = pos_ + vec3{f.x, 0, f.z} * 4.5f;
        level_.collide(p, 0.3f);
        s.pos = level_.wrap(p); s.yaw = yaw_ + kPi; s.state = Stalker::Idle;
      }
    flashOn_ = false;
    return;
  }
  if (sc == "locker" || sc == "lockerfront" || sc == "anomaly" || sc == "ray" || sc == "raycarry" || sc == "raycarryrun") {
    int best = -1;
    float bd = 1e9f;
    for (size_t i = 0; i < level_.props.size(); ++i) {
      const PropInstance& p = level_.props[i];
      bool want = (sc == "locker" || sc == "lockerfront") ? (p.type == PR_LOCKER && !p.anomaly) : (sc == "anomaly" ? (p.anomaly == 1 || p.anomaly == 4) : false);
      if (!want) continue;
      vec3 d = level_.delta(pos_, p.pos);
      float dl = d.x * d.x + d.z * d.z;
      if (dl < bd) { bd = dl; best = (int)i; }
    }
    vec3 target = best >= 0 ? level_.props[best].pos : pos_;
    if (sc == "ray" || sc == "raycarry" || sc == "raycarryrun") {
      rayLevel_ = levelIndex_; rayState_ = 0; placeRay(); target = rayPos_;
    }
    if (sc == "locker" && best >= 0) { enterLocker(best); return; }
    if (sc == "lockerfront" && best >= 0) {  // standing in front of the nearest locker, looking at its door
      const PropInstance& lp = level_.props[best];
      vec3 f{-std::sin(lp.yaw), 0, -std::cos(lp.yaw)};
      resetPlayer(level_.wrap(lp.pos + f * 1.3f), lp.yaw + kPi);
      pitch_ = -0.12f;
      return;
    }
    if (sc == "raycarry" || sc == "raycarryrun") { pos_ = target; rayInteract(); if (sc == "raycarry") lines_.clear(); return; }
    // stand ~2.5 m from it, looking at it
    int tx, tz; level_.tileOf(target.x, target.z, tx, tz);
    for (int d = 0; d < 4; ++d) {
      if (level_.blocked(tx, tz, d)) continue;
      vec3 p = level_.tileCenter(tx + kDX[d], tz + kDZ[d]);
      if (!level_.blocked(tx + kDX[d], tz + kDZ[d], d)) p = level_.tileCenter(tx + 2 * kDX[d], tz + 2 * kDZ[d]) - vec3{kDX[d] * 0.6f, 0, kDZ[d] * 0.6f};
      vec3 to = level_.delta(p, target);
      resetPlayer(p, std::atan2(-to.x, -to.z));
      pitch_ = sc == "anomaly" ? 0.05f : -0.35f;
      break;
    }
    return;
  }
  vec3 f = forward();
  auto firstStalker = [&](int kind) -> Stalker* {
    for (auto& s : stalkers_) if (s.kind == kind) return &s;
    if (stalkers_.empty()) return nullptr;
    return &stalkers_[0];
  };
  if (sc == "tenant" || sc == "hunt") {
    Stalker* s = firstStalker(CR_TENANT);
    if (s) {
      vec3 p = pos_ + vec3{f.x, 0, f.z} * (sc == "tenant" ? 3.2f : 6.5f);
      level_.collide(p, 0.32f);
      s->pos = level_.wrap(p);
      s->yaw = yaw_ + kPi;
      s->state = Stalker::Idle;
      if (sc == "hunt") { s->startHunt(30, 3.9f); alarm_ = 2.5f; }
      portrait_ = sc == "tenant";
    }
  } else if (sc == "hound") {
    Stalker* s = firstStalker(CR_HOUND);
    if (s) {
      vec3 p = pos_ + vec3{f.x, 0, f.z} * 2.4f;
      level_.collide(p, 0.36f);
      s->pos = level_.wrap(p);
      s->yaw = yaw_ + kPi - 0.6f;
      s->state = Stalker::Idle;
      pitch_ = -0.2f;
      portrait_ = true;
    }
  } else if (sc == "grin" && !grins_.empty()) {
    Grin& g = grins_[0];
    vec3 p = g.home;
    for (int k = 0; k < 16; ++k) {
      float a = k * kPi / 8.0f + 0.13f;
      vec3 dir{std::sin(a), 0, std::cos(a)};
      p = g.home + dir * 3.2f;
      level_.collide(p, 0.3f);
      if (length(level_.delta(g.home, p)) > 2.8f && level_.lineOfSight(p.x, p.z, g.home.x, g.home.z)) break;
    }
    vec3 dir = normalize(level_.delta(g.home, p));
    resetPlayer(level_.wrap(p), std::atan2(dir.x, dir.z));
    pitch_ = 0.12f;
    flashOn_ = false;
    exposure_ = 2.5f;
  } else if (sc == "camp" && level_.campX >= 0) {
    vec3 c = level_.tileCenter(level_.campX, level_.campZ);
    vec3 p = c + vec3{1.6f, 0, 1.4f};
    level_.collide(p, 0.3f);
    vec3 d = level_.delta(p, c);
    resetPlayer(level_.wrap(p), std::atan2(-d.x, -d.z));
    pitch_ = -0.35f;
  } else if (sc == "clue") {
    // Stand in front of the first arrow on the route and look at it.
    for (const Decal& d : level_.decals) {
      if (d.kind != DECAL_ARROW || length(d.right) > 0.5f) continue;
      vec3 p = d.pos + d.n * 2.2f;
      p.y = 0;
      level_.collide(p, 0.3f);
      vec3 to = level_.delta(p, d.pos);
      resetPlayer(level_.wrap(p), std::atan2(-to.x, -to.z));
      pitch_ = 0.0f;
      break;
    }
  } else if (sc == "poolstairs" && !level_.stairwells.empty()) {  // looking at a spiral stair
    vec3 c = level_.stairwells[0];
    vec3 at = c + vec3{4.6f, 0, 2.2f};
    resetPlayer(at, 0);
    vec3 d = level_.delta(pos_, c);
    yaw_ = std::atan2(-d.x, -d.z) + 0.15f; pitch_ = 0.08f;
  } else if (sc == "poolsun") {  // somewhere a skylight is in view
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int x = i % level_.W, z = i / level_.W;
      if (!level_.isSky(x, z)) continue;
      int px = x + 3, pz = z + 2;
      if (level_.solid[level_.idx(px, pz)] || level_.hasPillar(px, pz)) continue;
      resetPlayer(level_.tileCenter(px, pz), 0);
      vec3 d = level_.delta(pos_, level_.tileCenter(x, z));
      yaw_ = std::atan2(-d.x, -d.z) + 0.6f; pitch_ = -0.05f;
      break;
    }
  } else if (sc == "poolup") {  // straight up a skylight well
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int x = i % level_.W, z = i / level_.W;
      if (!level_.isSky(x, z)) continue;
      resetPlayer(level_.tileCenter(x, z) + vec3{0.6f, 0, 0.9f}, -0.6f);
      pitch_ = 0.95f;
      break;
    }
  } else if (sc == "pool") {
    int best = -1, bd = 1 << 30;
    for (int i = 0; i < level_.W * level_.H; ++i) {
      if (!level_.pool[i]) continue;
      int x = i % level_.W, z = i / level_.W;
      int dd = std::abs(x - level_.startX) + std::abs(z - level_.startZ);
      if (dd < bd) { bd = dd; best = i; }
    }
    if (best >= 0) {
      vec3 c = level_.tileCenter(best % level_.W, best / level_.W);
      vec3 p = c + vec3{3.0f, 0, 2.2f};
      level_.collide(p, 0.3f);
      vec3 d = level_.delta(p, c);
      resetPlayer(level_.wrap(p), std::atan2(-d.x, -d.z));
      pitch_ = -0.25f;
    }
  } else if (sc == "office" && level_.mural >= 0) {  // Count On Me: BR9_SPOT 0 the mural, 1 at the right-hand door, 2 the yellow stretch
    int spot = std::getenv("BR9_SPOT") ? std::atoi(std::getenv("BR9_SPOT")) : 0;
    int mx = level_.mural % level_.W, mz = level_.mural / level_.W;
    if (spot == 1) resetPlayer(level_.tileCenter(mx + 2, mz) + vec3{0, 0, 0.3f}, 0.0f);
    if (spot == 2 && level_.officeLit.size() > 1) {
      int i = level_.officeLit[1];
      resetPlayer(level_.tileCenter(i % level_.W, i / level_.W) + vec3{0, 0, 0.6f}, 0.0f);
    }
    if (std::getenv("BR9_YAW")) yaw_ = (float)std::atof(std::getenv("BR9_YAW"));
  } else if (sc == "open") {  // the most open, best-lit spot, looking down the longest view (compare with photos)
    int best = -1; float bestS = -1;
    for (int z = 0; z < level_.H; ++z)
      for (int x = 0; x < level_.W; ++x) {
        int i = z * level_.W + x;
        if (level_.pillar[i] || (!level_.solid.empty() && level_.solid[i]) || level_.isPit(x, z)) continue;
        float sc2 = 0;
        for (int dz = -3; dz <= 3; ++dz)
          for (int dx = -3; dx <= 3; ++dx) {
            int tx = level_.wx(x + dx), tz = level_.wz(z + dz), j = tz * level_.W + tx;
            int li = level_.lightAtTile[j];
            if (li >= 0 && level_.lights[li].kind == 0) sc2 += 1.0f;
            if (level_.isPit(tx, tz)) sc2 -= 2.0f;
            if (level_.pillar[j]) sc2 += 0.4f;  // a few pillars, like the photo
            for (int d = 0; d < 4; ++d) if (level_.blocked(tx, tz, d)) sc2 -= 0.15f;
          }
        if (sc2 > bestS) { bestS = sc2; best = i; }
      }
    if (best >= 0) {
      vec3 c = level_.tileCenter(best % level_.W, best / level_.W);
      float by = 0, bl = -1;
      for (int k = 0; k < 16; ++k) {
        float a = k * kPi / 8.0f;
        vec3 f{-std::sin(a), 0, -std::cos(a)};
        float run = 0;
        while (run < 30.0f && level_.lineOfSight(c.x, c.z, c.x + f.x * (run + 0.5f), c.z + f.z * (run + 0.5f), true)) run += 0.5f;
        if (run > bl) { bl = run; by = a; }
      }
      vec3 f{-std::sin(by), 0, -std::cos(by)};
      resetPlayer(level_.wrap(c - f * 0.8f), by);
      pitch_ = 0.06f;
    }
  } else if (sc == "hill" && level_.theme.terrain > 0.0f) {  // on a hilltop, looking out over the houses
    int best = -1; float bh = -1e9f;
    for (int i = 0; i < level_.W * level_.H; ++i) {
      if (level_.solid[i]) continue;
      bool nearHouse = false;
      for (int dz = -3; dz <= 3 && !nearHouse; ++dz)
        for (int dx = -3; dx <= 3; ++dx)
          if (level_.solid[level_.wz(i / level_.W + dz) * level_.W + level_.wx(i % level_.W + dx)]) { nearHouse = true; break; }
      if (nearHouse) continue;
      vec3 c = level_.tileCenter(i % level_.W, i / level_.W);
      float h = level_.terrainH(c.x, c.z);
      if (h > bh) { bh = h; best = i; }
    }
    vec3 c = level_.tileCenter(best % level_.W, best / level_.W);
    float by = 0, lo = 1e9f;
    for (int k = 0; k < 16; ++k) {
      float a = k * kPi / 8.0f;
      float h = level_.terrainH(c.x - std::sin(a) * 14.0f, c.z - std::cos(a) * 14.0f);
      if (h < lo) { lo = h; by = a; }
    }
    resetPlayer(c, by);
    pitch_ = -0.1f;
  } else if (sc == "gap" && !level_.lowGaps.empty()) {  // in front of a crawl hole (BR9_CRAWL: halfway through it)
    const Level::LowGap& g = level_.lowGaps[std::getenv("BR9_GAPI") ? std::atoi(std::getenv("BR9_GAPI")) % level_.lowGaps.size() : 0];
    bool crawl = std::getenv("BR9_CRAWL") != nullptr;
    resetPlayer(level_.wrap(g.c - g.n * (crawl ? 0.05f : 2.2f)), std::atan2(-g.n.x, -g.n.z));
    pitch_ = crawl ? -0.05f : -0.12f;
    if (crawl) { keys_[SDL_SCANCODE_LCTRL] = true; underGap_ = true; eyeH_ = 0.52f; }
  } else if (sc == "dark") {
    for (int i = 0; i < level_.W * level_.H; ++i) {
      vec3 c = level_.tileCenter(i % level_.W, i / level_.W);
      if (!level_.pillar[i] && level_.lightAt(c.x, c.z, lightState_) < 0.03f) { resetPlayer(c, 0); exposure_ = 2.5f; break; }
    }
  } else if (sc == "exit" || sc == "exitwalk") {
    vec3 c = level_.tileCenter(level_.exitX, level_.exitZ);
    vec3 nrm = level_.exitFaceNormal();
    resetPlayer(c + nrm * 0.6f, std::atan2(nrm.x, nrm.z));
    exitChaseDone_ = true;
    if (sc == "exitwalk") keys_[SDL_SCANCODE_W] = true;
  } else if (sc == "wrap") {
    // Walk east across the world's seam to prove there is no edge.
    for (int z = 0; z < level_.H; ++z) {
      int x = level_.W - 1;
      if (!level_.blocked(x, z, PX) && !level_.blocked(x + 1, z, PX) && !level_.hasPillar(x, z) && !level_.hasPillar(x + 1, z) &&
          !level_.isPool(x, z)) {
        resetPlayer(level_.tileCenter(x, z) - vec3{0.6f, 0, 0}, -kPi * 0.5f);
        keys_[SDL_SCANCODE_W] = true;
        portrait_ = true;
        break;
      }
    }
  } else if (sc == "note") {
    readingNote_ = 0;
    screen_ = Screen::Reading;
  } else if (sc == "pause") {
    screen_ = Screen::Paused;
  } else if (sc == "transition") {
    prevTitle_ = "THE LOBBY";
    screen_ = Screen::Transition;
    transitionTime_ = 0;
  }
}

void Game::freeLevelGpu() {
  for (auto& c : chunks_) { c.walls.destroy(); c.floor.destroy(); c.ceiling.destroy(); c.panels.destroy(); c.trim.destroy(); c.water.destroy(); c.walls2.destroy(); c.floor2.destroy(); c.ceiling2.destroy(); }
  chunks_.clear();
  GLuint t[] = {texWall_, texFloor_, texCeil_, texWall2_, texFloor2_, texCeil2_};
  for (GLuint x : t) if (x) glDeleteTextures(1, &x);
  texWall_ = texFloor_ = texCeil_ = texWall2_ = texFloor2_ = texCeil2_ = 0;
  if (!decalTex_.empty()) glDeleteTextures((GLsizei)decalTex_.size(), decalTex_.data());
  decalTex_.clear();
}

void Game::buildLevelTextures() {
  const Theme& t = level_.theme;
  uint32_t s = 1996 + (uint32_t)t.index * 31u;
  {
    Image wi = surfaceImage(t.wall, s, false);
    // the colour of light that has bounced off these walls (normalised; tinted toward white)
    double r = 0, g = 0, b = 0;
    for (size_t i = 0; i < wi.px.size(); i += 4) { r += wi.px[i]; g += wi.px[i + 1]; b += wi.px[i + 2]; }
    float mx = (float)std::max(r, std::max(g, b));
    bounceTint_ = mx > 0 ? vec3{(float)r / mx, (float)g / mx, (float)b / mx} : vec3{1, 1, 1};
    bounceTint_ = vec3{0.35f + 0.65f * bounceTint_.x, 0.35f + 0.65f * bounceTint_.y, 0.35f + 0.65f * bounceTint_.z};
    texWall_ = makeTexture(wi, true, true);
  }
  texFloor_ = makeTexture(surfaceImage(t.floor, s + 1, false), true, true);
  texCeil_ = makeTexture(surfaceImage(t.ceiling, s + 2, true), true, true);
  texWall2_ = makeTexture(surfaceImage(t.wall2, s + 3, false), true, true);
  texFloor2_ = makeTexture(surfaceImage(t.floor2, s + 4, false), true, true);
  texCeil2_ = makeTexture(surfaceImage(t.ceiling2, s + 5, true), true, true);
  decalTex_.push_back(makeTexture(texgen::paintArrow(256, 128, s), true, false));
  decalTex_.push_back(makeTexture(texgen::paintText("EXIT", 384, 128, s + 1), true, false));
  decalTex_.push_back(makeTexture(texgen::paintText("NOT THIS WAY", 512, 96, s + 2), true, false));
  decalTex_.push_back(makeTexture(texgen::paintText("X", 128, 128, s + 3), true, false));
  decalTex_.push_back(makeTexture(texgen::bloodDrag(512, 160, s + 4), true, false));   // DECAL_BLOOD_DRAG
  decalTex_.push_back(makeTexture(texgen::bloodSplat(256, s + 5), true, false));       // DECAL_BLOOD_SPLAT
  decalTex_.push_back(makeTexture(texgen::bloodPool(256, s + 6), true, false));        // DECAL_BLOOD_POOL
  decalTex_.push_back(makeTexture(texgen::handprint(256, s + 7), true, false));        // DECAL_HANDPRINT
  for (int k = 0; k < 8; ++k) {                                                          // DECAL_LETTER A-H
    char l[2] = {(char)('A' + k), 0};
    decalTex_.push_back(makeTexture(texgen::paintText(l, 128, 128, s + 30 + (uint32_t)k), true, false));
  }
  decalTex_.push_back(makeTexture(texgen::solid(255, 255, 255), true, false));          // DECAL_STRIPE
  {                                                                                      // DECAL_MURAL
    Image m;
    m.w = kMuralW; m.h = kMuralH;
    m.px.assign((size_t)m.w * m.h * 4, 0);
    size_t o = 0;
    for (size_t i = 0; i + 4 < sizeof(kMuralRLE); i += 5)
      for (int k = 0; k < kMuralRLE[i] && o < (size_t)m.w * m.h; ++k, ++o) {
        size_t row = o / m.w, col = o % m.w;
        size_t dst = ((m.h - 1 - row) * m.w + col) * 4;  // GL rows bottom-up
        for (int c = 0; c < 4; ++c) m.px[dst + c] = kMuralRLE[i + 1 + c];
      }
    decalTex_.push_back(makeTexture(m, true, false));
  }
  decalTex_.push_back(makeTexture(texgen::footprints(256, 112, s + 40), true, false));  // DECAL_FOOTPRINTS
  decalTex_.push_back(makeTexture(texgen::tapeFlag(128, s + 41), true, false));         // DECAL_TAPE
  auto unRLE = [&](const uint8_t* rle, size_t n, int w, int h) {
    Image m;
    m.w = w; m.h = h;
    m.px.assign((size_t)w * h * 4, 0);
    size_t o = 0;
    for (size_t i = 0; i + 4 < n; i += 5)
      for (int k = 0; k < rle[i] && o < (size_t)w * h; ++k, ++o) {
        size_t row = o / w, col = o % w;
        size_t dst = ((h - 1 - row) * w + col) * 4;  // GL rows bottom-up
        for (int c = 0; c < 4; ++c) m.px[dst + c] = rle[i + 1 + c];
      }
    return makeTexture(m, true, false);
  };
  decalTex_.push_back(unRLE(kEndRLE, sizeof(kEndRLE), kEndW, kEndH));    // DECAL_ENDNEAR
  decalTex_.push_back(unRLE(kSaleRLE, sizeof(kSaleRLE), kSaleW, kSaleH));  // DECAL_FORSALE
  decalTex_.push_back(makeTexture(texgen::stain(256, s + 42), true, false));            // DECAL_STAIN
  for (size_t i = 0; i < t.graffiti.size(); ++i)
    decalTex_.push_back(makeTexture(texgen::paintText(t.graffiti[i], 512, 96, s + 10 + (uint32_t)i), true, false));
}

void Game::loadLevel(int index, uint32_t seed) {
  hasPrevVP_ = false;  // no motion blur smear across a teleport
  {  // one frame of the loading screen while the level generates
    Theme peek = themeFor(index, seed);
    drawLoading(-1.0f, ("ENTERING " + peek.name).c_str());
  }
  Uint32 t0 = SDL_GetTicks();
  freeLevelGpu();
  levelIndex_ = index;
  Theme th = themeFor(index, seed);
  if (endless_ && index >= 0) endlessTheme(th);
  levelDeaths_ = deaths_;
  level_.generate(seed, kLevelSize, kLevelSize, th);
  rng_ = Rng(seed * 7919u + 17u + (uint32_t)index * 101u);

  std::vector<ChunkMeshes> cm;
  level_.buildChunks(cm);
  chunks_.resize(cm.size());
  for (size_t i = 0; i < cm.size(); ++i) {
    chunks_[i].walls.upload(cm[i].walls);
    chunks_[i].floor.upload(cm[i].floor);
    chunks_[i].ceiling.upload(cm[i].ceiling);
    chunks_[i].panels.upload(cm[i].panels);
    chunks_[i].trim.upload(cm[i].trim);
    chunks_[i].water.upload(cm[i].water);
    chunks_[i].walls2.upload(cm[i].walls2);
    chunks_[i].floor2.upload(cm[i].floor2);
    chunks_[i].ceiling2.upload(cm[i].ceiling2);
    chunks_[i].center = cm[i].center;
  }
  if (!texLightmap_) glGenTextures(1, &texLightmap_);
  glBindTexture(GL_TEXTURE_2D, texLightmap_);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, level_.lmW, level_.lmH, 0, GL_RGBA, GL_FLOAT, level_.lightmap.data());
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  if (!texWear_) glGenTextures(1, &texWear_);
  glBindTexture(GL_TEXTURE_2D, texWear_);
  if (!level_.wear.empty() && level_.giW > 0) glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, level_.giW, level_.giH, 0, GL_RED, GL_FLOAT, level_.wear.data());
  else { float z = 0; glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, 1, 1, 0, GL_RED, GL_FLOAT, &z); }
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  if (!texIndirect_) glGenTextures(1, &texIndirect_);
  glBindTexture(GL_TEXTURE_2D, texIndirect_);
  if (level_.giW > 0) glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, level_.giW, level_.giH, 0, GL_RED, GL_FLOAT, level_.indirect.data());
  else { float z = 0; glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, 1, 1, 0, GL_RED, GL_FLOAT, &z); }
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  buildLevelTextures();
  buildRTTextures();
  buildPoolPieces();
  {  // where the water is, softly: light off the pools dances on nearby walls and ceilings
    Image pm;
    pm.w = level_.W; pm.h = level_.H;
    pm.px.assign((size_t)pm.w * pm.h * 4, 0);
    hasPools_ = false;
    for (int z = 0; z < pm.h; ++z)
      for (int x = 0; x < pm.w; ++x) {
        float v = 0;
        for (int dz = -1; dz <= 1; ++dz)
          for (int dx = -1; dx <= 1; ++dx)
            if (!level_.pool.empty() && level_.pool[level_.idx(x + dx, z + dz)]) v += (dx == 0 && dz == 0) ? 0.5f : 0.0625f;
        if (v > 0) hasPools_ = true;
        size_t i = ((size_t)z * pm.w + x) * 4;
        pm.px[i] = pm.px[i + 1] = pm.px[i + 2] = (uint8_t)(std::min(1.0f, v) * 255);
        pm.px[i + 3] = 255;
      }
    if (texPoolMask_) glDeleteTextures(1, &texPoolMask_);
    texPoolMask_ = makeTexture(pm, false, true);
  }

  hasFlashlight_ = false;  // nothing to see by but the place's own lights
  flashOn_ = false;
  placeItems();
  float bestYaw = 0;
  int bestRun = -1;
  for (int dir = 0; dir < 4; ++dir) {
    int run = 0, x = level_.startX, z = level_.startZ;
    while (run < 20 && !level_.blocked(x, z, dir)) { x += kDX[dir]; z += kDZ[dir]; ++run; }
    if (run > bestRun) { bestRun = run; bestYaw = std::atan2(-(float)kDX[dir], -(float)kDZ[dir]); }
  }
  checkpoint_ = level_.tileCenter(level_.startX, level_.startZ);
  checkpointYaw_ = level_.court.on ? level_.court.startYaw : (level_.startYawSet ? level_.startYaw : (index == kChoiceLevel ? 0.0f : bestYaw));
  resetPlayer(checkpoint_, checkpointYaw_);
  notesMask_ = 0;
  playTime_ = 0;
  exitChaseDone_ = false;
  alarm_ = 0;
  huntTimer_ = th.firstSpawn + th.huntEvery;
  brownout_ = 0;
  updateLights(0);
  resetEntities();
  hiding_ = -1;
  placeRay();
  shockReset();
  suitReset();
  loreReset();
  scaresReset();
  buildCourtyard();
  if (index == kParkLevel) parkBegin();
  clarkReset();
  std::fprintf(stderr, "[br9] %s - %s ready in %u ms (%zu chunks, %zu clues)\n", th.name.c_str(), th.title.c_str(),
               SDL_GetTicks() - t0, chunks_.size(), level_.decals.size());
}

void Game::resetEntities() {
  const Theme& t = level_.theme;
  stalkers_.clear();
  spawnAt_.clear();
  for (int i = 0; i < t.tenants; ++i) {
    Stalker s;
    s.kind = CR_TENANT;
    s.variant = t.lifeguard ? 1 : 0;
    s.P = t.lifeguard ? lifeguardParams() : tenantParams();
    stalkers_.push_back(s);
  }
  for (int i = 0; i < t.hounds; ++i) {
    Stalker s;
    s.kind = CR_HOUND;
    s.P = houndParams();
    stalkers_.push_back(s);
  }
  for (int i = 0; i < t.stilts; ++i) {
    Stalker s;
    s.kind = CR_STILT;
    s.P = stiltParams();
    stalkers_.push_back(s);
  }
  for (int i = 0; i < t.partygoers; ++i) {
    Stalker s;
    s.kind = CR_PARTYGOER;
    s.P = partyParams();
    stalkers_.push_back(s);
  }
  partyReset();
  if (levelIndex_ == kLastLevel && leftRay_) {  // you left him down here
    Stalker s;
    s.kind = CR_HUMAN;
    s.variant = 2;
    s.P = tenantParams();
    s.P.chaseBase = 3.6f;
    s.P.chaseMax = 4.8f;
    s.P.catchDist = 0.9f;
    stalkers_.insert(stalkers_.begin(), s);
  }
  for (size_t i = 0; i < stalkers_.size(); ++i) spawnAt_.push_back(t.firstSpawn * (stalkers_[i].kind == CR_HUMAN ? 0.4f : 1.0f) + i * 55.0f);

  grins_.clear();
  std::vector<float> lit(64 * 64, 1.0f);
  for (size_t i = 0; i < level_.lights.size() && i < lit.size(); ++i) lit[i] = level_.lights[i].kind == 2 ? 0.0f : 1.0f;
  std::vector<int> cands;
  for (int i = 0; i < level_.W * level_.H; ++i) {
    int x = i % level_.W, z = i / level_.W;
    if (level_.pillar[i] || level_.pool[i]) continue;
    vec3 c = level_.tileCenter(x, z);
    if (length(level_.delta(c, level_.tileCenter(level_.startX, level_.startZ))) < 22.0f) continue;
    bool dark = true;
    for (int k = 0; k < 9 && dark; ++k)
      if (level_.lightAt(c.x + (k % 3 - 1) * 1.5f, c.z + (k / 3 - 1) * 1.5f, lit) > 0.05f) dark = false;
    if (dark) cands.push_back(i);
  }
  for (int k = 0; k < t.grins && !cands.empty(); ++k) {
    int pick = cands[rng_.next() % cands.size()];
    Grin g;
    g.home = g.pos = level_.tileCenter(pick % level_.W, pick / level_.W);
    g.active = true;
    g.yaw = rng_.range(0, 6.28f);
    grins_.push_back(g);
    vec3 c = g.home;
    cands.erase(std::remove_if(cands.begin(), cands.end(), [&](int i) {
      return length(level_.delta(level_.tileCenter(i % level_.W, i / level_.W), c)) < 18.0f;
    }), cands.end());
  }
}

void Game::placeItems() {
  const Theme& t = level_.theme;
  items_.clear();
  std::vector<int> d = level_.bfs(level_.startX, level_.startZ);
  int maxd = std::max(4, *std::max_element(d.begin(), d.end()));
  std::vector<uint8_t> used(level_.W * level_.H, 0);
  used[level_.idx(level_.startX, level_.startZ)] = 1;
  used[level_.idx(level_.exitX, level_.exitZ)] = 1;
  auto pickTile = [&](int dmin, int dmax) {
    std::vector<int> c;
    for (int i = 0; i < level_.W * level_.H; ++i)
      if (!used[i] && !level_.pillar[i] && !level_.pool[i] && !level_.isPit(i % level_.W, i / level_.W) && level_.propsAtTile[i].empty() && d[i] >= dmin && d[i] <= dmax) c.push_back(i);
    if (c.empty()) for (int i = 0; i < level_.W * level_.H; ++i) if (!used[i] && !level_.pillar[i] && !level_.pool[i] && !level_.isPit(i % level_.W, i / level_.W)) c.push_back(i);
    int x = c[rng_.next() % c.size()];
    used[x] = 1;
    return x;
  };
  auto spot = [&](int i) {
    vec3 p = level_.tileCenter(i % level_.W, i / level_.W);
    p.x += rng_.range(-0.45f, 0.45f);
    p.z += rng_.range(-0.45f, 0.45f);
    return level_.wrap(p);
  };
  int n = (int)t.notes.size();
  for (int i = 0; i < n; ++i) {
    vec3 p;
    if (i == 1 && level_.campX >= 0) {
      p = level_.tileCenter(level_.campX, level_.campZ) + vec3{0.25f, 0, 0.1f};
      used[level_.idx(level_.campX, level_.campZ)] = 1;
    } else if (i == n - 1 && n > 1) {  // near the exit
      std::vector<int> c;
      for (int k = 0; k < level_.W * level_.H; ++k)
        if (!used[k] && !level_.pillar[k] && !level_.pool[k] && level_.exitDist[k] >= 2 && level_.exitDist[k] <= 4) c.push_back(k);
      int x = c.empty() ? pickTile(maxd / 2, maxd) : c[rng_.next() % c.size()];
      used[x] = 1;
      p = spot(x);
    } else if (i == 0) {
      p = spot(pickTile(2, 3));
    } else {
      float a = (float)i / n;
      p = spot(pickTile((int)(maxd * a * 0.7f), (int)(maxd * (a * 0.7f + 0.3f))));
    }
    items_.push_back({ITEM_NOTE, level_.wrap(p), rng_.range(0, 6.28f), false, i});
  }
  // (no batteries to find: there's no light to put them in)
  for (int i = 0; i < t.waters; ++i) items_.push_back({ITEM_WATER, spot(pickTile(6, maxd)), rng_.range(0, 6.28f), false, -1});
  // Lost tapes: two per Backrooms level, tucked away from the route. Found ones stay found.
  if (levelIndex_ >= 0 && levelIndex_ <= kLastLevel)
    for (int k = 0; k < 2; ++k) {
      int id = levelIndex_ * 2 + k;
      if ((profile_.tapes >> id) & 1u) continue;
      std::vector<int> c;
      for (int i = 0; i < level_.W * level_.H; ++i)
        if (!used[i] && !level_.pillar[i] && !level_.pool[i] && d[i] >= maxd / 3 && level_.exitDist[i] >= 3) c.push_back(i);
      int x = c.empty() ? pickTile(maxd / 3, maxd) : c[rng_.next() % c.size()];
      used[x] = 1;
      items_.push_back({ITEM_TAPE, spot(x), rng_.range(0, 6.28f), false, id});
    }
}

void Game::resetPlayer(vec3 at, float yaw) {
  pos_ = inStore() ? vec3{at.x, 0, at.z} : level_.wrap({at.x, 0, at.z});  // the store and its lot are a real place: no wrapping
  vel_ = {0, 0, 0};
  yaw_ = yaw;
  pitch_ = 0;
  flashDir_ = forward();
  stamina_ = 1;
  exhausted_ = false;
  footY_ = level_.floorAt(pos_.x, pos_.z);
  pitFall_ = -1;
  // the body and the camera start settled: no bounce, crawl, glance or jolt carried over
  vy_ = 0; jumpY_ = 0; landDip_ = 0; grounded_ = true; jumpQueued_ = false; jumpBuf_ = 0; onBed_ = false;
  underGap_ = false; crawlMix_ = 0; camOffY_ = 0; camOffV_ = 0; prevVy_ = 0; glanceT_ = 0;
  adrenaline_ = 0;
}

int Game::notesFound() const { return __builtin_popcount(notesMask_); }

void Game::startNewGame() {
  uint32_t seed = opt_.seed ? opt_.seed : ((uint32_t)std::time(nullptr) * 2654435761u) | 1u;
  rayLevel_ = -99;  // Ray isn't on the way down. You only find him if you take the green EXIT slide back for him.
  rayState_ = 0;
  leftRay_ = false;
  wentBack_ = false;
  hazmat_ = false;
  chooseYellow_ = false;
  funMode_ = false; cheatsOpen_ = false; kills_ = 0; cheats_ = Cheats();
  chooseHome_ = false;
  hiding_ = -1;
  lockerScareDone_ = false;
  lines_.clear();
  int level = opt_.level >= 0 ? opt_.level : (opt_.scene.empty() ? kParkLevel : 0);
  if (!opt_.scene.empty()) seed = level_.seed;
  if (endless_) {  // KEEP FALLING: no store, no Ray, a random level
    seed = endlessSeed_;
    level = (int)((seed >> 9) % (uint32_t)kLevelCount);
    rayLevel_ = -99;
    rayState_ = 3;
  }
  if (level == kParkLevel) loadLevel(level, seed);
  else if (seed != level_.seed || level != levelIndex_) loadLevel(level, seed);
  else {
    placeItems();
    resetEntities();
    shockReset();
  suitReset();
  loreReset();
  scaresReset();
    checkpoint_ = level_.tileCenter(level_.startX, level_.startZ);
    resetPlayer(checkpoint_, checkpointYaw_);
    notesMask_ = 0;
    exitChaseDone_ = false;
    huntTimer_ = level_.theme.firstSpawn + level_.theme.huntEvery;
  }
  battery_ = 1.0f;
  flashOn_ = level != kParkLevel && defaultLight();
  playTime_ = 0;
  totalTime_ = 0;
  deaths_ = 0;
  fear_ = 0;
  hintTimer_ = 9.0f;
  exposure_ = 0.7f;
  screen_ = Screen::Playing;
  screenTime_ = 0;
  saveProgress();
  setMouseCapture(true);
}

void Game::continueGame() {
  platform::KeyValueFile s;
  if (!s.load(platform::dataDir() + "/save.ini")) { startNewGame(); return; }
  uint32_t seed = (uint32_t)s.geti("seed", 0);
  int level = s.geti("level", 0);
  rayLevel_ = s.geti("ray_level", 2);
  rayState_ = s.geti("ray_state", 0);
  if (!s.geti("went_back", 0) && rayState_ <= 1) { rayLevel_ = -99; rayState_ = 0; }  // old saves: no Ray until you go back for him
  leftRay_ = s.geti("left_ray", 0) != 0;
  wentBack_ = s.geti("went_back", 0) != 0;
  hazmat_ = s.geti("hazmat", 0) != 0;
  if (!seed) { startNewGame(); return; }
  if (seed != level_.seed || level != levelIndex_) loadLevel(level, seed);
  else { placeItems(); resetEntities(); }
  notesMask_ = (uint32_t)s.geti("notes", 0);
  for (auto& it : items_) if (it.type == ITEM_NOTE && (notesMask_ >> it.note) & 1u) it.taken = true;
  checkpoint_ = level_.wrap({s.getf("cp_x", checkpoint_.x), 0, s.getf("cp_z", checkpoint_.z)});
  checkpointYaw_ = s.getf("cp_yaw", checkpointYaw_);
  battery_ = clampf(s.getf("battery", 1.0f), 0.25f, 1.0f);
  playTime_ = s.getf("time", 0);
  totalTime_ = s.getf("total_time", 0);
  deaths_ = s.geti("deaths", 0);
  // Pick up exactly where you were (v2 saves), not just at the last checkpoint.
  std::string taken = s.gets("items", "");
  for (size_t i = 0; i < items_.size() && i < taken.size(); ++i) if (taken[i] == '1') items_[i].taken = true;
  exitChaseDone_ = s.geti("exit_chase", 0) != 0;
  if (rayState_ == 1 && rayLevel_ == level) rayPos_ = level_.wrap({s.getf("ray_x", rayPos_.x), 0, s.getf("ray_z", rayPos_.z)});
  if (s.geti("version", 1) >= 2 && level != kParkLevel && s.values.count("pos_x")) {
    vec3 p = level_.wrap({s.getf("pos_x", checkpoint_.x), 0, s.getf("pos_z", checkpoint_.z)});
    level_.collide(p, 0.3f);
    resetPlayer(p, s.getf("yaw", checkpointYaw_));
  } else {
    resetPlayer(checkpoint_, checkpointYaw_);
  }
  flashOn_ = false;
  fear_ = 0;
  hintTimer_ = 0.0f;
  toast_ = "WELCOME BACK - " + level_.theme.name + " - " + level_.theme.title;
  toastTime_ = 3.5f;
  screen_ = Screen::Playing;
  screenTime_ = 0;
  setMouseCapture(true);
}

bool Game::hasSave() const {
  platform::KeyValueFile s;
  return s.load(platform::dataDir() + "/save.ini") && s.geti("seed", 0) != 0;
}

void Game::saveProgress() {
  if (!opt_.screenshot.empty() || endless_ || funMode_) return;  // fun mode never touches the story save  // endless runs never touch the story save
  platform::KeyValueFile s;
  s.seti("level", levelIndex_);
  s.seti("seed", (int)level_.seed);
  s.seti("notes", (int)notesMask_);
  s.setf("cp_x", checkpoint_.x);
  s.setf("cp_z", checkpoint_.z);
  s.setf("cp_yaw", checkpointYaw_);
  s.setf("battery", battery_);
  s.setf("time", playTime_);
  s.setf("total_time", totalTime_);
  s.seti("deaths", deaths_);
  s.seti("ray_level", rayLevel_);
  s.seti("ray_state", rayState_);
  s.seti("left_ray", leftRay_ ? 1 : 0);
  s.seti("went_back", wentBack_ ? 1 : 0);
  s.seti("hazmat", hazmat_ ? 1 : 0);
  s.seti("version", 2);
  if (screen_ == Screen::Playing || screen_ == Screen::Paused || screen_ == Screen::Reading) {
    s.setf("pos_x", pos_.x);
    s.setf("pos_z", pos_.z);
    s.setf("yaw", yaw_);
  }
  std::string taken;
  for (const Item& it : items_) taken += it.taken ? '1' : '0';
  s.values["items"] = taken;
  s.setf("ray_x", rayPos_.x);
  s.setf("ray_z", rayPos_.z);
  s.seti("exit_chase", exitChaseDone_ ? 1 : 0);
  s.seti("flash", flashOn_ ? 1 : 0);
  s.save(platform::dataDir() + "/save.ini");
  savedFlash_ = 1.6f;
}

void Game::loadSettings() {
  platform::KeyValueFile s;
  s.load(platform::configDir() + "/settings.ini");
  settings.vhs = s.geti("camcorder_filter", 1) != 0;
  settings.frame43 = s.geti("frame_4_3", 1) != 0;
  settings.dateStamp = s.geti("date_stamp", 1) != 0;
  // v1.1 replaced the old filter with the worn-VHS look: switch it back on once for everyone
  if (s.geti("vhs_look", 0) < 2) settings.vhs = true;
  settings.rt = s.geti("ray_tracing", 1) != 0;
  settings.camShake = std::clamp(s.geti("camera_shake", 2), 0, 3);
  settings.quality = std::clamp(s.geti("quality", 2), 0, 2);
  settings.sensitivity = clampf(s.getf("mouse_sensitivity", 1.0f), 0.25f, 4.0f);
  settings.volume = clampf(s.getf("volume", 0.8f), 0.0f, 1.0f);
  settings.fullscreen = s.geti("fullscreen", 0) != 0 && !opt_.forceWindowed;
  settings.fov = clampf(s.getf("fov", 75.0f), 60.0f, 100.0f);
}

void Game::saveSettings() {
  if (!opt_.screenshot.empty()) return;
  platform::KeyValueFile s;
  s.seti("camcorder_filter", settings.vhs ? 1 : 0);
  s.seti("frame_4_3", settings.frame43 ? 1 : 0);
  s.seti("date_stamp", settings.dateStamp ? 1 : 0);
  s.seti("vhs_look", 2);
  s.seti("ray_tracing", settings.rt ? 1 : 0);
  s.seti("camera_shake", settings.camShake);
  s.seti("quality", settings.quality);
  s.setf("mouse_sensitivity", settings.sensitivity);
  s.setf("volume", settings.volume);
  s.seti("fullscreen", settings.fullscreen ? 1 : 0);
  s.setf("fov", settings.fov);
  s.save(platform::configDir() + "/settings.ini");
}

void Game::applySettings() {
  SDL_SetWindowFullscreen(win_, settings.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
  R_->setQuality(settings.quality);
  gTexRes = settings.quality >= 2 ? 1024 : 512;
  int w, h;
  SDL_GL_GetDrawableSize(win_, &w, &h);
  onResize(w, h);
}

void Game::onResize(int w, int h) {
  if (!R_->shadowTex && R_->quality.shadowSize) { R_->winW = w; R_->winH = h; R_->setQuality(settings.quality); return; }
  R_->resize(w, h);
}

void Game::setMouseCapture(bool on) {
  if (!opt_.screenshot.empty()) return;
  SDL_SetRelativeMouseMode(on ? SDL_TRUE : SDL_FALSE);
  mouseDX_ = mouseDY_ = 0;
}

void Game::shutdown() {
  saveSettings();
  freeLevelGpu();
  cube_.destroy();
  quad_.destroy();
  GLuint t[] = {texPanel_, texPaper_, texGrime_, texWhite_, texLightmap_, texLightState_};
  glDeleteTextures(6, t);
  if (pad_) SDL_GameControllerClose(pad_);
}

// ================================================================ input

vec3 Game::forward() const {
  float cp = std::cos(pitch_);
  return {-std::sin(yaw_) * cp, std::sin(pitch_), -std::cos(yaw_) * cp};
}
vec3 Game::eye() const { return {pos_.x, footY_ + eyeH_ + bob_ + jumpY_ - landDip_, pos_.z}; }

void Game::addRipple(vec3 p, float strength) {
  ripples_[rippleNext_] = {p, time_, strength};
  rippleNext_ = (rippleNext_ + 1) % 8;
}

void Game::splash(vec3 p, int count, float force) {
  for (int i = 0; i < count && drops_.size() < 300; ++i) {
    float a = rng_.range(0, 6.28f), sp = rng_.range(0.4f, 1.0f) * force;
    drops_.push_back({p + vec3{std::cos(a) * 0.15f, 0.02f, std::sin(a) * 0.15f},
                      {std::cos(a) * sp * 0.55f, rng_.range(1.2f, 2.6f) * force, std::sin(a) * sp * 0.55f}, rng_.range(0.6f, 1.1f)});
  }
}
float Game::ui() const { return std::max(1.0f, std::floor(R_->winH / 360.0f)); }

void Game::buildCheatMenu() {
  auto tog = [&](const char* name, bool& v, std::function<void()> after = nullptr) {
    menu_.push_back({std::string(name) + ": " + (v ? "ON" : "OFF"), [this, &v, after](int) { v = !v; if (after) after(); }});
  };
  tog("GOD MODE", cheats_.god);
  tog("NOCLIP (WALK THROUGH WALLS)", cheats_.noclip);
  tog("INFINITE STAMINA", cheats_.stamina);
  tog("NO MONSTERS", cheats_.noMonsters, [this] {
    if (!cheats_.noMonsters) return;
    for (Stalker& s : stalkers_) { s.state = Stalker::Dormant; s.hunt = 0; }
    for (Grin& g : grins_) g.active = false;
  });
  tog("DOUBLE SPEED", cheats_.fast);
  tog("ALL LIGHTS ON", cheats_.bright);
  tog("GUN", cheats_.gun);
  tog("BHOP", cheats_.bhop);
  menu_.push_back({"SKIP TO THE NEXT LEVEL", [this](int d) {
    if (d != 0 || levelIndex_ == kChoiceLevel) return;
    cheatsOpen_ = false;
    screen_ = Screen::Noclip; screenTime_ = 0; noclipFall_ = 0;
    for (Stalker& s : stalkers_) s.hunt = 0;
    if (A_) A_->play(Sfx::Noclip, 1.0f);
  }});
  char buf[48];
  std::snprintf(buf, sizeof buf, "KILLS: %d", kills_);
  menu_.push_back({buf, [](int) {}});
  menu_.push_back({"BACK", [this](int d) { if (d == 0) { cheatsOpen_ = false; menuSel_ = 0; } }});
}

void Game::buildMenu() {
  if (screen_ == Screen::Paused && cheatsOpen_) { menu_.clear(); buildCheatMenu(); return; }
  menu_.clear();
  auto onOff = [](bool b) { return std::string(b ? "ON" : "OFF"); };
  if (optionsOpen_) {
    const char* q[3] = {"LOW", "MEDIUM", "HIGH"};
    char buf[64];
    menu_.push_back({"CAMCORDER FILTER: " + onOff(settings.vhs), [this](int) { settings.vhs = !settings.vhs; saveSettings(); }});
    menu_.push_back({std::string("PICTURE: ") + (settings.frame43 ? "4:3 CAMCORDER" : "WIDESCREEN"), [this](int) { settings.frame43 = !settings.frame43; saveSettings(); }});
    menu_.push_back({"DATE STAMP: " + onOff(settings.dateStamp), [this](int) { settings.dateStamp = !settings.dateStamp; saveSettings(); }});
    menu_.push_back({"RAY TRACING: " + onOff(settings.rt), [this](int) { settings.rt = !settings.rt; saveSettings(); }});
    {
      static const char* kShake[4] = {"OFF", "LOW", "NORMAL", "STRONG"};
      menu_.push_back({std::string("CAMERA SHAKE: ") + kShake[settings.camShake], [this](int d) {
        settings.camShake = (settings.camShake + (d < 0 ? 3 : 1)) % 4; saveSettings(); }});
    }
    menu_.push_back({std::string("GRAPHICS: ") + q[settings.quality], [this](int d) {
      settings.quality = (settings.quality + (d < 0 ? 2 : 1)) % 3; applySettings(); saveSettings(); }});
    std::snprintf(buf, sizeof buf, "MOUSE SENSITIVITY: %.2f", settings.sensitivity);
    menu_.push_back({buf, [this](int d) {
      settings.sensitivity += (d < 0 ? -0.25f : 0.25f);
      if (settings.sensitivity > 4.0f) settings.sensitivity = 0.25f;
      if (settings.sensitivity < 0.25f) settings.sensitivity = 4.0f;
      saveSettings(); }});
    std::snprintf(buf, sizeof buf, "FIELD OF VIEW: %d", (int)settings.fov);
    menu_.push_back({buf, [this](int d) {
      settings.fov += (d < 0 ? -5.0f : 5.0f);
      if (settings.fov > 100.0f) settings.fov = 60.0f;
      if (settings.fov < 60.0f) settings.fov = 100.0f;
      saveSettings(); }});
    std::snprintf(buf, sizeof buf, "VOLUME: %d%%", (int)std::lround(settings.volume * 100));
    menu_.push_back({buf, [this](int d) {
      settings.volume = std::round((settings.volume + (d < 0 ? -0.1f : 0.1f)) * 10.0f) / 10.0f;
      if (settings.volume > 1.0f) settings.volume = 0.0f;
      if (settings.volume < 0.0f) settings.volume = 1.0f;
      saveSettings(); }});
    menu_.push_back({"FULLSCREEN: " + onOff(settings.fullscreen), [this](int) {
      settings.fullscreen = !settings.fullscreen; applySettings(); saveSettings(); }});
    menu_.push_back({"BACK", [this](int d) { if (d == 0) { optionsOpen_ = false; menuSel_ = 0; } }});
    return;
  }
  if (screen_ == Screen::Title) {
    if (archiveOpen_) { buildArchiveMenu(); return; }
    bool unlocked = profile_.endings != 0;
    char buf[64];
    if (runOverShow_) menu_.push_back({"FALL AGAIN", [this](int d) { if (d == 0) startEndless(lastDaily_); }});
    menu_.push_back({endingSeen_ ? "GO AGAIN" : "BEGIN", [this](int d) { if (d == 0) { endless_ = false; runOverShow_ = false; startNewGame(); } }});
    if (hasSave()) menu_.push_back({"CONTINUE", [this](int d) { if (d == 0) { endless_ = false; runOverShow_ = false; continueGame(); } }});
    if (unlocked) {
      std::snprintf(buf, sizeof buf, "KEEP FALLING   BEST %d", profile_.bestDepth);
      menu_.push_back({buf, [this](int d) { if (d == 0) startEndless(false); }});
      std::snprintf(buf, sizeof buf, "TODAY'S FALL   BEST %d", profile_.dailyBest);
      menu_.push_back({buf, [this](int d) { if (d == 0) startEndless(true); }});
    } else {
      menu_.push_back({"KEEP FALLING  - LOCKED: SEE AN ENDING", [](int) {}});
    }
    if (unlocked) menu_.push_back({"FUN MODE", [this](int d) { if (d == 0) startFunMode(); }});
    else menu_.push_back({"FUN MODE  - LOCKED: BEAT THE GAME", [](int) {}});
    menu_.push_back({"ARCHIVE", [this](int d) { if (d == 0) { archiveOpen_ = true; menuSel_ = 0; } }});
    menu_.push_back({"OPTIONS", [this](int d) { if (d == 0) { optionsOpen_ = true; menuSel_ = 0; } }});
    menu_.push_back({"QUIT", [this](int d) { if (d == 0) quit_ = true; }});
  } else if (screen_ == Screen::Paused) {
    menu_.push_back({"RESUME", [this](int d) { if (d == 0) { screen_ = Screen::Playing; setMouseCapture(true); } }});
    if (funMode_) menu_.push_back({"CHEATS  [TAB]", [this](int d) { if (d == 0) { cheatsOpen_ = true; menuSel_ = 0; } }});
    menu_.push_back({"OPTIONS", [this](int d) { if (d == 0) { optionsOpen_ = true; menuSel_ = 0; } }});
    if (!inStore() && !endless_) menu_.push_back({"RESTART FROM CHECKPOINT", [this](int d) { if (d == 0) { respawn(); screen_ = Screen::Playing; setMouseCapture(true); } }});
    if (levelIndex_ >= 0 && !daily_) menu_.push_back({"REGENERATE LEVEL", [this](int d) { if (d == 0) regenerateLevel(); }});
    if (endless_) menu_.push_back({"GIVE UP THIS RUN", [this](int d) { if (d == 0) endlessOver(); }});
    else menu_.push_back({"QUIT TO TITLE", [this](int d) { if (d == 0) { saveProgress(); screen_ = Screen::Title; menuSel_ = 0; } }});
    menu_.push_back({"QUIT GAME", [this](int d) { if (d == 0) { saveProgress(); quit_ = true; } }});
  }
}

float menuTop(float winH) { return winH * 0.47f; }  // shared with game_menu.cpp (mouse hover uses these too)
float menuLine(float s) { return 21.0f * s; }

void Game::event(const SDL_Event& e) {
  bool inMenu = screen_ == Screen::Title || screen_ == Screen::Paused;
  switch (e.type) {
    case SDL_QUIT: if (screen_ == Screen::Playing) saveProgress(); quit_ = true; break;
    case SDL_WINDOWEVENT:
      if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED) {
        int w, h;
        SDL_GL_GetDrawableSize(win_, &w, &h);
        onResize(w, h);
      } else if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST && screen_ == Screen::Playing && opt_.screenshot.empty()) {
        screen_ = Screen::Paused; menuSel_ = 0; setMouseCapture(false);
      }
      break;
    case SDL_CONTROLLERDEVICEADDED:
      if (!pad_) pad_ = SDL_GameControllerOpen(e.cdevice.which);
      break;
    case SDL_CONTROLLERDEVICEREMOVED:
      if (pad_ && e.cdevice.which == SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(pad_))) { SDL_GameControllerClose(pad_); pad_ = nullptr; }
      break;
    case SDL_MOUSEMOTION:
      usingPad_ = false;
      if (screen_ == Screen::Playing) { mouseDX_ += (float)e.motion.xrel; mouseDY_ += (float)e.motion.yrel; }
      else if (inMenu) {
        int w, h, ww, wh;
        SDL_GL_GetDrawableSize(win_, &w, &h);
        SDL_GetWindowSize(win_, &ww, &wh);
        float my = e.motion.y * (float)h / std::max(wh, 1);
        int idx = (int)std::floor((my - menuTop((float)h)) / menuLine(ui()));
        if (idx >= 0 && idx < (int)menu_.size() && idx != menuSel_) { menuSel_ = idx; if (A_) A_->play(Sfx::MenuMove, 0.4f); }
      }
      break;
    case SDL_MOUSEBUTTONDOWN:
      if (screen_ == Screen::Ending) { if (e.button.button == SDL_BUTTON_LEFT) endingInput(0, true); break; }
      if (screen_ == Screen::Plunge) { dropSkip(); break; }
      if (screen_ == Screen::Playing) {
        if (e.button.button == SDL_BUTTON_LEFT) { if (funLevel() && cheats_.gun) fireGun(); else tryInteract(); }

      } else if (inMenu && archiveInput(true)) {
      } else if (inMenu && e.button.button == SDL_BUTTON_LEFT && menuSel_ < (int)menu_.size()) {
        if (A_) A_->play(Sfx::MenuSelect, 0.5f);
        menu_[menuSel_].act(0);
      } else if (screen_ == Screen::Reading) { screen_ = Screen::Playing; readingTape_ = -1; setMouseCapture(true); }
      break;
    case SDL_KEYDOWN:
    case SDL_CONTROLLERBUTTONDOWN: {
      bool isPad = e.type == SDL_CONTROLLERBUTTONDOWN;
      usingPad_ = isPad;
      SDL_Scancode k = isPad ? SDL_SCANCODE_UNKNOWN : e.key.keysym.scancode;
      int b = isPad ? e.cbutton.button : -1;
      if (!isPad) keys_[k] = true;
      if (!isPad && e.key.repeat && !inMenu) break;
      bool up = k == SDL_SCANCODE_UP || k == SDL_SCANCODE_W || b == SDL_CONTROLLER_BUTTON_DPAD_UP;
      bool down = k == SDL_SCANCODE_DOWN || k == SDL_SCANCODE_S || b == SDL_CONTROLLER_BUTTON_DPAD_DOWN;
      bool left = k == SDL_SCANCODE_LEFT || k == SDL_SCANCODE_A || b == SDL_CONTROLLER_BUTTON_DPAD_LEFT;
      bool right = k == SDL_SCANCODE_RIGHT || k == SDL_SCANCODE_D || b == SDL_CONTROLLER_BUTTON_DPAD_RIGHT;
      bool accept = k == SDL_SCANCODE_RETURN || k == SDL_SCANCODE_SPACE || k == SDL_SCANCODE_KP_ENTER || b == SDL_CONTROLLER_BUTTON_A;
      bool back = k == SDL_SCANCODE_ESCAPE || b == SDL_CONTROLLER_BUTTON_B || b == SDL_CONTROLLER_BUTTON_START;
      bool use = k == SDL_SCANCODE_E || b == SDL_CONTROLLER_BUTTON_A;
      if (screen_ == Screen::Ending) { endingInput(up ? -1 : (down ? 1 : 0), accept || use); break; }
      if (screen_ == Screen::Plunge) { if (accept || use) dropSkip(); break; }
      if (screen_ == Screen::Playing && !inStore() && (k == SDL_SCANCODE_G || b == SDL_CONTROLLER_BUTTON_Y)) { rayPutDown(); break; }
      if (screen_ == Screen::Playing) {
        if (k == SDL_SCANCODE_ESCAPE || k == SDL_SCANCODE_P || b == SDL_CONTROLLER_BUTTON_START) {
          screen_ = Screen::Paused; menuSel_ = 0; optionsOpen_ = false; cheatsOpen_ = false; setMouseCapture(false);
        } else if (funMode_ && (k == SDL_SCANCODE_TAB || b == SDL_CONTROLLER_BUTTON_BACK)) {
          screen_ = Screen::Paused; menuSel_ = 0; optionsOpen_ = false; cheatsOpen_ = true; setMouseCapture(false);
        } else if (funLevel() && cheats_.gun && b == SDL_CONTROLLER_BUTTON_RIGHTSHOULDER) fireGun();
        else if (use) tryInteract();
        else if (k == SDL_SCANCODE_SPACE || b == SDL_CONTROLLER_BUTTON_X) jumpQueued_ = true;
        // (no light to switch on: F does nothing. V used to toggle the camcorder filter; it's in Options.)
      } else if (inMenu) {
        if (archiveInput(accept || back || use)) break;
        int n = (int)menu_.size();
        if (n == 0) break;
        if (up) { menuSel_ = (menuSel_ + n - 1) % n; if (A_) A_->play(Sfx::MenuMove, 0.4f); }
        else if (down) { menuSel_ = (menuSel_ + 1) % n; if (A_) A_->play(Sfx::MenuMove, 0.4f); }
        else if (left) { menu_[menuSel_].act(-1); if (A_) A_->play(Sfx::MenuMove, 0.4f); }
        else if (right) { menu_[menuSel_].act(1); if (A_) A_->play(Sfx::MenuMove, 0.4f); }
        else if (accept) { if (A_) A_->play(Sfx::MenuSelect, 0.5f); menu_[menuSel_].act(0); }
        else if (back) {
          if (cheatsOpen_) { cheatsOpen_ = false; menuSel_ = 0; }
          else if (optionsOpen_) { optionsOpen_ = false; menuSel_ = 0; }
          else if (archiveOpen_) { archiveOpen_ = false; menuSel_ = 0; }
          else if (screen_ == Screen::Paused) { screen_ = Screen::Playing; setMouseCapture(true); }
        }
      } else if (screen_ == Screen::Reading) {
        if (use || accept || back) { screen_ = Screen::Playing; setMouseCapture(true); if (A_) A_->play(readingTape_ >= 0 ? Sfx::Click : Sfx::Paper, 0.4f); readingTape_ = -1; }
      }
    } break;
    case SDL_KEYUP:
      keys_[e.key.keysym.scancode] = false;
      break;
    default: break;
  }
}

void Game::tryInteract() {
  if (hiding_ >= 0) { leaveLocker(); return; }
  if (levelIndex_ == kChoiceLevel) { int t = focusTube(); if (t >= 0) { enterSlide(t); return; } }
  if (suitInteract()) return;
  if (shockInteract()) return;
  if (rayInteract()) return;
  if (focusItem_ < 0) {
    int l = focusLocker();
    if (l >= 0) enterLocker(l);
    return;
  }
  Item& it = items_[focusItem_];
  it.taken = true;
  switch (it.type) {
    case ITEM_NOTE:
      notesMask_ |= 1u << it.note;
      readingNote_ = it.note;
      screen_ = Screen::Reading;
      setMouseCapture(false);
      checkpoint_ = pos_;
      checkpointYaw_ = yaw_;
      if (A_) A_->play(Sfx::Paper, 0.7f);
      saveProgress();
      toast_ = "CHECKPOINT";
      toastTime_ = 2.5f;
      if (notesFound() >= (int)level_.theme.notes.size()) unlockBadge(2);
      break;
    case ITEM_BATTERY:
      battery_ = std::min(1.0f, battery_ + 0.5f);
      if (A_) A_->play(Sfx::Battery, 0.7f);
      toast_ = "BATTERY +50%";
      toastTime_ = 2.0f;
      break;
    case ITEM_WATER:
      stamina_ = 1.0f;
      exhausted_ = false;
      waterBoost_ = 25.0f;
      if (A_) A_->play(Sfx::Drink, 0.7f);
      toast_ = "ALMOND WATER - YOU FEEL STEADIER";
      toastTime_ = 2.5f;
      break;
    case ITEM_TAPE:
      metaTapeFound(it.note);
      break;
  }
  focusItem_ = -1;
}

// ================================================================ simulation

void Game::update(float dt) {
  time_ += dt;
  screenTime_ += dt;
  buildMenu();
  if (menuSel_ >= (int)menu_.size()) menuSel_ = 0;
  if (toastTime_ > 0) toastTime_ -= dt;
  bool popupOk = screen_ != Screen::Plunge && screen_ != Screen::Noclip && screen_ != Screen::Transition && screen_ != Screen::Caught;
  if (!badgeQueue_.empty() && popupOk) {
    if (badgeT_ == 0 && A_) { A_->play(Sfx::Chime, 0.6f); A_->play(Sfx::Coins, 0.35f, 0, 0.12f); }
    badgeT_ += dt;
    if (badgeT_ > 4.2f) { badgeQueue_.erase(badgeQueue_.begin()); badgeT_ = 0; }
  }
  if (archiveView_) archiveT_ += dt;

  switch (screen_) {
    case Screen::Playing: updatePlaying(dt); break;
    case Screen::Ending: updateEnding(dt); break;
    case Screen::Caught:
      fear_ = 1.0f;
      if (screenTime_ > 1.9f) { if (endless_) endlessOver(); else respawn(); }
      break;
    case Screen::Noclip:
      noclipFall_ += dt * dt * 60.0f + dt * 0.5f;
      if (screenTime_ > 2.8f) {
        // Fall through the floor of the world into the next one.
        prevTitle_ = level_.theme.title;
        prevNotes_ = notesFound();
        prevNoteTotal_ = (int)level_.theme.notes.size();
        prevTime_ = playTime_;
        prevDeaths_ = deaths_;
        uint32_t nextSeed = (level_.seed * 1103515245u + 12345u) | 1u;
        bool fromStore = inStore() || inPark();
        bool fromPark = inPark();
        metaEscaped(fromStore);
        if (endless_) { endlessNext(nextSeed); return; }
        bool leaving = false;
        if (rayLevel_ == levelIndex_ && rayState_ <= 1) { leaving = rayState_ == 1; leftRay_ = leftRay_ || leaving; rayState_ = 3; }
        if (wentBack_) {  // you went back down for him: this exit is the way home
          beginEnding();
          return;
        }
        if (levelIndex_ == kLastLevel || levelIndex_ == kAboveLevel) {  // out (or up the stairs and out the top): the end
          std::fprintf(stderr, "[br9] escaped the last level (ray state %d)\n", rayState_);
          if (rayState_ == 2) { beginEnding(); return; }
          loadLevel(kChoiceLevel, nextSeed);  // three slides; pick one
          hintTimer_ = 0;
          screen_ = Screen::Transition;
          transitionTime_ = 1.5f;
          prevTitle_ = level_.theme.title;
          if (A_) A_->play(Sfx::Whoosh, 0.9f);
          return;
        }
        if (fromStore) prevTitle_ = "ROUTE 9 PARK";
        pending_.level = fromStore ? 0 : nextStoryLevel(levelIndex_);
        pending_.seed = nextSeed; pending_.fromStore = fromStore; pending_.fromPark = fromPark; pending_.leaving = leaving;
        std::fprintf(stderr, "[br9] escaped %s in %.1f s (deaths so far %d)\n", prevTitle_.c_str(), prevTime_, deaths_);
        // meanwhile, up top: a short scene from the search before the next level. Which one goes by the
        // level you just left (the story order), so CONTINUE picks up the evening where it was.
        static const int kOrder[] = {0, 1, 9, 2, 3, 8, 4, 5, 10, 6};
        int step = -1;
        for (int k = 0; k < 10; ++k) if (kOrder[k] == levelIndex_) step = k;
        if (!fromStore && step >= 0 && beginInterlude(step)) return;
        finishLevelChange();
      }
      break;
    case Screen::Plunge: updatePlunge(dt); break;
    case Screen::Slide: updateSlide(dt); break;
    case Screen::Transition:
      transitionTime_ += dt;
      if (transitionTime_ > 5.0f) {
        screen_ = Screen::Playing;
        screenTime_ = 0;
        hintTimer_ = 9.0f;
        setMouseCapture(true);
      }
      break;
    default: break;
  }
  if (brownout_ > 0) brownout_ = std::max(0.0f, brownout_ - dt * 1.4f);
  if (alarm_ > 0) alarm_ = std::max(0.0f, alarm_ - dt);
  // Red pulsing lights while something is hunting you.
  float red = anyChasing() ? (0.5f + 0.5f * std::sin(time_ * 6.0f)) * 0.75f : 0.0f;
  red = std::max(red, alarm_ > 0 ? 0.8f * (0.5f + 0.5f * std::sin(time_ * 14.0f)) : 0.0f);
  lightTint_ = lerp(vec3{1, 1, 1}, vec3{1.0f, 0.22f, 0.16f}, red);
  if (partySong_ > 0) {  // a birthday: the lights go party coloured instead of red
    float pt = time_ * 2.2f;
    lightTint_ = vec3{0.8f + 0.45f * std::sin(pt), 0.6f + 0.45f * std::sin(pt + 2.1f), 0.7f + 0.5f * std::sin(pt + 4.2f)};
  }
  chaseIntensity_ = lerpf(chaseIntensity_, anyChasing() ? 1.0f : 0.0f, 1.0f - std::exp(-dt * 1.5f));
  updateLights(dt);
  updateAudio();
}

void Game::finishLevelChange() {
  interlude_ = false;
  loadLevel(pending_.level, pending_.seed);
  if (pending_.fromStore) { toast_ = pending_.fromPark ? "MOM? DAD?" : "RAY?"; toastTime_ = 5.0f; hintTimer_ = 12.0f; }
  if (pending_.leaving) { toast_ = "YOU CAN STILL HEAR HIM BEGGING"; toastTime_ = 5.0f; }
  battery_ = std::max(battery_, 0.6f);
  flashOn_ = defaultLight();
  fear_ = 0;
  exposure_ = 1.0f;
  startPlunge();  // a hundred feet of nothing, then the ceiling, then the floor
  saveProgress();
}

bool Game::anyChasing() const {
  for (const Stalker& s : stalkers_) if (s.active() && (s.hunt > 0 || s.state == Stalker::Chase)) return true;
  return false;
}

bool Game::beginHunt(float seconds) {
  int px, pz;
  level_.tileOf(pos_.x, pos_.z, px, pz);
  std::vector<int> d = level_.bfs(px, pz);
  std::vector<Stalker*> c;
  for (Stalker& s : stalkers_) {
    if (!s.active() || s.hunt > 0) continue;
    int sx, sz;
    level_.tileOf(s.pos.x, s.pos.z, sx, sz);
    if (d[level_.idx(sx, sz)] >= 6) c.push_back(&s);
  }
  if (c.empty()) return false;
  Stalker* s = c[rng_.next() % c.size()];
  s->startHunt(seconds, s->kind == CR_HOUND ? 4.3f : 3.9f);
  adrenaline_ = 10.0f; stamina_ = std::max(stamina_, 0.85f); exhausted_ = false;  // your second wind
  std::fprintf(stderr, "[br9] hunt begins (%.1f s into the level)\n", playTime_);
  alarm_ = 2.5f;
  if (A_) { A_->play(Sfx::Alarm, 0.55f); A_->play(Sfx::ChaseSting, 0.8f); }
  toast_ = "IT KNOWS WHERE YOU ARE. RUN.";
  toastTime_ = 3.5f;
  return true;
}

void Game::beginExitChase() {
  exitChaseDone_ = true;
  std::fprintf(stderr, "[br9] exit chase begins (%.1f s into the level)\n", playTime_);
  if (stalkers_.empty()) return;
  Stalker* s = nullptr;
  for (Stalker& st : stalkers_) if (st.active() && st.hunt <= 0) { s = &st; break; }
  if (!s) s = &stalkers_[0];
  // Put it behind you: further from the exit than you are, out of sight, 7-12 tiles away.
  int px, pz;
  level_.tileOf(pos_.x, pos_.z, px, pz);
  std::vector<int> d = level_.bfs(px, pz);
  int myExit = level_.exitDist[level_.idx(px, pz)];
  std::vector<int> cands;
  for (int i = 0; i < level_.W * level_.H; ++i) {
    if (d[i] < 7 || d[i] > 12 || level_.exitDist[i] <= myExit || level_.pillar[i]) continue;
    vec3 c = level_.tileCenter(i % level_.W, i / level_.W);
    if (level_.lineOfSight(c.x, c.z, pos_.x, pos_.z)) continue;
    cands.push_back(i);
  }
  if (cands.empty()) for (int i = 0; i < level_.W * level_.H; ++i) if (d[i] >= 6 && d[i] <= 14 && !level_.pillar[i]) cands.push_back(i);
  if (cands.empty()) return;
  int pick = cands[rng_.next() % cands.size()];
  if (!s->active()) s->placeFar(level_, pos_, rng_, 6, 14);
  s->pos = level_.tileCenter(pick % level_.W, pick / level_.W);
  // it's fast, but not as fast as a kid running flat out: sprint and you make it, stop and it has you
  float spd = s->kind == CR_HOUND ? 4.25f : (s->variant == 1 ? 4.1f : 4.05f);
  s->startHunt(60.0f, spd);
  adrenaline_ = 14.0f; stamina_ = 1.0f; exhausted_ = false;  // a second wind: you can run the rest of the way
  alarm_ = 3.0f;
  if (A_) { A_->play(Sfx::Alarm, 0.7f); A_->play(Sfx::ChaseSting, 1.0f); }
  toast_ = "SOMETHING IS COMING. RUN FOR THE EXIT.";
  toastTime_ = 4.0f;
}

void Game::updateEvents(float dt) {
  const Theme& t = level_.theme;
  // Spawns.
  for (size_t i = 0; i < stalkers_.size(); ++i) {
    Stalker& s = stalkers_[i];
    if (s.active()) continue;
    if (playTime_ > spawnAt_[i] || (notesFound() > (int)i && playTime_ > 20.0f)) {
      s.placeFar(level_, pos_, rng_);
      if (A_) A_->play(s.kind == CR_HOUND ? Sfx::Snarl : Sfx::Slam, 0.4f, rng_.range(-0.8f, 0.8f));
    }
  }
  // Hunts.
  if (t.huntEvery > 0) {
    huntTimer_ -= dt;
    if (huntTimer_ <= 0) huntTimer_ = beginHunt(18.0f) ? t.huntEvery * rng_.range(0.8f, 1.2f) : 10.0f;
  }
  // The run to the exit.
  if (!exitChaseDone_ && !inPark() && playTime_ > 15.0f && level_.distToExit(pos_.x, pos_.z) <= 11) beginExitChase();
}

void Game::cineUpdate(float dt) {
  static const float total = std::getenv("BR9_CINE") ? (float)std::atof(std::getenv("BR9_CINE")) : 4.0f;
  static const float speed = std::getenv("BR9_CINE_SPEED") ? (float)std::atof(std::getenv("BR9_CINE_SPEED")) : 1.3f;
  if (!cineInit_) { cineInit_ = true; cineStart_ = pos_; cineT_ = 0; }
  cineT_ += dt;
  float t = cineT_;
  vec3 f{-std::sin(checkpointYaw_), 0, -std::cos(checkpointYaw_)};
  vec3 p = cineStart_ + f * (speed * t);
  level_.collide(p, 0.3f);
  pos_ = level_.wrap(p);
  float eyeY = 1.55f;
  static const bool glideOnly = std::getenv("BR9_CINE_GLIDE") != nullptr;
  float in = glideOnly ? 1.0f : clampf(t / 1.5f, 0, 1), out = glideOnly ? 0.0f : clampf((t - (total - 1.3f)) / 1.3f, 0, 1);
  float yIn = level_.wallH + 1.4f + (eyeY - level_.wallH - 1.4f) * (1.0f - std::pow(1.0f - in, 3.0f));  // ease out of the ceiling
  float yOut = eyeY - 3.6f * out * out;                                                                  // fall through the floor
  cineY_ = (t < 1.5f && !glideOnly) ? yIn : yOut;
  yaw_ = checkpointYaw_ + 0.05f * std::sin(t * 0.6f);
  pitch_ = -0.06f - 0.25f * (1.0f - in) + 0.02f * std::sin(t * 0.9f) - 0.35f * out * out;
  playerLight_ = level_.lightAt(pos_.x, pos_.z, lightState_);
  exposure_ = lerpf(exposure_, clampf(0.95f / (0.30f + playerLight_ + (flashOn_ ? 0.1f : 0.0f)), 0.5f, 2.8f), 1.0f - std::exp(-dt * 2.0f));
  flashDir_ = forward();
}

void Game::updatePlaying(float dt) {
  if (savedFlash_ > 0) savedFlash_ -= dt;
  autosave_ -= dt;
  if (autosave_ <= 0 && !inStore() && !inPark() && !portrait_) { autosave_ = 30.0f; saveProgress(); }
  static const bool cine = std::getenv("BR9_CINE") != nullptr;
  if (cine && !inStore()) { playTime_ += dt; cineUpdate(dt); return; }
  playTime_ += dt;
  totalTime_ += dt;
  if (hintTimer_ > 0) hintTimer_ -= dt;
  if (inPark()) parkUpdate(dt);

  // --- look
  float sens = 0.0022f * settings.sensitivity;
  yaw_ -= mouseDX_ * sens;
  pitch_ -= mouseDY_ * sens;
  mouseDX_ = mouseDY_ = 0;
  float padMX = 0, padMZ = 0;
  bool padSprint = false, padCrouch = false;
  if (pad_) {
    auto ax = [&](SDL_GameControllerAxis a) {
      float v = SDL_GameControllerGetAxis(pad_, a) / 32767.0f;
      return std::fabs(v) < 0.15f ? 0.0f : v;
    };
    yaw_ -= ax(SDL_CONTROLLER_AXIS_RIGHTX) * 2.8f * dt * settings.sensitivity;
    pitch_ -= ax(SDL_CONTROLLER_AXIS_RIGHTY) * 2.0f * dt * settings.sensitivity;
    padMX = ax(SDL_CONTROLLER_AXIS_LEFTX);
    padMZ = -ax(SDL_CONTROLLER_AXIS_LEFTY);
    padSprint = SDL_GameControllerGetButton(pad_, SDL_CONTROLLER_BUTTON_LEFTSTICK) || ax(SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 0.5f;
    padCrouch = SDL_GameControllerGetButton(pad_, SDL_CONTROLLER_BUTTON_B);
  }
  if (const char* pan = std::getenv("BR9_PAN")) yaw_ += (float)std::atof(pan) * dt;  // capture: slow camera pan
  if (const char* pt = std::getenv("BR9_PITCH")) pitch_ = (float)std::atof(pt);   // capture: fixed pitch
  yaw_ = wrapPi(yaw_);
  pitch_ = clampf(pitch_, -1.45f, 1.45f);
  if (hiding_ >= 0) {
    hideT_ += dt;
    yaw_ = hideYaw_ + clampf(wrapPi(yaw_ - hideYaw_), -0.55f, 0.55f);
    pitch_ = clampf(pitch_, -0.3f, 0.3f);
  }

  // --- move
  vec3 f{-std::sin(yaw_), 0, -std::cos(yaw_)}, r{std::cos(yaw_), 0, -std::sin(yaw_)};
  float mx = (keys_[SDL_SCANCODE_D] ? 1.0f : 0.0f) - (keys_[SDL_SCANCODE_A] ? 1.0f : 0.0f) + padMX;
  float mz = (keys_[SDL_SCANCODE_W] ? 1.0f : 0.0f) - (keys_[SDL_SCANCODE_S] ? 1.0f : 0.0f) + padMZ;
  crouch_ = keys_[SDL_SCANCODE_LCTRL] || keys_[SDL_SCANCODE_C] || padCrouch;
  bool wantSprint = (keys_[SDL_SCANCODE_LSHIFT] || keys_[SDL_SCANCODE_RSHIFT] || padSprint) && mz > 0.3f && !crouch_ && !exhausted_;
  vec3 wish = f * mz + r * mx;
  if (hiding_ >= 0) { wish = {0, 0, 0}; wantSprint = false; crouch_ = false; }
  if (const char* aw = std::getenv("BR9_AUTOWALK")) wish = f * (float)std::atof(aw);  // capture: walk straight ahead
  if (opt_.scene == "autorun" || opt_.scene == "raycarryrun" || opt_.scene == "autowalk") {
    // Test autopilot: follow the exit gradient at a run, like a player following the arrows.
    int tx, tz;
    level_.tileOf(pos_.x, pos_.z, tx, tz);
    static float trace = 0.0f;  // where it is every few seconds, so a stuck run shows where it stuck
    if ((trace += dt) > 5.0f) {
      trace = 0.0f;
      std::fprintf(stderr, "[br9] autorun t=%.0f s at (%.1f, %.1f) tile (%d, %d), %d tiles from the exit%s\n", playTime_, pos_.x, pos_.z, tx, tz,
                   level_.exitDist[level_.idx(tx, tz)], level_.isNarrow(tx, tz) ? " (corridor)" : "");
    }
    vec3 target = level_.exitFaceCenter();
    int cur = level_.exitDist[level_.idx(tx, tz)];
    for (int d = 0; d < 4 && cur > 0; ++d)
      if (!level_.blocked(tx, tz, d) && level_.exitDist[level_.idx(tx + kDX[d], tz + kDZ[d])] == cur - 1) {
        target = level_.tileCenter(tx + kDX[d], tz + kDZ[d]);
        break;
      }
    vec3 to = level_.delta(pos_, target);
    to.y = 0;
    if (length(to) > 0.05f) wish = normalize(to);
    float want = std::atan2(-wish.x, -wish.z);
    yaw_ += wrapPi(want - yaw_) * (1.0f - std::exp(-dt * 6.0f));  // turn like a person, not a snap
    wantSprint = opt_.scene != "autowalk" && !exhausted_ && stamina_ > 0.25f;
    if (std::getenv("BR9_SCARED")) fear_ = std::max(fear_, 0.8f);
    for (const Level::LowGap& g : level_.lowGaps) {  // get down for the crawl holes
      vec3 d = level_.delta(g.c, pos_);
      if (d.x * d.x + d.z * d.z < 1.6f * 1.6f) { crouch_ = true; wantSprint = false; }
    }
  }
  float wl = length(wish);
  if (wl > 1.0f) wish = wish * (1.0f / wl);
  sprinting_ = wantSprint && wl > 0.1f;
  float targetFloor = level_.floorAt(pos_.x, pos_.z);
  inWater_ = targetFloor < -0.1f;
  float speed = (crouch_ ? 1.2f : (sprinting_ ? 4.8f : 2.3f)) * (inWater_ ? 0.7f : 1.0f) * (rayState_ == 2 ? 0.74f : 1.0f) *
                (level_.theme.special == Special::Playplace ? 0.78f : 1.0f);  // wading through the balls
  float accel = !grounded_ ? 1.6f : (inWater_ ? 2.6f : (wl > 0.1f ? 6.5f : 8.5f));  // a body has weight; water has momentum
  bool fun = funLevel();
  if (fun && cheats_.fast) speed *= 2.0f;
  if (fun && cheats_.stamina) { stamina_ = 1.0f; exhausted_ = false; }
  bool bhop = fun && cheats_.bhop && hiding_ < 0;
  if (bhop && grounded_ && !crouch_ && (keys_[SDL_SCANCODE_SPACE] || (pad_ && SDL_GameControllerGetButton(pad_, SDL_CONTROLLER_BUTTON_X)))) jumpQueued_ = true;  // hold to hop
  if (bhop && !grounded_) {
    // air strafing, the Quake/Source way: you can only add speed along where you're steering, up to a
    // small cap, so turning the mouse with the strafe key bends your path and builds speed
    if (wl > 0.1f) {
      vec3 wd = wish * (1.0f / std::max(wl, 1e-4f));
      float cur = dot(vel_, wd), add = 0.9f - cur;
      if (add > 0.0f) vel_ = vel_ + wd * std::min(add, 12.0f * speed * dt);
    }
    float hs = length(vel_);
    if (hs > 22.0f) vel_ = vel_ * (22.0f / hs);
  } else if (!(bhop && grounded_ && jumpQueued_)) {  // a hop the frame you land skips the ground friction
    vel_ = lerp(vel_, wish * speed, 1.0f - std::exp(-dt * accel));
  }
  bool jumpNow = jumpQueued_;
  jumpQueued_ = false;
  if (inPark()) {  // on a bed you can't help bouncing; jump at the bottom for a big one
    int tx, tz;
    level_.tileOf(pos_.x, pos_.z, tx, tz);
    static const bool noBounce = std::getenv("BR9_NOBOUNCE") != nullptr;  // screenshots
    if (jumpNow) jumpBuf_ = 0.35f;  // press jump anywhere near the bottom of a bounce
    static const bool autoBounce = std::getenv("BR9_BOUNCE") != nullptr;  // capture: keep bouncing big
    if (autoBounce) jumpBuf_ = 0.35f;
    jumpBuf_ = std::max(0.0f, jumpBuf_ - dt);
    onBed_ = level_.isBed(tx, tz) && hiding_ < 0 && !crouch_ && !noBounce;
    if (onBed_) {
      grounded_ = false;  // a trampoline bed is never solid ground: you're always riding the spring
      jumpNow = false;
    }
    if (level_.isFoam(tx, tz)) vel_ = vel_ * (1.0f - std::min(1.0f, dt * 3.0f));  // wading through foam blocks
  }
  if (jumpNow && grounded_ && hiding_ < 0 && !crouch_) {
    vy_ = rayState_ == 2 ? 2.9f : (inWater_ ? 3.3f : 4.3f);
    grounded_ = false;
    if (!(fun && cheats_.stamina)) stamina_ = std::max(0.0f, stamina_ - 0.08f);
    if (inWater_) { splash(vec3{pos_.x, footY_, pos_.z}, 14, 0.8f); addRipple(pos_, 0.8f); if (A_) A_->play(Sfx::Splash, 0.6f); }
    else if (A_) A_->play(Sfx::Footstep, 0.35f, 0, 1.3f);
  }
  if (!grounded_ && onBed_ && inPark()) {
    // The bed is a stiff spring: you land, sink 20-30 cm while it stretches under you, and it throws
    // you back up. Your legs put the energy back in: an ordinary bounce, or a big one if you push.
    if (jumpBuf_ > 0.0f && jumpY_ <= 0.0f && jumpY_ > -0.12f && vy_ > -0.6f && vy_ < 0.6f) vy_ = -2.4f;  // standing still: push the bed down to get going
    float sub = dt / 4.0f;
    for (int k = 0; k < 4; ++k) {
      float a = -13.0f;
      if (jumpY_ < 0.0f) a += -170.0f * jumpY_ - 2.5f * vy_;
      float vPrev = vy_;
      vy_ += a * sub;
      jumpY_ += vy_ * sub;
      if (jumpY_ < 0.0f && vPrev < 0.0f && vy_ >= 0.0f) {  // the bottom of the dip
        bedImpact_ = -jumpY_;
        if (A_) A_->play(Sfx::Footstep, 0.25f + bedImpact_ * 1.2f, 0, 0.5f + rng_.f01() * 0.08f);  // the bed's deep 'whump'
      }
      if (jumpY_ >= 0.0f && vy_ > 0.0f && jumpY_ - vy_ * sub < 0.0f) {  // leaving the bed
        bool big = jumpBuf_ > 0.0f;
        vy_ = big ? 6.6f : 4.1f;
        if (big) { jumpBuf_ = 0.0f; stamina_ = std::max(0.0f, stamina_ - 0.04f); }
        if (++parkBounces_ == 30) unlockBadge(15);
      }
    }
    jumpY_ = std::max(jumpY_, -0.34f);
  } else if (!grounded_) {
    vy_ -= 13.0f * dt;
    jumpY_ += vy_ * dt;
    if (jumpY_ <= 0) {
      float impact = -vy_;
      jumpY_ = 0; vy_ = 0; grounded_ = true;
      landDip_ = std::min(0.14f, impact * 0.028f);
      if (impact > 5.5f) jolt_ = std::max(jolt_, std::min(1.0f, (impact - 5.5f) * 0.12f + 0.2f));
      noiseRadius_ = std::max(noiseRadius_, inWater_ ? 14.0f : 9.0f);
      noiseHold_ = 0.6f;
      if (inWater_) {
        splash(vec3{pos_.x, footY_, pos_.z}, 40, 1.15f);
        addRipple(pos_, 1.4f);
        wetLens_ = 1.0f;
        if (A_) A_->play(Sfx::Splash, 1.2f, 0, 0.8f);
      } else if (A_) A_->play(Sfx::HeavyStep, 0.55f, 0, 1.2f);
    }
  }
  landDip_ = std::max(0.0f, landDip_ - dt * 0.6f);
  wetLens_ = std::max(0.0f, wetLens_ - dt * 0.12f);
  for (auto& d : drops_) { d.v.y -= 9.8f * dt; d.p += d.v * dt; d.life -= dt; }
  drops_.erase(std::remove_if(drops_.begin(), drops_.end(), [&](const Drop& d) { return d.life <= 0 || d.p.y < footY_ - 0.05f; }), drops_.end());
  pos_ += vel_ * dt;
  if (!(fun && cheats_.noclip)) level_.collide(pos_, kPlayerRadius);
  {  // crawl gaps: standing, the wall over the hole stops you; down low you get through, and you stay down till you're out
    bool was = underGap_;
    underGap_ = false;
    for (const Level::LowGap& g : level_.lowGaps) {
      vec3 d = level_.delta(g.c, pos_);
      float an = d.x * g.n.x + d.z * g.n.z, at = d.x * g.t.x + d.z * g.t.z;
      float reach = Level::kWallT * 0.5f + kPlayerRadius;
      if (std::fabs(at) > Level::kGapW || std::fabs(an) > reach) continue;
      if (crouch_ || was) { underGap_ = true; crouch_ = true; continue; }
      float side = an >= 0.0f ? 1.0f : -1.0f;
      pos_ = pos_ + g.n * (side * reach - an);  // bump: the wall's at head height
      if (gapHintT_ <= 0.0f) { toast_ = usingPad_ ? "GET DOWN AND CRAWL THROUGH  [B]" : "GET DOWN AND CRAWL THROUGH  [CTRL]"; toastTime_ = 3.0f; gapHintT_ = 8.0f; }
    }
    gapHintT_ = std::max(0.0f, gapHintT_ - dt);
  }
  updateKickables(dt);
  if (level_.court.on && !inStore()) {
    // the balcony railing: you stop against it, not half through it
    const auto& c = level_.court;
    float x0 = c.x0 * Level::kTile, z0 = c.z0 * Level::kTile, x1 = (c.x0 + c.n) * Level::kTile, z1 = (c.z0 + c.n) * Level::kTile;
    vec3 ctr{(x0 + x1) * 0.5f, 0, (z0 + z1) * 0.5f};
    vec3 d = level_.delta(ctr, pos_);
    const float half = (x1 - x0) * 0.5f + kPlayerRadius + 0.22f;
    if (std::fabs(d.x) < half && std::fabs(d.z) < half) {
      float ox = half - std::fabs(d.x), oz = half - std::fabs(d.z);
      if (ox < oz) pos_.x += (d.x < 0 ? -ox : ox); else pos_.z += (d.z < 0 ? -oz : oz);
    }
  }
  if (!inStore()) pos_ = level_.wrap(pos_);
  if (hiding_ >= 0) { pos_ = hidePos_; vel_ = {0, 0, 0}; }
  footY_ = lerpf(footY_, level_.floorAt(pos_.x, pos_.z), 1.0f - std::exp(-dt * 8.0f));
  if (level_.stairClimb && levelIndex_ == 0 && !endless_ && screen_ == Screen::Playing && footY_ > 1.55f) {
    // the top of the stairs to nowhere: up through the black square in the ceiling, into the floor above
    std::fprintf(stderr, "[br9] climbed the stairs out of Level 0\n");
    prevTitle_ = level_.theme.title;
    loadLevel(kAboveLevel, (level_.seed * 2654435761u + 77u) | 1u);
    hintTimer_ = 0;
    screen_ = Screen::Transition;
    transitionTime_ = 1.5f;
    if (A_) A_->play(Sfx::Whoosh, 0.7f);
    return;
  }
  // the pit floor: step off the walkway and you go down the hole
  if (pitFall_ < 0 && !inStore() && hiding_ < 0 && level_.overPit(pos_.x, pos_.z, 0.08f)) {
    pitFall_ = 0; pitDrop_ = 0; pitVy_ = 0; pitAt_ = pos_;
    fear_ = 1.0f;
    if (A_) { A_->play(Sfx::Whoosh, 1.0f, 0, 0.7f); A_->play(Sfx::Grunt, 0.9f, 0, 1.2f); }
  }
  if (pitFall_ >= 0) {
    pitFall_ += dt;
    pitVy_ += 9.8f * dt;
    pitDrop_ += pitVy_ * dt;
    int tx, tz;
    level_.tileOf(pitAt_.x, pitAt_.z, tx, tz);
    float x0 = tx * Level::kTile + Level::kPitLo + 0.2f, x1 = tx * Level::kTile + Level::kPitHi - 0.2f;
    float z0 = tz * Level::kTile + Level::kPitLo + 0.2f, z1 = tz * Level::kTile + Level::kPitHi - 0.2f;
    vec3 p = pitAt_ + level_.delta(pitAt_, pos_);
    pos_ = level_.wrap({clampf(p.x, x0, x1), 0, clampf(p.z, z0, z1)});
    vel_ = vel_ * 0.5f;
    footY_ = -pitDrop_;
    if (pitFall_ > 1.5f) {  // ...and you come round back where you last were safe, camcorder on the floor
      pitFall_ = -1;
      resetPlayer(checkpoint_, checkpointYaw_);
      startPlunge();
      plungeT_ = 3.39f;
      toast_ = "YOU FELL";
      toastTime_ = 3;
      return;
    }
  }

  // --- stamina
  adrenaline_ = std::max(0.0f, adrenaline_ - dt);
  if (sprinting_) {
    stamina_ -= dt / ((rayState_ == 2 ? 4.2f : 6.5f) * (adrenaline_ > 0.0f ? 2.6f : 1.0f));
    staminaDelay_ = 1.2f;
    if (stamina_ <= 0) { stamina_ = 0; exhausted_ = true; }
  } else {
    staminaDelay_ -= dt;
    if (staminaDelay_ <= 0) stamina_ = std::min(1.0f, stamina_ + dt * (waterBoost_ > 0 ? 0.45f : 0.2f));
  }
  if (exhausted_ && stamina_ > 0.35f) exhausted_ = false;
  waterBoost_ -= dt;

  // --- body, footsteps, noise
  eyeH_ = lerpf(eyeH_, underDesk() ? 0.42f : underGap_ ? 0.52f : (crouch_ ? 0.78f : (rayState_ == 2 ? 1.1f : 1.2f)), 1.0f - std::exp(-dt * 10.0f));  // you're nine
  float spd = std::sqrt(vel_.x * vel_.x + vel_.z * vel_.z);
  float stride = sprinting_ ? 1.4f : (crouch_ ? 0.6f : 0.85f);  // metres per step
  float prev = stepPhase_;
  stepPhase_ += spd * dt / stride;
  float amp = clampf(spd / 2.7f, 0.0f, 1.6f);
  bob_ = std::sin(stepPhase_ * kPi) * std::sin(stepPhase_ * kPi) * 0.045f * amp - 0.02f * amp;
  if (std::floor(stepPhase_) != std::floor(prev) && spd > 0.4f) {
    float g = crouch_ ? 0.15f : (sprinting_ ? 0.85f : 0.45f);
    float pan = (((int)std::floor(stepPhase_)) & 1) ? 0.15f : -0.15f;
    if (A_) A_->play(inWater_ ? Sfx::Splash : Sfx::Footstep, inWater_ ? g * 1.3f + 0.2f : g, pan, 0.85f + rng_.f01() * 0.3f);
    if (inWater_) { addRipple(pos_, sprinting_ ? 0.8f : 0.5f); splash(vec3{pos_.x, footY_, pos_.z}, sprinting_ ? 8 : 3, 0.5f); }
    noiseRadius_ = crouch_ ? 2.0f : (sprinting_ ? 17.0f : 7.0f);
    if (inWater_) noiseRadius_ = std::max(noiseRadius_ * 2.5f, 9.0f);  // splashing carries
    if (rayState_ == 2) noiseRadius_ *= 1.3f;  // two people are louder than one
    noiseHold_ = 0.7f;
    // running with a camcorder: every so often a footfall knocks the tape and the picture tears
    if (sprinting_ && rng_.f01() < 0.22f) jolt_ = std::max(jolt_, 0.25f + rng_.f01() * 0.35f);
  }
  noiseHold_ -= dt;
  if (noiseHold_ <= 0) noiseRadius_ = exhausted_ ? 3.0f : 0.0f;

  // --- flashlight and exposure
  if (flashOn_) {
    if (!inStore()) battery_ -= dt / 200.0f;
    if (battery_ <= 0) { battery_ = 0; flashOn_ = false; toast_ = cameraLight() ? "BATTERY LOW - LIGHT OFF" : "FLASHLIGHT BATTERY DEAD"; toastTime_ = 3; }
  }
  flashDir_ = normalize(lerp(flashDir_, forward(), 1.0f - std::exp(-dt * 13.0f)));
  playerLight_ = level_.lightAt(pos_.x, pos_.z, lightState_);
  // The camcorder meters what it's pointed at (centre-weighted), not where you're standing: aim
  // it down a dead corridor and the gain climbs, swing it into a lit room and it's blown out for
  // a moment while the iris catches up, overshoots a little, and settles.
  float metered = playerLight_ * 0.35f, mw = 0.35f;
  {
    vec3 f = forward();
    // (centre-weighted, and it sees all the way down a corridor: a lit doorway at the far end of a black
    // hall sets the exposure, and the hall goes black)
    const float ds[7] = {1.5f, 3.5f, 6.5f, 11.0f, 16.0f, 22.0f, 29.0f}, ws[4] = {0.3f, 0.2f, 0.1f, 0.05f};
    float farBright = 0.0f;
    for (int k = 0; k < 7; ++k) {
      vec3 q = pos_ + vec3{f.x, 0, f.z} * ds[k];
      if (!level_.lineOfSight(pos_.x, pos_.z, q.x, q.z, true)) break;  // a wall fills the frame from here on
      float lq = level_.lightAt(q.x, q.z, lightState_);
      if (k < 4) { metered += lq * ws[k]; mw += ws[k]; }
      else farBright = std::max(farBright, lq);  // far off, only something bright counts (a lit doorway at the end)
    }
    metered /= mw;
    metered = std::max(metered, farBright * 0.45f);
  }
  // (the gain only goes so far: a dark corridor stays dark and grainy, it doesn't turn into a lit one)
  float targetExp = clampf(0.95f / (0.42f + metered + (flashOn_ ? 0.10f : 0.0f)), 0.5f, 1.75f);
  if (level_.theme.outdoor) targetExp = 0.62f;  // broad daylight: the iris stops right down
  {  // in a dark hallway the lit room at the end holds the exposure down: the hall itself stays black
    int htx, htz;
    level_.tileOf(pos_.x, pos_.z, htx, htz);
    if (!level_.hallDark.empty() && level_.hallDark[level_.idx(htx, htz)] < 0.9f) targetExp = std::min(targetExp, 0.75f);
  }
  if (inPark()) targetExp = std::min(targetExp, 0.62f);  // a bright hall: high lights, but plenty of them
  // a lagging iris: a damped spring, a touch underdamped
  float k = 7.0f, c = 3.9f;
  expVel_ += ((targetExp - exposure_) * k - expVel_ * c) * dt;
  exposure_ = clampf(exposure_ + expVel_ * dt, 0.4f, 3.2f);
  if (!opt_.screenshot.empty() && playTime_ < 0.25f) { exposure_ = targetExp; expVel_ = 0; }  // test shots: as if the iris had settled

  // --- focus item
  focusItem_ = -1;
  float bestD = 1.8f;
  vec3 e = eye(), fw = forward();
  for (size_t i = 0; i < items_.size(); ++i) {
    if (items_[i].taken) continue;
    vec3 d = level_.delta(e, items_[i].pos);
    d.y = items_[i].pos.y + level_.floorAt(items_[i].pos.x, items_[i].pos.z) - e.y;
    float dl = length(d);
    if (dl < bestD && dot(d * (1.0f / dl), fw) > 0.82f) { bestD = dl; focusItem_ = (int)i; }
  }

  if (portrait_) return;
  updateLines(dt);
  if (levelIndex_ == kChoiceLevel) {  // walk into a slide and it takes you
    for (int k = 0; k < 3; ++k) {
      vec3 d = level_.delta(pos_, level_.tubes[k]);
      if (std::sqrt(d.x * d.x + d.z * d.z) < 0.75f) { enterSlide(k); return; }
    }
  }
  updateEvents(dt);
  rayUpdate(dt);
  shockUpdate(dt);
  suitUpdate(dt);
  partyUpdate(dt);
  loreUpdate(dt);
  scaresUpdate(dt);

  clarkUpdate(dt);
  // --- entities
  Perception per;
  per.playerPos = pos_;
  per.noiseRadius = noiseRadius_;
  per.sightRange = clampf((4.5f + (flashOn_ ? 15.0f : 0.0f) + playerLight_ * 9.0f) * (crouch_ ? 0.8f : 1.0f), 4.0f, 26.0f);
  per.flashlightOn = flashOn_;
  per.hidden = hiding_ >= 0 && !seenHiding_;
  if (!flashOn_ && playerLight_ < 0.25f) per.sightRange = crouch_ ? 1.6f : std::min(per.sightRange, 3.5f);
  if (per.hidden) per.sightRange = 0;
  per.playerLight = playerLight_;
  float targetFear = 0;
  if (funLevel()) {
    gunCool_ = std::max(0.0f, gunCool_ - dt);
    gunKick_ *= std::exp(-dt * 11.0f);
    muzzle_ = std::max(0.0f, muzzle_ - dt * 14.0f);
    hitMark_ = std::max(0.0f, hitMark_ - dt);
    if (cheats_.noMonsters) { for (Stalker& s : stalkers_) { s.state = Stalker::Dormant; s.hunt = 0; } for (Grin& g : grins_) g.active = false; }
    if (cheats_.bright) for (float& l : lightState_) l = std::max(l, 1.0f);
    static const float fireAt = std::getenv("BR9_FIREAT") ? (float)std::atof(std::getenv("BR9_FIREAT")) : -1.0f;
    static bool fired = false;
    if (fireAt >= 0.0f && !fired && playTime_ >= fireAt) { fired = true; fireGun(); }
  }
  for (Stalker& s : stalkers_) {
    if (!s.active()) continue;
    Stalker::Events ev = s.update(dt, level_, per, rng_);
    if (ev.step && level_.floorAt(s.pos.x, s.pos.z) < -0.1f) addRipple(s.pos, 0.7f);  // you can see it coming
    vec3 to = level_.delta(pos_, s.pos);
    to.y = 0;
    float d = length(to);
    float pan = d > 0.01f ? dot(to * (1.0f / d), r) : 0.0f;
    bool wet = level_.floorAt(s.pos.x, s.pos.z) < -0.1f;
    Sfx step = wet ? Sfx::Splash : ((s.kind == CR_HOUND || s.kind == CR_PARTYGOER) ? Sfx::Footstep : (s.kind == CR_STILT ? Sfx::Click : Sfx::HeavyStep));
    float sv = s.kind == CR_HOUND ? 1.6f : (s.kind == CR_PARTYGOER ? 0.7f : (s.kind == CR_STILT ? 1.1f : 1.3f));
    if (ev.step && A_) A_->play(step, sv / (1.0f + d * 0.22f), pan, (s.kind == CR_STILT ? 0.55f : 0.8f) + rng_.f01() * 0.2f);
    if (ev.chaseStarted && A_ && s.hunt <= 0) {
      A_->play(Sfx::ChaseSting, 0.9f);
      if (s.kind == CR_HOUND) A_->play(Sfx::Snarl, 1.0f, pan);
    }
    targetFear = std::max(targetFear, (s.state == Stalker::Chase || s.hunt > 0) ? 1.0f : clampf(1.0f - d / 14.0f, 0.0f, 0.6f));
    if (ev.chaseStarted && s.kind == CR_HUMAN) { lines_.clear(); lineTime_ = 0; say("RAY?", "YOU LEFT ME DOWN HERE, KID.", 3.0f); }
    if (ev.caught) {
      float hh = s.kind == CR_HOUND ? 0.8f : (s.kind == CR_HUMAN ? 2.25f : (s.kind == CR_PARTYGOER ? 1.85f : (s.kind == CR_STILT ? 2.35f : 2.45f)));
      if (s.kind == CR_PARTYGOER) { toast_ = "HAPPY BIRTHDAY =)"; toastTime_ = 3.0f; }
      gotCaught(s.pos + vec3{0, hh + level_.floorAt(s.pos.x, s.pos.z), 0});
      return;
    }
  }
  for (Grin& g : grins_) {
    // the Grin only moves when you aren't looking at it
    Grin::Events ev = g.update(dt, level_, per, lightState_, forward(), rng_);
    vec3 to = level_.delta(pos_, g.pos);
    float d = length(to);
    if (ev.noticed && A_) A_->play(Sfx::Giggle, 0.8f, d > 0.01f ? dot(to * (1.0f / d), r) : 0.0f);
    targetFear = std::max(targetFear, g.alert * clampf(1.0f - d / 16.0f, 0.0f, 1.0f));
    if (ev.caught) { gotCaught(g.pos + vec3{0, 2.1f, 0}); return; }
  }
  fear_ = lerpf(fear_, targetFear, 1.0f - std::exp(-dt * 2.0f));

  // --- the exit
  vec3 ex = level_.delta(pos_, level_.exitFaceCenter());
  if (levelIndex_ != kChoiceLevel && std::sqrt(ex.x * ex.x + ex.z * ex.z) < 0.75f) {
    std::fprintf(stderr, "[br9] through the thin place on %s\n", level_.theme.title.c_str());
    if (inPark()) { lines_.clear(); say("MOM", "...honey?", 2.0f); }
    screen_ = Screen::Noclip;
    screenTime_ = 0;
    noclipFall_ = 0;
    for (Stalker& s : stalkers_) s.hunt = 0;
    if (A_) A_->play(Sfx::Noclip, 1.0f);
    return;
  }

  // --- ambient events
  ambientTimer_ -= dt;
  if (ambientTimer_ <= 0) {
    ambientTimer_ = rng_.range(25.0f, 70.0f);
    float r01 = rng_.f01(), pn = rng_.range(-1, 1);
    if (r01 < 0.45f) { if (A_) A_->play(Sfx::Knock, rng_.range(0.25f, 0.5f), pn); }
    else if (r01 < 0.7f) { if (A_) A_->play(Sfx::Slam, rng_.range(0.2f, 0.4f), pn); }
    else { brownout_ = 1.0f; if (A_) A_->play(Sfx::Brownout, 0.6f); }
  }
}

void Game::gotCaught(vec3 head) {
  if (funLevel() && cheats_.god) return;  // nothing can touch you
  std::fprintf(stderr, "[br9] caught at %.1f s\n", playTime_);
  screen_ = Screen::Caught;
  screenTime_ = 0;
  ++deaths_;
  vec3 e = eye();
  vec3 dd = level_.delta(e, head);
  dd.y = head.y - e.y;
  vec3 d = normalize(dd);
  caughtYaw_ = std::atan2(-d.x, -d.z);
  caughtPitch_ = std::asin(clampf(d.y, -1, 1));
  if (A_) A_->play(Sfx::Death, 1.0f);
}

void Game::respawn() {
  if (scareGrin_ >= 0 && scareGrin_ < (int)grins_.size()) grins_.erase(grins_.begin() + scareGrin_);
  scareGrin_ = -1;
  resetPlayer(checkpoint_, checkpointYaw_);
  for (Stalker& s : stalkers_) {
    s.hunt = 0;
    if (s.active()) { s.placeFar(level_, pos_, rng_, 16, 30); s.state = Stalker::Idle; }
  }
  for (Grin& g : grins_) { g.pos = g.home; g.alert = 0; }
  exitChaseDone_ = false;  // you'll have to make the run again
  huntTimer_ = std::max(huntTimer_, 40.0f);
  battery_ = std::max(battery_, 0.35f);
  flashOn_ = defaultLight();
  fear_ = 0;
  exposure_ = 1.5f;
  screen_ = Screen::Playing;
  screenTime_ = 0;
  toast_ = "YOU WERE FOUND";
  toastTime_ = 3.0f;
  setMouseCapture(true);
}

void Game::regenerateLevel() {
  if (levelIndex_ < 0 || daily_) return;  // story/special rooms and the shared daily run stay as they are
  uint32_t seed = ((uint32_t)std::time(nullptr) * 2654435761u) ^ ((uint32_t)SDL_GetTicks() * 2246822519u) ^ (level_.seed * 747796405u + 2891336453u);
  seed |= 1u;
  if (seed == level_.seed) seed = (seed * 2654435761u + 12345u) | 1u;
  // what you carry over: the tape's battery, how long you've been at it, your deaths
  float battery = battery_;
  loadLevel(levelIndex_, seed);  // new walls, new lights, new clues, new monsters (all grown from the new seed)
  battery_ = battery;
  flashOn_ = defaultLight();
  fear_ = 0;
  exposure_ = 1.5f;
  optionsOpen_ = false;
  cheatsOpen_ = false;
  menuSel_ = 0;
  screen_ = Screen::Playing;
  screenTime_ = 0;
  toast_ = "THE LEVEL SHIFTED";
  toastTime_ = 3.0f;
  saveProgress();
  setMouseCapture(true);
}

void Game::updateLights(float dt) {
  (void)dt;
  const auto& lights = level_.lights;
  for (size_t i = 0; !inStore() && i < lights.size() && i < lightState_.size(); ++i) {
    const Light& L = lights[i];
    float s = L.kind == 2 ? 0.0f : 1.0f;
    if (L.kind == 1) {
      float slow = hashf((int)i, (int)(time_ * 0.6f + L.phase), 999);
      if (slow > 0.45f) {
        float f = hashf((int)i, (int)(time_ * 13.0f));
        s = f < 0.3f ? 0.06f : (f < 0.42f ? 0.55f : 1.0f);
      }
    }
    for (const Stalker& st : stalkers_) {  // the Tenant drinks the light around it
      if (!st.active() || st.kind != CR_TENANT) continue;
      vec3 d = level_.delta(st.pos, L.pos);
      float dist = std::sqrt(d.x * d.x + d.z * d.z);
      float reach = 9.0f + (st.state == Stalker::Chase ? 3.0f : 0.0f);
      if (dist < reach) {
        float k = 1.0f - dist / reach;
        float j = hashf((int)i, (int)(time_ * 22.0f), 7);
        s *= 1.0f - k * (0.45f + 0.5f * (j > 0.5f ? 1.0f : 0.0f));
      }
    }
    s = scareLight((int)i, s);
    s *= 1.0f - brownout_ * 0.85f;
    lightState_[i] = s;
  }
  if (screen_ == Screen::Ending) endingLights();
  glBindTexture(GL_TEXTURE_2D, texLightState_);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 64, 64, GL_RED, GL_FLOAT, lightState_.data());
}

void Game::updateAudio() {
  if (!A_ || !A_->ok()) return;
  const Theme& t = level_.theme;
  Audio::Params p;
  p.master = settings.volume;
  bool world = screen_ == Screen::Playing || screen_ == Screen::Paused || screen_ == Screen::Reading || screen_ == Screen::Caught;
  float light = level_.lightAt(pos_.x, pos_.z, lightState_);
  p.hum = (0.12f + clampf(light, 0.0f, 2.0f) * 0.4f) * t.humGain;
  p.water = world ? t.waterGain * 0.8f : 0.0f;
  p.reverbMix = t.layout == Layout::Pools ? 2.2f : (t.layout == Layout::Warehouse ? 1.5f : 1.0f);
  float crackle = 0;
  for (const Light& L : level_.lights) {
    if (L.kind != 1) continue;
    vec3 d = level_.delta(pos_, L.pos);
    float d2 = d.x * d.x + d.z * d.z;
    if (d2 < 64.0f) crackle += 1.0f - std::sqrt(d2) / 8.0f;
  }
  p.crackle = clampf(crackle, 0.0f, 1.5f);
  vec3 r{std::cos(yaw_), 0, -std::sin(yaw_)};
  auto voice = [&](vec3 src, float base, float falloff, float& gain, float& pan) {
    vec3 to = level_.delta(pos_, src);
    to.y = 0;
    float d = length(to);
    bool los = level_.lineOfSight(pos_.x, pos_.z, src.x, src.z);
    float g = base / (1.0f + d * falloff) * (los ? 1.0f : 0.45f);
    if (g > gain) { gain = g; pan = d > 0.01f ? dot(to * (1.0f / d), r) : 0.0f; }
  };
  if (world) {
    for (const Stalker& s : stalkers_) {
      if (!s.active()) continue;
      if (s.kind == CR_HOUND) voice(s.pos, 1.2f, 0.35f, p.houndGain, p.houndPan);
      else voice(s.pos, (s.state == Stalker::Chase || s.hunt > 0) ? 1.5f : 1.1f, 0.3f, p.droneGain, p.dronePan);
    }
    for (const Grin& g : grins_) voice(g.pos, 0.5f + g.alert, 0.3f, p.grinGain, p.grinPan);
  }
  if ((world || screen_ == Screen::Noclip) && !inStore()) {
    voice(level_.exitFaceCenter() + level_.exitFaceNormal() * 0.3f, 0.9f, 0.16f, p.staticGain, p.staticPan);
    if (screen_ == Screen::Noclip) p.staticGain = 1.0f;
  }
  if (world && fear_ > 0.05f) { p.heartRate = 70.0f + fear_ * 85.0f; p.heartGain = fear_ * 0.9f; }
  if (screen_ == Screen::Playing) {
    // your breathing: quiet and slow standing still, quick and hard running, ragged when you're scared
    float spd = std::sqrt(vel_.x * vel_.x + vel_.z * vel_.z);
    float effort = clampf(spd / 4.8f, 0.0f, 1.0f) * (sprinting_ ? 1.0f : 0.45f) + (1.0f - stamina_) * 0.6f + (exhausted_ ? 0.5f : 0.0f);
    float scared = clampf(fear_ + (anyChasing() ? 0.5f : 0.0f), 0.0f, 1.0f);
    p.breath = clampf(0.06f + effort * 0.75f + scared * 0.35f, 0.0f, 1.0f) * (hiding_ >= 0 ? 0.5f : 1.0f);  // holding it in, hiding
    p.breathRate = 0.3f + effort * 1.25f + scared * 0.5f;
    p.breathFear = scared;
  }
  p.tape = (settings.vhs && (screen_ == Screen::Playing || screen_ == Screen::Plunge || screen_ == Screen::Paused)) ? 1.0f : 0.0f;
  p.chase = world ? chaseIntensity_ : 0.0f;
  if (inStore()) {
    p.muzak = inPark() && screen_ != Screen::Title ? 0.9f : 0.0f;
  }
  if (screen_ == Screen::Paused || screen_ == Screen::Reading || screen_ == Screen::Title) p.muffle = 0.85f;
  if (screen_ == Screen::Transition) { p.hum = 0; p.water = 0; p.master = settings.volume * 0.5f; }
  if (screen_ == Screen::Ending) endingAudio(p);
  A_->set(p);
}

// ================================================================ drawing

void Game::drawModel(Shader& S, const Model& m, const mat4& world) {
  S.set("uSkinned", 0);
  S.set("uModel", world);
  glUniform4fv(S.loc("uRegion"), 8, &m.region[0].x);
  glUniform1fv(S.loc("uSpecR"), 8, m.spec);
  m.mesh.draw();
}

void Game::drawCreature(Shader& S, CreatureId id, vec3 pos, float yaw, const AnimInput& in, int variant, const vec4* regions) {
  drawCreatureAt(S, id, translate(pos) * rotY(yaw), in, variant, regions);
}

void Game::drawCreatureAt(Shader& S, CreatureId id, const mat4& world, const AnimInput& in, int variant, const vec4* regions) {
  const Model& m = creatures::creature(id);
  creatures::pose(id, in, world, boneScratch_);
  S.set("uSkinned", 1);
  S.set("uModel", mat4::identity());
  glUniformMatrix4fv(S.loc("uBones"), (GLsizei)boneScratch_.size(), GL_FALSE, boneScratch_[0].m);
  vec4 reg[8];
  float spec[8];
  for (int k = 0; k < 8; ++k) { reg[k] = m.region[k]; spec[k] = m.spec[k]; }
  if (variant == 1) {  // the Lifeguard: drowned-pale, wet sheen
    reg[0] = {0.42f, 0.46f, 0.47f, 0};
    reg[1] = {0.02f, 0.02f, 0.02f, 0};
    spec[0] = 1.3f;
  }
  if (regions)
    for (int k = 0; k < 4; ++k) reg[k] = vec4{regions[k].x, regions[k].y, regions[k].z, reg[k].w};
  glUniform4fv(S.loc("uRegion"), 8, &reg[0].x);
  glUniform1fv(S.loc("uSpecR"), 8, spec);
  static const bool noHuman = std::getenv("BR9_NOHUMAN") != nullptr;
  S.set("uHuman", noHuman || variant == 1 ? 0 : (isKid(id) ? 2 : ((id == CR_HUMAN || id == CR_SUIT || id == CR_WORKER || id == CR_HAZMAT) ? 1 : 0)));
  m.mesh.draw();
  S.set("uHuman", 0);
  S.set("uSkinned", 0);
}

void Game::drawProps(Shader& S, vec3 cam, float range) {
  for (const PropInstance& p : level_.props) {
    vec3 at = near(p.pos, cam);
    vec3 d = at - cam;
    if (d.x * d.x + d.z * d.z > range * range) continue;
    if (p.type == PR_TUBE) {
      Model& m = creatures::prop(PR_TUBE);
      static const vec4 cols[3] = {{0.12f, 0.22f, 0.85f, 0}, {0.92f, 0.78f, 0.12f, 0}, {0.1f, 0.62f, 0.14f, 0}};  // blue, yellow, green
      m.region[0] = cols[p.variant % 3];
    }
    if (p.type == PR_CAR) { at.y = level_.floorAt(at.x, at.z); drawParkedCar(S, at, p.yaw, p.variant); continue; }
    if (p.type == PR_HOUSE) {  // painted siding: cream, white, pale yellow, pale blue, beige; brown roofs
      static const vec4 walls[5] = {{0.93f, 0.86f, 0.62f, 0}, {0.92f, 0.92f, 0.88f, 0}, {0.95f, 0.9f, 0.55f, 0}, {0.72f, 0.8f, 0.86f, 0}, {0.84f, 0.76f, 0.62f, 0}};
      Model& m = creatures::prop(PR_HOUSE);
      m.region[0] = walls[p.variant % 5];
      m.region[1] = vec4{0.3f, 0.21f, 0.16f, 0};
    }
    if (p.type == PR_HOURGLASS) {  // most cushions are blue, the odd one yellow
      Model& m = creatures::prop(PR_HOURGLASS);
      m.region[1] = p.variant ? vec4{0.85f, 0.62f, 0.06f, 0} : vec4{0.06f, 0.12f, 0.62f, 0};
    }
    if (!p.anomaly) {
      bool painted = p.type == PR_DOORSIDE || p.type == PR_WALLDOOR || p.type == PR_DOORLEAF;  // part of the wall, or a door: flat paint
      if (painted) S.set("uHuman", 3);
      drawModel(S, creatures::prop((PropId)p.type), translate(at) * rotY(p.yaw) * rotZ(p.roll) * (p.type == PR_HOUSE ? rotX(p.phase) : mat4::identity()));
      if (painted) S.set("uHuman", 0);
      continue;
    }
    // Caught mid-noclip: stuck in walls, half-sunk, on the ceiling, drifting, glitching through the floor.
    float t = time_ + p.phase;
    vec3 q = at;
    float yaw = p.yaw, roll = p.roll, pitch = 0;
    switch (p.anomaly) {
      case 1: if (hashf((int)(t * 7.0f), 31) < 0.04f) q.x += 0.05f; break;              // in a wall, twitching
      case 2: q.y += 0.02f * std::sin(t * 0.7f); roll += 0.03f * std::sin(t * 0.5f); break;  // sinking
      case 3: break;                                                                      // upside down on the ceiling
      case 4: q.y += 0.12f * std::sin(t * 0.8f); yaw += t * 0.25f; pitch = 0.3f * std::sin(t * 0.37f); roll += 0.25f * std::sin(t * 0.29f); break;
      default: break;
    }
    if (p.anomaly == 2 && hashf((int)(t * 3.0f), 33) < 0.03f) q.y -= 0.6f;  // flickers through the floor
    if (hashf((int)(t * 11.0f), 32) < 0.015f) { q.x += 0.25f; q.z -= 0.15f; }  // a frame where it's somewhere else
    drawModel(S, creatures::prop((PropId)p.type), translate(q) * rotY(yaw) * rotX(pitch) * rotZ(roll));
  }
}

static AnimInput animOf(const Stalker& s, float time, float speedScale) {
  AnimInput in;
  in.time = time;
  in.phase = s.anim;
  in.speed = s.speed / speedScale;
  in.twitch = s.twitch;
  in.alert = s.alert();
  return in;
}

void Game::drawCreatures(Shader& S, vec3 cam) {
  for (const Stalker& s : stalkers_) {
    if (!s.active()) continue;
    vec3 at = near(s.pos, cam);
    at.y = level_.floorAt(s.pos.x, s.pos.z);
    if (s.kind == CR_HUMAN) {  // Ray, almost: too tall, head that won't hold still
      AnimInput in = animOf(s, time_, 1.1f);
      in.look = std::sin(time_ * 13.0f) * 0.5f * (0.3f + s.twitch);
      drawCreatureAt(S, CR_WORKER, translate(at) * rotY(s.yaw) * scale({1.0f, 1.24f, 1.0f}), in, 0, rayThingLook());
      continue;
    }
    drawCreature(S, (CreatureId)s.kind, at, s.yaw, animOf(s, time_, s.kind == CR_HOUND ? 2.0f : 1.3f), s.variant);
  }
}

// Everything that should block the flashlight, near `around`.
void Game::drawCasters(Shader& S, vec3 around) {
  for (ChunkGpu& c : chunks_) {
    vec3 off = near(c.center, around) - c.center;
    vec3 d = c.center + off - around;
    if (d.x * d.x + d.z * d.z > 34.0f * 34.0f) continue;
    S.set("uModel", translate(off));
    c.walls.draw();
  }
  S.set("uModel", mat4::identity());
  drawProps(S, around, 25.0f);
  drawCreatures(S, around);
}

// Lit EXIT signs hung from the ceiling over the last stretch of the way out.
void Game::drawExitSigns(Shader& S, vec3 cam) {
  if (level_.exitSigns.empty()) return;
  if (!texExitSign_[0]) for (int k = 0; k < 3; ++k) texExitSign_[k] = makeTexture(texgen::exitSign(256, 128, k), true, false);
  S.set("uSkinned", 0);
  for (const Level::ExitSign& sg : level_.exitSigns) {
    vec3 at = near(sg.pos, cam);
    vec3 d = at - cam;
    if (d.x * d.x + d.z * d.z > 40.0f * 40.0f) continue;
    vec3 up{0, 1, 0};
    // housing and two hanging rods
    S.set("uMat", MAT_PROP);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    float yaw = std::atan2(sg.n.x, sg.n.z);
    drawPart(translate(at - sg.n * 0.03f) * rotY(yaw) * scale({0.4f, 0.21f, 0.05f}), {0.82f, 0.82f, 0.8f});
    for (int k = -1; k <= 1; k += 2)
      drawPart(translate(at + sg.right * (0.13f * k) + vec3{0, 0.2f, 0}) * scale({0.01f, 0.2f, 0.01f}), {0.5f, 0.5f, 0.5f});
    // the lit face
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    S.set("uEmissive", 1.6f);
    glBindTexture(GL_TEXTURE_2D, texExitSign_[sg.arrow % 3]);
    S.set("uModel", basis(sg.right * 0.36f, up * 0.18f, sg.n, at + sg.n * 0.0015f));
    quad_.draw();
  }
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
  S.set("uMat", MAT_MODEL);
}

void Game::drawDecals(Shader& S, vec3 cam) {
  const Theme& t = level_.theme;
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDepthMask(GL_FALSE);
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(-1.0f, -2.0f);
  S.set("uMat", MAT_DECAL);
  S.set("uSkinned", 0);
  vec3 paint = t.paint;
  for (const Decal& d : level_.decals) {
    vec3 at = near(d.pos, cam);
    vec3 dd = at - cam;
    if (dd.x * dd.x + dd.z * dd.z > 45.0f * 45.0f) continue;
    int tex = std::min(d.kind, (int)decalTex_.size() - 1);
    glBindTexture(GL_TEXTURE_2D, decalTex_[tex]);
    vec3 up{0, 1, 0};
    vec3 r = cross(up, d.n);
    if (length(d.right) > 0.5f) { r = d.right; up = cross(d.n, r); }  // floor paint
    float c = std::cos(d.tilt), s = std::sin(d.tilt);
    vec3 r2 = r * c - up * s, u2 = up * c + r * s;
    vec3 col = paint;
    if (d.kind == DECAL_EXIT) col = paint * 1.15f;
    bool custom = d.color.x >= 0;
    if (custom) col = d.color;
    S.set("uTint", col);
    if (d.kind == DECAL_FOOTPRINTS) {  // dirt on light floors, dust on dark ones
      bool darkFloor = t.floor == Surf::DarkCarpet || t.floor == Surf::OfficeCarpet || t.floor == Surf::PartyCarpet ||
                       t.floor == Surf::ParkingFloor || t.floor == Surf::Grass || level_.districtAt((int)(d.pos.x / Level::kTile), (int)(d.pos.z / Level::kTile)) == Level::D_OLD;
      col = darkFloor ? vec3{0.5f, 0.47f, 0.42f} : vec3{0.035f, 0.028f, 0.02f};
      S.set("uTint", col);
    }
    bool plain = isBloodDecal(d.kind) || (d.kind >= DECAL_LETTER && d.kind <= DECAL_STAIN);
    S.set("uEmissive", plain ? 0.0f : (custom ? 0.55f : t.paintGlow));
    if (d.kind == DECAL_MURAL || d.kind == DECAL_ENDNEAR || d.kind == DECAL_FORSALE) S.set("uTint", vec3{-1, -1, -1});  // full colour: take it from the texture
    S.set("uFlipU", d.flip ? 1 : 0);
    S.set("uModel", basis(r2 * d.w, u2 * d.h, d.n, at));
    quad_.draw();
  }
  S.set("uFlipU", 0);
  S.set("uEmissive", 0.0f);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uModel", mat4::identity());
  glDisable(GL_POLYGON_OFFSET_FILL);
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
}

void Game::drawScene(vec3 camPos, vec3 camDir, float fovDeg, float time, PostParams& pp) {
  const Theme& th = level_.theme;
  float aspect = (float)R_->rtW / (float)R_->rtH;
  mat4 proj = perspective(fovDeg * kPi / 180.0f, aspect, 0.05f, 140.0f);
  mat4 view = lookAt(camPos, camPos + camDir, camUp_);
  viewProj_ = proj * view;

  vec3 rt = normalize(cross(camDir, {0, 1, 0}));
  vec3 fpos = camPos + rt * 0.16f - vec3{0, 0.18f, 0} + camDir * 0.1f;
  vec3 fdir = screen_ == Screen::Playing ? flashDir_ : camDir;
  bool flash = flashOn_ && screen_ != Screen::Title && battery_ > 0;
  float flicker = battery_ < 0.15f ? (hashf((int)(time * 20.0f)) < 0.2f ? 0.3f : 1.0f) : 1.0f;
  float flashI = flash ? 2.4f * flicker * (0.6f + 0.4f * std::min(1.0f, battery_ * 3.0f)) : 0.0f;
  if (screen_ == Screen::Ending && endingFlash(fpos, fdir, flashI)) flash = true;
  if (muzzle_ > 0.02f && funLevel()) {  // the muzzle flash: a hard white burst down the corridor
    flash = true;
    flashI = std::max(flashI, 14.0f * muzzle_);
    fpos = camPos + camDir * 0.45f;
    fdir = camDir;
  }
  if (flash && cameraLight() && muzzle_ <= 0.02f) {  // the lamp on the camcorder, a hand's width over the lens: shadows fall just under things
    fpos = camPos + camDir * 0.05f + camUp_ * 0.07f;
    fdir = camDir;
  }
  vec3 lightCol{th.lightColor.x * lightTint_.x, th.lightColor.y * lightTint_.y, th.lightColor.z * lightTint_.z};

  shadowsDrawn_ = false;
  if (flash) {
    vec3 up = std::fabs(fdir.y) > 0.95f ? vec3{1, 0, 0} : vec3{0, 1, 0};
    shadowVP_ = perspective(80.0f * kPi / 180.0f, 1.0f, 0.08f, 30.0f) * lookAt(fpos, fpos + fdir, up);
    if (R_->beginShadow(shadowVP_)) {
      drawCasters(R_->shadow, fpos);
      R_->endShadow();
      shadowsDrawn_ = true;
    }
  }
  renderSun(camPos);

  R_->beginScene();
  Shader& S = R_->world;
  S.use();
  S.set("uViewProj", viewProj_);
  S.set("uModel", mat4::identity());
  S.set("uSkinned", 0);
  S.set("uCamPos", camPos);
  S.set("uFlashPos", fpos);
  S.set("uFlashDir", fdir);
  S.set("uFlash", flashI);
  S.set("uShadowVP", shadowVP_);
  S.set("uShadowOn", shadowsDrawn_ ? 1 : 0);
  {
    glActiveTexture(GL_TEXTURE7);
    glBindTexture(GL_TEXTURE_2D, R_->sunTex ? R_->sunTex : R_->shadowTex);
    glActiveTexture(GL_TEXTURE0);
    S.set("uSunShadow", 7);
    S.set("uSunOn", sunOn_ ? 1 : 0);
    S.set("uSunVP", sunVP_);
    S.set("uSunDir", normalize(th.sunDir));
    S.set("uSunColor", th.sunColor * th.sun);
    pp.sunOn = sunOn_;
    pp.sunVP = sunVP_;
    pp.sunDir = normalize(th.sunDir);
    pp.sunColor = th.sunColor * th.sun;
    pp.sunHaze = th.outdoor ? 0.3f : 1.0f;  // a clear day outside: colours stay crisp to the horizon
  }
  float L = level_.lightAt(camPos.x, camPos.z, lightState_);
  const bool darkLevel = th.deadChance > 0.5f;  // Lights Out keeps its faint glow to find your way by
  vec3 fog = th.fogColor * (darkLevel ? 1.0f : 0.3f) + th.fogLit * clampf(L, 0.0f, 1.5f);
  S.set("uFogColor", fog);
  S.set("uAmbFloor", darkLevel ? 1.0f : 0.3f);
  S.set("uFogDensity", th.fogDensity * (screen_ == Screen::Plunge ? 0.3f : 1.0f));
  S.set("uTime", time);
  S.set("uLMSize", (float)level_.lmW, (float)level_.lmH);
  S.set("uLMPerMeter", (float)Level::kLmPerMeter);
  S.set("uWallH", level_.wallH);
  S.set("uLightColor", lightCol);
  S.set("uGrimeAmt", th.grime);
  S.set("uWetFloor", th.wetFloor);
  S.set("uAmbient", th.ambient);
  S.set("uBounce", bounceTint_);
  S.set("uFlipU", 0);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  S.set("uRough", 0.8f);
  S.set("uAlbedo", 0);
  S.set("uLightmap", 1);
  S.set("uLightState", 2);
  S.set("uGrime", 3);
  S.set("uShadow", 5);
  glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, texLightmap_);
  glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_2D, texLightState_);
  glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_2D, texGrime_);
  glActiveTexture(GL_TEXTURE5); glBindTexture(GL_TEXTURE_2D, R_->shadowTex);
  glActiveTexture(GL_TEXTURE6); glBindTexture(GL_TEXTURE_2D, texPoolMask_ ? texPoolMask_ : texWhite_);
  glActiveTexture(GL_TEXTURE0 + 12); glBindTexture(GL_TEXTURE_2D, texIndirect_);
  S.set("uIndirect", 12);
  glActiveTexture(GL_TEXTURE0 + 13); glBindTexture(GL_TEXTURE_2D, texWear_);
  S.set("uWear", 13);
  S.set("uGISize", level_.W * Level::kTile, level_.H * Level::kTile);
  S.set("uGIScale", settings.gi && !std::getenv("BR9_NOGI") ? (inStore() ? 0.0f : (inPark() ? 0.3f : 0.8f)) * (1.0f - clampf(brownout_, 0.0f, 1.0f)) : 0.0f);
  S.set("uPoolMask", 6);
  S.set("uPoolOn", hasPools_ ? 1 : 0);
  S.set("uPoolSize", level_.W * Level::kTile, level_.H * Level::kTile);
  glActiveTexture(GL_TEXTURE0);
  rtBind(S, camPos);

  // Chunks, each at its nearest copy around the camera: no edges, ever.
  SurfaceLook lw = look(th.wall), lf = look(th.floor), lc = look(th.ceiling);
  vec3 fwd2 = normalize(vec3{camDir.x, 0, camDir.z});
  std::vector<std::pair<ChunkGpu*, vec3>> visible;
  for (ChunkGpu& c : chunks_) {
    vec3 off = near(c.center, camPos) - c.center;
    vec3 d = c.center + off - camPos;
    d.y = 0;
    float dist = length(d);
    if (dist > 80.0f) continue;
    if (dist > 14.0f && dot(d, fwd2) < -12.0f && screen_ != Screen::Plunge) continue;  // behind the camera
    visible.push_back({&c, off});
  }
  auto pass = [&](GpuMesh ChunkGpu::*mesh, GLuint tex, int mat, float rough, float bump) {
    glBindTexture(GL_TEXTURE_2D, tex);
    S.set("uMat", mat);
    S.set("uUVScale", (mat == MAT_FLOOR && th.floor == Surf::ParkingFloor) ? 0.25f : 1.0f);  // garage floor: tracks every 4 m
    S.set("uRough", rough);
    S.set("uBump", bump);
    for (auto& v : visible) {
      if (!(v.first->*mesh).count) continue;
      S.set("uModel", translate(v.second));
      (v.first->*mesh).draw();
    }
  };
  S.set("uWallFull", th.wall == Surf::ParkWall ? 1 : 0);  // one picture floor to ceiling, 2 m wide
  pass(&ChunkGpu::walls, texWall_, MAT_WALL, lw.rough, lw.bump);
  pass(&ChunkGpu::floor, texFloor_, MAT_FLOOR, lf.rough, lf.bump);
  S.set("uCeilTiles", th.ceiling == Surf::CeilingTiles ? 1 : 0);
  pass(&ChunkGpu::ceiling, texCeil_, MAT_CEIL, lc.rough, lc.bump);
  {
    SurfaceLook l2 = look(th.wall2), f2 = look(th.floor2), c2 = look(th.ceiling2);
    pass(&ChunkGpu::walls2, texWall2_, MAT_WALL, l2.rough, l2.bump);
    pass(&ChunkGpu::floor2, texFloor2_, MAT_FLOOR, f2.rough, f2.bump);
    S.set("uCeilTiles", th.ceiling2 == Surf::CeilingTiles ? 1 : 0);
    pass(&ChunkGpu::ceiling2, texCeil2_, MAT_CEIL, c2.rough, c2.bump);
    S.set("uCeilTiles", 0);
    S.set("uWallFull", 0);
  }
  pass(&ChunkGpu::panels, texPanel_, MAT_PANEL, 0.5f, 0.0f);
  pass(&ChunkGpu::trim, texWhite_, MAT_TRIM, 0.6f, 0.0f);
  S.set("uModel", mat4::identity());

  drawItems(camPos);
  S.set("uMat", MAT_MODEL);
  S.set("uBump", 0.0f);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  drawProps(S, camPos, level_.theme.special == Special::Suburbs ? 110.0f : 60.0f);
  specialDraw(S, camPos);
  drawCord(S, camPos);
  drawCreatures(S, camPos);
  drawGun(S, camPos, camDir);
  clarkDraw(S, camPos);
  for (const Grin& g : grins_) {
    if (!g.active) continue;
    AnimInput in;
    in.time = time + g.home.x;
    in.speed = g.speed;
    in.twitch = g.twitch;
    in.alert = g.alert;
    float lit = level_.lightAt(g.pos.x, g.pos.z, lightState_);
    Model& m = creatures::creature(CR_GRIN);
    float base = m.region[3].w;
    m.region[3].w = base * clampf(1.0f - lit * 6.0f, 0.15f, 1.0f) * (0.75f + 0.25f * std::sin(time * 1.7f));
    drawCreature(S, CR_GRIN, near(g.pos, camPos), g.yaw, in);
    m.region[3].w = base;
    drawSoot(S, near(g.pos, camPos), time + g.home.x, camPos);
  }

  drawContactShadows(S, camPos);
  drawDecals(S, camPos);
  drawDust(S, camPos);
  drawExitSigns(S, camPos);
  drawCourtyard(S, camPos);
  drawPoolPieces(S, camPos);
  if (screen_ == Screen::Slide) drawSlide(S, camPos);
  if (levelIndex_ == kChoiceLevel) {  // the dark insides of the slide openings
    if (!texHole_[0]) {
      texHole_[0] = makeTexture(texgen::slideHole(256, 0.15f, 0.28f, 0.95f), true, false);
      texHole_[1] = makeTexture(texgen::slideHole(256, 0.95f, 0.8f, 0.15f), true, false);
      texHole_[2] = makeTexture(texgen::slideHole(256, 0.12f, 0.62f, 0.16f), true, false);  // green: EXIT :)
    }
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    S.set("uMat", MAT_SCREEN);
    S.set("uSkinned", 0);
    S.set("uUVScale", 1.0f);
    S.set("uEmissive", 0.32f);
    for (int k = 0; k < 3; ++k) {
      vec3 c = near(level_.tubes[k], camPos) + vec3{0, 0, 0.004f};
      mat4 m = mat4::identity();
      m.m[0] = 1.0f; m.m[5] = 1.0f; m.m[10] = 1.0f;
      m.m[12] = c.x; m.m[13] = c.y; m.m[14] = c.z;
      glBindTexture(GL_TEXTURE_2D, texHole_[k]);
      S.set("uModel", m);
      quad_.draw();
    }
    glDisable(GL_BLEND);
    S.set("uModel", mat4::identity());
  }
  if (screen_ == Screen::Ending) endingDraw(S, camPos);
  if (inPark()) parkDraw(S, camPos);
  else if (screen_ != Screen::Title) { rayDraw(S, camPos); shockDraw(S, camPos); suitDraw(S, camPos); dropDraw(S, camPos); partyDraw(S, camPos); loreDraw(S, camPos); scaresDraw(S, camPos); }

  // Water surfaces.
  {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    S.set("uMat", MAT_WATER);
    glDepthMask(GL_TRUE);  // the surface is what reflections and fog should see
    {
      float rp[32];
      for (int k = 0; k < 8; ++k) {
        vec3 rpos = near(ripples_[k].pos, camPos);
        rp[k * 4] = rpos.x; rp[k * 4 + 1] = rpos.z; rp[k * 4 + 2] = ripples_[k].t0; rp[k * 4 + 3] = ripples_[k].strength;
      }
      glUniform4fv(S.loc("uRipple"), 8, rp);
    }
    for (auto& v : visible) {
      if (!v.first->water.count) continue;
      S.set("uModel", translate(v.second));
      v.first->water.draw();
    }
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    S.set("uModel", mat4::identity());
  }
  if (!drops_.empty()) {  // splash droplets
    S.set("uMat", MAT_PROP);
    S.set("uSkinned", 0);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    for (const Drop& d : drops_) {
      vec3 p = near(d.p, camPos);
      float sz = 0.018f + 0.02f * d.life;
      drawPart(translate(p) * scale({sz, sz * 1.6f, sz}), {0.75f, 0.88f, 0.95f}, 0.35f);
    }
  }

  drawFirstPerson(S);

  // The thin place.
  if (!inStore() && !inPark() && screen_ != Screen::Ending && level_.theme.layout != Layout::Apartment && levelIndex_ != kChoiceLevel) {
    vec3 c = near(level_.exitFaceCenter(), camPos), n = level_.exitFaceNormal();
    float hgt = std::min(2.4f, level_.wallH - 0.2f);
    vec3 sc = std::fabs(n.x) > 0.5f ? vec3{0.01f, hgt, 1.5f} : vec3{1.5f, hgt, 0.01f};
    vec3 at = c + n * 0.012f;
    at.y = level_.floorAt(at.x + n.x * 0.3f, at.z + n.z * 0.3f) + hgt * 0.5f + 0.02f;
    (void)sc;
    // Not static any more: somebody marked it. A door outlined in blue tape, and the wall inside
    // the tape not quite holding still.
    if (!texTape_) texTape_ = makeTexture(texgen::blueTape(256, 560, level_.seed), true, false);
    vec3 dd = level_.delta(pos_, c);
    float d = std::sqrt(dd.x * dd.x + dd.z * dd.z);
    vec3 r = cross(vec3{0, 1, 0}, n);
    const float tw = 1.05f, th = std::min(2.2f, level_.wallH - 0.15f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(-1.0f, -2.0f);
    S.set("uMat", MAT_DECAL);
    S.set("uFlipU", 0);
    // inside the tape: a faint darkness that breathes, stronger the closer you are
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    float breathe = 0.5f + 0.5f * std::sin(time * 1.3f) * std::sin(time * 0.47f + 1.0f);
    S.set("uTint", vec3{0.02f, 0.02f, 0.03f});
    S.set("uEmissive", 0.0f);
    float shadeA = clampf(0.9f - d * 0.06f, 0.15f, 0.55f) * (0.6f + 0.4f * breathe);
    (void)shadeA;
    mat4 inner = mat4::identity();
    vec3 ic = c + n * 0.008f;
    ic.y = th * 0.5f + 0.02f;
    inner.m[0] = r.x * (tw - 0.12f); inner.m[1] = 0; inner.m[2] = r.z * (tw - 0.12f);
    inner.m[5] = th - 0.1f;
    inner.m[8] = n.x; inner.m[10] = n.z;
    inner.m[12] = ic.x; inner.m[13] = ic.y; inner.m[14] = ic.z;
    S.set("uModel", inner);
    S.set("uGlitch", shadeA);
    S.set("uMat", MAT_GLITCH);
    quad_.draw();
    // the tape itself
    S.set("uMat", MAT_DECAL);
    glBindTexture(GL_TEXTURE_2D, texTape_);
    S.set("uTint", vec3{0.13f, 0.36f, 0.86f});
    S.set("uEmissive", 0.05f);
    mat4 m = inner;
    m.m[0] = r.x * tw; m.m[2] = r.z * tw; m.m[5] = th;
    m.m[12] = c.x + n.x * 0.012f; m.m[14] = c.z + n.z * 0.012f; m.m[13] = th * 0.5f + 0.02f;
    S.set("uModel", m);
    quad_.draw();
    glDisable(GL_POLYGON_OFFSET_FILL);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    S.set("uTint", vec3{1, 1, 1});
    S.set("uModel", mat4::identity());
  }
  R_->endScene();

  pp.view = view;
  pp.proj = proj;
  pp.camPos = camPos;
  pp.flashPos = fpos;
  pp.flashDir = fdir;
  pp.night = 0.0f;
  pp.flash = flashI;
  pp.shadowVP = shadowVP_;
  pp.lightmap = texLightmap_;
  pp.lightState = texLightState_;
  pp.lmW = (float)level_.lmW;
  pp.lmH = (float)level_.lmH;
  pp.lmPerMeter = (float)Level::kLmPerMeter;
  pp.fogColor = fog;
  pp.wallH = level_.wallH;
  pp.lightColor = lightCol;
}

void Game::drawPart(const mat4& m, vec3 tint, float emissive) {
  Shader& S = R_->world;
  S.set("uModel", m);
  S.set("uTint", tint);
  S.set("uEmissive", emissive);
  cube_.draw();
}

void Game::drawItems(vec3 cam) {
  Shader& S = R_->world;
  S.set("uMat", MAT_PROP);
  S.set("uUVScale", 1.0f);
  S.set("uBump", 0.0f);
  S.set("uRough", 0.6f);
  for (const Item& it : items_) {
    if (it.taken) continue;
    vec3 at = near(it.pos, cam);
    vec3 dd = at - cam;
    if (dd.x * dd.x + dd.z * dd.z > 50.0f * 50.0f) continue;
    at.y = level_.floorAt(it.pos.x, it.pos.z);
    mat4 base = translate(at) * rotY(it.yaw);
    switch (it.type) {
      case ITEM_NOTE:
        glBindTexture(GL_TEXTURE_2D, texPaper_);
        drawPart(base * translate({0, 0.003f, 0}) * rotY(0.1f) * scale({0.21f, 0.004f, 0.28f}), {1, 1, 1}, 0.004f + level_.theme.paintGlow * 0.01f);
        break;
      case ITEM_BATTERY:
        glBindTexture(GL_TEXTURE_2D, texWhite_);
        drawPart(base * translate({0, 0.025f, 0}) * rotZ(kPi / 2) * scale({0.05f, 0.1f, 0.05f}), {0.08f, 0.09f, 0.1f});
        drawPart(base * translate({0.055f, 0.025f, 0}) * scale({0.012f, 0.03f, 0.03f}), {0.7f, 0.45f, 0.2f});
        drawPart(base * translate({-0.02f, 0.025f, 0}) * rotZ(kPi / 2) * scale({0.052f, 0.04f, 0.052f}), {0.7f, 0.55f, 0.1f});
        break;
      case ITEM_TAPE: {
        glBindTexture(GL_TEXTURE_2D, texWhite_);
        drawPart(base * translate({0, 0.013f, 0}) * scale({0.188f, 0.025f, 0.104f}), {0.05f, 0.05f, 0.055f});
        drawPart(base * translate({0, 0.026f, 0.005f}) * scale({0.15f, 0.002f, 0.06f}), {0.85f, 0.82f, 0.72f});
        drawPart(base * translate({-0.04f, 0.0275f, 0.005f}) * scale({0.022f, 0.002f, 0.022f}), {0.12f, 0.1f, 0.09f});
        drawPart(base * translate({0.04f, 0.0275f, 0.005f}) * scale({0.022f, 0.002f, 0.022f}), {0.12f, 0.1f, 0.09f});
        // a blinking red REC dot so you can spot it in the dark
        float on = std::fmod(time_ + it.yaw, 1.4f) < 0.7f ? 1.0f : 0.15f;
        drawPart(base * translate({0.075f, 0.028f, -0.035f}) * scale({0.008f, 0.004f, 0.008f}), {1.0f, 0.1f, 0.05f}, 6.0f * on);
      } break;
      case ITEM_WATER:
        glBindTexture(GL_TEXTURE_2D, texWhite_);
        drawPart(base * translate({0, 0.11f, 0}) * scale({0.075f, 0.22f, 0.075f}), {0.82f, 0.8f, 0.68f});
        drawPart(base * translate({0, 0.235f, 0}) * scale({0.035f, 0.03f, 0.035f}), {0.12f, 0.25f, 0.65f});
        drawPart(base * translate({0, 0.11f, 0.038f}) * scale({0.06f, 0.08f, 0.002f}), {0.85f, 0.85f, 0.85f});
        break;
    }
  }
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
}

void Game::render() {
  float fov = settings.fov;
  PostParams pp;
  pp.time = time_;
  pp.vhs = settings.vhs && !std::getenv("BR9_NOVHS");
  pp.frame43 = pp.vhs && settings.frame43 && !std::getenv("BR9_WIDE");
  pp.exposure = exposure_;
  pp.grain = 0.018f + 0.03f * clampf((exposure_ - 1.0f) / 1.8f, 0.0f, 1.0f);  // the camera's gain goes up in the dark, and so does the noise
  pp.fear = fear_ * 0.6f;

  vec3 camPos = eye(), camDir = forward();
  camUp_ = {0, 1, 0};
  if (std::getenv("BR9_CINE") && screen_ == Screen::Playing && !inStore()) camPos.y = cineY_;
  if (screen_ == Screen::Playing && !std::getenv("BR9_CINE")) {
    // Somebody is holding this camera. They breathe (faster when they're scared or out of breath),
    // it dips and sways with every footstep, it shakes when they run, their hands tremble when
    // something's near, it rolls a little into turns and trails your look by a hair.
    float t = time_;
    float rdt = clampf(t - lastCamT_, 0.0f, 0.1f);
    lastCamT_ = t;
    vec3 rt = normalize(cross(camDir, vec3{0, 1, 0}));
    float spd = std::sqrt(vel_.x * vel_.x + vel_.z * vel_.z);
    float walk = clampf(spd / 2.7f, 0.0f, 1.6f);
    float scared = clampf(fear_ + (anyChasing() ? 0.6f : 0.0f), 0.0f, 1.0f);
    breathPhase_ += rdt * (1.45f + 2.4f * scared + 2.2f * (1.0f - stamina_));
    float breath = std::sin(breathPhase_);
    // a nine-year-old's hands: never still. A slow drift, the breathing, and a constant fine tremor on top
    float sy = 0.0058f * std::sin(t * 0.71f) + 0.003f * std::sin(t * 1.93f + 1.3f) + 0.0014f * std::sin(t * 4.7f + 0.3f);
    float sp = 0.0047f * std::sin(t * 0.93f + 0.4f) + 0.0024f * std::sin(t * 2.31f) + 0.0055f * breath * (0.6f + scared) +
               0.0013f * std::sin(t * 5.3f + 1.1f);
    float roll = 0.0075f * std::sin(t * 0.53f + 2.0f) + 0.0022f * std::sin(t * 1.7f + 0.6f);
    {
      float tq = std::sin(t * 8.7f) + 0.6f * std::sin(t * 13.3f + 2.0f) + 0.35f * std::sin(t * 19.1f + 4.0f);  // hand tremor, 8-19 Hz
      float tw = std::sin(t * 9.9f + 1.0f) + 0.6f * std::sin(t * 15.7f + 3.0f);
      sy += 0.0008f * tq;
      sp += 0.0007f * tw;
      roll += 0.0006f * tq;
    }
    float ph = stepPhase_ * kPi;
    auto wobble = [](float x) { return 0.5f * std::sin(x * 1.7f) + 0.3f * std::sin(x * 3.9f + 1.0f) + 0.2f * std::sin(x * 7.3f + 2.0f); };
    // which way you're moving decides how the camera moves: a careful walk or running scared
    bool running = sprinting_ && walk > 0.3f;
    runMix_ = lerpf(runMix_, running ? 1.0f : 0.0f, 1.0f - std::exp(-rdt * (running ? 5.0f : 2.5f)));
    walkMix_ = lerpf(walkMix_, (!running && walk > 0.08f) ? clampf(walk * 1.3f, 0.0f, 1.0f) : 0.0f, 1.0f - std::exp(-rdt * 3.0f));
    float wm = walkMix_ * (1.0f - runMix_), rm = runMix_;
    vec3 posOff{0, 0, 0};
    // -- careful walking: soft heel strikes that settle, weight rolling foot to foot, the camera
    //    tipped a little toward the floor to watch your footing, and a slow look left and right
    {
      float strike = std::pow(1.0f - std::fabs(std::sin(ph)), 5.0f);
      sp -= 0.0085f * wm * strike + 0.035f * wm;                       // eyes on the floor ahead
      sy += 0.0095f * wm * std::sin(ph) + 0.026f * wm * wobble(t * 0.33f) + 0.004f * wm * wobble(t * 2.9f);  // checking the corners
      roll += 0.0095f * wm * std::sin(ph) + 0.003f * wm * wobble(t * 2.3f + 5.0f);
      posOff = posOff + rt * (0.012f * wm * std::sin(ph));
    }
    // -- running scared: hard kicks on every footfall, the body swinging, the arm pumping the
    //    camera up and down, panicky jerks, and every so often a look back over your shoulder
    {
      float strike = std::pow(1.0f - std::fabs(std::sin(ph)), 4.0f);
      float panic = 0.5f + 0.8f * scared;
      sp -= 0.038f * rm * strike;
      sp += 0.026f * rm * std::sin(ph * 0.5f * 2.0f + 0.8f) * std::sin(ph);   // arm pumping
      sy += 0.03f * rm * std::sin(ph) + 0.02f * rm * panic * wobble(t * 6.1f);
      sp += 0.015f * rm * panic * wobble(t * 5.3f + 7.0f);
      roll += 0.055f * rm * std::sin(ph + 0.5f) + 0.026f * rm * panic * wobble(t * 4.4f + 3.0f);
      posOff = posOff + rt * (0.042f * rm * std::sin(ph)) + vec3{0, -0.038f * rm * strike, 0};
      // a glance back while something's after you
      glanceNext_ -= rdt;
      if (rm > 0.8f && anyChasing() && glanceNext_ <= 0.0f && glanceT_ <= 0.0f) {
        glanceT_ = 0.75f; glanceSide_ = rng_.f01() < 0.5f ? -1.0f : 1.0f; glanceNext_ = rng_.range(3.5f, 7.0f);
      }
      if (glanceT_ > 0.0f) {
        float g = std::sin(kPi * (1.0f - glanceT_ / 0.75f));
        sy += glanceSide_ * 0.42f * g * g;
        roll += glanceSide_ * 0.06f * g;
        glanceT_ = std::max(0.0f, glanceT_ - rdt);
      }
    }
    // -- the camera is in your hand, not bolted to your head: when your body changes speed up or
    //    down (a jump, a bounce, a landing) it lags, dips, overshoots and settles
    {
      float acc = rdt > 0 ? clampf((vy_ - prevVy_) / rdt, -80.0f, 80.0f) : 0.0f;
      if (grounded_ && !onBed_) acc = 0.0f;
      prevVy_ = vy_;
      float sub = rdt / 3.0f;
      for (int k = 0; k < 3; ++k) {
        camOffV_ += (-90.0f * camOffY_ - 11.0f * camOffV_ - acc * 0.006f) * sub;
        camOffY_ += camOffV_ * sub;
      }
      camOffY_ = clampf(camOffY_, -0.12f, 0.12f);
      posOff.y += camOffY_;
      sp += camOffY_ * 1.1f;                                 // the wrist nods with it
      float air = (!grounded_ && jumpY_ > 0.05f) ? 1.0f : 0.0f;
      roll += 0.018f * air * std::sin(t * 2.3f);             // floating at the top, a slow tilt
      sy += 0.008f * air * std::sin(t * 1.7f + 1.0f);
    }
    // crawling through a hole: on your hands and knees, the camera in one hand, lurching with each shuffle
    crawlMix_ = lerpf(crawlMix_, underGap_ ? 1.0f : 0.0f, 1.0f - std::exp(-rdt * 6.0f));
    if (crawlMix_ > 0.01f) {
      float cph = stepPhase_ * kPi * 0.5f;
      roll += crawlMix_ * (0.06f * std::sin(cph) + 0.02f);
      sp += crawlMix_ * (0.012f * std::sin(cph * 2.0f) - 0.04f);
      sy += crawlMix_ * 0.015f * std::sin(cph + 1.0f);
      posOff = posOff + rt * (0.03f * crawlMix_ * std::sin(cph)) + vec3{0, -0.02f * crawlMix_ * std::fabs(std::sin(cph * 2.0f)), 0};
    }
    // ---- a person, not a rig: everything below is what makes it look hand-held
    {
      // re-framing: the hand drifts off what it's pointing at, then catches it with a small quick
      // correction that overshoots a hair and settles
      fixNext_ -= rdt;
      if (fixNext_ <= 0.0f) {
        fixNext_ = rng_.range(1.6f, 4.5f) * (1.0f - 0.5f * scared);
        fixYaw_ = rng_.range(-1.0f, 1.0f) * (0.006f + 0.01f * scared);
        fixPitch_ = rng_.range(-1.0f, 1.0f) * (0.005f + 0.008f * scared);
        fixT_ = 0.0f;
      }
      fixT_ += rdt;
      float settle = 1.0f - std::exp(-fixT_ * 9.0f) * std::cos(fixT_ * 14.0f);  // 0 -> 1 with a little overshoot
      sy += fixYaw_ * (1.0f - settle);
      sp += fixPitch_ * (1.0f - settle);
      // shifting the grip: every so often the camera tips while the fingers re-settle, then comes back
      gripNext_ -= rdt;
      if (gripNext_ <= 0.0f && gripT_ <= 0.0f) { gripNext_ = rng_.range(7.0f, 18.0f); gripT_ = 0.7f; gripRoll_ = rng_.range(-1.0f, 1.0f) * 0.035f; }
      if (gripT_ > 0.0f) {
        float g = std::sin(kPi * (1.0f - gripT_ / 0.7f));
        roll += gripRoll_ * g;
        sp += std::fabs(gripRoll_) * 0.3f * g;
        posOff.y -= 0.006f * g;
        gripT_ = std::max(0.0f, gripT_ - rdt);
      }
      // every footfall knocks the camera: a short sharp jolt that dies away, harder when running
      float stepNow = std::floor(stepPhase_);
      if (stepNow != lastStep_ && walk > 0.1f) { stepJolt_ = 0.5f + 0.5f * rm + 0.25f * wm; joltSeed_ = rng_.range(0.0f, 100.0f); }
      lastStep_ = stepNow;
      if (stepJolt_ > 0.001f) {
        float j = stepJolt_;
        sp += j * 0.006f * std::sin(t * 61.0f + joltSeed_);
        sy += j * 0.004f * std::sin(t * 47.0f + joltSeed_ * 1.7f);
        roll += j * 0.005f * std::sin(t * 53.0f + joltSeed_ * 0.6f);
        posOff.y -= j * 0.008f;
        stepJolt_ *= std::exp(-rdt * 14.0f);
      }
      // the body carries on when you stop and lags when you start: the camera sways forward and
      // back, and side to side, on a soft spring
      vec3 acc = rdt > 0 ? (vel_ - prevVel_) * (1.0f / rdt) : vec3{0, 0, 0};
      prevVel_ = vel_;
      vec3 fw{camDir.x, 0, camDir.z};
      if (dot(fw, fw) > 1e-6f) fw = normalize(fw);
      float aF = clampf(dot(acc, fw), -30.0f, 30.0f), aS = clampf(dot(acc, rt), -30.0f, 30.0f);
      float sub = rdt / 3.0f;
      for (int k = 0; k < 3; ++k) {
        swayFwdV_ += (-55.0f * swayFwd_ - 8.5f * swayFwdV_ - aF * 0.011f) * sub; swayFwd_ += swayFwdV_ * sub;
        swaySideV_ += (-48.0f * swaySide_ - 8.0f * swaySideV_ - aS * 0.010f) * sub; swaySide_ += swaySideV_ * sub;
      }
      swayFwd_ = clampf(swayFwd_, -0.08f, 0.08f); swaySide_ = clampf(swaySide_, -0.08f, 0.08f);
      sp -= swayFwd_ * 0.9f;                // stopping: the camera dips forward, then rocks back
      posOff = posOff + fw * (swayFwd_ * 0.5f) + rt * (swaySide_ * 0.4f);
      roll -= swaySide_ * 0.6f;
      // walking sideways you lean into it
      float side = clampf(dot(vel_, rt) / 2.7f, -1.0f, 1.0f);
      leanRoll_ = lerpf(leanRoll_, side * 0.022f, 1.0f - std::exp(-rdt * 4.0f));
      roll += leanRoll_;
      // the breath is in the shoulders too: the camera rises and falls with it
      posOff.y += 0.0035f * breath * (1.0f + scared + 1.5f * (1.0f - stamina_));
    }
    // trembling hands when something's near (less when you're concentrating on walking quietly)
    float tr = scared * 0.0032f * (1.0f - 0.4f * wm);
    sy += tr * (std::sin(t * 11.3f) + 0.6f * std::sin(t * 17.9f + 1.0f));
    sp += tr * (std::sin(t * 13.1f + 2.0f) + 0.5f * std::sin(t * 19.7f));
    // how much of all that: the CAMERA SHAKE setting (normal is the full hand-held look)
    static const float kShakeAmt[4] = {0.0f, 0.45f, 1.0f, 1.6f};
    float amt = kShakeAmt[std::clamp(settings.camShake, 0, 3)];
    sy *= amt; sp *= amt; roll *= amt; posOff = posOff * amt;
    camPos = camPos + posOff;
    float yr = rdt > 0 ? wrapPi(yaw_ - lastYaw_) / rdt : 0.0f;
    {
      // the camera is swung by an arm: it trails a fast turn a little and overshoots when you stop
      float pr = rdt > 0 ? (pitch_ - lastPitchCam_) / rdt : 0.0f;
      lastPitchCam_ = pitch_;
      float sub = rdt / 3.0f;
      for (int k = 0; k < 3; ++k) {
        lagYawV_ += (-70.0f * lagYaw_ - 10.0f * lagYawV_ - clampf(yr, -12.0f, 12.0f) * 0.55f) * sub; lagYaw_ += lagYawV_ * sub;
        lagPitchV_ += (-80.0f * lagPitch_ - 11.0f * lagPitchV_ - clampf(pr, -8.0f, 8.0f) * 0.45f) * sub; lagPitch_ += lagPitchV_ * sub;
      }
      lagYaw_ = clampf(lagYaw_, -0.05f, 0.05f); lagPitch_ = clampf(lagPitch_, -0.04f, 0.04f);
      sy += lagYaw_ * amt * 0.5f;
      sp += lagPitch_ * amt * 0.5f;
    }
    lastYaw_ = yaw_;
    turnRoll_ = lerpf(turnRoll_, clampf(-yr * 0.011f, -0.045f, 0.045f), 1.0f - std::exp(-rdt * 5.0f));
    pp.pan = clampf(yr / (settings.fov * kPi / 180.0f * 1.33f) / 60.0f, -0.012f, 0.012f);  // a field is 1/60 s
    pp.banding = (level_.theme.outdoor || inStore()) ? 0.0f : 0.022f;
    roll += turnRoll_ * amt;
    camDir = normalize(camDir + rt * sy + vec3{0, 1, 0} * sp);
    if (dot(camLook_, camDir) < 0.9f || rdt <= 0) camLook_ = camDir;     // teleports snap
    camLook_ = normalize(lerp(camLook_, camDir, 1.0f - std::exp(-rdt * 24.0f)));
    camDir = camLook_;
    camUp_ = normalize(vec3{0, 1, 0} + rt * roll);
    // autofocus: it hunts after a fast pan, now and then for no reason, more in the dark
    if (std::fabs(yr) > 3.0f) focusHunt_ = std::max(focusHunt_, 0.55f);
    focusNext_ -= rdt * (1.0f + 1.5f * clampf(exposure_ - 1.2f, 0.0f, 1.0f));
    if (focusNext_ <= 0) { focusNext_ = 20.0f + 35.0f * hashf((int)(t * 10.0f), 91); focusHunt_ = 1.0f; }
    focusHunt_ = std::max(0.0f, focusHunt_ - rdt * 1.4f);
    pp.focus = focusHunt_ > 0 ? std::sin(focusHunt_ * kPi * 1.5f) * std::sin(focusHunt_ * kPi * 1.5f) * focusHunt_ : 0.0f;
  }
  switch (screen_) {
    case Screen::Title: {
      float t = time_ * 0.05f;
      vec3 c = level_.tileCenter(level_.startX, level_.startZ, 1.55f);
      camPos = c + vec3{std::sin(t) * 1.2f, std::sin(time_ * 0.3f) * 0.03f, std::cos(t * 0.7f) * 1.2f};
      float y = checkpointYaw_ + std::sin(time_ * 0.04f) * 0.9f;
      camDir = {-std::sin(y), -0.04f, -std::cos(y)};
      exposure_ = 0.8f;
      pp.exposure = exposure_;
      pp.fear = 0;
    } break;
    case Screen::Playing:
      if (sprinting_) fov += 6.0f;
      if (pitFall_ >= 0) {
        pp.fade = clampf((pitFall_ - 0.8f) / 0.6f, 0.0f, 1.0f);
        pp.staticAmt = clampf(pitFall_ - 0.6f, 0.0f, 0.6f);
        pp.fear = 1.0f;
      }
      break;
    case Screen::Caught: {
      float k = clampf(screenTime_ / 0.25f, 0, 1);
      float yy = yaw_ + wrapPi(caughtYaw_ - yaw_) * k;
      float p2 = lerpf(pitch_, caughtPitch_, k);
      yy += (hashf((int)(time_ * 60)) - 0.5f) * 0.03f * (1.0f - k * 0.5f);
      camDir = {-std::sin(yy) * std::cos(p2), std::sin(p2), -std::cos(yy) * std::cos(p2)};
      pp.staticAmt = clampf((screenTime_ - 0.6f) / 1.0f, 0.0f, 1.0f);
      pp.fear = 1.0f;
      pp.fade = clampf((screenTime_ - 1.5f) / 0.4f, 0.0f, 1.0f);
      fov -= 12.0f * k;
    } break;
    case Screen::Noclip:
      camPos.y -= noclipFall_;
      fov += screenTime_ * 25.0f;
      pp.staticAmt = clampf(screenTime_ / 2.2f, 0.0f, 1.0f) * 0.9f;
      pp.fade = clampf((screenTime_ - 2.2f) / 0.6f, 0.0f, 1.0f);
      break;
    case Screen::Transition:
      pp.fade = clampf(1.0f - (transitionTime_ - 3.6f) / 1.4f, 0.0f, 1.0f);
      pp.staticAmt = clampf(0.4f - (transitionTime_ - 3.6f), 0.0f, 0.4f) * (transitionTime_ > 3.6f ? 1.0f : 0.0f);
      break;
    case Screen::Ending: endingCamera(camPos, camDir, fov, pp); break;
    case Screen::Slide: slideCamera(camPos, camDir); fov = 88.0f; pp.fear = 0.2f; pp.exposure = 1.0f; break;
    case Screen::Plunge: {
      if (dropping_) { dropCamera(camPos, camDir, camUp_, fov, pp); break; }
      float k = clampf(plungeT_ / 3.4f, 0, 1);
      camPos = {pos_.x, plungeY_, pos_.z};
      float pitch = lerpf(-1.28f, -0.12f, std::pow(k, 3.0f)) + std::sin(time_ * 23.0f) * 0.01f * k;
      float yaw = yaw_ + std::sin(plungeT_ * 0.8f) * 0.15f * (1 - k);
      camDir = {-std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
      fov = 78.0f + 14.0f * k;
      pp.fear = 0.25f + 0.5f * k;
      pp.staticAmt = std::max(0.0f, 0.5f - plungeT_ * 0.8f) + (k > 0.97f ? 0.4f : 0.0f);
      pp.exposure = 1.1f;
    } break;
    default: break;
  }
  if (screen_ == Screen::Playing) pp.staticAmt = std::max(pp.staticAmt, scareStatic());  // tracking glitch (game_scares.cpp)
  {  // knocks and panic: the tape mechanism jumps (decays over a few fields)
    float rdt = clampf(time_ - lastJoltT_, 0.0f, 0.1f);
    lastJoltT_ = time_;
    if (screen_ == Screen::Playing && fear_ - prevFear_ > 0.12f) jolt_ = std::max(jolt_, 0.75f);  // a sudden fright: your hands jerk
    if (screen_ == Screen::Caught && screenTime_ < 0.3f) jolt_ = 1.0f;
    prevFear_ = fear_;
    if (const char* j = std::getenv("BR9_JOLT")) jolt_ = std::max(jolt_, (float)std::atof(j));
    pp.jolt = jolt_;
    jolt_ = std::max(0.0f, jolt_ - rdt * 3.2f);
    if (scarAmt_ > 0.35f) scarAmt_ -= rdt * 0.008f;  // it settles to a faint line that stays
    if (const char* sc = std::getenv("BR9_SCAR")) { scarAmt_ = (float)std::atof(sc); scarY_ = 0.4f; }
    if (pp.vhs) { pp.scar = scarAmt_; pp.scarY = scarY_; }
    // in the dark the shutter slows and the gain climbs: moving things smear
    pp.lag = clampf((exposure_ - 1.15f) / 1.3f, 0.0f, 1.0f) * 0.6f;
    // each stretch of the tape is worn differently; the park at the start is near the beginning, barely played
    uint32_t th = (uint32_t)(levelIndex_ * 7919 + 13) ^ (uint32_t)level_.seed * 2654435761u;
    pp.tapeWear = inPark() ? 0.12f : 0.2f + 0.65f * (float)((th >> 8) % 1000) / 1000.0f;
    pp.tapeSeed = (float)(th % 997) * 0.37f;
    if (const char* w = std::getenv("BR9_WEAR")) pp.tapeWear = (float)std::atof(w);
  }

  mat4 prevVP = viewProj_;
  drawScene(camPos, camDir, fov, time_, pp);
  {
    Surf f = level_.theme.floor;
    pp.wet = wetLens_;
    pp.gradeGain = level_.theme.gradeGain;
    pp.gradeLift = level_.theme.gradeLift;
    pp.floorGloss = f == Surf::Vinyl ? 0.6f : (f == Surf::Tile || f == Surf::PoolTile) ? 0.75f : f == Surf::Wood ? 0.45f : f == Surf::ConcreteFloor ? 0.28f : 0.0f;
    static const bool sharp = std::getenv("BR9_SHARP") != nullptr;  // model close-ups: no smear, no lag, no hunting focus
    pp.motion = sharp ? 0.0f : 0.65f;
    if (sharp) { pp.lag = 0.0f; pp.focus = 0.0f; pp.jolt = 0.0f; }
    pp.prevViewProj = prevVP;
    pp.hasPrev = hasPrevVP_ && screen_ != Screen::Transition && !sharp;
    hasPrevVP_ = true;
  }
  // The in-game overlay: with the camcorder filter on it's drawn onto the tape, so it bends,
  // smears, fringes and jitters with the picture. Menus, notes and the title stay crisp.
  bool tapeHud = pp.vhs;
  auto gameHud = [&]() {
    switch (screen_) {
      case Screen::Playing:
        if (std::getenv("BR9_NOHUD")) { if (!inStore()) suitHUD(); break; }  // clean capture still sees through the visor
        drawHUD();
        if (!std::getenv("BR9_NOHUD")) drawEndlessHUD();
        break;
      case Screen::Paused: case Screen::Reading: drawHUD(); break;
      case Screen::Plunge: drawPlungeHUD(); break;
      default: break;
    }
  };
  if (tapeHud) {
    R_->beginTapeUI();
    int fullW = R_->winW;
    int frameW = pp.frame43 ? std::min(fullW, R_->winH * 4 / 3) : fullW;
    R_->uiOffX = (fullW - frameW) / 2;  // the OSD sits inside the 4:3 picture
    R_->winW = frameW;
    gameHud();
    R_->endUI();
    R_->winW = fullW;
    R_->uiOffX = 0;
    R_->endTapeUI();
  }
  R_->present(pp);

  R_->beginUI();
  if (!tapeHud) gameHud();
  switch (screen_) {
    case Screen::Title: drawTitle(); break;
    case Screen::Paused: drawMenu(cheatsOpen_ ? "CHEATS" : (optionsOpen_ ? "OPTIONS" : "PAUSED"), 1.0f); break;
    case Screen::Reading: drawNote(); break;
    case Screen::Transition: drawTransition(); break;
    case Screen::Ending: drawEnding(); break;
    default: break;
  }
  if (badgeT_ > 0) drawBadgePopup();
  R_->endUI();
}

void Game::drawHUD() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  bool osdVhs = settings.vhs && !std::getenv("BR9_NOVHS");
  float m = (osdVhs ? 28.0f : 12.0f) * s;  // keep the camcorder text inside the rounded picture
  // VCR on-screen display: soft, smeared, colour-fringed, like text recorded onto the tape
  auto osd = [&](const std::string& str, float x, float y, float r, float g, float b) {
    vt(str, x, y, s, r, g, b, osdVhs ? 0.95f : 1.0f);  // on tape, the shader smears and fringes it
  };
  float sz = 8.0f * s;
  const float wr = 0.92f, wg = 0.92f, wb = 0.88f;
  suitHUD();  // the visor goes under everything else
  if (funLevel() && cheats_.gun && screen_ == Screen::Playing && hiding_ < 0) {  // fun mode: a small crosshair, red on a hit
    float cx = W * 0.5f, cy = H * 0.5f, l = 6.0f * s, w = std::max(1.0f, 1.0f * s), g = 3.0f * s;
    float hr = hitMark_ > 0 ? 1.0f : 0.92f, hg = hitMark_ > 0 ? 0.15f : 0.92f, hb = hitMark_ > 0 ? 0.1f : 0.88f;
    R_->rect(cx - g - l, cy - w * 0.5f, l, w, hr, hg, hb, 0.85f);
    R_->rect(cx + g, cy - w * 0.5f, l, w, hr, hg, hb, 0.85f);
    R_->rect(cx - w * 0.5f, cy - g - l, w, l, hr, hg, hb, 0.85f);
    R_->rect(cx - w * 0.5f, cy + g, w, l, hr, hg, hb, 0.85f);
    if (bhopSpeedShow_) {
      char sb[32];
      std::snprintf(sb, sizeof sb, "%.1f M/S", length(vel_));
      vt(sb, cx - vw(sb, s) * 0.5f, cy + 40.0f * s, s, 0.92f, 0.92f, 0.88f, 0.7f);
    }
  }

  if (alarm_ > 0) {  // red edge flash
    float a = 0.25f * (0.5f + 0.5f * std::sin(time_ * 14.0f)) * std::min(alarm_, 1.0f);
    float b = 40.0f * s;
    R_->rect(0, 0, W, b, 0.9f, 0.05f, 0.05f, a);
    R_->rect(0, H - b, W, b, 0.9f, 0.05f, 0.05f, a);
    R_->rect(0, b, b, H - 2 * b, 0.9f, 0.05f, 0.05f, a);
    R_->rect(W - b, b, b, H - 2 * b, 0.9f, 0.05f, 0.05f, a);
  }

  if (savedFlash_ > 0) {
    std::string sv = "SAVED";
    float a = clampf(savedFlash_ / 0.4f, 0, 1);
    vt(sv, W * 0.5f - vw(sv, s) * 0.5f, m, s, 0.75f, 0.9f, 0.75f, a * 0.8f);
  }
  if (osdVhs) {
    // PLAY > / SP, VCR TAPE: the tape is being played back, not recorded
    osd("PLAY", m, m, wr, wg, wb);
    for (int k = 0; k < 7; ++k) {  // the little play triangle
      float h = (13 - 2 * k) * s;
      R_->rect(m + sz * 5.4f + k * s, m + (13 * s - h) * 0.5f - 2.5f * s, s, h, wr, wg, wb, 0.8f);
    }
    osd("SP", m, m + sz * 1.9f, wr, wg, wb);
  } else {
    if (std::fmod(time_, 1.2f) < 0.8f) R_->rect(m, m, sz, sz, 0.9f, 0.1f, 0.1f, 0.95f);
    vt("REC", m + sz * 1.6f, m, s, wr, wg, wb);
  }

  if (osdVhs) osd("VCR TAPE", W - m - vw("VCR TAPE", s), m, wr, wg, wb);
  float bw = 24.0f * s, bh = 10.0f * s, bx = W - m - bw - 3 * s, by = m + (osdVhs ? sz * 1.9f : 0.0f);
  float t = std::max(1.0f, s * 0.75f);
  bool low = battery_ < 0.2f;
  float cr = low ? 0.95f : wr, cg = low ? 0.25f : wg, cb = low ? 0.2f : wb;
  R_->rect(bx, by, bw, t, cr, cg, cb, 0.9f);
  R_->rect(bx, by + bh - t, bw, t, cr, cg, cb, 0.9f);
  R_->rect(bx, by, t, bh, cr, cg, cb, 0.9f);
  R_->rect(bx + bw - t, by, t, bh, cr, cg, cb, 0.9f);
  R_->rect(bx + bw, by + bh * 0.3f, 3 * s, bh * 0.4f, cr, cg, cb, 0.9f);
  int bars = (int)std::ceil(battery_ * 4.0f - 0.001f);
  for (int i = 0; i < bars; ++i) R_->rect(bx + 2 * t + i * (bw - 3 * t) / 4.0f, by + 2 * t, (bw - 3 * t) / 4.0f - t, bh - 4 * t, cr, cg, cb, 0.9f);


  char buf[96];
  int secs = (int)totalTime_;
  std::snprintf(buf, sizeof buf, "SP %d:%02d:%02d  %s", secs / 3600, (secs / 60) % 60, secs % 60, level_.theme.name.c_str());
  float leftW = vw(buf, s);
  if (osdVhs) {
    // the tape counter, top left under SP
    char ctr[32];
    std::snprintf(ctr, sizeof ctr, "%d:%02d:%02d", secs / 3600, (secs / 60) % 60, secs % 60);
    osd(ctr, m, m + sz * 3.8f, wr, wg, wb);
    if (settings.dateStamp) {
      // Burned into the picture by the camera when it was recorded: chunky, yellowish, black-edged,
      // bottom right. Saturday the 31st of October, 1998; it was 2:47 in the afternoon at the park.
      int clk = 14 * 3600 + 47 * 60 + secs;
      int hh = (clk / 3600) % 24, h12 = hh % 12 == 0 ? 12 : hh % 12;
      int day = 31 + clk / 86400;
      char tl[32], dl[32];
      std::snprintf(tl, sizeof tl, "%d:%02d:%02d %s", h12, (clk / 60) % 60, clk % 60, hh < 12 ? "AM" : "PM");
      if (day <= 31) std::snprintf(dl, sizeof dl, "OCT.%d 1998", day);
      else std::snprintf(dl, sizeof dl, "NOV.%2d 1998", day - 31);
      float px = std::max(14.0f, H * 0.046f);
      float x0 = W - m - std::max(vcrWidth(tl, px), vcrWidth(dl, px));
      float y1 = H - m - px * 1.05f, y0 = y1 - px * 1.12f;
      vcrText(tl, x0, y0, px, 0.98f, 0.9f, 0.52f, 0.92f, px * 0.05f, px * 0.05f);
      vcrText(dl, x0, y1, px, 0.98f, 0.9f, 0.52f, 0.92f, px * 0.05f, px * 0.05f);
    } else if (std::fmod(time_, 1.0f) < 0.6f) {
      osd("-:-- --", W - m - vw("-:-- --", s), H - m - sz, wr, wg, wb);  // the clock was never set
    }
  } else {
    vt(buf, m, H - m - sz, s, wr, wg, wb);
  }
  int clock = 3 * 3600 + 14 * 60 + secs;
  std::snprintf(buf, sizeof buf, "OCT.24 1996  %d:%02d:%02d AM", (clock / 3600) % 12 == 0 ? 12 : (clock / 3600) % 12, (clock / 60) % 60, clock % 60);
  bool narrow = leftW + vw(buf, s) + 3 * m > W;  // portrait screens: stack the camcorder lines
  if (!osdVhs) vt(buf, W - m - vw(buf, s), H - m - sz - (narrow ? sz * 1.6f : 0.0f), s, wr, wg, wb);

  R_->rect(W * 0.5f - s, H * 0.5f - s, 2 * s, 2 * s, 1, 1, 1, 0.35f);

  if (stamina_ < 0.995f) {
    float sw = 120.0f * s, sh = 3.0f * s, sx = W * 0.5f - sw * 0.5f, sy = H - m - sz * 3.2f;
    R_->rect(sx, sy, sw, sh, 1, 1, 1, 0.15f);
    R_->rect(sx, sy, sw * stamina_, sh, exhausted_ ? 0.9f : wr, exhausted_ ? 0.3f : wg, exhausted_ ? 0.25f : wb, 0.7f);
  }

  std::string prompt;
  const char* key = usingPad_ ? "[A]" : "[E]";
  if (screen_ == Screen::Playing && focusItem_ >= 0) {
    switch (items_[focusItem_].type) {
      case ITEM_NOTE: prompt = std::string(key) + " READ NOTE"; break;
      case ITEM_BATTERY: prompt = std::string(key) + " TAKE BATTERY"; break;
      case ITEM_WATER: prompt = std::string(key) + " DRINK ALMOND WATER"; break;
      case ITEM_TAPE: prompt = std::string(key) + " PICK UP THE TAPE"; break;
    }
  } else if (screen_ == Screen::Playing) {
    vec3 d = level_.delta(pos_, level_.exitFaceCenter());
    if (inPark()) { if (std::sqrt(d.x * d.x + d.z * d.z) < 3.0f) prompt = "THERE'S A GAP BEHIND THE PAD. IT GOES DOWN A LONG WAY."; }
    else if (std::sqrt(d.x * d.x + d.z * d.z) < 4.5f && levelIndex_ != kChoiceLevel) prompt = "SOMEONE TAPED A DOOR ON THIS WALL";
  }
  if (!prompt.empty()) vt(prompt, W * 0.5f - vw(prompt, s) * 0.5f, H * 0.62f, s, wr, wg, wb, 0.9f);

  static const bool cleanCapture = std::getenv("BR9_CLEAN") != nullptr;  // trailers: no tutorial text
  if (hintTimer_ > 0 && screen_ == Screen::Playing && !cleanCapture) {
    float a = clampf(hintTimer_ / 2.0f, 0, 1) * clampf((9.0f - hintTimer_) / 1.0f, 0, 1);
    std::string h1 = "FIND A WAY OUT.";
    std::string h2 = levelIndex_ == 0 ? (usingPad_ ? "LS MOVE  L3 RUN  B CROUCH  A USE" : "WASD MOVE  SHIFT RUN  CTRL CROUCH  E USE")
                                      : "SOMEBODY GOT OUT OF HERE. FOLLOW WHAT THEY LEFT BEHIND.";
    vt(h1, W * 0.5f - vw(h1, s * 1.5f) * 0.5f, H * 0.28f, s * 1.5f, wr, wg, wb, a);
    float s2 = std::min(s, W * 0.92f / std::max(1.0f, vw(h2, 1.0f)));
    vt(h2, W * 0.5f - vw(h2, s2) * 0.5f, H * 0.28f + sz * 2.5f, s2, wr, wg, wb, a * 0.7f);
  }
  if (toastTime_ > 0) {
    float a = clampf(toastTime_, 0, 1);
    bool danger = toast_.find("RUN") != std::string::npos;
    vt(toast_, W * 0.5f - vw(toast_, s * (danger ? 1.5f : 1.0f)) * 0.5f, H * 0.2f, s * (danger ? 1.5f : 1.0f),
             danger ? 1.0f : wr, danger ? 0.3f : wg, danger ? 0.25f : wb, a);
  }
  scaresHUD();
  rayHUD();
}


void Game::drawNote() {
  if (readingTape_ >= 0) { drawTape(readingTape_, screenTime_, false); return; }
  if (readingNote_ < 0 || readingNote_ >= (int)level_.theme.notes.size()) return;
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  R_->rect(0, 0, W, H, 0, 0, 0, 0.7f);
  float pw = 48 * 8.0f * s, ph = 15 * 12.0f * s;
  if (pw > W * 0.95f) { s = std::max(1.0f, s - 1); pw = 48 * 8.0f * s; ph = 15 * 12.0f * s; }
  float px = (W - pw) * 0.5f, py = (H - ph) * 0.5f;
  R_->rect(px + 6 * s, py + 6 * s, pw, ph, 0, 0, 0, 0.5f);
  R_->rect(px, py, pw, ph, 0.86f, 0.83f, 0.72f, 1.0f);
  for (int i = 0; i < 13; ++i) R_->rect(px, py + 30.0f * s + i * 12.0f * s, pw, std::max(1.0f, s * 0.5f), 0.55f, 0.65f, 0.8f, 0.35f);
  const NoteText& n = level_.theme.notes[readingNote_];
  R_->text(n.title, px + 16 * s, py + 12 * s, s, 0.55f, 0.08f, 0.06f);
  R_->text(n.body, px + 16 * s, py + 34 * s, s, 0.12f, 0.1f, 0.09f);
  std::string f = usingPad_ ? "[A] CLOSE" : "[E] CLOSE";
  R_->text(f, W * 0.5f - R_->textWidth(f, s) * 0.5f, py + ph + 14 * s, s, 0.9f, 0.9f, 0.85f, 0.8f);
}


void Game::drawTransition() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  float t = transitionTime_;
  float a = clampf(t / 0.6f, 0, 1) * clampf((4.4f - t) / 0.6f, 0, 1);
  if (t < 3.6f) R_->rect(0, 0, W, H, 0, 0, 0, 1);
  auto center = [&](const std::string& str, float y, float sc, float r, float g, float b, float al) {
    vt(str, W * 0.5f - vw(str, sc) * 0.5f, y, sc, r, g, b, al);
  };
  if (!prevTitle_.empty()) {
    char buf[96];
    std::snprintf(buf, sizeof buf, "LEFT %s    NOTES %d/%d    %d:%02d", prevTitle_.c_str(), prevNotes_, prevNoteTotal_, (int)prevTime_ / 60,
                  (int)prevTime_ % 60);
    center(buf, H * 0.26f, s, 0.6f, 0.58f, 0.5f, a * 0.8f);
  }
  // Typewriter title.
  std::string name = level_.theme.name, title = level_.theme.title;
  size_t n1 = (size_t)clampf((t - 0.5f) * 12.0f, 0, (float)name.size());
  size_t n2 = (size_t)clampf((t - 1.2f) * 14.0f, 0, (float)title.size());
  center(name.substr(0, n1), H * 0.40f, s * 3.0f, 0.95f, 0.92f, 0.82f, a);
  center(title.substr(0, n2), H * 0.40f + 34.0f * s, s * 1.5f, 0.85f, 0.75f, 0.5f, a);
  if (t > 2.4f) center("THE BACKROOMS GO ON.", H * 0.62f, s, 0.55f, 0.52f, 0.45f, a * clampf(t - 2.4f, 0, 1));
}

void Game::debugReport() const {
  std::fprintf(stderr, "[br9] state: level %d, player (%.2f, %.2f) of (%.0f x %.0f), screen %d, notes %d, stalkers active %d\n",
               levelIndex_, pos_.x, pos_.z, level_.periodX, level_.periodZ, (int)screen_, notesFound(),
               (int)std::count_if(stalkers_.begin(), stalkers_.end(), [](const Stalker& s) { return s.active(); }));
}


// ================================================================ the drop
void Game::startPlunge() {
  dropping_ = false;
  screen_ = Screen::Plunge;
  screenTime_ = 0;
  plungeT_ = 0;
  plungeY_ = 30.0f;  // about a hundred feet
  hasPrevVP_ = false;
  setMouseCapture(true);
  if (A_) { A_->play(Sfx::Whoosh, 1.1f); A_->play(Sfx::Whoosh, 0.8f, 0, 0.6f); }
}

void Game::updatePlunge(float dt) {
  plungeT_ += dt;
  const float T = 3.4f, top = 30.0f, eye = 1.2f;
  float k = clampf(plungeT_ / T, 0, 1);
  plungeY_ = top - (top - eye) * k * k;  // accelerating
  updateLights(dt);
  if (dropping_) { updateDrop(dt); return; }
  if (plungeT_ >= T) {
    startDrop();  // the camcorder goes flying (game_drop.cpp)
    if (const char* e = std::getenv("BR9_DROPT")) dropT_ = (float)std::atof(e);
  }
}

void Game::drawPlungeHUD() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  float a = clampf(plungeT_ / 0.4f, 0, 1) * clampf((3.0f - plungeT_) / 0.6f, 0, 1);
  std::string t1 = level_.theme.name, t2 = level_.theme.title;
  vt(t1, W * 0.5f - vw(t1, s * 3) * 0.5f, H * 0.18f, s * 3, 0.95f, 0.92f, 0.82f, a);
  vt(t2, W * 0.5f - vw(t2, s * 1.5f) * 0.5f, H * 0.18f + 34 * s, s * 1.5f, 0.85f, 0.8f, 0.65f, a * 0.85f);
  dropHUD();  // title card while the camera's on the floor (game_drop.cpp)
  if (endless_) {
    char buf[32];
    std::snprintf(buf, sizeof buf, "DEPTH %d", depth_);
    vt(buf, W * 0.5f - vw(buf, s * 2) * 0.5f, H * 0.18f + 60 * s, s * 2, 1.0f, 0.82f, 0.3f, a);
  }
}

void Game::chooseRed() {
  // Go back down for him: the floor opens, and you fall into the level where you left him.
  wentBack_ = true;
  int target = 1 + (int)((level_.seed >> 7) % 2u);  // he's somewhere in the middle: Level 1 or 2
  rayLevel_ = target;
  rayState_ = 0;  // he's still down there; placeRay() puts him back on that level
  if (A_) { A_->play(Sfx::Brownout, 1.0f); A_->play(Sfx::Noclip, 1.0f); }
  loadLevel(target, (level_.seed * 2246822519u + 3u) | 1u);
  battery_ = 1.0f;
  flashOn_ = defaultLight();
  startPlunge();
}

void Game::chooseBlue() {
  chooseHome_ = true;
  if (A_) A_->play(Sfx::Whoosh, 0.9f);
  beginEnding();
}


// ================================================================ Level 188: the atrium
void Game::buildCourtyard() {
  courtWalls_.destroy(); courtFloor_.destroy(); courtCeil_.destroy();
  const auto& c = level_.court;
  if (!c.on) return;
  if (!texFacade_) {
    texFacade_ = makeTexture(texgen::facade(1024, 1024, 188, 20.0f, 21.0f), true, false);
    texCourt_ = makeTexture(texgen::courtyardFloor(1024, 188), true, false);
    texCourtCeil_ = makeTexture(texgen::solid(196, 188, 200), false, false);
    Image g; g.w = g.h = 4; g.px.assign(64, 255); for (int i = 3; i < 64; i += 4) g.px[i] = 46;
    texGlass_ = makeTexture(g, false, false);
  }
  float x0 = c.x0 * Level::kTile, z0 = c.z0 * Level::kTile, x1 = (c.x0 + c.n) * Level::kTile, z1 = (c.z0 + c.n) * Level::kTile;
  float fy = c.floorY, ty = c.topY, bh = level_.wallH, span = ty - fy;
  Mesh walls, floor, ceil;
  auto wallQuad = [&](vec3 a, vec3 b, float y0, float y1, vec3 n) {
    float v0 = (y0 - fy) / span, v1 = (y1 - fy) / span;
    walls.quad({a.x, y0, a.z}, {b.x, y0, b.z}, {b.x, y1, b.z}, {a.x, y1, a.z}, n, {0, 1 - v0}, {1, 1 - v0}, {1, 1 - v1}, {0, 1 - v1}, 1, 1, 1, 1);
  };
  struct Side { vec3 a, b, n; } sides[4] = {{{x0, 0, z0}, {x1, 0, z0}, {0, 0, 1}}, {{x1, 0, z1}, {x0, 0, z1}, {0, 0, -1}},
                                            {{x0, 0, z1}, {x0, 0, z0}, {1, 0, 0}}, {{x1, 0, z0}, {x1, 0, z1}, {-1, 0, 0}}};
  for (auto& sd : sides) { wallQuad(sd.a, sd.b, fy, 0.0f, sd.n); wallQuad(sd.a, sd.b, bh, ty, sd.n); }
  floor.quad({x0, fy, z0}, {x1, fy, z0}, {x1, fy, z1}, {x0, fy, z1}, {0, 1, 0}, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1);
  ceil.quad({x0, ty, z0}, {x1, ty, z0}, {x1, ty, z1}, {x0, ty, z1}, {0, -1, 0}, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1);
  courtWalls_.upload(walls); courtFloor_.upload(floor); courtCeil_.upload(ceil);
}

void Game::drawCourtyard(Shader& S, vec3 cam) {
  const auto& c = level_.court;
  if (!c.on || !courtWalls_.count) return;
  vec3 center{(c.x0 + c.n * 0.5f) * Level::kTile, 0, (c.z0 + c.n * 0.5f) * Level::kTile};
  vec3 off = near(center, cam) - center;
  glDisable(GL_CULL_FACE);
  S.set("uSkinned", 0);
  S.set("uMat", MAT_SCREEN);
  S.set("uUVScale", 1.0f);
  S.set("uModel", translate(off));
  glBindTexture(GL_TEXTURE_2D, texFacade_);
  S.set("uEmissive", 0.62f);
  courtWalls_.draw();
  glBindTexture(GL_TEXTURE_2D, texCourt_);
  S.set("uEmissive", 0.5f);
  courtFloor_.draw();
  glBindTexture(GL_TEXTURE_2D, texCourtCeil_);
  S.set("uEmissive", 0.55f);
  courtCeil_.draw();
  // the railing: chrome handrail, glass, and the blue LED strip
  float x0 = c.x0 * Level::kTile + off.x, z0 = c.z0 * Level::kTile + off.z;
  float x1 = (c.x0 + c.n) * Level::kTile + off.x, z1 = (c.z0 + c.n) * Level::kTile + off.z;
  float len = c.n * Level::kTile;
  S.set("uMat", MAT_PROP);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  struct Edge { vec3 mid; bool alongX; } edges[4] = {{{(x0 + x1) * 0.5f, 0, z0}, true}, {{(x0 + x1) * 0.5f, 0, z1}, true},
                                                     {{x0, 0, (z0 + z1) * 0.5f}, false}, {{x1, 0, (z0 + z1) * 0.5f}, false}};
  for (auto& e : edges) {
    vec3 sz = e.alongX ? vec3{len + 0.1f, 0.05f, 0.06f} : vec3{0.06f, 0.05f, len + 0.1f};
    drawPart(translate(e.mid + vec3{0, 1.07f, 0}) * scale(sz), {0.78f, 0.78f, 0.84f}, 0.1f);                          // handrail
    vec3 led = e.alongX ? vec3{len, 0.012f, 0.02f} : vec3{0.02f, 0.012f, len};
    drawPart(translate(e.mid + vec3{0, 1.035f, 0}) * scale(led), {0.22f, 0.32f, 1.0f}, 5.0f);                          // blue LED
    drawPart(translate(e.mid + vec3{0, 0.06f, 0}) * scale(led), {0.22f, 0.32f, 1.0f}, 2.5f);
    for (float k = -len * 0.5f; k <= len * 0.5f + 0.01f; k += 2.0f) {                                                  // posts
      vec3 p = e.mid + (e.alongX ? vec3{k, 0.53f, 0} : vec3{0, 0.53f, k});
      drawPart(translate(p) * scale({0.04f, 1.06f, 0.04f}), {0.7f, 0.7f, 0.75f});
    }
  }
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDepthMask(GL_FALSE);
  S.set("uMat", MAT_DECAL);
  glBindTexture(GL_TEXTURE_2D, texGlass_);
  S.set("uTint", vec3{0.72f, 0.82f, 0.86f});
  S.set("uEmissive", 0.12f);
  S.set("uFlipU", 0);
  for (auto& e : edges) {
    vec3 n = e.alongX ? vec3{0, 0, 1} : vec3{1, 0, 0};
    vec3 r = cross(vec3{0, 1, 0}, n);
    mat4 m = mat4::identity();
    m.m[0] = r.x * len; m.m[1] = r.y * len; m.m[2] = r.z * len;
    m.m[4] = 0; m.m[5] = 1.0f; m.m[6] = 0;
    m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
    m.m[12] = e.mid.x; m.m[13] = 0.52f; m.m[14] = e.mid.z;
    S.set("uModel", m);
    quad_.draw();
  }
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
  glEnable(GL_CULL_FACE);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
}


// ================================================================ the slides
int Game::focusTube() const {
  if (levelIndex_ != kChoiceLevel) return -1;
  vec3 e = eye(), f = forward();
  for (int k = 0; k < 3; ++k) {
    vec3 d = level_.delta(e, level_.tubes[k]);
    d.y = level_.tubes[k].y - e.y;
    float dl = length(d);
    if (dl < 2.0f && dot(d * (1.0f / dl), f) > 0.8f) return k;
  }
  return -1;
}

void Game::enterSlide(int which) {
  slideWhich_ = which;
  slideT2_ = 0;
  screen_ = Screen::Slide;
  screenTime_ = 0;
  hasPrevVP_ = false;
  slideBase_ = vec3{pos_.x, -220.0f, pos_.z};  // far below everything
  if (!slideMesh_.count) {
    // two and a half turns of helix, dropping as it goes
    Mesh m;
    const int segs = 160, ring = 18;
    const float R = 2.6f, drop = 16.0f, turns = 2.5f, rad = 0.75f;
    auto C = [&](float s) { float a = s * turns * 6.2831853f; return vec3{R * std::cos(a), -drop * s, R * std::sin(a)}; };
    for (int i = 0; i < segs; ++i) {
      float s0 = (float)i / segs, s1 = (float)(i + 1) / segs;
      vec3 c0 = C(s0), c1 = C(s1);
      vec3 t0 = normalize(C(s0 + 0.001f) - c0), t1 = normalize(C(s1 + 0.001f) - c1);
      vec3 n0 = normalize(cross(t0, vec3{0, 1, 0})), n1 = normalize(cross(t1, vec3{0, 1, 0}));
      vec3 b0 = cross(n0, t0), b1 = cross(n1, t1);
      for (int j = 0; j < ring; ++j) {
        float a0 = j * 6.2831853f / ring, a1 = (j + 1) * 6.2831853f / ring;
        auto P = [&](vec3 c, vec3 n, vec3 b, float a) { return c + (n * std::cos(a) + b * std::sin(a)) * rad; };
        vec3 p00 = P(c0, n0, b0, a0), p01 = P(c0, n0, b0, a1), p11 = P(c1, n1, b1, a1), p10 = P(c1, n1, b1, a0);
        vec3 nn = normalize(c0 - p00);
        m.quad(p00, p01, p11, p10, nn, {(float)j / ring, s0 * 8}, {(float)(j + 1) / ring, s0 * 8}, {(float)(j + 1) / ring, s1 * 8}, {(float)j / ring, s1 * 8}, 1, 1, 1, 1);
      }
    }
    slideMesh_.upload(m);
    texTube_[0] = makeTexture(texgen::slideTube(64, 256, 0.18f, 0.32f, 0.95f), true, true);
    texTube_[1] = makeTexture(texgen::slideTube(64, 256, 0.95f, 0.82f, 0.2f), true, true);
    texTube_[2] = makeTexture(texgen::slideTube(64, 256, 0.14f, 0.7f, 0.2f), true, true);
  }
  if (A_) { A_->play(Sfx::Whoosh, 1.0f, 0, 1.4f); A_->play(Sfx::Splash, 0.4f, 0, 0.5f); }
}

void Game::slideCamera(vec3& pos, vec3& dir) {
  const float R = 2.6f, drop = 16.0f, turns = 2.5f;
  float k = clampf(slideT2_ / 2.8f, 0, 1);
  float s = k * k * (1.5f - 0.5f * k);  // gets faster
  auto C = [&](float u) { float a = u * turns * 6.2831853f; return vec3{R * std::cos(a), -drop * u, R * std::sin(a)}; };
  vec3 c = C(s);
  vec3 t = normalize(C(std::min(s + 0.02f, 1.0f)) - c + vec3{0, -0.001f, 0});
  pos = slideBase_ + c + vec3{0, -0.25f, 0};
  dir = normalize(t + vec3{0, -0.15f, 0});
  yaw_ = std::atan2(-dir.x, -dir.z);
  pitch_ = std::asin(clampf(dir.y, -1, 1));
}

void Game::drawSlide(Shader& S, vec3 cam) {
  (void)cam;
  if (!slideMesh_.count) return;
  glDisable(GL_CULL_FACE);
  S.set("uMat", MAT_SCREEN);
  S.set("uSkinned", 0);
  S.set("uUVScale", 1.0f);
  S.set("uEmissive", 0.85f);
  S.set("uModel", translate(slideBase_));
  glBindTexture(GL_TEXTURE_2D, texTube_[slideWhich_ % 3]);
  slideMesh_.draw();
  S.set("uModel", mat4::identity());
  glEnable(GL_CULL_FACE);
}

void Game::updateSlide(float dt) {
  slideT2_ += dt;
  if (std::fmod(slideT2_, 0.45f) < dt && A_) A_->play(Sfx::Whoosh, 0.35f, std::sin(slideT2_ * 5.0f) * 0.6f, 1.6f);
  if (slideT2_ < 2.8f) return;
  // out the bottom of the tube
  if (slideWhich_ == 2) { chooseRed(); return; }
  if (slideWhich_ == 0) { chooseBlue(); return; }
  // ??? : the yellow slide goes somewhere nobody comes back from the same
  chooseYellow_ = true;
  beginEnding();
}
