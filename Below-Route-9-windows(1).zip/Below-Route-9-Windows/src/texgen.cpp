#include <cstdio>
#include "texgen.h"
#include "mathx.h"
#include "../third_party/font8x8_basic.h"
#include <cstring>
#include <vector>
#include <algorithm>
#include <cmath>

namespace {

// Tileable value noise: lattice wraps at `period`.
float vnoise(float x, float y, int period, uint32_t seed) {
  int xi = (int)std::floor(x), yi = (int)std::floor(y);
  float fx = x - xi, fy = y - yi;
  auto h = [&](int a, int b) {
    a = ((a % period) + period) % period;
    b = ((b % period) + period) % period;
    return hashf(a, b, (int)seed);
  };
  float ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  float a = h(xi, yi), b = h(xi + 1, yi), c = h(xi, yi + 1), d = h(xi + 1, yi + 1);
  return lerpf(lerpf(a, b, ux), lerpf(c, d, ux), uy);
}

// Fractal noise in [0,1], tileable over the unit square for u,v in [0,1).
float fbm(float u, float v, int basePeriod, int octaves, uint32_t seed) {
  float sum = 0, amp = 0.5f, norm = 0;
  int p = basePeriod;
  for (int o = 0; o < octaves; ++o) {
    sum += amp * vnoise(u * p, v * p, p, seed + o * 131u);
    norm += amp;
    amp *= 0.5f;
    p *= 2;
  }
  return sum / norm;
}

uint8_t to8(float v) { return (uint8_t)std::lround(clampf(v, 0, 1) * 255.0f); }

Image make(int s) { Image im; im.w = im.h = s; im.px.resize((size_t)s * s * 4); return im; }
void put(Image& im, int x, int y, float r, float g, float b, float h) {
  size_t i = ((size_t)y * im.w + x) * 4;
  im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = to8(h);
}

}  // namespace

namespace texgen {

// Classic Level 0 wallpaper: pale yellow-green paper printed with thin columns of grey-green
// chevron "feather" motifs, alternate columns offset half a repeat. Clean, a little uneven.
// Covers 1m x 1m of wall.
Image wallpaper(int s, uint32_t seed) {
  Image im = make(s);
  const float cols = 22.0f, reps = 16.0f;  // narrow columns, small repeat: reads as fine print, not big shapes
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float cu = u * cols;
      int col = (int)std::floor(cu);
      float su = cu - col;
      float sv = std::fmod(v * reps + ((col & 1) ? 0.5f : 0.0f), 1.0f);
      float cx = (su - 0.5f) * 2.0f;  // -1..1 across the column
      float ax = std::fabs(cx);
      // two nested downward chevrons and a short stem: a feather / arrowhead
      float c1 = std::fabs(sv - (0.22f + ax * 0.34f));
      float c2 = std::fabs(sv - (0.42f + ax * 0.30f));
      float stroke1 = smoothstepf(0.035f, 0.015f, c1) * smoothstepf(0.92f, 0.7f, ax);
      float stroke2 = smoothstepf(0.028f, 0.012f, c2) * smoothstepf(0.62f, 0.45f, ax);
      float stem = smoothstepf(0.06f, 0.025f, ax) * smoothstepf(0.08f, 0.14f, sv) * smoothstepf(0.62f, 0.52f, sv);
      float dot = smoothstepf(0.05f, 0.02f, std::hypot(cx * 0.5f, sv - 0.8f));
      float motif = std::min(1.0f, std::max(std::max(stroke1, stroke2), std::max(stem * 0.8f, dot * 0.7f)));
      // a faint printed hairline between columns
      float line = std::exp(-std::pow(std::min(su, 1.0f - su) * 90.0f, 2.0f)) * 0.5f;
      float paper = fbm(u, v, 96, 3, seed) - 0.5f;
      float tone = fbm(u, v, 3, 4, seed + 7) - 0.5f;  // very slight unevenness, no stains
      // the seams between strips of paper every half metre: a fine dark line, one edge lifting a little
      float su2 = std::fmod(u, 0.5f);
      float sd = std::min(su2, 0.5f - su2);
      float seam = std::exp(-std::pow(sd * s / 1.2f, 2.0f));
      float lift = su2 < 0.5f - su2 ? 0.0f : std::exp(-std::pow((0.5f - su2) * s / 3.0f, 2.0f)) * (0.5f + 0.5f * fbm(u, v * 3.0f, 8, 2, seed + 13));
      float k = 1.0f + paper * 0.05f + tone * 0.05f - seam * 0.12f + lift * 0.04f;
      float r = 0.84f * k, g = 0.77f * k, b = 0.46f * k;
      // ink: a soft grey-blue print, plainly visible up close (like the photo)
      r = lerpf(r, 0.6f, motif * 0.55f + line * 0.3f);
      g = lerpf(g, 0.64f, motif * 0.55f + line * 0.3f);
      b = lerpf(b, 0.58f, motif * 0.55f + line * 0.3f);
      float height = 0.5f + motif * 0.12f + paper * 0.3f - seam * 0.25f + lift * 0.2f;
      put(im, x, y, r, g, b, height);
    }
  return im;
}

// Flat, clean commercial carpet: even grey-beige, fine fibre, almost no pattern. Covers 1m x 1m.
Image carpet(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float fibre = hashf(x, y, (int)seed);
      float fibre2 = hashf(x / 2, y / 2, (int)seed + 3);
      float tuft = fbm(u, v, 48, 3, seed + 11);
      float tone = fbm(u, v, 3, 4, seed + 19);
      float k = 0.93f + (fibre - 0.5f) * 0.07f + (fibre2 - 0.5f) * 0.05f + (tuft - 0.5f) * 0.08f + (tone - 0.5f) * 0.05f;
      put(im, x, y, 0.62f * k, 0.55f * k, 0.28f * k, fibre * 0.4f + tuft * 0.6f);  // tan, going brown
    }
  return im;
}

// Suspended ceiling: 2x4 ft tiles (0.6 x 1.2 m) in a thin T-bar grid, fine fissured speckle.
// Covers 1.2m x 1.2m (two tiles side by side).
Image ceilingTiles(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float tu = std::fmod(u * 2.0f, 1.0f), tv = v;
      float eu = std::min(tu, 1 - tu) * 0.6f, ev = std::min(tv, 1 - tv) * 1.2f;  // metres to the nearest bar
      float edge = std::min(eu, ev);
      float bar = smoothstepf(0.016f, 0.009f, edge);
      float shade = smoothstepf(0.04f, 0.016f, edge) * (1 - bar);  // tile edge sits a little in shadow
      float speck = hashf(x, y, (int)seed) > 0.88f ? 1.0f : 0.0f;
      float fiss = fbm(u, v, 40, 3, seed + 5);
      float fissure = smoothstepf(0.49f, 0.5f, fiss) * smoothstepf(0.53f, 0.5f, fiss);
      float tone = fbm(u, v, 2, 4, seed + 9) - 0.5f;
      float k = 0.9f - speck * 0.07f - fissure * 0.06f - shade * 0.16f + tone * 0.04f;
      float r = 0.86f * k, g = 0.83f * k, b = 0.64f * k;
      if (bar > 0) { r = lerpf(r, 0.97f, bar); g = lerpf(g, 0.96f, bar); b = lerpf(b, 0.86f, bar); }  // pale painted T-bar
      float h = 0.6f - speck * 0.25f - shade * 0.3f - bar * 0.25f - fissure * 0.15f;
      put(im, x, y, r, g, b, h);
    }
  return im;
}

// Fluorescent troffer: an egg-crate louvre (a grid of small bright cells with thin dark
// dividers) in a metal frame. Luminance only; tinted in the shader.
Image lightPanel(int s) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float frame = std::min(std::min(u, 1 - u), std::min(v, 1 - v) * 0.5f);
      float rim = smoothstepf(0.045f, 0.03f, frame);
      float cu = std::fmod(u * 4.0f, 1.0f), cv = std::fmod(v * 8.0f, 1.0f);
      float div = std::max(smoothstepf(0.07f, 0.03f, std::min(cu, 1 - cu)), smoothstepf(0.07f, 0.03f, std::min(cv, 1 - cv)));
      float cell = 0.85f + 0.15f * (1.0f - std::pow(std::max(std::fabs(cu - 0.5f), std::fabs(cv - 0.5f)) * 2.0f, 3.0f));
      float tube = 0.85f + 0.15f * std::exp(-std::pow((u - 0.5f) * 3.0f, 2.0f));
      float k = lerpf(lerpf(cell * tube, 0.28f, div), 0.15f, rim);
      put(im, x, y, k, k, k, 0.5f);
    }
  return im;
}

// Lined notebook paper with coffee ring and creases.
Image paper(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float n = fbm(u, v, 16, 3, seed) - 0.5f;
      float lines = (std::fmod(v * 18.0f, 1.0f) < 0.06f && v > 0.12f) ? 1.0f : 0.0f;
      float margin = std::fabs(u - 0.14f) < 0.004f ? 1.0f : 0.0f;
      // pseudo handwriting: noisy dark strokes on some lines
      float row = std::floor(v * 18.0f);
      float inRow = std::fmod(v * 18.0f, 1.0f);
      float lineLen = 0.55f + 0.35f * hashf((int)row, 9, (int)seed);
      float write = (row > 2 && row < 16 && u > 0.18f && u < lineLen && inRow > 0.35f && inRow < 0.9f)
                        ? smoothstepf(0.55f, 0.75f, fbm(u * 3.0f, v, 64, 2, seed + (int)row)) : 0.0f;
      float dx = u - 0.72f, dy = v - 0.78f;
      float ringD = std::sqrt(dx * dx + dy * dy);
      float ring = smoothstepf(0.012f, 0.0f, std::fabs(ringD - 0.11f)) * 0.5f;
      float k = 0.93f + n * 0.08f;
      float r = k, g = k * 0.97f, b = k * 0.88f;
      r -= lines * 0.15f; g -= lines * 0.10f; b += lines * 0.02f;
      r += margin * 0.02f; g -= margin * 0.2f; b -= margin * 0.2f;
      r -= write * 0.7f; g -= write * 0.7f; b -= write * 0.55f;
      r -= ring * 0.25f; g -= ring * 0.32f; b -= ring * 0.4f;
      put(im, x, y, r, g, b, 0.5f + n);
    }
  return im;
}

Image grime(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float a = fbm(u, v, 4, 6, seed);
      float b = fbm(u, v, 8, 4, seed + 77);
      put(im, x, y, a, b, smoothstepf(0.6f, 0.75f, a), 1.0f);
    }
  return im;
}

Image solid(uint8_t r, uint8_t g, uint8_t b) {
  Image im = make(4);
  for (int i = 0; i < 16; ++i) { im.px[i * 4] = r; im.px[i * 4 + 1] = g; im.px[i * 4 + 2] = b; im.px[i * 4 + 3] = 128; }
  return im;
}


void tint(Image& im, float r, float g, float b) {
  for (size_t i = 0; i < im.px.size(); i += 4) {
    im.px[i] = to8(im.px[i] / 255.0f * r);
    im.px[i + 1] = to8(im.px[i + 1] / 255.0f * g);
    im.px[i + 2] = to8(im.px[i + 2] / 255.0f * b);
  }
}

// Board-formed concrete: panel seams, tie holes, efflorescence, rust streaks. Covers 1m.
Image concreteWall(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float n = fbm(u, v, 16, 5, seed) - 0.5f;
      float big = fbm(u, v, 2, 4, seed + 3);
      float seamH = smoothstepf(0.006f, 0.0f, std::fabs(std::fmod(v * 2.0f + 0.5f, 1.0f) - 0.5f) - 0.495f + 0.006f);
      float seamV = smoothstepf(0.004f, 0.0f, std::min(u, 1.0f - u));
      float tu = std::fmod(u * 2.0f, 1.0f) - 0.5f, tv = std::fmod(v * 2.0f, 1.0f) - 0.5f;
      float tie = smoothstepf(0.03f, 0.02f, std::sqrt(tu * tu + tv * tv));
      float pores = hashf(x, y, (int)seed) > 0.985f ? 1.0f : 0.0f;
      float streak = smoothstepf(0.6f, 0.9f, fbm(u * 0.3f, v * 0.05f + 0.0f, 32, 2, seed + 9)) * (1.0f - v);
      float k = 0.56f + n * 0.12f + (big - 0.5f) * 0.1f - seamH * 0.15f - seamV * 0.1f - tie * 0.25f - pores * 0.12f;
      float r = k, g = k * 0.985f, b = k * 0.96f;
      r += streak * 0.06f; g += streak * 0.01f; b -= streak * 0.03f;
      put(im, x, y, r, g, b, 0.55f + n * 0.6f - tie * 0.4f - seamH * 0.3f - pores * 0.3f);
    }
  return im;
}

// Soot-stained brick, 4 bricks per metre, running bond.
Image brick(int s, uint32_t seed) {
  Image im = make(s);
  const float rows = 14.0f, cols = 4.0f;
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float row = std::floor(v * rows);
      float uu = u * cols + (std::fmod(row, 2.0f) * 0.5f);
      float col = std::floor(uu);
      float fu = uu - col, fv = v * rows - row;
      float mortar = std::max(smoothstepf(0.06f, 0.0f, std::min(fu, 1.0f - fu) * 0.6f), smoothstepf(0.12f, 0.0f, std::min(fv, 1.0f - fv)));
      float var = hashf((int)col, (int)row, (int)seed);
      float n = fbm(u, v, 32, 3, seed) - 0.5f;
      float soot = fbm(u, v, 2, 4, seed + 5);
      float r = (0.36f + var * 0.12f + n * 0.08f), g = (0.17f + var * 0.05f + n * 0.04f), b = (0.12f + var * 0.03f + n * 0.03f);
      float m = 0.32f + n * 0.05f;
      r = lerpf(r, m, mortar); g = lerpf(g, m * 0.95f, mortar); b = lerpf(b, m * 0.9f, mortar);
      float sk = lerpf(1.0f, 0.45f, smoothstepf(0.45f, 0.8f, soot));
      put(im, x, y, r * sk, g * sk, b * sk, 0.7f - mortar * 0.6f + n * 0.3f);
    }
  return im;
}

// Glossy white pool tiles with grey grout.
Image tiles(int s, uint32_t seed, int perMeter) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * perMeter, v = (y + 0.5f) / s * perMeter;
      float fu = u - std::floor(u), fv = v - std::floor(v);
      float e = std::min(std::min(fu, 1.0f - fu), std::min(fv, 1.0f - fv));
      float grout = smoothstepf(0.045f, 0.02f, e);
      float bevel = smoothstepf(0.12f, 0.045f, e) * (1.0f - grout);
      float var = hashf((int)std::floor(u), (int)std::floor(v), (int)seed);
      float n = fbm((x + 0.5f) / s, (y + 0.5f) / s, 8, 3, seed) - 0.5f;
      float k = 0.88f + var * 0.06f + n * 0.04f - bevel * 0.05f;
      float r = k * 0.97f, g = k, b = k * 1.0f;
      float gr = 0.55f + n * 0.1f;
      r = lerpf(r, gr, grout); g = lerpf(g, gr * 0.98f, grout); b = lerpf(b, gr * 0.92f, grout);
      put(im, x, y, r, g, b, 0.8f - grout * 0.7f - bevel * 0.2f);
    }
  return im;
}

// Poolroom tile: warm cream squares, slightly uneven glaze, thin grey grout.
Image poolTile(int s, uint32_t seed, int perMeter) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * perMeter, v = (y + 0.5f) / s * perMeter;
      float fu = u - std::floor(u), fv = v - std::floor(v);
      float e = std::min(std::min(fu, 1.0f - fu), std::min(fv, 1.0f - fv));
      float grout = smoothstepf(0.03f, 0.012f, e);
      float bevel = smoothstepf(0.09f, 0.03f, e) * (1.0f - grout);
      float var = hashf((int)std::floor(u), (int)std::floor(v), (int)seed);
      float glaze = fbm((x + 0.5f) / s, (y + 0.5f) / s, 8, 3, seed) - 0.5f;
      float k = 0.86f + var * 0.05f + glaze * 0.03f - bevel * 0.04f;
      float r = k * 0.98f, g = k * 0.93f, b = k * 0.82f;
      float gr = 0.5f + glaze * 0.08f;
      r = lerpf(r, gr, grout); g = lerpf(g, gr * 0.97f, grout); b = lerpf(b, gr * 0.9f, grout);
      put(im, x, y, r, g, b, 0.85f - grout * 0.75f - bevel * 0.2f);
    }
  return im;
}

// Pool floor: small sea-green mosaic, crazed and irregular, darker in the joints.
Image poolMosaic(int s, uint32_t seed) {
  Image im = make(s);
  const int per = 10;
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * per, v = (y + 0.5f) / s * per;
      // jitter the grid a little so the tiles are hand-laid
      float ju = u + (fbm((x + 0.5f) / s, (y + 0.5f) / s, 16, 2, seed + 4) - 0.5f) * 0.35f;
      float jv = v + (fbm((x + 0.5f) / s, (y + 0.5f) / s, 16, 2, seed + 9) - 0.5f) * 0.35f;
      float fu = ju - std::floor(ju), fv = jv - std::floor(jv);
      float e = std::min(std::min(fu, 1.0f - fu), std::min(fv, 1.0f - fv));
      float grout = smoothstepf(0.07f, 0.03f, e);
      float var = hashf((int)std::floor(ju), (int)std::floor(jv), (int)seed);
      float n = fbm((x + 0.5f) / s, (y + 0.5f) / s, 4, 3, seed + 1) - 0.5f;
      float r = 0.2f + var * 0.08f + n * 0.04f, g = 0.46f + var * 0.12f + n * 0.05f, b = 0.36f + var * 0.08f + n * 0.04f;
      float gr = 0.32f;
      r = lerpf(r, gr * 0.7f, grout); g = lerpf(g, gr, grout); b = lerpf(b, gr * 0.85f, grout);
      put(im, x, y, r, g, b, 0.75f - grout * 0.6f);
    }
  return im;
}

// The round mouth of a tiled tunnel, going dark.
Image tunnelMouth(int s) {
  Image im;
  im.w = im.h = s;
  im.px.resize((size_t)s * s * 4);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float dx = (x + 0.5f) / s * 2 - 1, dy = (y + 0.5f) / s * 2 - 1;
      float d = std::sqrt(dx * dx + dy * dy);
      float a = d < 0.98f ? 1.0f : 0.0f;
      float depth = std::pow(d, 2.5f);
      float ring = 0.5f + 0.5f * std::cos(std::log(std::max(d, 0.02f)) * 26.0f);
      float seam = 0.5f + 0.5f * std::cos(std::atan2(dy, dx) * 24.0f);
      float tile = (ring > 0.12f && seam > 0.08f) ? 1.0f : 0.6f;
      float k = depth * tile;
      float rim = d > 0.9f ? 0.25f : 0.0f;
      size_t i = ((size_t)y * s + x) * 4;
      im.px[i] = to8(std::sqrt(k * 0.55f + rim * 0.8f));
      im.px[i + 1] = to8(std::sqrt(k * 0.6f + rim * 0.75f));
      im.px[i + 2] = to8(std::sqrt(k * 0.52f + rim * 0.65f));
      im.px[i + 3] = (uint8_t)(a * 255);
    }
  return im;
}

// Sealed concrete slab with saw-cut joints and hairline cracks.
Image concreteFloor(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float n = fbm(u, v, 16, 5, seed) - 0.5f;
      float big = fbm(u, v, 2, 4, seed + 1);
      float joint = smoothstepf(0.004f, 0.0f, std::min(std::min(u, 1.0f - u), std::min(v, 1.0f - v)));
      float c = fbm(u, v, 8, 4, seed + 7);
      float crack = smoothstepf(0.006f, 0.0f, std::fabs(c - 0.5f)) * smoothstepf(0.4f, 0.6f, fbm(u, v, 4, 2, seed + 11));
      float spec = hashf(x, y, (int)seed + 2) > 0.97f ? 0.06f : 0.0f;
      float k = 0.5f + n * 0.1f + (big - 0.5f) * 0.12f - joint * 0.2f - crack * 0.18f + spec;
      put(im, x, y, k, k * 0.98f, k * 0.95f, 0.6f + n * 0.4f - joint * 0.5f - crack * 0.4f);
    }
  return im;
}

Image concreteCeiling(int s, uint32_t seed) {
  Image im = concreteWall(s, seed + 40);
  tint(im, 0.9f, 0.9f, 0.92f);
  return im;
}

namespace {
// Soft spray edge + overspray speckle + drips for a coverage mask.
void sprayify(std::vector<float>& m, int w, int h, uint32_t seed) {
  std::vector<float> t(m.size());
  for (int pass = 0; pass < 2; ++pass) {  // two box blurs: soft edges
    for (int y = 0; y < h; ++y)
      for (int x = 0; x < w; ++x) {
        float s = 0; int n = 0;
        for (int k = -2; k <= 2; ++k) { int xx = x + k; if (xx >= 0 && xx < w) { s += m[y * w + xx]; ++n; } }
        t[y * w + x] = s / n;
      }
    for (int y = 0; y < h; ++y)
      for (int x = 0; x < w; ++x) {
        float s = 0; int n = 0;
        for (int k = -2; k <= 2; ++k) { int yy = y + k; if (yy >= 0 && yy < h) { s += t[yy * w + x]; ++n; } }
        m[y * w + x] = s / n;
      }
  }
  // drips: run down from heavy paint
  for (int x = 0; x < w; ++x) {
    if (hashf(x / 3, 0, (int)seed) > 0.12f) continue;
    int len = (int)(hashf(x, 1, (int)seed) * h * 0.35f);
    for (int y = 0; y < h - 1; ++y) {
      if (m[y * w + x] > 0.8f) {
        for (int k = 1; k < len && y + k < h; ++k) {
          float a = 0.85f * (1.0f - (float)k / len);
          for (int dx = -1; dx <= 1; ++dx)
            if (x + dx >= 0 && x + dx < w) m[(y + k) * w + x + dx] = std::max(m[(y + k) * w + x + dx], a * (dx == 0 ? 1.0f : 0.5f));
        }
        break;
      }
    }
  }
  for (int i = 0; i < w * h; ++i) {
    float speck = hashf(i % w, i / w, (int)seed + 5);
    float edge = m[i] * (1.0f - m[i]) * 4.0f;
    m[i] = clampf(m[i] * 1.25f - 0.1f + (speck - 0.5f) * 0.5f * edge, 0.0f, 1.0f);
    if (m[i] < 0.02f && speck > 0.995f) m[i] = 0.5f;  // stray overspray dots
  }
}
Image fromMask(const std::vector<float>& m, int w, int h) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;  // flip so v=0 is the bottom of the decal
      im.px[i] = im.px[i + 1] = im.px[i + 2] = 255;
      im.px[i + 3] = to8(m[(size_t)y * w + x]);
    }
  return im;
}
}  // namespace

Image paintArrow(int w, int h, uint32_t seed) {
  std::vector<float> m((size_t)w * h, 0.0f);
  float cy = h * 0.42f, th = h * 0.13f;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float wob = std::sin(x * 0.05f + seed) * h * 0.02f;
      bool shaft = x > w * 0.06f && x < w * 0.68f && std::fabs(y - cy - wob) < th;
      float hx = (x - w * 0.62f) / (w * 0.32f);
      bool head = hx >= 0 && hx <= 1 && std::fabs(y - cy) < (1.0f - hx) * h * 0.36f;
      if (shaft || head) m[(size_t)y * w + x] = 1.0f;
    }
  sprayify(m, w, h, seed);
  return fromMask(m, w, h);
}

Image paintText(const char* text, int w, int h, uint32_t seed) {
  std::vector<float> m((size_t)w * h, 0.0f);
  int n = (int)std::strlen(text);
  float cell = std::min((float)w / (n * 8.0f + 2.0f), h / 11.0f);
  float ox = (w - n * 8.0f * cell) * 0.5f, oy = (h - 8.0f * cell) * 0.42f;
  for (int i = 0; i < n; ++i) {
    unsigned char c = (unsigned char)text[i];
    if (c >= 128) continue;
    float jx = (hashf(i, 3, (int)seed) - 0.5f) * cell * 1.2f, jy = (hashf(i, 4, (int)seed) - 0.5f) * cell * 1.6f;
    for (int row = 0; row < 8; ++row)
      for (int col = 0; col < 8; ++col) {
        if (!(font8x8_basic[c][row] & (1 << col))) continue;
        int x0 = (int)(ox + (i * 8 + col) * cell + jx), y0 = (int)(oy + row * cell + jy);
        for (int yy = y0; yy < y0 + (int)std::ceil(cell); ++yy)
          for (int xx = x0; xx < x0 + (int)std::ceil(cell); ++xx)
            if (xx >= 0 && yy >= 0 && xx < w && yy < h) m[(size_t)yy * w + xx] = 1.0f;
      }
  }
  sprayify(m, w, h, seed);
  return fromMask(m, w, h);
}


// ---------------------------------------------------------------- blood (decal masks; tinted dark red)
// A body dragged along the floor: a smear with fibrous streaks running along u, thinning and
// breaking up toward the end (u = 1), a ragged edge, drips off the sides.
Image bloodDrag(int w, int h, uint32_t seed) {
  std::vector<float> m((size_t)w * h, 0.0f);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
      float width = 0.30f + 0.12f * (fbm(u * 1.5f, 0.3f, 4, 3, seed) - 0.5f) * 2.0f;
      width *= 1.0f - 0.45f * u;
      float centre = 0.5f + 0.08f * std::sin(u * 7.0f + seed * 0.1f) + 0.05f * (fbm(u, 0.7f, 6, 2, seed + 3) - 0.5f);
      float edgeN = (fbm(u * 8.0f, v * 2.0f, 8, 3, seed + 5) - 0.5f) * 0.12f;
      float band = smoothstepf(width + 0.02f, width - 0.03f, std::fabs(v - centre) * 2.0f + edgeN);
      float streak = 0.55f + 0.45f * std::sin(v * 140.0f + fbm(u * 2.0f, v * 4.0f, 6, 2, seed + 9) * 9.0f);  // dragged fibres
      float breakup = smoothstepf(0.25f + 0.5f * u, 0.15f + 0.5f * u, fbm(u * 6.0f, v * 3.0f, 10, 3, seed + 13));
      float dense = band * (0.45f + 0.55f * streak) * lerpf(1.0f, breakup, smoothstepf(0.3f, 1.0f, u));
      // drops flicked off to the sides
      float drops = 0.0f;
      for (int k = 0; k < 14; ++k) {
        float du = hashf(k, 1, (int)seed), dv = hashf(k, 2, (int)seed) < 0.5f ? 0.12f + 0.1f * hashf(k, 3, (int)seed) : 0.88f - 0.1f * hashf(k, 3, (int)seed);
        float rr = 0.006f + 0.012f * hashf(k, 4, (int)seed);
        float d2 = ((u - du) * 4.0f) * ((u - du) * 4.0f) + (v - dv) * (v - dv);
        drops = std::max(drops, smoothstepf(rr * rr * 1.4f, rr * rr * 0.6f, d2));
      }
      m[(size_t)y * w + x] = clampf(std::max(dense, drops * 0.9f), 0.0f, 1.0f);
    }
  return fromMask(m, w, h);
}

// Where it hit: a heavy blot with a crown of droplets and short spatter tails.
Image bloodSplat(int s, uint32_t seed) {
  std::vector<float> m((size_t)s * s, 0.0f);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s - 0.5f, v = (y + 0.5f) / s - 0.5f;
      float r = std::sqrt(u * u + v * v), a = std::atan2(v, u);
      float rim = 0.16f + 0.05f * std::sin(a * 7.0f + seed) + 0.04f * (fbm(std::cos(a) + 2.0f, std::sin(a) + 2.0f, 4, 3, seed) - 0.5f) * 4.0f;
      float core = smoothstepf(rim + 0.01f, rim - 0.02f, r);
      float spikes = smoothstepf(0.6f, 0.95f, std::pow(std::fabs(std::sin(a * 11.0f + seed * 0.3f)), 8.0f)) * smoothstepf(0.34f, 0.18f, r) * (r > rim ? 1.0f : 0.0f);
      float drops = 0.0f;
      for (int k = 0; k < 22; ++k) {
        float ang = hashf(k, 5, (int)seed) * 6.2832f, dist = 0.22f + 0.24f * hashf(k, 6, (int)seed);
        float cx = std::cos(ang) * dist, cy = std::sin(ang) * dist, rr = 0.008f + 0.02f * hashf(k, 7, (int)seed) * (1.0f - dist);
        float d2 = (u - cx) * (u - cx) + (v - cy) * (v - cy);
        drops = std::max(drops, smoothstepf(rr * rr * 1.5f, rr * rr * 0.5f, d2));
      }
      m[(size_t)y * s + x] = clampf(std::max(core, std::max(spikes * 0.85f, drops)), 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// A pool that has spread and started to dry at the edges.
Image bloodPool(int s, uint32_t seed) {
  std::vector<float> m((size_t)s * s, 0.0f);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s - 0.5f, v = (y + 0.5f) / s - 0.5f;
      float n = fbm(u + 0.5f, v + 0.5f, 3, 4, seed) - 0.5f;
      float r = std::sqrt(u * u * 1.0f + v * v * 1.3f) + n * 0.22f;
      float body = smoothstepf(0.36f, 0.33f, r);
      float dryRing = smoothstepf(0.30f, 0.34f, r) * body * 0.25f;
      m[(size_t)y * s + x] = clampf(body * 0.95f + dryRing, 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// A bloody handprint, smeared downward as the hand slid (v = 1 is the top).
Image handprint(int s, uint32_t seed) {
  std::vector<float> m((size_t)s * s, 0.0f);
  auto capsule = [](float px, float py, float ax, float ay, float bx, float by, float r) {
    float pax = px - ax, pay = py - ay, bax = bx - ax, bay = by - ay;
    float h = clampf((pax * bax + pay * bay) / (bax * bax + bay * bay), 0.0f, 1.0f);
    float dx = pax - bax * h, dy = pay - bay * h;
    return std::sqrt(dx * dx + dy * dy) - r;
  };
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = 1.0f - (y + 0.5f) / s;  // v up
      float smear = 0.0f;
      float best = 1e9f;
      for (int k = 0; k < 6; ++k) {  // the slide: the print repeated, fainter, lower
        float off = k * 0.06f;
        float vv = v + off;
        float d = capsule(u, vv, 0.5f, 0.42f, 0.5f, 0.52f, 0.13f);  // palm
        const float fx[4] = {0.36f, 0.46f, 0.56f, 0.65f}, fl[4] = {0.17f, 0.2f, 0.19f, 0.14f};
        for (int f = 0; f < 4; ++f) d = std::min(d, capsule(u, vv, fx[f], 0.6f, fx[f] + (f - 1.5f) * 0.03f, 0.6f + fl[f], 0.035f));
        d = std::min(d, capsule(u, vv, 0.34f, 0.44f, 0.22f, 0.56f, 0.04f));  // thumb
        float w = k == 0 ? 1.0f : 0.5f * (1.0f - k / 6.0f);
        float cov = smoothstepf(0.012f, -0.006f, d) * w;
        smear = std::max(smear, cov);
        best = std::min(best, d);
      }
      float skin = 0.75f + 0.25f * (fbm(u * 3.0f, v * 3.0f, 24, 2, seed) > 0.5f ? 1.0f : 0.6f);  // skin ridges / uneven contact
      float drip = 0.0f;
      for (int k = 0; k < 3; ++k) {
        float dx = 0.38f + 0.12f * k + 0.04f * hashf(k, 1, (int)seed);
        float len = 0.15f + 0.25f * hashf(k, 2, (int)seed);
        if (v < 0.42f && v > 0.42f - len) drip = std::max(drip, smoothstepf(0.012f, 0.004f, std::fabs(u - dx)) * (1.0f - (0.42f - v) / len));
      }
      m[(size_t)y * s + x] = clampf(std::max(smear * skin, drip * 0.8f), 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// A left and a right shoe print, toes toward +u, someone walking that way.
Image footprints(int w, int h, uint32_t seed) {
  std::vector<float> m((size_t)w * h, 0.0f);
  const float LW = 0.95f, LH = 0.42f;  // the decal's size in metres
  auto capsule = [](float px, float py, float ax, float ay, float bx, float by, float r) {
    float pax = px - ax, pay = py - ay, bax = bx - ax, bay = by - ay;
    float hh = clampf((pax * bax + pay * bay) / (bax * bax + bay * bay), 0.0f, 1.0f);
    float dx = pax - bax * hh, dy = pay - bay * hh;
    return std::sqrt(dx * dx + dy * dy) - r;
  };
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float X = (x + 0.5f) / w * LW, Y = (1.0f - (y + 0.5f) / h) * LH;
      float cov = 0.0f;
      for (int f = 0; f < 2; ++f) {
        float cx = f ? 0.68f : 0.26f, cy = f ? 0.13f : 0.29f;
        float a = f ? -0.08f : 0.08f;  // toes turned out a little
        float lx = (X - cx) * std::cos(a) + (Y - cy) * std::sin(a), ly = -(X - cx) * std::sin(a) + (Y - cy) * std::cos(a);
        float d = capsule(lx, ly, -0.01f, 0.0f, 0.085f, f ? -0.008f : 0.008f, 0.047f);  // ball of the foot
        d = std::min(d, capsule(lx, ly, -0.125f, 0.0f, -0.085f, 0.0f, 0.039f));         // heel
        float tread = 0.55f + 0.45f * (std::sin(lx * 160.0f + (f ? 1.0f : 0.0f)) > -0.2f ? 1.0f : 0.0f);
        float heelGap = (lx > -0.06f && lx < -0.035f) ? 0.25f : 1.0f;
        float c = smoothstepf(0.006f, -0.004f, d) * tread * heelGap;
        float grit = fbm(X * 9.0f, Y * 9.0f, 20, 3, seed + f) ;
        cov = std::max(cov, c * clampf(0.35f + 0.9f * grit, 0.0f, 1.0f));
      }
      m[(size_t)y * w + x] = clampf(cov * 0.9f, 0.0f, 1.0f);
    }
  return fromMask(m, w, h);
}

Image softDot(int s) {
  std::vector<float> m((size_t)s * s, 0.0f);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * 2.0f - 1.0f, v = (y + 0.5f) / s * 2.0f - 1.0f;
      m[(size_t)y * s + x] = clampf(std::exp(-(u * u + v * v) * 4.0f) * 1.1f - 0.05f, 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// The shadow under a thing standing on the floor: dark in the middle, a long soft falloff.
Image softBlob(int s) {
  std::vector<float> m((size_t)s * s, 0.0f);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * 2.0f - 1.0f, v = (y + 0.5f) / s * 2.0f - 1.0f;
      float r = std::sqrt(std::pow(std::fabs(u), 3.0f) + std::pow(std::fabs(v), 3.0f));  // a rounded square
      r = std::pow(r, 1.0f / 3.0f);
      m[(size_t)y * s + x] = clampf(0.62f * smoothstepf(1.0f, 0.35f, r), 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// A water stain: an irregular blotch, faint inside, with the darker tide-mark rings at its edge.
Image stain(int s, uint32_t seed) {
  std::vector<float> m((size_t)s * s, 0.0f);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s - 0.5f, v = (y + 0.5f) / s - 0.5f;
      float r = std::sqrt(u * u + v * v) * 2.0f;
      float a = std::atan2(v, u);
      float edge = 0.62f + 0.22f * (fbm(0.5f + 0.35f * std::cos(a), 0.5f + 0.35f * std::sin(a), 6, 3, seed) - 0.5f) * 2.0f;
      float d = r - edge;  // < 0 inside
      float inside = smoothstepf(0.02f, -0.05f, d) * (0.18f + 0.25f * fbm(u + 0.5f, v + 0.5f, 8, 3, seed + 1));
      float ring = std::exp(-std::pow(d / 0.025f, 2.0f)) * 0.75f + std::exp(-std::pow((d + 0.12f) / 0.02f, 2.0f)) * 0.3f;
      m[(size_t)y * s + x] = clampf((inside + ring) * smoothstepf(1.0f, 0.85f, r), 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// Blue tape: a strip down the wall with a tab sticking out the way to go.
Image tapeFlag(int s, uint32_t seed) {
  std::vector<float> m((size_t)s * s, 0.0f);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = 1.0f - (y + 0.5f) / s;
      float torn = 0.02f * (hashf(x / 2, 3, (int)seed) - 0.5f), torn2 = 0.02f * (hashf(y / 2, 4, (int)seed) - 0.5f);
      bool strip = u > 0.12f + torn2 && u < 0.21f + torn2 && v > 0.06f + torn && v < 0.94f + torn;
      bool tab = v > 0.71f + torn && v < 0.82f + torn && u > 0.12f && u < 0.9f + torn2 * 2.0f;
      if (!strip && !tab) continue;
      float wr = 0.82f + 0.18f * fbm(u * 6.0f, v * 6.0f, 16, 2, seed);  // creases
      m[(size_t)y * s + x] = clampf(wr, 0.0f, 1.0f);
    }
  return fromMask(m, s, s);
}

// Two frames of this, inside a tracking glitch.
Image faceFlash(int s, uint32_t seed) {
  Image im;
  im.w = im.h = s;
  im.px.resize((size_t)s * s * 4);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s - 0.5f, v = 0.5f - (y + 0.5f) / s;
      float face = std::sqrt(u * u / 0.09f + (v + 0.02f) * (v + 0.02f) / 0.16f);
      float skin = smoothstepf(1.0f, 0.9f, face);
      float shade = 0.75f - 0.4f * face * face + (fbm(u + 0.5f, v + 0.5f, 6, 3, seed) - 0.5f) * 0.25f;
      auto eye = [&](float cx) {
        float d = std::sqrt((u - cx) * (u - cx) / 0.006f + (v - 0.08f) * (v - 0.08f) / 0.009f);
        return smoothstepf(1.0f, 0.75f, d);
      };
      float eyes = std::max(eye(-0.11f), eye(0.11f));
      float mouthW = 0.2f, mouthY = -0.17f + 0.03f * (u / mouthW) * (u / mouthW);  // a smile that goes on too long
      float mouth = smoothstepf(0.03f, 0.015f, std::fabs(v - mouthY)) * smoothstepf(mouthW + 0.02f, mouthW - 0.02f, std::fabs(u));
      float k = clampf(shade, 0.0f, 1.0f) * skin * (1.0f - eyes) * (1.0f - mouth * 0.95f);
      size_t i = ((size_t)(s - 1 - y) * s + x) * 4;
      im.px[i] = to8(k * 0.95f); im.px[i + 1] = to8(k * 0.9f); im.px[i + 2] = to8(k * 0.82f);
      im.px[i + 3] = to8(std::max(skin, 0.0f));
    }
  return im;
}

// Lit green EXIT sign: a white running figure heading into a doorway, and an arrow.
// arrow: 0 straight on (up), 1 right, 2 left. RGB, self-lit in the shader.
Image exitSign(int w, int h, int arrow) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  auto cap = [](float px, float py, float ax, float ay, float bx, float by) {
    float pax = px - ax, pay = py - ay, bax = bx - ax, bay = by - ay;
    float t = clampf((pax * bax + pay * bay) / std::max(bax * bax + bay * bay, 1e-6f), 0.0f, 1.0f);
    float dx = pax - bax * t, dy = pay - bay * t;
    return std::sqrt(dx * dx + dy * dy);
  };
  bool mirror = arrow == 2;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = 1.0f - (y + 0.5f) / h;  // v up
      float uu = mirror ? 1.0f - u : u;
      float X = uu * 2.0f, Y = v;  // 2:1 panel
      float white = 0.0f;
      // doorway: an open frame on the left
      float fx0 = 0.14f, fx1 = 0.5f, fy0 = 0.12f, fy1 = 0.88f, t = 0.045f;
      bool inFrame = X > fx0 && X < fx1 && Y > fy0 && Y < fy1;
      bool inside = X > fx0 + t && X < fx1 - t && Y > fy0 + t;
      if (inFrame && !inside) white = 1.0f;
      // running figure
      const float r = 0.045f;
      auto seg = [&](float ax, float ay, float bx, float by) { if (cap(X, Y, ax, ay, bx, by) < r) white = 1.0f; };
      if (std::hypot(X - 0.86f, Y - 0.74f) < 0.075f) white = 1.0f;  // head
      seg(0.82f, 0.62f, 0.74f, 0.42f);                            // torso
      seg(0.81f, 0.6f, 0.95f, 0.52f); seg(0.81f, 0.6f, 0.7f, 0.64f);  // arms
      seg(0.74f, 0.42f, 0.86f, 0.28f); seg(0.86f, 0.28f, 0.83f, 0.14f);  // front leg
      seg(0.74f, 0.42f, 0.62f, 0.32f); seg(0.62f, 0.32f, 0.54f, 0.2f);   // back leg
      // arrow
      if (arrow == 0) {
        float cx = 1.55f;
        bool shaft = std::fabs(X - cx) < 0.06f && Y > 0.18f && Y < 0.6f;
        bool head = Y >= 0.52f && Y < 0.84f && std::fabs(X - cx) < (0.84f - Y) * 0.75f;
        if (shaft || head) white = 1.0f;
      } else {
        bool shaft = std::fabs(Y - 0.5f) < 0.07f && X > 1.18f && X < 1.66f;
        bool head = X >= 1.58f && X < 1.86f && std::fabs(Y - 0.5f) < (1.86f - X) * 0.95f;
        if (shaft || head) white = 1.0f;
      }
      float edge = std::min(std::min(u, 1.0f - u) * 2.0f, std::min(v, 1.0f - v));
      float border = edge < 0.035f ? 1.0f : 0.0f;
      float r0 = 0.04f, g0 = 0.62f, b0 = 0.3f;
      float rr = lerpf(r0, 0.97f, white), gg = lerpf(g0, 1.0f, white), bb = lerpf(b0, 0.95f, white);
      if (border > 0) { rr = 0.85f; gg = 0.87f; bb = 0.85f; }
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;
      im.px[i] = to8(rr); im.px[i + 1] = to8(gg); im.px[i + 2] = to8(bb); im.px[i + 3] = 255;
    }
  return im;
}

// ---------------------------------------------------------------- new levels
// Corrugated metal sheet: vertical ribs, pale grey, rust weeping from the fixings. 1m x 1m.
Image corrugated(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float rib = 0.5f + 0.5f * std::cos(u * 6.2832f * 13.0f);
      float shade = 0.84f + 0.16f * rib;
      float rust = smoothstepf(0.62f, 0.8f, fbm(u * 3.0f, v * 0.4f, 6, 4, seed)) * smoothstepf(0.3f, 0.9f, fbm(u, v, 3, 3, seed + 3));
      float dirt = (fbm(u, v, 8, 3, seed + 7) - 0.5f) * 0.1f;
      float r = (0.76f + dirt) * shade, g = (0.78f + dirt) * shade, b = (0.79f + dirt) * shade;
      r = lerpf(r, 0.42f, rust * 0.6f); g = lerpf(g, 0.27f, rust * 0.6f); b = lerpf(b, 0.16f, rust * 0.6f);
      put(im, x, y, r, g, b, rib);
    }
  return im;
}

// Parking-garage concrete: mottled grey, oil, and two dark tyre tracks running along v.
// Covers 4m (the shader scales it): the tracks don't repeat every metre.
Image parkingFloor(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float mott = fbm(u, v, 8, 5, seed) - 0.5f;
      float fine = hashf(x, y, (int)seed) - 0.5f;
      float k = 0.46f + mott * 0.12f + fine * 0.04f;
      float wob = (fbm(u * 0.5f, v, 2, 3, seed + 5) - 0.5f) * 0.06f;
      auto track = [&](float c) { return smoothstepf(0.05f, 0.02f, std::fabs(u - c + wob)); };
      float tracks = std::max(track(0.3f), track(0.62f)) * (0.55f + 0.45f * fbm(u, v * 2.0f, 4, 3, seed + 9));
      float oil = smoothstepf(0.7f, 0.85f, fbm(u + 0.3f, v, 5, 4, seed + 13)) * 0.6f;
      k *= 1.0f - tracks * 0.35f - oil * 0.4f;
      float crack = smoothstepf(0.495f, 0.5f, fbm(u, v, 12, 3, seed + 21)) * smoothstepf(0.505f, 0.5f, fbm(u, v, 12, 3, seed + 21));
      k *= 1.0f - crack * 0.5f;
      put(im, x, y, k * 0.98f, k, k * 1.02f, 0.5f + mott * 0.4f - crack * 0.3f);
    }
  return im;
}

// Office drywall, painted beige: a faint roller texture, nothing else. 1m x 1m.
Image officeWall(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float peel = fbm(u, v, 48, 3, seed) - 0.5f;
      float tone = fbm(u, v, 3, 3, seed + 4) - 0.5f;
      float k = 1.0f + peel * 0.035f + tone * 0.04f;
      put(im, x, y, 0.80f * k, 0.74f * k, 0.62f * k, 0.5f + peel * 0.5f);
    }
  return im;
}

// Commercial carpet tiles: dark grey-blue loop pile, each 50cm tile a slightly different shade.
Image officeCarpet(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      int tx = (int)(u * 2.0f), tz = (int)(v * 2.0f);
      float tileTone = (hashf(tx, tz, (int)seed) - 0.5f) * 0.08f;
      float loop = hashf(x, y, (int)seed + 1) - 0.5f;
      float row = 0.5f + 0.5f * std::sin((u + v) * 6.2832f * 120.0f);
      float k = 1.0f + tileTone + loop * 0.12f + (row - 0.5f) * 0.06f;
      float tu = std::fmod(u * 2.0f, 1.0f), tv = std::fmod(v * 2.0f, 1.0f);
      float seam = smoothstepf(0.012f, 0.0f, std::min(std::min(tu, 1 - tu), std::min(tv, 1 - tv))) * 0.25f;
      k *= 1.0f - seam;
      put(im, x, y, 0.2f * k, 0.21f * k, 0.24f * k, 0.5f + loop * 0.4f);
    }
  return im;
}

// A ball pit seen from a distance: packed plastic balls, red, yellow, blue, white, the odd black.
Image ballPit(int s, uint32_t seed) {
  Image im = make(s);
  const int n = 11;  // balls per metre
  const float cell = 1.0f / n;
  const float pal[5][3] = {{0.78f, 0.06f, 0.07f}, {0.95f, 0.78f, 0.08f}, {0.08f, 0.18f, 0.78f}, {0.93f, 0.93f, 0.9f}, {0.04f, 0.04f, 0.05f}};
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float best = 1e9f;
      float br = 0.05f, bg = 0.05f, bb = 0.06f, h = 0.0f;
      int cx = (int)(u / cell), cz = (int)(v / cell);
      for (int dz = -1; dz <= 1; ++dz)
        for (int dx = -1; dx <= 1; ++dx) {
          int gx = cx + dx, gz = cz + dz;
          int wx = ((gx % n) + n) % n, wz = ((gz % n) + n) % n;
          float jx = (hashf(wx, wz, (int)seed) - 0.5f) * 0.4f, jz = (hashf(wx, wz, (int)seed + 1) - 0.5f) * 0.4f;
          float bx = (gx + 0.5f + jx) * cell, bz = (gz + 0.5f + jz) * cell;
          float r = cell * 0.52f;
          float ddx = u - bx, ddz = v - bz;
          float d = std::sqrt(ddx * ddx + ddz * ddz);
          if (d < r && d < best) {
            best = d;
            float pk = hashf(wx, wz, (int)seed + 2);
            int ci = pk < 0.27f ? 0 : pk < 0.52f ? 1 : pk < 0.75f ? 2 : pk < 0.96f ? 3 : 4;
            float z = std::sqrt(std::max(0.0f, 1.0f - (d / r) * (d / r)));
            float light = 0.35f + 0.65f * clampf(z * 0.8f - ddx / r * 0.25f - ddz / r * 0.25f, 0.0f, 1.0f);
            float spec = std::pow(clampf(1.0f - std::hypot(ddx / r + 0.35f, ddz / r + 0.35f), 0.0f, 1.0f), 6.0f) * 0.6f;
            br = pal[ci][0] * light + spec; bg = pal[ci][1] * light + spec; bb = pal[ci][2] * light + spec;
            h = z;
          }
        }
      put(im, x, y, br, bg, bb, h);
    }
  return im;
}

// Padded play-area wall: dark blue-grey vinyl, quilted into 50cm squares.
Image playWall(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float tu = std::fmod(u * 2.0f, 1.0f), tv = std::fmod(v * 2.0f, 1.0f);
      float e = std::min(std::min(tu, 1 - tu), std::min(tv, 1 - tv));
      float puff = smoothstepf(0.0f, 0.18f, e);
      float n = fbm(u, v, 16, 3, seed) - 0.5f;
      float k = (0.55f + 0.45f * puff) * (1.0f + n * 0.08f);
      put(im, x, y, 0.16f * k, 0.18f * k, 0.3f * k, puff);
    }
  return im;
}

// The trampoline park's wall, floor to the 6 m ceiling (v = 0 at the top): vinyl crash pads up to
// 1.5 m, royal blue with puffy seams every metre, an orange cap rail, then painted cinder block
// above, grubby where hands and balls hit it, going grey and dim toward the roof deck.
Image parkWall(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float hm = (1.0f - v) * 6.0f;  // metres above the floor
      float n = fbm(u, v * 3.0f, 24, 3, seed) - 0.5f;
      float r, g, b, h;
      if (hm < 1.5f) {  // crash pads
        float tu = std::fmod(u * 2.0f, 1.0f);
        float e = std::min(std::min(tu, 1 - tu) * 1.0f, std::min(hm, 1.5f - hm) / 1.5f * 0.6f);
        float puff = smoothstepf(0.0f, 0.06f, e);
        float scuff = std::max(0.0f, fbm(u, v * 3.0f, 9, 3, seed + 4) - 0.6f) * 1.2f * smoothstepf(1.2f, 0.2f, hm);
        float k = (0.62f + 0.38f * puff) * (1.0f + n * 0.06f) * (1.0f - scuff * 0.4f);
        float sheen = 0.04f * puff * (0.5f + 0.5f * std::sin(tu * 3.1416f));
        r = 0.05f * k + sheen + scuff * 0.08f; g = 0.16f * k + sheen + scuff * 0.08f; b = 0.55f * k + sheen + scuff * 0.06f;
        h = 0.2f + 0.6f * puff;
      } else if (hm < 1.72f) {  // cap rail
        float t = (hm - 1.5f) / 0.22f;
        float k = 0.8f + 0.2f * std::sin(t * 3.1416f) + n * 0.05f;
        r = 0.92f * k; g = 0.42f * k; b = 0.06f * k;
        h = 0.3f + 0.4f * std::sin(t * 3.1416f);
      } else {  // painted block
        float by = (hm - 1.72f) / 0.2f;
        int row = (int)std::floor(by);
        float bx = u * 2.0f / 0.4f * 1.0f + (row & 1) * 0.5f;
        float fy = by - row, fx = bx - std::floor(bx);
        float mortar = std::min(std::min(fy, 1 - fy) * 0.2f, std::min(fx, 1 - fx) * 0.4f);
        float joint = smoothstepf(0.012f, 0.004f, mortar);
        float pore = hashf(x, y, (int)seed + 9) - 0.5f;
        float grime = std::max(0.0f, fbm(u, v * 3.0f, 5, 4, seed + 2) - 0.55f) * smoothstepf(4.0f, 2.0f, hm);
        float high = smoothstepf(3.5f, 6.0f, hm);  // up into the dim roof
        float k = (0.86f + pore * 0.08f + n * 0.06f) * (1.0f - joint * 0.18f) * (1.0f - grime * 0.5f) * (1.0f - high * 0.35f);
        r = 0.36f * k; g = 0.37f * k; b = 0.4f * k;  // charcoal paint, like most of these places
        h = 0.55f + pore * 0.3f - joint * 0.4f;
      }
      put(im, x, y, r, g, b, h);
    }
  return im;
}

// Spring-green lawn, freshly mown in faint stripes.
Image grass(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float blade = hashf(x, y, (int)seed) - 0.5f;
      float clump = fbm(u, v, 12, 4, seed + 3) - 0.5f;
      float stripe = std::sin(u * 6.2832f) * 0.04f;
      float k = 1.0f + blade * 0.12f + clump * 0.14f + stripe * 0.25f;  // smooth, even, like the footage
      put(im, x, y, 0.27f * k, 0.33f * k, 0.13f * k, 0.5f + blade * 0.4f);  // muted olive, not lawn-ad green
    }
  return im;
}

// Daytime sky around a dome: pale at the horizon, deep blue overhead, puffy clouds. u = azimuth,
// v = elevation (0 horizon .. 1 zenith). RGB, self-lit.
Image daySky(int w, int h, uint32_t seed) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
      float r = lerpf(0.72f, 0.24f, std::pow(v, 0.6f)), g = lerpf(0.82f, 0.45f, std::pow(v, 0.6f)), b = lerpf(0.94f, 0.86f, std::pow(v, 0.6f));
      float c = fbm(u * 6.0f, v * 2.0f, 8, 5, seed);
      float cloud = smoothstepf(0.55f, 0.72f, c) * smoothstepf(0.0f, 0.12f, v) * (1.0f - smoothstepf(0.6f, 0.95f, v) * 0.7f);
      float shade = 0.82f + 0.18f * smoothstepf(0.5f, 0.8f, fbm(u * 6.0f, v * 2.0f + 0.05f, 8, 5, seed));
      r = lerpf(r, 0.97f * shade, cloud); g = lerpf(g, 0.97f * shade, cloud); b = lerpf(b, 0.98f * shade, cloud);
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;
      im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = 255;
    }
  return im;
}

Image paintedBlock(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float row = std::floor(v * 5.0f);
      float uu = u * 2.5f + std::fmod(row, 2.0f) * 0.5f;
      float fu = uu - std::floor(uu), fv = v * 5.0f - row;
      float joint = std::max(smoothstepf(0.03f, 0.0f, std::min(fu, 1.0f - fu) * 0.5f), smoothstepf(0.05f, 0.0f, std::min(fv, 1.0f - fv)));
      float n = fbm(u, v, 32, 4, seed) - 0.5f;
      float pits = hashf(x, y, (int)seed) > 0.97f ? 1.0f : 0.0f;
      float k = 0.82f + n * 0.05f - joint * 0.08f - pits * 0.05f;
      put(im, x, y, k, k * 0.97f, k * 0.88f, 0.6f + n * 0.5f - joint * 0.35f - pits * 0.2f);
    }
  return im;
}

Image vinyl(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * 2.0f, v = (y + 0.5f) / s * 2.0f;
      int cx = (int)std::floor(u), cz = (int)std::floor(v);
      float fu = u - cx, fv = v - cz;
      float seam = smoothstepf(0.012f, 0.0f, std::min(std::min(fu, 1.0f - fu), std::min(fv, 1.0f - fv)));
      bool dark = ((cx + cz) & 1) != 0;
      float chip = fbm((x + 0.5f) / s, (y + 0.5f) / s, 48, 3, seed + (dark ? 3 : 0));
      float scuff = smoothstepf(0.62f, 0.8f, fbm((x + 0.5f) / s, (y + 0.5f) / s, 4, 4, seed + 7));
      float k = dark ? 0.42f : 0.82f;
      k += (chip - 0.5f) * 0.12f - scuff * 0.08f - seam * 0.12f;
      float r = k * (dark ? 0.92f : 1.0f), g = k * (dark ? 0.95f : 0.98f), b = k * (dark ? 1.0f : 0.92f);
      put(im, x, y, r, g, b, 0.7f - seam * 0.5f + (chip - 0.5f) * 0.2f);
    }
  return im;
}

// The view out of the front of the store at night: dark lot, sodium lamp, a road.
Image nightWindow(int w, int h, uint32_t seed, bool door) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = 1.0f - (y + 0.5f) / h;  // v=0 bottom
      float horizon = door ? 0.42f : 0.35f;
      float r, g, b;
      if (v > horizon) {  // sky: deep navy with a faint town glow low down
        float t = (v - horizon) / (1.0f - horizon);
        r = lerpf(0.10f, 0.012f, t); g = lerpf(0.08f, 0.016f, t); b = lerpf(0.10f, 0.045f, t);
      } else {  // asphalt lot
        float t = v / horizon;
        r = g = b = lerpf(0.05f, 0.025f, t);
        r += 0.01f;
        float stripe = std::fmod(u * 5.0f + seed * 0.37f, 1.0f);
        if (std::fabs(stripe - 0.5f) < 0.02f && v < horizon * 0.8f) { r += 0.05f; g += 0.05f; b += 0.04f; }
      }
      // sodium streetlight and its pool on the ground
      float lx = 0.3f + 0.4f * hashf((int)seed, 1, 2), ly = horizon + 0.32f;
      float d = std::sqrt((u - lx) * (u - lx) * 4.0f + (v - ly) * (v - ly));
      float glow = std::exp(-d * 9.0f) * 1.6f + std::exp(-d * 40.0f) * 3.0f;
      r += glow * 1.0f; g += glow * 0.55f; b += glow * 0.18f;
      float pool = std::exp(-((u - lx) * (u - lx) * 6.0f + (v - horizon * 0.5f) * (v - horizon * 0.5f) * 40.0f));
      r += pool * 0.18f; g += pool * 0.1f; b += pool * 0.03f;
      if (std::fabs(u - lx) < 0.004f && v > horizon * 0.6f && v < ly) { r = g = b = 0.02f; }
      // reflections of the store lights on the glass
      float refl = std::exp(-std::pow((u - 0.15f - v * 0.3f) * 18.0f, 2.0f)) * 0.06f;
      r += refl; g += refl; b += refl * 1.1f;
      // frame and door details
      float fx = std::min(u, 1.0f - u), fy = std::min(v, 1.0f - v);
      bool frame = fx < 0.025f || fy < 0.03f;
      if (door) {
        if (std::fabs(u - 0.5f) < 0.012f) frame = true;                       // two leaves
        if (std::fabs(v - 0.45f) < 0.012f && std::fabs(u - 0.5f) > 0.012f) frame = true;  // push bar
      }
      if (frame) { r = 0.32f; g = 0.33f; b = 0.35f; }
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;
      im.px[i] = to8(std::sqrt(clampf(r, 0, 1))); im.px[i + 1] = to8(std::sqrt(clampf(g, 0, 1)));
      im.px[i + 2] = to8(std::sqrt(clampf(b, 0, 1))); im.px[i + 3] = 255;
    }
  return im;
}

Image woodDoor(int w, int h, uint32_t seed) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = 1.0f - (y + 0.5f) / h;
      float grain = fbm(u * 0.3f, v * 3.0f, 16, 4, seed);
      float k = 0.38f + (grain - 0.5f) * 0.15f;
      float r = k * 0.95f, g = k * 0.72f, b = k * 0.5f;
      bool frame = u < 0.05f || u > 0.95f || v > 0.97f;
      auto panel = [&](float x0, float y0, float x1, float y1) {
        float e = std::min(std::min(u - x0, x1 - u), std::min(v - y0, y1 - v));
        return e > 0 && e < 0.02f;
      };
      if (panel(0.15f, 0.08f, 0.85f, 0.45f) || panel(0.15f, 0.55f, 0.85f, 0.9f)) { r *= 0.7f; g *= 0.7f; b *= 0.7f; }
      if (frame) { r = 0.62f; g = 0.6f; b = 0.55f; }
      float knob = std::sqrt((u - 0.85f) * (u - 0.85f) * 3.0f + (v - 0.48f) * (v - 0.48f));
      if (knob < 0.025f) { r = 0.6f; g = 0.55f; b = 0.4f; }
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;
      im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = 255;
    }
  return im;
}

Image woodFloor(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      int row = (int)std::floor(v * 8.0f);                 // 8 boards per metre-texture
      float off = hashf(row, 3, (int)seed) * 3.0f;
      float bu = u * 2.0f + off;
      int plank = (int)std::floor(bu);
      float fv = v * 8.0f - row, fu = bu - plank;
      float seam = (fv < 0.04f || fu < 0.008f) ? 1.0f : 0.0f;
      float tone = 0.75f + 0.35f * hashf(row, plank, (int)seed + 1);
      float grain = fbm(u * 0.25f + off, v * 4.0f, 24, 4, seed + (uint32_t)row) - 0.5f;
      float ring = 0.5f + 0.5f * std::sin((u * 40.0f + grain * 6.0f + off * 9.0f));
      float k = tone * (0.85f + grain * 0.35f + ring * 0.08f) * (1.0f - seam * 0.55f);
      put(im, x, y, 0.42f * k, 0.27f * k, 0.15f * k, 0.6f - seam * 0.5f + grain * 0.2f);
    }
  return im;
}

Image plaster(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float n = fbm(u, v, 64, 3, seed) - 0.5f, m = fbm(u, v, 6, 3, seed + 9) - 0.5f;
      float k = 0.8f + n * 0.05f + m * 0.04f;
      put(im, x, y, k * 0.93f, k * 0.9f, k * 0.84f, 0.5f + n * 0.4f);
    }
  return im;
}

Image viewWindow(int w, int h, uint32_t seed, int mode) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  bool city = mode >= 2, dawn = mode == 0 || mode == 1 || mode == 3;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = 1.0f - (y + 0.5f) / h;
      float horizon = city ? 0.3f : 0.36f;
      float r, g, b;
      if (v > horizon) {
        float t = (v - horizon) / (1.0f - horizon);
        if (dawn) { r = lerpf(1.0f, 0.25f, t); g = lerpf(0.55f, 0.32f, t); b = lerpf(0.32f, 0.55f, t); }
        else { r = lerpf(0.08f, 0.01f, t); g = lerpf(0.07f, 0.015f, t); b = lerpf(0.12f, 0.05f, t); }
        if (dawn) {  // the sun just over the horizon
          float d = std::sqrt((u - 0.7f) * (u - 0.7f) * 3.0f + (v - horizon - 0.04f) * (v - horizon - 0.04f) * 8.0f);
          float sun = std::exp(-d * 6.0f) * 1.5f + (d < 0.05f ? 3.0f : 0.0f);
          r += sun; g += sun * 0.7f; b += sun * 0.35f;
        }
      } else {
        float t = v / horizon;
        r = g = b = dawn ? lerpf(0.22f, 0.12f, t) : lerpf(0.05f, 0.02f, t);
      }
      if (city) {  // skyline with lit windows
        float col = std::floor(u * 14.0f);
        float bh = horizon + 0.12f + 0.4f * hashf((int)col, 5, (int)seed);
        if (v > horizon * 0.6f && v < bh) {
          float k = dawn ? 0.18f : 0.03f;
          r = k * 0.9f; g = k * 0.85f; b = k;
          int wx = (int)(u * 140.0f), wy = (int)(v * 90.0f);
          if (wx % 3 != 0 && wy % 3 != 0 && hashf(wx, wy, (int)seed) < (dawn ? 0.08f : 0.35f)) { r = 1.0f; g = 0.75f; b = 0.4f; }
        }
      }
      if (mode == 0 || mode == 1) {  // parking stripes
        float stripe = std::fmod(u * 5.0f + seed * 0.37f, 1.0f);
        if (std::fabs(stripe - 0.5f) < 0.02f && v < horizon * 0.8f) { r += 0.15f; g += 0.15f; b += 0.12f; }
      }
      if (mode == 0) {  // Ray's van, parked where he left it
        if (u > 0.3f && u < 0.78f && v > 0.14f && v < 0.48f) {
          r = g = b = 0.78f;
          if (u > 0.66f && v > 0.36f) { r = 0.2f; g = 0.25f; b = 0.3f; }
          if (v > 0.22f && v < 0.26f) { r = 0.15f; g = 0.25f; b = 0.55f; }  // the stripe and lettering
          if (v < 0.17f) { r = g = b = 0.05f; }
        }
        float w1 = std::sqrt((u - 0.38f) * (u - 0.38f) * 4.0f + (v - 0.13f) * (v - 0.13f));
        float w2 = std::sqrt((u - 0.7f) * (u - 0.7f) * 4.0f + (v - 0.13f) * (v - 0.13f));
        if (w1 < 0.06f || w2 < 0.06f) { r = g = b = 0.03f; }
      }
      float fx = std::min(u, 1.0f - u), fy = std::min(v, 1.0f - v);
      if (fx < 0.02f || fy < 0.025f || (city && std::fabs(u - 0.5f) < 0.01f)) { r = 0.3f; g = 0.3f; b = 0.31f; }
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;
      im.px[i] = to8(std::sqrt(clampf(r, 0, 1))); im.px[i + 1] = to8(std::sqrt(clampf(g, 0, 1)));
      im.px[i + 2] = to8(std::sqrt(clampf(b, 0, 1))); im.px[i + 3] = 255;
    }
  return im;
}

Image tvNews(int w, int h) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = 1.0f - (y + 0.5f) / h;
      float r = 0.1f + 0.08f * v, g = 0.16f + 0.1f * v, b = 0.35f + 0.15f * v;
      // photo inset with Ray's face
      if (u > 0.3f && u < 0.7f && v > 0.22f && v < 0.9f) {
        r = 0.22f; g = 0.28f; b = 0.42f;
        float fu = (u - 0.5f) / 0.1f, fv = (v - 0.62f) / 0.15f;
        float face = fu * fu + fv * fv;
        if (face < 1.0f) { r = 0.68f; g = 0.5f; b = 0.4f; }
        if (fv > 0.55f && face < 1.15f) { r = 0.5f; g = 0.48f; b = 0.45f; }      // grey hair
        if (std::fabs(fv - 0.15f) < 0.07f && std::fabs(std::fabs(fu) - 0.38f) < 0.1f) { r = g = b = 0.08f; }  // eyes
        if (std::fabs(fv + 0.45f) < 0.05f && std::fabs(fu) < 0.35f) { r = 0.4f; g = 0.18f; b = 0.15f; }       // a smile
        float body = (u - 0.5f) * (u - 0.5f) / 0.03f + (v - 0.22f) * (v - 0.22f) / 0.05f;
        if (body < 1.0f && v < 0.44f) { r = 0.12f; g = 0.22f; b = 0.42f; }
      }
      if (v > 0.06f && v < 0.19f) { r = 0.75f; g = 0.08f; b = 0.06f; }            // banner
      if (v > 0.06f && v < 0.19f && u < 0.2f) { r = 0.95f; g = 0.95f; b = 0.95f; }
      if (v > 0.9f && u < 0.16f) { r = 0.8f; g = 0.1f; b = 0.08f; }               // LIVE bug
      if ((int)(v * h) % 3 == 0) { r *= 0.85f; g *= 0.85f; b *= 0.85f; }
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;
      im.px[i] = to8(std::sqrt(clampf(r, 0, 1))); im.px[i + 1] = to8(std::sqrt(clampf(g, 0, 1)));
      im.px[i + 2] = to8(std::sqrt(clampf(b, 0, 1))); im.px[i + 3] = 255;
    }
  return im;
}

Image tvHall(int w, int h) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w - 0.5f, v = 0.5f - (y + 0.5f) / h;
      float d = std::max(std::fabs(u) / 0.5f, std::fabs(v) / 0.5f);   // square tunnel depth
      float depth = 1.0f / std::max(d, 0.05f);
      float k = std::pow(d, 0.7f);
      float r = 0.75f * k, g = 0.68f * k, b = 0.3f * k;
      bool floor = v < 0 && std::fabs(v) / 0.5f >= std::fabs(u) / 0.5f;
      bool ceil = v > 0 && std::fabs(v) / 0.5f >= std::fabs(u) / 0.5f;
      if (floor) { r *= 0.6f; g *= 0.5f; b *= 0.35f; }
      if (ceil && std::fmod(depth, 2.0f) < 0.35f && std::fabs(u) < 0.12f * d) { r = g = 1.0f * k + 0.2f; b = 0.9f * k + 0.2f; }
      if (d < 0.1f) { r = g = b = 0.02f; }
      if ((int)(y) % 3 == 0) { r *= 0.8f; g *= 0.8f; b *= 0.8f; }
      size_t i = ((size_t)y * w + x) * 4;
      im.px[i] = to8(std::sqrt(clampf(r, 0, 1))); im.px[i + 1] = to8(std::sqrt(clampf(g, 0, 1)));
      im.px[i + 2] = to8(std::sqrt(clampf(b, 0, 1))); im.px[i + 3] = 255;
    }
  return im;
}


Image facade(int w, int h, uint32_t seed, float wallM, float heightM) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  const float colStep = 2.3f, rowStep = 3.0f, winW = 0.82f, winH = 0.95f;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float mx = (x + 0.5f) / w * wallM, my = (y + 0.5f) / h * heightM;
      float n = fbm(mx * 0.08f, my * 0.08f, 8, 3, seed) - 0.5f;
      float r = 0.86f + n * 0.03f, g = 0.84f + n * 0.03f, b = 0.87f + n * 0.03f;  // pale lilac cladding
      // cladding seams
      if (std::fmod(mx, 1.2f) < 0.012f || std::fmod(my, 1.5f) < 0.012f) { r *= 0.93f; g *= 0.93f; b *= 0.94f; }
      float cx = std::fmod(mx + colStep * 0.5f, colStep) - colStep * 0.5f;
      float cy = std::fmod(my + 0.9f, rowStep) - rowStep * 0.5f;
      int col = (int)std::floor((mx + colStep * 0.5f) / colStep), row = (int)std::floor((my + 0.9f) / rowStep);
      if (std::fabs(cx) < winW * 0.5f + 0.05f && std::fabs(cy) < winH * 0.5f + 0.05f) {
        bool frame = std::fabs(cx) > winW * 0.5f - 0.02f || std::fabs(cy) > winH * 0.5f - 0.02f;
        float hsh = hashf(col, row, (int)seed);
        if (frame) { r = 0.22f; g = 0.23f; b = 0.25f; }
        else if (hsh < 0.06f) { float k = 0.85f + 0.15f * (cy / winH + 0.5f); r = 1.0f * k; g = 0.78f * k; b = 0.5f * k; }    // someone's lamp
        else if (hsh < 0.11f) { r = 0.35f; g = 0.5f; b = 1.0f; }                                                            // a TV
        else if (hsh < 0.15f) { r = 0.45f; g = 0.45f; b = 0.42f; }                                                          // curtains, lit dimly
        else {  // dark glass with a faint sky-ish reflection
          float refl = 0.1f + 0.06f * (cy / winH + 0.5f) + 0.04f * (cx / winW);
          r = 0.09f + refl * 0.4f; g = 0.11f + refl * 0.45f; b = 0.13f + refl * 0.5f;
        }
      }
      size_t i = ((size_t)y * w + x) * 4;
      im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = 255;
    }
  return im;
}

Image courtyardFloor(int s, uint32_t seed) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s - 0.5f, v = (y + 0.5f) / s - 0.5f;  // -0.5..0.5 across the courtyard
      float n = clampf(fbm(u + 0.5f, v + 0.5f, 64, 3, seed), 0.0f, 1.0f) - 0.5f;
      // warm grey paving with a joint grid
      float r = 0.6f + n * 0.05f, g = 0.57f + n * 0.05f, b = 0.52f + n * 0.05f;
      float gu = std::fmod((u + 0.5f) * 40.0f, 1.0f), gv = std::fmod((v + 0.5f) * 40.0f, 1.0f);
      if (gu < 0.04f || gv < 0.04f) { r *= 0.88f; g *= 0.88f; b *= 0.88f; }
      // grass: four quadrants inside a border path, cut by a cross and two diagonals, round centre
      float au = std::fabs(u), av = std::fabs(v);
      bool inBorder = au < 0.43f && av < 0.43f;
      bool cross = au < 0.035f || av < 0.035f;
      bool diag = std::fabs(au - av) < 0.03f;
      float rad = std::sqrt(u * u + v * v);
      bool circle = rad < 0.085f;
      if (inBorder && !cross && !diag && !circle) {
        float gn = clampf(fbm(u + 0.5f, v + 0.5f, 48, 3, seed + 5), 0.0f, 1.0f);
        r = 0.2f + gn * 0.06f; g = 0.38f + gn * 0.1f; b = 0.14f + gn * 0.04f;
        if (std::fmod((u + 0.5f) * 24.0f, 1.0f) < 0.5f) { r *= 0.93f; g *= 0.93f; b *= 0.93f; }  // mowing stripes
      }
      if (circle) { float k = 0.9f + 0.1f * std::sin(rad * 220.0f); r = 0.5f * k; g = 0.38f * k; b = 0.28f * k; }
      if (std::fabs(rad - 0.085f) < 0.004f) { r = g = b = 0.4f; }
      put(im, x, y, r, g, b, 0.5f + n * 0.3f);
    }
  return im;
}


Image slideHole(int s, float cr, float cg, float cb) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s * 2 - 1, v = (y + 0.5f) / s * 2 - 1;
      float rad = std::sqrt(u * u + v * v);
      // the tube bends away down and to one side: the dark centre sits off-centre
      float du = u - 0.18f, dv = v - 0.25f;
      float deep = std::sqrt(du * du + dv * dv);
      float k = clampf(deep * 1.25f, 0.0f, 1.0f);
      k = k * k;
      float r = cr * (0.08f + 0.85f * k), g = cg * (0.08f + 0.85f * k), b = cb * (0.08f + 0.85f * k);
      float band = 0.5f + 0.5f * std::sin(deep * 30.0f);
      r *= 0.9f + 0.1f * band; g *= 0.9f + 0.1f * band; b *= 0.9f + 0.1f * band;
      float a = rad < 0.98f ? 1.0f : 0.0f;
      size_t i = ((size_t)y * s + x) * 4;
      im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = to8(a);
    }
  return im;
}

Image slideTube(int w, int h, float cr, float cg, float cb) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
      float seam = std::fmod(v * 24.0f, 1.0f) < 0.06f ? 0.6f : 1.0f;            // section joints
      float shine = 0.75f + 0.45f * std::pow(std::max(0.0f, std::cos((u - 0.25f) * 6.2831f)), 6.0f);  // highlight stripe
      float k = seam * shine;
      size_t i = ((size_t)y * w + x) * 4;
      im.px[i] = to8(cr * k); im.px[i + 1] = to8(cg * k); im.px[i + 2] = to8(cb * k); im.px[i + 3] = 255;
    }
  return im;
}


namespace {
// 5x7 block font for signs.
const char* glyph(char c) {
  switch (c) {
    case 'A': return " ### #   ##   #######   ##   ##   #";
    case 'C': return " #####    #    #    #    #     ####";
    case 'D': return "#### #   ##   ##   ##   ##   ##### ";
    case 'E': return "######    #    #### #    #    #####";
    case 'G': return " #####    #    #  ###   ##   # ### ";
    case 'H': return "#   ##   ##   #######   ##   ##   #";
    case 'I': return " ###   #    #    #    #    #   ### ";
    case 'K': return "#   ##  # # #  ##   # #  #  # #   #";
    case 'L': return "#    #    #    #    #    #    #####";
    case 'N': return "#   ###  ## # ##  ###   ##   ##   #";
    case 'O': return " ### #   ##   ##   ##   ##   # ### ";
    case 'P': return "#### #   ##   ##### #    #    #    ";
    case 'Q': return " ### #   ##   ##   ## # ##  #  ## #";
    case 'R': return "#### #   ##   ##### # #  #  # #   #";
    case 'S': return " #####    #     ###     #    ##### ";
    case 'T': return "#####  #    #    #    #    #    #  ";
    case 'U': return "#   ##   ##   ##   ##   ##   # ### ";
    case 'Y': return "#   ##   # # #   #    #    #    #  ";
    case 'M': return "#   ### ### # ##   ##   ##   ##   #";
    case 'B': return "#### #   ##   ##### #   ##   ##### ";
    case 'F': return "######    #    #### #    #    #    ";
    case 'V': return "#   ##   ##   ##   ##   # # #   #  ";
    case 'W': return "#   ##   ##   ##   ## # ### ###   #";
    case '-': return "                ###                ";
    case '.': return "                          ##   ##  ";
    case '\'': return "  #    #   #                       ";
    case '0': return " ### #   ##  ### # ###  ##   # ### ";
    case '1': return "  #   ##    #    #    #    #   ### ";
    case '2': return " ### #   #    #   #   #   #   #####";
    case '3': return "####     #    # ###     #    ##### ";
    case '4': return "   #   ##  # # #  # #####   #    # ";
    case '9': return " ### #   ##   # ####    #   #  ##  ";
    case '/': return "    #    #   #   #   #   #    #    ";
    case '$': return "  #   ##### #   ###   # #####   #  ";
    case '5': return "######    ####     #    ##   # ### ";
    case '6': return " ### #    #    #### #   ##   # ### ";
    case '7': return "#####    #   #   #   #    #    #   ";
    case '8': return " ### #   ##   # ### #   ##   # ### ";
    case ':': return "      ##   ##        ##   ##       ";
    case 'X': return "#   ##   # # #   #   # # #   ##   #";
    case 'Z': return "#####    #   #   #   #   #    #####";
    default: return "                                   ";
  }
}
}  // namespace

Image signText(const char* text, int w, int h, float cr, float cg, float cb, float br, float bg, float bb) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  int n = (int)std::strlen(text);
  float cellW = (float)w / (n * 6 + 1), cellH = (float)h / 9.0f;
  float cell = std::min(cellW, cellH);
  float ox = (w - cell * (n * 6 - 1)) * 0.5f, oy = (h - cell * 7) * 0.5f;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float r = br, g = bg, b = bb;
      int ci = (int)std::floor((x - ox) / (cell * 6));
      float lx = (x - ox) / cell - ci * 6, ly = (y - oy) / cell;
      if (ci >= 0 && ci < n && lx >= 0 && lx < 5 && ly >= 0 && ly < 7) {
        const char* gph = glyph(text[ci]);
        int gi = (int)ly * 5 + (int)lx;
        if (gi < (int)std::strlen(gph) && gph[gi] == '#') { r = cr; g = cg; b = cb; }
      }
      float edge = std::min(std::min(x, w - 1 - x), std::min(y, h - 1 - y));
      if (edge < 3) { r *= 0.4f; g *= 0.4f; b *= 0.4f; }
      size_t i = ((size_t)(h - 1 - y) * w + x) * 4;  // GL rows run bottom-up
      im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = 255;
    }
  return im;
}

Image bill(int w, int h, int denom) {
  // A worn banknote: pale green paper, engraved border, portrait oval, denomination in the corners.
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  char num[8];
  std::snprintf(num, sizeof num, "%d", denom);
  int n = (int)std::strlen(num);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
      float r = 0.72f, g = 0.76f, b = 0.66f;
      float wear = hashf(x / 3, y / 3, denom) * 0.06f;
      r -= wear; g -= wear; b -= wear;
      float bx = std::min(u, 1 - u) * w, by = std::min(v, 1 - v) * h;
      float edge = std::min(bx, by);
      if (edge > 3 && edge < 9) { float k = 0.5f + 0.5f * std::sin((u + v) * 160.0f); r -= 0.25f * k; g -= 0.18f * k; b -= 0.22f * k; }
      float du = (u - 0.5f) * w / h, dv = v - 0.5f;
      float oval = std::sqrt(du * du / 0.06f + dv * dv / 0.12f);
      if (oval < 1.0f) { float k = 0.5f + 0.5f * std::sin(oval * 40.0f); r -= 0.3f * k * 0.6f; g -= 0.25f * k * 0.6f; b -= 0.3f * k * 0.6f; }
      if (std::fabs(oval - 1.0f) < 0.06f) { r -= 0.35f; g -= 0.3f; b -= 0.35f; }
      // corner numerals
      for (int c = 0; c < 2; ++c) {
        float cell = h * 0.045f;
        float ox = c == 0 ? 12 : w - 12 - cell * (n * 6 - 1), oy = c == 0 ? h - 12 - cell * 7 : 12;
        float lx = (x - ox) / cell, ly = 6.999f - (y - oy) / cell;
        int ci = (int)std::floor(lx / 6);
        float gx = lx - ci * 6;
        if (ci >= 0 && ci < n && gx >= 0 && gx < 5 && ly >= 0 && ly < 7) {
          const char* gph = glyph(num[ci]);
          if (gph[(int)ly * 5 + (int)gx] == '#') { r = 0.12f; g = 0.2f; b = 0.12f; }
        }
      }
      size_t i = ((size_t)y * w + x) * 4;
      im.px[i] = to8(r); im.px[i + 1] = to8(g); im.px[i + 2] = to8(b); im.px[i + 3] = 255;
    }
  return im;
}

Image parkingLot(int w, int h, uint32_t seed, bool storeLights) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  // world: x -16..44 (60 m), z 4..-36 (40 m). v=0 is the store side.
  struct Pool { float x, z, r, cr, cg, cb; };
  const Pool pools[] = {{14, -12, 9, 0.9f, 0.9f, 0.85f}, {-4, -24, 9, 1.0f, 0.55f, 0.18f}, {32, -24, 9, 1.0f, 0.55f, 0.18f},
                        {14, 1, 6, 0.85f, 0.88f, 0.95f}, {2, 1, 5, 0.85f, 0.88f, 0.95f}, {26, 1, 5, 0.85f, 0.88f, 0.95f}};
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float wx = -16 + (x + 0.5f) / w * 60, wz = 4 - (y + 0.5f) / h * 40;
      float n = fbm(wx * 0.05f + 3, wz * 0.05f + 3, 32, 4, seed) - 0.5f;
      float base = 0.07f + n * 0.03f;
      if (fbm(wx * 0.02f, wz * 0.02f, 8, 3, seed + 3) > 0.62f) base *= 0.75f;  // oil stains and patches
      float r = base, g = base, b = base * 1.05f;
      if (wz > 2.0f) { r = g = b = 0.22f + n * 0.04f; }                                  // sidewalk
      if (wz > 1.85f && wz <= 2.0f) { r = g = b = 0.32f; }                               // curb
      // parking stalls in front of the store
      if (wz < 1.8f && wz > -3.6f && std::fmod(wx + 100.0f, 2.8f) < 0.1f) { r = g = b = 0.6f; }
      // road
      if (wz < -27.0f && wz > -35.0f) {
        r = g = b = 0.05f + n * 0.02f;
        if (std::fabs(wz + 31.0f) < 0.08f && std::fmod(wx + 100.0f, 6.0f) < 3.0f) { r = 0.65f; g = 0.5f; b = 0.08f; }
        if (std::fabs(wz + 27.4f) < 0.06f || std::fabs(wz + 34.6f) < 0.06f) { r = g = b = 0.5f; }
      }
      if (wz <= -35.0f) { r = 0.03f; g = 0.045f; b = 0.03f; }                             // verge
      // lamp light
      float lr = 0.06f, lg = 0.06f, lb = 0.07f;
      for (int pi = 0; pi < 6; ++pi) {
        const Pool& p = pools[pi];
        if (pi >= 3 && !storeLights) continue;
        float d = std::sqrt((wx - p.x) * (wx - p.x) + (wz - p.z) * (wz - p.z));
        float k = std::exp(-(d * d) / (p.r * p.r * 0.5f));
        lr += p.cr * k; lg += p.cg * k; lb += p.cb * k;
      }
      r *= lr * 3.0f; g *= lg * 3.0f; b *= lb * 3.0f;
      size_t i = ((size_t)y * w + x) * 4;
      im.px[i] = to8(std::sqrt(clampf(r, 0, 1))); im.px[i + 1] = to8(std::sqrt(clampf(g, 0, 1)));
      im.px[i + 2] = to8(std::sqrt(clampf(b, 0, 1))); im.px[i + 3] = 255;
    }
  return im;
}

Image nightSky(int w, int h, uint32_t seed) {
  Image im;
  im.w = w; im.h = h;
  im.px.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float v = (y + 0.5f) / h;  // 0 bottom .. 1 top (GL rows run bottom-up)
      float u = (x + 0.5f) / w;
      float r = lerpf(0.09f, 0.008f, v), g = lerpf(0.07f, 0.012f, v), b = lerpf(0.08f, 0.04f, v);
      float town = std::exp(-v * 6.0f) * (0.5f + 0.5f * std::sin(u * 9.0f)) * 0.1f;
      r += town * 1.0f; g += town * 0.55f; b += town * 0.25f;
      // treeline
      float tree = 0.18f + 0.06f * std::sin(u * 41.0f) + 0.04f * std::sin(u * 97.0f + 1.0f) + 0.03f * (fbm(u * 2, 0.5f, 64, 3, seed) - 0.5f);
      if (v < tree) { r = 0.01f; g = 0.014f; b = 0.012f; }
      if (v > 0.35f && hashf(x, y, (int)seed) > 0.9985f) { r = g = b = 0.6f; }  // a few stars
      size_t i = ((size_t)y * w + x) * 4;
      im.px[i] = to8(std::sqrt(clampf(r, 0, 1))); im.px[i + 1] = to8(std::sqrt(clampf(g, 0, 1)));
      im.px[i + 2] = to8(std::sqrt(clampf(b, 0, 1))); im.px[i + 3] = 255;
    }
  return im;
}


// Blue painter's tape stuck to the wall in the shape of a door: four strips, a little crooked,
// torn ends running past the corners, one corner peeling. Alpha is the tape.
Image blueTape(int w, int h, uint32_t seed) {
  Image im;
  im.w = w; im.h = h;
  im.px.assign((size_t)w * h * 4, 0);
  auto strip = [&](float x0, float y0, float x1, float y1, float width, float tone) {
    float dx = x1 - x0, dy = y1 - y0, len = std::sqrt(dx * dx + dy * dy);
    float ux = dx / len, uy = dy / len;
    for (int y = 0; y < h; ++y)
      for (int x = 0; x < w; ++x) {
        float px = x + 0.5f - x0, py = y + 0.5f - y0;
        float along = px * ux + py * uy, across = -px * uy + py * ux;
        if (along < -4 || along > len + 4) continue;
        float tear = 2.5f * hashf((int)(across * 0.6f), (int)seed, (int)(along > len * 0.5f));  // ragged torn ends
        if (along < tear - 3 || along > len + 3 - tear) continue;
        float edge = width * 0.5f + 0.8f * (hashf((int)(along * 0.5f), (int)seed + 3) - 0.5f);
        if (std::fabs(across) > edge) continue;
        float crepe = 0.92f + 0.08f * std::sin(along * 0.9f) + 0.05f * (hashf(x, y, (int)seed) - 0.5f);
        float k = tone * crepe * (std::fabs(across) > edge - 1.2f ? 0.82f : 1.0f);
        size_t i = ((size_t)(h - 1 - y) * w + x) * 4;  // GL rows run bottom-up
        im.px[i] = to8(0.85f * k); im.px[i + 1] = to8(0.9f * k); im.px[i + 2] = to8(1.0f * k); im.px[i + 3] = 255;
      }
  };
  float tw = w * 0.055f;  // about 5 cm of tape
  float L = w * 0.09f, R = w * 0.91f, T = h * 0.04f, B = h * 0.99f;
  strip(L + 2, B + 4, L - 3, T - tw * 0.6f, tw, 1.0f);       // left side, slightly leaning
  strip(R - 1, B + 4, R + 4, T - tw * 0.5f, tw, 0.95f);      // right side
  strip(L - tw * 1.2f, T + 2, R + tw * 1.1f, T - 3, tw, 1.0f);  // the top, overlapping both
  strip(R - tw * 0.4f, T + tw * 0.2f, R - tw * 1.8f, T + tw * 2.2f, tw * 0.9f, 0.8f);  // a short extra piece at the corner
  return im;
}


// Kids' party carpet: deep red-orange pile scattered with bright letters, squiggles, triangles and stars.
constexpr float kPiF = 3.14159265f;
Image partyCarpet(int s, uint32_t seed) { return partyCarpetBase(s, seed, false); }
// The trampoline park's arcade carpet: near-black navy with small neon confetti shapes.
Image arcadeCarpet(int s, uint32_t seed) { return partyCarpetBase(s, seed, true); }
Image partyCarpetBase(int s, uint32_t seed, bool dark) {
  Image im = make(s);
  const int per = dark ? 12 : 6;  // cells per metre
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float fib = hashf(x, y, (int)seed) * 0.08f + (fbm(u, v, 32, 3, seed) - 0.5f) * 0.12f;
      float r = 0.55f + fib, g = 0.16f + fib * 0.5f, b = 0.08f + fib * 0.3f;
      if (dark) { r = 0.05f + fib * 0.25f; g = 0.05f + fib * 0.25f; b = 0.1f + fib * 0.35f; }
      float cu = u * per, cv = v * per;
      int ci = (int)cu, cj = (int)cv;
      float lu = cu - ci, lv = cv - cj;
      float h = hashf(ci, cj, (int)seed + 1);
      const float pal[5][3] = {{0.3f, 0.85f, 0.95f}, {0.98f, 0.85f, 0.2f}, {0.95f, 0.4f, 0.7f}, {0.45f, 0.9f, 0.35f}, {0.95f, 0.95f, 0.9f}};
      const float* c = pal[(int)(hashf(ci, cj, (int)seed + 2) * 4.99f)];
      bool ink = false;
      float ox = 0.2f + 0.3f * hashf(ci, cj, 9), oy = 0.2f + 0.3f * hashf(ci, cj, 13);
      float px = lu - ox, py = lv - oy;
      if (h < 0.3f) {  // a letter
        const char* letters = "ACNVWZMKT";
        char ch = letters[(int)(hashf(ci, cj, 5) * 8.99f)];
        float gx = px / 0.07f, gy = 6.999f - py / 0.07f;
        if (gx >= 0 && gx < 5 && gy >= 0 && gy < 7) ink = glyph(ch)[(int)gy * 5 + (int)gx] == '#';
      } else if (h < 0.48f) {  // triangle outline
        float a = std::fabs(px - 0.17f) * 1.6f + (0.3f - py) * 0.0f;
        float e = std::min(std::fabs(py - 0.02f), std::fabs((0.3f - py) * 0.55f - std::fabs(px - 0.17f)));
        ink = py > 0 && py < 0.32f && a < (0.32f - py) * 0.95f && e < 0.025f;
      } else if (h < 0.64f) {  // squiggle
        float yy = 0.12f + 0.06f * std::sin(px * 30.0f);
        ink = px > 0 && px < 0.4f && std::fabs(py - yy) < 0.018f;
      } else if (h < 0.76f) {  // ring
        float d = std::sqrt((px - 0.12f) * (px - 0.12f) + (py - 0.12f) * (py - 0.12f));
        ink = std::fabs(d - 0.1f) < 0.018f;
      } else if (h < 0.86f) {  // little star
        float ang = std::atan2(py - 0.12f, px - 0.12f), d = std::sqrt((px - 0.12f) * (px - 0.12f) + (py - 0.12f) * (py - 0.12f));
        ink = d < 0.05f + 0.05f * std::pow(std::fabs(std::cos(ang * 2.5f)), 3.0f);
      }
      if (ink) { r = c[0] * (0.85f + fib); g = c[1] * (0.85f + fib); b = c[2] * (0.85f + fib); }
      put(im, x, y, r, g, b, 0.6f + fib);
    }
  return im;
}

// Party walls: smooth painted drywall in a loud colour, faint roller marks.
Image partyWall(int s, uint32_t seed, float cr, float cg, float cb) {
  Image im = make(s);
  for (int y = 0; y < s; ++y)
    for (int x = 0; x < s; ++x) {
      float u = (x + 0.5f) / s, v = (y + 0.5f) / s;
      float n = fbm(u, v, 8, 4, seed) - 0.5f;
      float roller = 0.02f * std::sin(u * 6.2831853f * 4.0f + n * 3.0f);
      float k = 1.0f + n * 0.06f + roller;
      put(im, x, y, cr * k, cg * k, cb * k, 0.7f + n * 0.2f);
    }
  return im;
}

// Bunting: a string of little triangle flags.
Image bunting(int w, int h, uint32_t seed) {
  Image im;
  im.w = w; im.h = h;
  im.px.assign((size_t)w * h * 4, 0);
  const float pal[5][3] = {{0.95f, 0.3f, 0.3f}, {0.98f, 0.85f, 0.2f}, {0.3f, 0.75f, 0.95f}, {0.5f, 0.9f, 0.4f}, {0.95f, 0.45f, 0.8f}};
  int flags = 8;
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      float u = (x + 0.5f) / w, v = 1.0f - (y + 0.5f) / h;  // v=0 top
      float sag = 0.15f + 0.12f * std::sin(u * kPiF);
      float k = u * flags;
      int fi = (int)k;
      float lu = k - fi;
      bool string = std::fabs(v - sag) < 0.02f;
      float fv = v - sag;
      bool flag = fv > 0 && fv < 0.6f * (1.0f - std::fabs(lu - 0.5f) * 2.0f);
      if (!string && !flag) continue;
      const float* c = pal[(fi + (int)seed) % 5];
      size_t i = ((size_t)y * w + x) * 4;
      if (string) { im.px[i] = im.px[i + 1] = im.px[i + 2] = 230; }
      else { im.px[i] = to8(c[0]); im.px[i + 1] = to8(c[1]); im.px[i + 2] = to8(c[2]); }
      im.px[i + 3] = 255;
    }
  return im;
}

}  // namespace texgen
