// Vertex-animated models baked from rigged characters (tools/bake_clark.py): a fixed mesh and a
// loop of keyframes, blended on the CPU and drawn with their own textures.
#pragma once
#include <string>
#include <vector>

#include "gl.h"
#include "level.h"
#include "mathx.h"
#include "render.h"

struct VamModel {
  struct Mat { std::string tex; GLuint gl = 0; uint32_t first = 0, count = 0; };
  int nVerts = 0, nFrames = 0;
  float loopSeconds = 1, stride = 1, height = 2;
  std::vector<Mat> mats;
  std::vector<float> uv;            // 2 per vertex (v flipped for GL)
  std::vector<uint32_t> idx;
  std::vector<float> pos, nrm;      // frames x verts x 3
  Mesh cpu;                         // the blended pose, re-uploaded when drawn
  GpuMesh gpu;
  bool ok() const { return nVerts > 0 && nFrames > 0; }
  bool load(const std::string& path);  // also loads the textures from the same folder
  void pose(float phase);              // 0..1 through the loop -> cpu + gpu
};
