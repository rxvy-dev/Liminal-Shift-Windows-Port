// The start: Saturday afternoon at SKY HIGH trampoline park. You're nine. Mom and Dad are at the
// tables by the front, other kids are bouncing, the music's loud. One of the beds against the back
// wall has a pad that's come away from the wall, and there's a dark gap down the side of it that goes
// a lot further down than it should. Get close enough and you slip in (the level's "exit" is that gap).
#include <cmath>

#include "audio.h"
#include "game.h"

namespace {
// skin, hair, top, legs
const vec4 kDadLook[4] = {{0.62f, 0.46f, 0.36f, 0}, {0.16f, 0.11f, 0.07f, 0}, {0.18f, 0.3f, 0.22f, 0}, {0.16f, 0.17f, 0.22f, 0}};
const vec4 kMomLook[4] = {{0.66f, 0.5f, 0.4f, 0}, {0.32f, 0.2f, 0.1f, 0}, {0.62f, 0.2f, 0.26f, 0}, {0.08f, 0.09f, 0.14f, 0}};
const vec4 kKidLooks[6][4] = {
    {{0.62f, 0.45f, 0.35f, 0}, {0.3f, 0.2f, 0.1f, 0}, {0.85f, 0.2f, 0.12f, 0}, {0.12f, 0.15f, 0.3f, 0}},
    {{0.42f, 0.28f, 0.2f, 0}, {0.05f, 0.04f, 0.03f, 0}, {0.12f, 0.45f, 0.8f, 0}, {0.2f, 0.2f, 0.22f, 0}},
    {{0.7f, 0.55f, 0.45f, 0}, {0.75f, 0.6f, 0.3f, 0}, {0.95f, 0.8f, 0.15f, 0}, {0.3f, 0.12f, 0.35f, 0}},
    {{0.55f, 0.38f, 0.28f, 0}, {0.1f, 0.07f, 0.05f, 0}, {0.2f, 0.65f, 0.3f, 0}, {0.1f, 0.1f, 0.12f, 0}},
    {{0.66f, 0.5f, 0.4f, 0}, {0.45f, 0.25f, 0.1f, 0}, {0.9f, 0.45f, 0.65f, 0}, {0.15f, 0.2f, 0.4f, 0}},
    {{0.35f, 0.24f, 0.17f, 0}, {0.04f, 0.03f, 0.03f, 0}, {0.95f, 0.95f, 0.92f, 0}, {0.6f, 0.15f, 0.12f, 0}},
};
}  // namespace

void Game::say(const std::string& who, const std::string& text, float dur) {
  if (dur <= 0) dur = 1.6f + text.size() * 0.055f;
  lines_.push_back({who, text, dur});
}

void Game::parkBegin() {
  parkT_ = 0;
  parkCue_ = 0;
  parkBounces_ = 0;
  lines_.clear();
  lineTime_ = 0;
  hintTimer_ = 0;
  flashOn_ = false;
  hasFlashlight_ = false;
  parkFamily_ = parkKids_ = true;
  toast_ = "SKY HIGH TRAMPOLINE PARK - SATURDAY";
  toastTime_ = 4.0f;
}

void Game::parkUpdate(float dt) {
  parkT_ += dt;
  auto cue = [&](int i, float at) {
    if (parkT_ >= at && !(parkCue_ & (1 << i))) { parkCue_ |= 1 << i; return true; }
    return false;
  };
  if (cue(0, 0.6f)) say("DAD", "Go on, bud. Shoes in the cubbies. We'll be right here.", 3.6f);
  if (cue(1, 4.6f)) say("MOM", "Stay where we can see you, okay? Ten minutes!", 3.4f);
  if (cue(2, 9.0f)) { toast_ = "GO BOUNCE. (SPACE AT THE BOTTOM FOR A BIG ONE)"; toastTime_ = 5.0f; }
  // after a while: something about that back wall
  vec3 gap = level_.exitFaceCenter();
  vec3 d = level_.delta(pos_, gap);
  float dist = std::sqrt(d.x * d.x + d.z * d.z);
  if (cue(3, 26.0f)) {
    say("YOU", "(There's a gap behind that pad by the back wall. It's really dark down there.)", 4.2f);
    toast_ = "THE BACK WALL. BEHIND THE PADS.";
    toastTime_ = 5.0f;
  }
  if (dist < 6.0f && cue(4, 0.0f)) say("YOU", "(It's cold coming out of it. Like a fridge. And humming.)", 3.6f);
  if (dist < 3.0f && cue(5, 0.0f)) say("MOM", "...hon? Don't go too far!", 2.6f);
  if (cue(6, 75.0f)) say("DAD", "Five more minutes, then pizza!", 3.0f);
}

void Game::parkDraw(Shader& S, vec3 cam) {
  const Level::ParkSpots& pk = level_.park;
  S.set("uMat", MAT_MODEL);
  S.set("uSkinned", 0);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  // Mom and Dad at the tables, watching you (Dad on his phone half the time)
  if (parkFamily_) {
    AnimInput in;
    in.time = time_;
    vec3 to = level_.delta(pk.dad, pos_);
    float look = std::atan2(-to.x, -to.z) - pk.dadYaw;
    in.look = clampf(std::remainder(look, 2.0f * kPi), -0.8f, 0.8f);
    in.hold = std::fmod(time_, 20.0f) < 11.0f ? 1.0f : 0.0f;  // the phone
    drawCreature(S, CR_HUMAN, pk.dad, pk.dadYaw, in, 0, kDadLook);
    AnimInput im;
    im.time = time_ + 3.0f;
    vec3 tm = level_.delta(pk.mom, pos_);
    im.look = clampf(std::remainder(std::atan2(-tm.x, -tm.z) - pk.momYaw, 2.0f * kPi), -0.9f, 0.9f);
    im.cross = 1.0f;
    drawCreatureAt(S, CR_HUMAN, translate(near(pk.mom, cam)) * rotY(pk.momYaw) * scale({0.96f, 0.95f, 0.96f}), im, 0, kMomLook);
  }
  // the other kids, bouncing
  for (size_t k = 0; k < pk.kids.size() && parkKids_; ++k) {
    float ph = time_ * 3.1f + k * 1.7f;
    float h = std::fabs(std::sin(ph)) * (0.55f + 0.25f * std::sin(k * 2.3f));
    vec3 p = near(pk.kids[k], cam) + vec3{0, h + 0.03f, 0};
    AnimInput in;
    in.time = time_ + k;
    in.speed = 0.3f;
    in.phase = ph;
    float yaw = time_ * (k % 2 ? 0.4f : -0.3f) + k;
    drawCreatureAt(S, CR_HUMAN, translate(p) * rotY(yaw) * scale({0.6f, 0.6f, 0.6f}), in, 0, kKidLooks[k % 6]);
  }
  // the gap: a black slot between the back pad and the wall, going down
  {
    vec3 c = near(level_.tileCenter(pk.crevX, pk.crevZ), cam);
    S.set("uMat", MAT_PROP);
    drawPart(translate(c + vec3{0, -0.394f, -0.76f}) * scale({2.0f, 0.8f, 0.33f}), {0.0f, 0.0f, 0.0f});  // its top just over the floor
    S.set("uMat", MAT_MODEL);
  }
  // the foam pit
  buildBallPatch();
  for (int z = pk.z0; z <= pk.z1; ++z)
    for (int x = pk.x0; x <= pk.x1; ++x) {
      if (!level_.isFoam(x, z)) continue;
      vec3 o = near(vec3{x * Level::kTile, 0, z * Level::kTile}, cam);
      drawModel(S, ballPatch_, translate(o) * scale({1.0f, 2.2f, 1.0f}));
      drawModel(S, ballPatch_, translate(o + vec3{0.04f, 0.1f, 0.05f}) * scale({1.0f, 2.2f, 1.0f}));
    }
  S.set("uModel", mat4::identity());
}
