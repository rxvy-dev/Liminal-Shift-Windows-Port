// Level themes: everything that makes one level of the Backrooms feel different
// from the next (layout, surfaces, light, fog, hazards, who lives there, notes).
#pragma once
#include "mathx.h"
#include <string>
#include <vector>

enum class Layout { Office, Warehouse, Tunnels, Pools, Halls, Store, Apartment, Choice };
enum class Surf { Wallpaper, DarkWallpaper, Concrete, Brick, Tile, Carpet, DarkCarpet, ConcreteFloor, CeilingTiles, CeilingConcrete, Painted, Vinyl, Wood, Plaster, HotelCarpet, PoolTile, PoolMosaic, PartyCarpet, PartyWall, PartyWall2, PartyCeiling,
                  Corrugated, ParkingFloor, OfficeWall, OfficeCarpet, BallPit, PlayWall, PlayCeiling, Grass };
// Levels with their own furniture and rules (level_special.cpp, game_special.cpp).
enum class Special { None, Parking, Office, Playplace, Suburbs, Park };

struct NoteText {
  const char* title;
  const char* body;
};

struct Theme {
  int index = 0;              // level number (0, 1, 2 ...)
  std::string name;           // "LEVEL 3"
  std::string title;          // "THE POOLROOMS"
  std::string label;          // display name override, e.g. "LEVEL 37" (the real numbering)
  int courtyard = 0;          // Level 188: tiles across the open atrium in the middle (0 = none)
  Layout layout = Layout::Office;
  float wallH = 2.9f;
  float braid = 0.58f;        // fraction of maze walls knocked out
  int rooms = 16, hallways = 9;
  float pillarChance = 0.7f;
  Surf wall = Surf::Wallpaper, floor = Surf::Carpet, ceiling = Surf::CeilingTiles;
  // second surface set for zone-1 tiles (the store's back room and basement)
  Surf wall2 = Surf::Concrete, floor2 = Surf::ConcreteFloor, ceiling2 = Surf::CeilingConcrete;
  vec3 lightColor{1.0f, 0.91f, 0.70f};
  float lightIntensity = 1.0f;
  int lightSpacing = 2;       // tiles between fixtures
  float panelW = 0.5f, panelL = 1.0f;
  float deadChance = 0.07f, flickerChance = 0.13f;
  int darkZones = 6;
  float darkRadius = 5.0f;
  vec3 fogColor{0.016f, 0.013f, 0.007f};
  vec3 fogLit{0.07f, 0.058f, 0.028f};
  float fogDensity = 0.05f;
  vec3 paint{0.42f, 0.03f, 0.025f};
  float paintGlow = 0.0f;     // luminous paint in dark levels
  bool pools = false, pipes = false;
  int lockers = 10;           // hiding spots
  int anomalies = 12;         // furniture caught mid-noclip
  float grime = 1.0f;
  // inhabitants
  int tenants = 1, hounds = 1, grins = 2;
  bool roundPillars = false;  // tiled columns instead of square piers
  bool party = false;         // Level Fun: desks to hide under, balloon arches, birthdays
  bool arrows = false;        // painted route arrows (off: you find your own way; EXIT signs near the end)
  bool openEdge = false;      // the level's edge is open ground (invisible boundary) instead of a wall
  Special special = Special::None;
  float terrain = 0.0f;       // rolling ground: hill height in metres (0 = flat floors)
  bool outdoor = false;       // no ceiling, sky overhead
  float wetFloor = 0.0f;      // standing water in the damp patches (mirror puddles)
  vec3 ambient{0, 0, 0};      // sky light from above (outdoor levels)
  int stilts = 0, partygoers = 0;
  float sun = 0;               // sunlight through skylights (0 = none)
  vec3 sunDir{-0.45f, 1.0f, -0.3f}, sunColor{1.0f, 0.86f, 0.62f};
  bool lifeguard = false;     // Poolrooms: the Tenant's pale, wet cousin
  float firstSpawn = 60.0f;   // seconds before the first stalker appears
  float huntEvery = 120.0f;   // seconds between hunts (0 = never)
  // supplies
  int batteries = 9, waters = 5;
  // props: chairs, boxes, coolers, camp
  int chairs = 26, boxes = 22, coolers = 6;
  bool camp = true;
  float humGain = 1.0f, waterGain = 0.0f;
  vec3 gradeGain{1, 1, 1}, gradeLift{0, 0, 0};  // film grade per level
  std::vector<NoteText> notes;
  std::vector<const char*> graffiti;  // flavour lines painted on walls
};

// Levels 0-4 are hand-designed; beyond that the Backrooms keep generating remixes.
constexpr int kStoreLevel = -1;  // the Quik-Stop, before everything
constexpr int kAptLevel = -2;    // Dana's apartment (endings)
constexpr int kAptWrongLevel = -3;  // ...when it stops looking like it
constexpr int kLastLevel = 7;    // Level !; leaving it ends the game
constexpr int kChoiceLevel = -4; // the two painted walls
constexpr int kParkLevel = -5;   // Route 9 Park: where it starts, with Mom and Dad
constexpr int kLevelCount = 11;  // 0-7 the originals, 8 the Playplace, 9 Count On Me, 10 the Suburbs
// The way down, in story order: Lobby, Parking, Count On Me, Pipes, Poolrooms, Playplace,
// Lights Out, 188, Suburbs, Fun, ! (the numbers stay put so saves and tapes still line up).
inline int nextStoryLevel(int i) {
  switch (i) {
    case 0: return 1; case 1: return 9; case 9: return 2; case 2: return 3; case 3: return 8;
    case 8: return 4; case 4: return 5; case 5: return 10; case 10: return 6; case 6: return 7;
    default: return i + 1;
  }
}
Theme themeFor(int level, uint32_t seed);
