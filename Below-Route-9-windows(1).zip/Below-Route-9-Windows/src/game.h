// Game state machine: title, play, pause, reading, caught, noclip, level transition.
#pragma once
#include "audio.h"
#include "creatures.h"
#include "entity.h"
#include "level.h"
#include "platform.h"
#include "render.h"
#include "theme.h"
#include <SDL.h>
#include <deque>
#include <functional>
#include <string>
#include <vector>

struct Options {
  uint32_t seed = 0;
  bool forceWindowed = false;
  int width = 1280, height = 720;
  std::string screenshot;  // write a PPM after `frames` frames, then quit
  int frames = 0;
  std::string scene;       // autotest scenes (see main.cpp --help)
  bool noAudio = false;
  int quality = -1;        // override graphics preset
  int level = -1;          // start at this level (testing)
};

struct Settings {
  bool vhs = true;
  int quality = 2;
  float sensitivity = 1.0f;
  float volume = 0.8f;
  bool fullscreen = false;
  float fov = 75.0f;
  bool blink = true;  // Dana blinks (and things move while her eyes are shut)
  bool rt = true;     // ray-traced lighting, shadows and reflections
};

class Game {
 public:
  bool init(SDL_Window* win, Renderer* r, Audio* a, const Options& o, std::string& err);
  void event(const SDL_Event& e);
  void update(float dt);
  void render();
  bool wantsQuit() const { return quit_; }
  void onResize(int w, int h);
  void shutdown();
  void debugReport() const;
  Settings settings;

 private:
  enum class Screen { Title, Playing, Paused, Reading, Caught, Noclip, Transition, Ending, Plunge, Slide };
  enum ItemType { ITEM_NOTE, ITEM_BATTERY, ITEM_WATER, ITEM_TAPE };
  struct Item { ItemType type; vec3 pos; float yaw; bool taken = false; int note = -1; };
  struct MenuItem { std::string label; std::function<void(int)> act; };
  struct ChunkGpu { GpuMesh walls, floor, ceiling, panels, trim, water, walls2, floor2, ceiling2; vec3 center; };

  // --- setup
  void loadLevel(int index, uint32_t seed);
  void buildLevelTextures();
  void freeLevelGpu();
  void placeItems();
  void resetEntities();
  void resetPlayer(vec3 at, float yaw);
  void startNewGame();
  void continueGame();
  void applySettings();
  void loadSettings();
  void saveSettings();
  void saveProgress();
  bool hasSave() const;
  void setupScene(const std::string& sc);

  // --- simulation
  void updatePlaying(float dt);
  void updateEvents(float dt);
  void updateLights(float dt);
  void updateAudio();
  void tryInteract();
  void gotCaught(vec3 head);
  void respawn();
  void beginExitChase();
  bool beginHunt(float seconds);
  vec3 eye() const;
  vec3 forward() const;
  int notesFound() const;
  vec3 near(vec3 p, vec3 ref) const { return level_.nearest(p, ref); }
  bool anyChasing() const;

  // --- drawing
  void drawScene(vec3 camPos, vec3 camDir, float fovDeg, float time, PostParams& pp);
  void drawCasters(Shader& S, vec3 around);
  void drawProps(Shader& S, vec3 cam, float range);
  void drawItems(vec3 cam);
  void drawDecals(Shader& S, vec3 cam);
  void drawExitSigns(Shader& S, vec3 cam);
  // special levels (game_special.cpp)
  void specialDraw(Shader& S, vec3 cam);
  void drawParkedCar(Shader& S, vec3 at, float yaw, int variant);
  void buildBallPatch();
  Model ballPatch_;
  GpuMesh skyDome_;
  GLuint texDaySky_ = 0, texMural_ = 0;
  vec3 bounceTint_{1, 1, 1};
  GLuint texExitSign_[3] = {0, 0, 0};
  void drawCreatures(Shader& S, vec3 cam);
  void drawCreature(Shader& S, CreatureId id, vec3 pos, float yaw, const AnimInput& in, int variant = 0, const vec4* regions = nullptr);
  void drawCreatureAt(Shader& S, CreatureId id, const mat4& world, const AnimInput& in, int variant = 0, const vec4* regions = nullptr);
  void drawModel(Shader& S, const Model& m, const mat4& world);
  void drawPart(const mat4& m, vec3 tint, float emissive = 0);
  void drawCord(Shader& S, vec3 cam);  // the orange extension cord to the way out
  void drawHUD();
  void drawMenu(const std::string& title, float alpha);
  void drawNote();
  void drawTitle();
  void drawLoading(float progress, const char* what);  // progress < 0: indeterminate
  // VCR OSD Mono (game_font.cpp)
  void ensureVcrFont();
  float vcrWidth(const std::string& s, float px) const;
  void vcrText(const std::string& s, float x, float y, float px, float r, float g, float b, float a, float outline = 0, float shadow = 0);
  GLuint texVcr_ = 0;
  void vt(const std::string& s, float x, float y, float scale, float r, float g, float b, float a = 1.0f);
  float vw(const std::string& s, float scale) const;
  void drawTransition();
  void buildMenu();
  float ui() const;
  void setMouseCapture(bool on);

  SDL_Window* win_ = nullptr;
  Renderer* R_ = nullptr;
  Audio* A_ = nullptr;
  Options opt_;
  Screen screen_ = Screen::Title;
  bool quit_ = false;
  Rng rng_{1};

  // world
  int levelIndex_ = 0;
  Level level_;
  std::vector<ChunkGpu> chunks_;
  GpuMesh cube_, quad_;
  GLuint texWall_ = 0, texFloor_ = 0, texCeil_ = 0, texPanel_ = 0, texPaper_ = 0, texGrime_ = 0, texWhite_ = 0;
  GLuint texWall2_ = 0, texFloor2_ = 0, texCeil2_ = 0;
  GLuint texFacade_ = 0, texCourt_ = 0, texCourtCeil_ = 0, texGlass_ = 0;
  GpuMesh courtWalls_, courtFloor_, courtCeil_;
  // outside the Quik-Stop
  GLuint texLotOn_ = 0, texLotOff_ = 0, texSky_ = 0, texSignQ_ = 0, texSignGas_ = 0, texSignVan_ = 0, texSignHours_ = 0, texSignIce_ = 0;
  GLuint texBrickOut_ = 0, texGround_ = 0, texStoreGlass_ = 0, texGlow_ = 0;
  GpuMesh frontIn_, frontOut_, skyRing_;
  // the till
  int saleStage_ = 0;  // 0 ring up, 1 customer holding out cash, 2 cash in hand / drawer open
  float drawer_ = 0, drawerTarget_ = 0, drawerCloseAt_ = -1, totalTaken_ = 0;
  bool cashHeld_ = false;
  GLuint texRegDisp_ = 0, texBill_ = 0;
  std::string regText_;
  void setRegisterText(const std::string& t);
  void drawRegister(Shader& S);
  void drawFirstPerson(Shader& S);
  void drawSoot(Shader& S, vec3 at, float t, vec3 cam);
  GLuint texSoot_ = 0, texTape_ = 0, texBunting_ = 0;
  float partyT_ = 60, partySong_ = 0, partyTalk_ = 6;
  void partyReset();
  void partyUpdate(float dt);
  void partyDraw(Shader& S, vec3 cam);
  bool underDesk() const;
  void drawItemModel(Shader& S, int item, int color, const mat4& m);
  bool hazmat_ = false;  // Dana is wearing the suit
  bool chooseYellow_ = false;
  int loreState_ = 0;
  float loreT_ = 0, loreAt_ = 60, echoCool_ = 0;
  vec3 echoPos_{0, 0, 0}, echoDir_{1, 0, 0}, unitPos_{0, 0, 0};
  bool hasUnit_ = false;
  void loreReset();
  void loreUpdate(float dt);
  void loreDraw(Shader& S, vec3 cam);
  float blinkT_ = 4.0f, blinkPhase_ = -1.0f;
  float lidClosure() const;  // 0 open .. 1 shut
  void updateBlink(float dt);
  void drawBlink();
  GLuint texPoolMask_ = 0, texTunnel_ = 0;
  GpuMesh stairSteps_, stairCeil_, stairShaft_;
  bool sunOn_ = false;
  mat4 sunVP_ = mat4::identity();
  void buildPoolPieces();
  void drawPoolPieces(Shader& S, vec3 cam);
  void renderSun(vec3 camPos);
  bool hasPools_ = false;
  int suitState_ = 0, teamState_ = 0;  // suit: 0 none, 1 waiting on the floor, 2 putting it on, 3 worn
  float suitT_ = 0, suitYaw_ = 0, teamT_ = 0, teamAt_ = 60, teamLen_ = 0, breathT_ = 0;
  vec3 suitPos_{0, 0, 0}, teamPos_{0, 0, 0}, teamDir_{1, 0, 0};
  GLuint texVisor_ = 0, texFog_ = 0;
  void suitReset();
  bool suitFocus() const;
  bool suitInteract();
  void suitUpdate(float dt);
  void suitDraw(Shader& S, vec3 cam);
  void suitHUD();
  int lastCarSlot_ = -999, rayWalkIn_ = 0;
  static const vec3 kVanPark;
  bool storePowered() const;
  bool vanPose(vec3& p, float& yaw, float& lights) const;
  void buildStoreOutside();
  void drawStoreOutside(Shader& S, vec3 cam);
  void drawGlow(Shader& S, vec3 p, vec3 cam, float size, vec3 col, float strength);
  void drawCar(Shader& S, vec3 p, float yaw, vec3 paint, float lights, int kind, vec3 cam);
  void outsideUpdate(float dt);
  float doorOpen_ = 0, leaveMsgT_ = 0;
  bool wasOutside_ = false;
  void buildCourtyard();
  void drawCourtyard(Shader& S, vec3 cam);
  GLuint texLightmap_ = 0, texLightState_ = 0;
  std::vector<GLuint> decalTex_;
  std::vector<float> lightState_;
  std::vector<Item> items_;
  std::vector<Stalker> stalkers_;
  std::vector<float> spawnAt_;
  std::vector<Grin> grins_;
  mat4 viewProj_, shadowVP_;
  bool shadowsDrawn_ = false, hasPrevVP_ = false;
  // trailer capture: scripted camera that drops in through the ceiling, glides, and sinks through the floor
  float cineT_ = 0, cineY_ = 1.6f;
  vec3 cineStart_{0, 0, 0};
  bool cineInit_ = false;
  void cineUpdate(float dt);
  std::vector<mat4> boneScratch_;
  vec3 lightTint_{1, 1, 1};

  // events
  float huntTimer_ = 0, alarm_ = 0, chaseIntensity_ = 0;
  bool exitChaseDone_ = false;
  float transitionTime_ = 0;
  int prevNotes_ = 0, prevNoteTotal_ = 0, prevDeaths_ = 0;
  float prevTime_ = 0;
  std::string prevTitle_;

  // player
  vec3 pos_{0, 0, 0}, vel_{0, 0, 0};
  float yaw_ = 0, pitch_ = 0;
  float eyeH_ = 1.62f, footY_ = 0, bob_ = 0, stepPhase_ = 0;
  float stamina_ = 1, staminaDelay_ = 0, waterBoost_ = 0;
  bool exhausted_ = false, crouch_ = false, sprinting_ = false, inWater_ = false;
  float battery_ = 1.0f;
  bool flashOn_ = true;
  vec3 flashDir_{0, 0, -1};
  float noiseRadius_ = 0, noiseHold_ = 0;
  float playerLight_ = 1.0f, exposure_ = 0.7f;
  vec3 checkpoint_{0, 0, 0};
  float checkpointYaw_ = 0;
  uint32_t notesMask_ = 0;
  int readingNote_ = -1;
  float playTime_ = 0, totalTime_ = 0, screenTime_ = 0, time_ = 0;
  float fear_ = 0, hintTimer_ = 0;
  float ambientTimer_ = 30, brownout_ = 0;
  int deaths_ = 0;
  std::string toast_;
  float toastTime_ = 0;
  int focusItem_ = -1;
  float caughtYaw_ = 0, caughtPitch_ = 0;
  float noclipFall_ = 0;
  bool portrait_ = false;

  // ---- the Quik-Stop (intro) : see game_store.cpp
  enum class StorePhase { Shift, FindLight, CallRay, WaitRay, MeetRay, LeadRay, Basement, HoldLight, Wrong, Fall };
  struct Npc {
    vec3 pos{0, 0, 0}, target{0, 0, 0};
    float yaw = 0, speed = 0, anim = 0, timer = 0, patience = 0, look = 0, fade = 1;
    int state = 0, browseLeft = 0;
    bool active = false;
    vec4 look4[4];
    float total = 0;
    int sit = 0;
    float hug = 0, size = 1;
    bool lie = false;
    int next = 0;  // state to take once inside
    int outfit = 0;  // 0 casual, 1 suit, 2 work jacket, 3 hazmat
    int item = -1;     // what they're buying (0 can, 1 chips, 2 bottle, 3 candy)
    int itemColor = 0;
    bool itemDown = false;  // on the counter
    float offer = 0;        // arm held out with cash
    float waited = 0;       // seconds at the counter
    int rude = 0;           // how fed up they are
    float price = 0;
    bool strange = false;
  };
  struct Line { std::string who, text; float dur; };
  bool inStore() const { return levelIndex_ == kStoreLevel; }
  // Down here there's no flashlight (it didn't survive the fall): F switches the camcorder to NightShot.
  bool nightShot() const { return levelIndex_ >= 0 || levelIndex_ == kChoiceLevel; }
  bool defaultLight() const { return !nightShot() || level_.theme.deadChance > 0.5f; }  // NightShot starts on only where it's dark
  void drawHeldItem(Shader& S, const Npc& n, CreatureId id);
  void storeBegin();
  void storeUpdate(float dt);
  void storeInteract();
  void storeDraw(Shader& S, vec3 cam);
  void storeHUD();
  void storeLights();
  void say(const std::string& who, const std::string& text, float dur = 0);
  void npcWalk(Npc& n, vec3 goal, float spd, float dt);
  void spawnCustomer(bool strange = false);
  void powerOut();
  void beginFall();
  std::string storePrompt();
  StorePhase storePhase_ = StorePhase::Shift;
  float shiftTime_ = 0, phaseTime_ = 0, power_ = 1;
  std::vector<Npc> customers_;
  Npc ray_;
  std::deque<Line> lines_;
  float lineTime_ = 0;
  bool hasFlashlight_ = true, carrying_ = false, strangeDone_ = false, knockDone_ = false;
  int restockSlot_ = -1, spill_ = -1, served_ = 0, walkouts_ = 0, waitingIdx_ = -1;
  float nextCustomer_ = 5, nextRestock_ = 50, nextSpill_ = 140, holdProgress_ = 0, holdLight_ = 0, fade_ = 0;
  float lastBeep_ = 0;
  std::string objective_;
  GLuint texWindow_ = 0, texDoor_ = 0, texWoodDoor_ = 0, texPuddle_ = 0;

  // ---- hiding, Ray, endings : see game_down.cpp
  struct Slide { int scene; std::string text; float autoAdvance; float fx; int param; };
  int focusLocker() const;
  void enterLocker(int prop);
  void leaveLocker();
  void placeRay();
  bool rayInteract();
  void rayPutDown();
  void rayUpdate(float dt);
  void rayDraw(Shader& S, vec3 cam);
  void rayHUD();
  void drawSubtitles();
  void updateLines(float dt);
  void beginEnding();
  void buildEndingB(bool goBack);
  void endingInput(int dir, bool accept);
  void updateEnding(float dt);
  void endingAudio(Audio::Params& p);
  void startSlide();
  void setupShot(const Slide& sl);
  void endingLights();
  void endingCamera(vec3& pos, vec3& dir, float& fov, PostParams& pp);
  void endingDraw(Shader& S, vec3 cam);
  bool endingFlash(vec3& pos, vec3& dir, float& intensity);
  void drawNpc(Shader& S, const Npc& n, vec3 pos);
  void drawEnding();
  int hiding_ = -1;
  vec3 hidePos_{0, 0, 0};
  float hideYaw_ = 0, hideT_ = 0;
  bool seenHiding_ = false, flashBeforeHide_ = true;
  int rayLevel_ = 2, rayState_ = 0;  // state: 0 lost, 1 found (on the floor), 2 carried, 3 left behind
  bool leftRay_ = false;
  vec3 rayPos_{0, 0, 0};
  float rayYaw_ = 0, rayTalk_ = 8;
  int rayBeg_ = 0;
  std::vector<Slide> slides_;
  int slide_ = 0, choice_ = 0;
  float slideT_ = 0, slideOut_ = -1;
  vec3 shotFrom_{0, 0, 0}, shotTo_{0, 0, 0}, shotTint_{1, 1, 1};
  float shotYaw0_ = 0, shotYaw1_ = 0, shotPitch0_ = 0, shotPitch1_ = 0, shotFov_ = 62, shotDur_ = 10, shotLight_ = 1, shotFlicker_ = 0;
  int tvMode_ = -1, winMode_ = -1;
  bool bricked_ = false, ambulance_ = false, shotArms_ = false, shotFlash_ = false;
  GLuint texNews_ = 0, texHall_ = 0, texAptWin_ = 0, texBrick_ = 0, texSign_ = 0;

  // ---- shocks : see game_shock.cpp
  void shockReset();
  void shockUpdate(float dt);
  void shockDraw(Shader& S, vec3 cam);
  bool shockInteract();
  std::string shockPrompt() const;
  bool lockerScare(int prop);
  void loadEndingFlag();
  void saveEndingFlag(int ending);
  void addStinger();
  const vec4* rayThingLook() const;
  int phoneState_ = 0, ghostState_ = 0, scareGrin_ = -1, endingSeen_ = 0, endingId_ = 0;
  vec3 phonePos_{0, 0, 0}, phoneNormal_{0, 0, 1}, ghostPos_{0, 0, 0};
  float phoneRing_ = 0, phoneT_ = 0, ghostT_ = 0, ghostLook_ = 0, ghostRetry_ = 0, rayThingTalk_ = 12, huntDelay_ = -1;
  bool lockerScareDone_ = false, endingLeft_ = false;
  float savedFlash_ = 0, autosave_ = 30.0f;
  // the 100-foot drop into a level, and the choice at the end
  float plungeT_ = 0, plungeY_ = 30.0f;
  float pitFall_ = -1, pitDrop_ = 0, pitVy_ = 0;  // falling down one of the holes in the pit floor
  vec3 pitAt_;
  bool wentBack_ = false, chooseHome_ = false;
  void startPlunge();
  void updatePlunge(float dt);
  void drawPlungeHUD();
  void chooseRed();
  void chooseBlue();
  int focusTube() const;
  void enterSlide(int which);
  void updateSlide(float dt);
  void drawSlide(Shader& S, vec3 cam);
  void slideCamera(vec3& pos, vec3& dir);
  int slideWhich_ = 0;
  float slideT2_ = 0;
  vec3 slideBase_{0, 0, 0};
  GpuMesh slideMesh_;
  GLuint texHole_[3] = {0, 0, 0}, texTube_[3] = {0, 0, 0};
  // jumping and water
  float vy_ = 0, jumpY_ = 0, landDip_ = 0, wetLens_ = 0;
  bool grounded_ = true, jumpQueued_ = false;
  struct Ripple { vec3 pos; float t0, strength; };
  Ripple ripples_[8] = {};
  int rippleNext_ = 0;
  struct Drop { vec3 p, v; float life; };
  std::vector<Drop> drops_;
  void addRipple(vec3 p, float strength);
  void splash(vec3 p, int count, float force);

  // input
  bool keys_[SDL_NUM_SCANCODES] = {};
  SDL_GameController* pad_ = nullptr;
  bool usingPad_ = false;
  float mouseDX_ = 0, mouseDY_ = 0;

  // menus
  std::vector<MenuItem> menu_;
  int menuSel_ = 0;
  bool optionsOpen_ = false;

  // --- the landing (game_drop.cpp): camera knocked to the floor, you pick it back up
  void startDrop();
  void updateDrop(float dt);
  void dropSkip();
  void dropCamera(vec3& camPos, vec3& camDir, vec3& camUp, float& fov, PostParams& pp);
  void dropDraw(Shader& S, vec3 cam);
  void dropHUD();
  bool dropping_ = false;
  float dropT_ = 0, dropBodyYaw_ = 0, dropStartYaw_ = 0;
  int dropCue_ = 0;
  vec3 dropBody_{0, 0, 0}, dropCam_{0, 0, 0}, dropKneel_{0, 0, 0};
  vec3 camUp_{0, 1, 0};

  // --- quiet scares (game_scares.cpp)
  void scaresReset();
  void scaresUpdate(float dt);
  void scaresDraw(Shader& S, vec3 cam);
  void scaresHUD();
  float scareLight(int i, float s) const;
  float scareStatic() const;
  int scare_ = 0;
  float scareT_ = 0, scareAt_ = 60, scareRun_ = 0, stepsYaw_ = 0, stepsNext_ = 0, stepsQuiet_ = 0, watcherAway_ = 0, faceT_ = -1;
  bool watcher_ = false, faceDone_ = false;
  vec3 watcherPos_{0, 0, 0};
  std::vector<int> chaseOrder_;
  std::vector<float> lightKill_;
  GLuint texFace_ = 0;

  // --- ray tracing (game_rt.cpp + the world shader)
  void buildRTTextures();
  void rtBind(Shader& S, vec3 cam);
  GLuint texRTGrid_ = 0, texRTLights_ = 0;

  // --- meta progression (game_meta.cpp): lost tapes, badges, endings, endless runs
  struct Profile { uint32_t tapes = 0, badges = 0; int endings = 0, bestDepth = 0, runs = 0, dailyDay = 0, dailyBest = 0, falls = 0; };
  Profile profile_;
  void loadProfile();
  void saveProfile();
  void unlockBadge(int id);
  void metaEnding(int id);
  void metaEscaped(bool fromStore);
  void metaTapeFound(int id);
  void startEndless(bool daily);
  void endlessNext(uint32_t nextSeed);
  void endlessOver();
  void endlessTheme(Theme& th) const;
  void buildArchiveMenu();
  void drawTape(int id, float t, bool archive);
  void drawArchiveView();
  void drawBadgePopup();
  void drawRunOver();
  void drawTitleStats();
  void drawEndlessHUD();
  bool archiveInput(bool any);
  static int tapeCount();
  static int badgeCount();
  bool endless_ = false, daily_ = false, archiveOpen_ = false, runOverShow_ = false, runOverRecord_ = false, lastDaily_ = false;
  int depth_ = 0, readingTape_ = -1, archiveSel_ = 0, archiveView_ = 0, runOverDepth_ = 0, levelDeaths_ = 0;
  uint32_t endlessSeed_ = 1;
  std::vector<int> badgeQueue_;
  float badgeT_ = 0, archiveT_ = 0;
};
