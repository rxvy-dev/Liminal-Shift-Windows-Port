// Districts and the way out.
//
// A level isn't one pattern copied 48 x 48 times any more. It's split into a handful of
// districts, each with its own layout, light and furniture, and walled off from the next
// except for a few doorways:
//   plain      the level as it always was
//   hall       one huge open room on a grid of piers
//   maze       tight, twisting corridors, nearly no loops
//   old wing   the second set of walls and floors (darker, older), lights that won't settle
//   dark       most of the lights are dead
//   office     an open floor of abandoned desks and chairs
//   corridors  long parallel hallways with the odd gap between them
// Most districts have a landmark you can steer by: a tower of boxes, a living room, a ring
// of chairs, a row of lockers.
//
// Someone got out before you, and left a trail that gets harder to miss the closer you get:
//   footprints from early on (with a couple of trails that don't end well),
//   blue tape at the turns from about a third of the way,
//   an orange extension cord on the floor for the last half, running right to the door,
//   steady lights along the route near the end, while the lights around it die,
//   lit EXIT signs over the last stretch (level.cpp).
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <queue>

#include "creatures.h"
#include "level.h"

namespace {
vec3 dirD(int d) { return {(float)kDX[d], 0, (float)kDZ[d]}; }
}  // namespace

void Level::carveDistricts(Rng& rng) {
  district.assign(W * H, D_PLAIN);
  if (theme.special == Special::Suburbs || theme.special == Special::Playplace) return;
  const bool pools = theme.layout == Layout::Pools;

  // which kinds this level can have
  std::vector<int> kinds = {D_HALL, D_MAZE, D_DARK, D_CORRIDORS, D_OFFICE};
  if (!pools && !theme.party) kinds.push_back(D_OLD);
  if (pools) kinds = {D_HALL, D_MAZE, D_DARK};
  if (theme.deadChance > 0.5f) std::replace(kinds.begin(), kinds.end(), (int)D_DARK, (int)D_PLAIN);  // Lights Out is all dark already
  for (size_t i = kinds.size(); i > 1; --i) std::swap(kinds[i - 1], kinds[rng.next() % i]);
  // the pit floor (the Lobby, Lights Out, Run) and the closing-down bookstore always make it in
  const int ti = theme.index;
  bool office = theme.special == Special::Office, parking = theme.special == Special::Parking;
  if (!pools && !theme.party && (ti == 0 || ti == 5 || ti == 7 || office)) kinds.insert(kinds.begin(), D_SHOP);
  if (!pools && !parking && (ti == 0 || ti == 4 || ti == 7)) kinds.insert(kinds.begin(), D_PITS);

  // seeds, spread out
  struct Seed { float x, z; int kind; };
  std::vector<Seed> seeds;
  int want = std::clamp(W * H / 270, 5, 9);
  for (int tries = 0; tries < 2000 && (int)seeds.size() < want; ++tries) {
    Seed s{rng.range(2.0f, W - 2.0f), rng.range(2.0f, H - 2.0f), 0};
    bool ok = true;
    for (const Seed& o : seeds) if (std::hypot(o.x - s.x, o.z - s.z) < 11.0f) ok = false;
    if (!ok) continue;
    seeds.push_back(s);
  }
  for (size_t i = 0; i < seeds.size(); ++i)
    seeds[i].kind = i == 0 ? D_PLAIN : (i - 1 < kinds.size() ? kinds[i - 1] : kinds[rng.next() % kinds.size()]);
  // nearest seed, with wobbly borders
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      float best = 1e9f;
      int bk = 0;
      for (const Seed& s : seeds) {
        float d = std::hypot(s.x - x, s.z - z) + 3.0f * (hashf(x / 3, z / 3, (int)seed + (int)(s.x * 7)) - 0.5f);
        if (d < best) { best = d; bk = s.kind; }
      }
      district[idx(x, z)] = (uint8_t)bk;
    }
  auto same = [&](int x, int z, int d) {
    int nx = x + kDX[d], nz = z + kDZ[d];
    if (nx < 0 || nz < 0 || nx >= W || nz >= H) return false;
    return district[idx(x, z)] == district[idx(nx, nz)];
  };
  // corridor districts run one way or the other
  std::vector<uint8_t> alongX(D_COUNT, 0);
  for (auto& a : alongX) a = rng.f01() < 0.5f ? 1 : 0;

  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      int i = idx(x, z), k = district[i];
      for (int d : {PX, PZ}) {
        if (!same(x, z, d)) {
          // the border between two districts: mostly wall, a few ways through
          if ((d == PX && x < W - 1) || (d == PZ && z < H - 1)) setWall(x, z, d, rng.f01() < 0.82f ? 1 : 0);
          continue;
        }
        switch (k) {
          case D_HALL: case D_OFFICE: case D_PITS: case D_SHOP: setWall(x, z, d, 0); break;
          case D_CORRIDORS: {
            bool along = (d == PX) == (alongX[k] != 0);
            int cross = alongX[k] ? z : x;
            if (along) setWall(x, z, d, 0);
            else setWall(x, z, d, (cross % 2 == 0 && hashf(x, z, (int)seed + 5) > 0.1f) ? 1 : 0);
          } break;
          case D_MAZE: setWall(x, z, d, 1); break;
          default: break;
        }
      }
      if (k == D_HALL) pillar[i] = (x % 3 == 1 && z % 3 == 1 && same(x, z, PX) && same(x, z, NX) && same(x, z, PZ) && same(x, z, NZ)) ? 1 : 0;
      if (k == D_OFFICE || k == D_MAZE || k == D_CORRIDORS || k == D_PITS) pillar[i] = 0;
      if (k == D_SHOP) pillar[i] = (x % 5 == 2 && z % 5 == 2 && same(x, z, PX) && same(x, z, NX) && same(x, z, PZ) && same(x, z, NZ)) ? 1 : 0;
      if (k == D_PITS || k == D_SHOP) pool[i] = 0;
      if (k == D_OLD) zone[i] = 1;
      if (k == D_MAZE && !pools) pool[i] = 0;
    }
  // the maze districts: a perfect maze inside each, then a few loops
  {
    std::vector<uint8_t> seen(W * H, 0);
    for (int start = 0; start < W * H; ++start) {
      if (district[start] != D_MAZE || seen[start]) continue;
      std::vector<int> stack{start};
      seen[start] = 1;
      while (!stack.empty()) {
        int c = stack.back(), cx = c % W, cz = c / W;
        int opts[4], n = 0;
        for (int d = 0; d < 4; ++d) {
          int nx = cx + kDX[d], nz = cz + kDZ[d];
          if (nx < 0 || nz < 0 || nx >= W || nz >= H) continue;
          int ni = idx(nx, nz);
          if (district[ni] == D_MAZE && !seen[ni]) opts[n++] = d;
        }
        if (!n) { stack.pop_back(); continue; }
        int d = opts[rng.next() % n];
        setWall(cx, cz, d, 0);
        int ni = idx(cx + kDX[d], cz + kDZ[d]);
        seen[ni] = 1;
        stack.push_back(ni);
      }
    }
    for (int i = 0; i < W * H; ++i)
      if (district[i] == D_MAZE)
        for (int d : {PX, PZ})
          if (same(i % W, i / W, d) && rng.f01() < 0.1f) setWall(i % W, i / W, d, 0);
  }
  ensureConnected();
  if (std::getenv("BR9_ROUTEDBG")) {
    int cnt[D_COUNT] = {};
    for (uint8_t k : district) ++cnt[k];
    std::fprintf(stderr, "[districts] plain %d hall %d maze %d old %d dark %d office %d corridors %d pits %d shop %d\n", cnt[0], cnt[1], cnt[2], cnt[3], cnt[4], cnt[5], cnt[6], cnt[7], cnt[8]);
  }
}

// The cheapest walk from the start to the exit (wading and squeezing past pillars cost extra).
void Level::computeRoute() {
  routePath.clear();
  routeFrac.assign(W * H, -1.0f);
  std::vector<int> cost(W * H, 1 << 29);
  using QE = std::pair<int, int>;
  std::priority_queue<QE, std::vector<QE>, std::greater<QE>> q;
  cost[idx(exitX, exitZ)] = 0;
  q.push({0, idx(exitX, exitZ)});
  while (!q.empty()) {
    auto [c, i] = q.top(); q.pop();
    if (c > cost[i]) continue;
    int x = i % W, z = i / W;
    for (int d = 0; d < 4; ++d) {
      if (blocked(x, z, d)) continue;
      int n = idx(x + kDX[d], z + kDZ[d]);
      if (!solid.empty() && solid[n]) continue;
      int step = 2 + (pool[n] ? 7 : 0) + (pillar[n] ? 2 : 0);
      if (c + step < cost[n]) { cost[n] = c + step; q.push({c + step, n}); }
    }
  }
  int cx = startX, cz = startZ;
  routePath.push_back(idx(cx, cz));
  for (int guard = 0; guard < W * H && cost[idx(cx, cz)] > 0; ++guard) {
    int best = -1, bc = cost[idx(cx, cz)];
    for (int d = 0; d < 4; ++d) {
      if (blocked(cx, cz, d)) continue;
      int c = cost[idx(cx + kDX[d], cz + kDZ[d])];
      if (c < bc) { bc = c; best = d; }
    }
    if (best < 0) break;
    cx = wx(cx + kDX[best]); cz = wz(cz + kDZ[best]);
    routePath.push_back(idx(cx, cz));
  }
  int n = (int)routePath.size();
  for (int k = 0; k < n; ++k) routeFrac[routePath[k]] = n > 1 ? k / (float)(n - 1) : 1.0f;
}

void Level::districtLights(Rng& rng) {
  // how far along the route the nearest route tile is (within a tile), or -1
  auto nearRoute = [&](int x, int z) {
    float best = -1;
    for (int dz = -1; dz <= 1; ++dz)
      for (int dx = -1; dx <= 1; ++dx) {
        int nx = x + dx, nz = z + dz;
        if (nx < 0 || nz < 0 || nx >= W || nz >= H) continue;
        best = std::max(best, routeFrac.empty() ? -1.0f : routeFrac[idx(nx, nz)]);
      }
    return best;
  };
  const bool darkLevel = theme.deadChance > 0.5f;
  for (Light& L : lights) {
    if (L.pos.y < wallH - 0.2f) continue;  // skylights and stairwells
    int x, z;
    tileOf(L.pos.x, L.pos.z + 0.25f, x, z);
    int i = idx(x, z);
    switch (districtAt(x, z)) {
      case D_DARK: L.kind = rng.f01() < 0.78f ? 2 : 1; break;
      case D_OLD: if (L.kind == 0 && rng.f01() < 0.35f) L.kind = 1; L.intensity *= 0.85f; break;
      case D_OFFICE: if (rng.f01() < 0.18f) L.kind = 2; break;
      case D_HALL: L.intensity *= 1.05f; break;
      default: break;
    }
    // near the end, the lights lead you: steady along the way out, dying around it
    float f = nearRoute(x, z);
    int ed = exitDist.empty() ? 999 : exitDist[i];
    if (f > 0.55f) {
      L.kind = darkLevel ? 1 : 0;  // in the dark levels: a trail of flickering lights
      L.intensity *= 1.1f;
    } else if (ed >= 0 && ed < 16 && rng.f01() < 0.55f) {
      L.kind = 2;
    }
  }
}

void Level::districtProps(Rng& rng) {
  if (district.empty()) return;
  auto onRoute = [&](int i) { return !routeFrac.empty() && routeFrac[i] >= 0; };
  auto free = [&](int x, int z) {
    if (x < 1 || z < 1 || x >= W - 1 || z >= H - 1) return false;
    int i = idx(x, z);
    if (pillar[i] || pool[i] || (!solid.empty() && solid[i]) || !propsAtTile[i].empty() || onRoute(i) || isNarrow(x, z)) return false;
    if (std::abs(x - startX) <= 1 && std::abs(z - startZ) <= 1) return false;
    if (std::abs(x - exitX) <= 1 && std::abs(z - exitZ) <= 1) return false;
    return true;
  };
  auto openSides = [&](int x, int z) { int n = 0; for (int d = 0; d < 4; ++d) n += blocked(x, z, d) ? 0 : 1; return n; };

  // the office floors: rows of desks, chairs pushed back or knocked over
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      if (districtAt(x, z) != D_OFFICE || x % 2 || z % 3 == 2 || !free(x, z) || openSides(x, z) < 3) continue;
      if (hashf(x, z, (int)seed + 61) < 0.2f) continue;
      vec3 c = tileCenter(x, z);
      float yaw = (z % 3 == 0) ? 0.0f : kPi;
      addProp(PR_DESK, c, yaw + rng.range(-0.06f, 0.06f), 0, 0.64f, 0.4f);
      vec3 ch = c + vec3{std::sin(yaw), 0, std::cos(yaw)} * 0.75f + vec3{rng.range(-0.3f, 0.3f), 0, 0};
      if (rng.f01() < 0.25f) addProp(PR_CHAIR, {ch.x, 0.3f, ch.z}, rng.range(0, 6.28f), kPi * 0.5f, 0, 0);
      else if (rng.f01() < 0.8f) addProp(PR_CHAIR, ch, yaw + kPi + rng.range(-0.5f, 0.5f), 0, 0, 0);
      if (rng.f01() < 0.15f) addProp(PR_BOX, c + vec3{0.3f, 0.76f, 0}, rng.range(0, 6.28f), 0, 0, 0);
    }

  // the closing-down bookstore: rows of emptied wooden shelving, a cross aisle every few metres
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      if (districtAt(x, z) != D_SHOP || z % 2 || x % 5 == 4 || !free(x, z)) continue;
      vec3 c = tileCenter(x, z) + vec3{0, 0, rng.range(-0.08f, 0.08f)};
      if (rng.f01() < 0.08f) { addProp(PR_BOOKCASE, c, rng.range(-0.5f, 0.5f), 0, 0.92f, 0.34f); continue; }  // dragged out of line
      addProp(PR_BOOKCASE, c, 0.0f, 0, 0.92f, 0.34f);
    }

  // one staircase to nowhere per level: a short dead-end corridor, stairs climbing into the ceiling
  if (theme.special != Special::Suburbs && theme.special != Special::Playplace && theme.layout != Layout::Pools && !theme.outdoor) {
    std::vector<std::pair<int, int>> cands;
    for (int z = 2; z < H - 2; ++z)
      for (int x = 2; x < W - 2; ++x)
        for (int d = 0; d < 4; ++d) {
          int bx = x + kDX[d], bz = z + kDZ[d];
          int a = idx(x, z), b = idx(bx, bz);
          if (!free(x, z) || !free(bx, bz) || lightAtTile[b] >= 0) continue;
          if (blocked(x, z, d) || !blocked(bx, bz, d) || solidNext(bx, bz, d) || blocked(x, z, d ^ 1)) continue;
          int side1 = d < 2 ? PZ : PX, side2 = side1 ^ 1;
          if (!blocked(x, z, side1) || !blocked(x, z, side2) || !blocked(bx, bz, side1) || !blocked(bx, bz, side2)) continue;
          int k = districtAt(x, z);
          if (k == D_OFFICE || k == D_SHOP || k == D_PITS) continue;
          (void)a;
          cands.push_back({a, d});
        }
    if (!cands.empty()) {
      auto [a, d] = cands[rng.next() % cands.size()];
      int x = a % W, z = a / W;
      vec3 mid = tileCenter(x, z) + dirD(d) * (kTile * 0.5f);
      addProp(PR_STAIRS, mid, std::atan2(-(float)kDX[d], -(float)kDZ[d]), 0, 0.62f, 1.9f);
      stairUp.push_back(idx(x + kDX[d], z + kDZ[d]));
      // one warm bulb over the bottom step, always on, so you see them from down the corridor
      {
        int ai = idx(x, z);
        int id = lightAtTile[ai];
        if (id < 0) {
          Light L;
          L.pos = tileCenter(x, z, wallH - 0.02f) - dirD(d) * 0.3f;
          L.id = id = (int)lights.size();
          lights.push_back(L);
          lightAtTile[ai] = id;
        }
        lights[id].kind = 0;
        lights[id].intensity = 0.9f * theme.lightIntensity;
      }
      if (std::getenv("BR9_ROUTEDBG")) std::fprintf(stderr, "[districts] stairs at %d,%d dir %d (%zu spots)\n", x, z, d, cands.size());
    }
  }

  // landmarks: one per district, near its middle
  // group by connected region of the same kind
  std::vector<int> region(W * H, -1);
  std::vector<int> regionKind;
  std::vector<std::vector<int>> regionTiles;
  for (int s = 0; s < W * H; ++s) {
    if (region[s] >= 0) continue;
    int r = (int)regionKind.size();
    regionKind.push_back(district[s]);
    regionTiles.emplace_back();
    std::vector<int> st{s};
    region[s] = r;
    while (!st.empty()) {
      int c = st.back(); st.pop_back();
      regionTiles[r].push_back(c);
      int x = c % W, z = c / W;
      for (int d = 0; d < 4; ++d) {
        int nx = x + kDX[d], nz = z + kDZ[d];
        if (nx < 0 || nz < 0 || nx >= W || nz >= H) continue;
        int n = idx(nx, nz);
        if (region[n] < 0 && district[n] == district[c]) { region[n] = r; st.push_back(n); }
      }
    }
  }
  int placed = 0;
  for (size_t r = 0; r < regionKind.size(); ++r) {
    int k = regionKind[r];
    if (regionTiles[r].size() < 40 || k == D_PLAIN) continue;
    double mx = 0, mz = 0;
    for (int t : regionTiles[r]) { mx += t % W; mz += t / W; }
    mx /= regionTiles[r].size(); mz /= regionTiles[r].size();
    // the free tile nearest the middle that suits this landmark
    int best = -1;
    double bd = 1e9;
    for (int t : regionTiles[r]) {
      int x = t % W, z = t / W;
      if (!free(x, z)) continue;
      int open = openSides(x, z);
      if (k == D_MAZE ? open != 1 : open < (k == D_CORRIDORS ? 2 : 4)) continue;
      double d = (x - mx) * (x - mx) + (z - mz) * (z - mz);
      if (d < bd) { bd = d; best = t; }
    }
    if (best < 0) continue;
    int x = best % W, z = best / W;
    vec3 c = tileCenter(x, z);
    ++placed;
    switch (k) {
      case D_HALL: {  // a tower of boxes nearly to the ceiling, seen from all over the hall
        int levels = std::max(3, (int)(wallH / 0.38f) - 1);
        for (int l = 0; l < levels; ++l)
          for (int q = 0; q < 2; ++q) {
            if (l == levels - 1 && q == 1) continue;
            vec3 p = c + vec3{q ? 0.27f : -0.27f, l * 0.38f, (l % 2) ? 0.08f : -0.08f};
            addProp(PR_BOX, p, rng.range(-0.3f, 0.3f) + (l % 2) * 1.57f, 0, l == 0 ? 0.55f : 0.0f, l == 0 ? 0.3f : 0.0f);
          }
      } break;
      case D_OLD: {  // somebody's living room: a couch, a TV on a table, a lamp
        float yaw = rng.range(0, 6.28f);
        vec3 f{std::sin(yaw), 0, std::cos(yaw)}, rt{std::cos(yaw), 0, -std::sin(yaw)};
        addProp(PR_COUCH, c - f * 0.6f, yaw + kPi, 0, 1.05f, 0.45f);
        addProp(PR_TABLE, c + f * 0.2f, yaw, 0, 0.5f, 0.3f);
        addProp(PR_TVSET, c + f * 0.88f, yaw, 0, 0.55f, 0.28f);
        addProp(PR_LAMP, c - f * 0.75f + rt * 1.3f, 0, 0, 0.15f, 0.15f);
      } break;
      case D_DARK: {  // a ring of chairs, all facing a lantern
        addProp(PR_LANTERN, c, 0, 0, 0, 0);
        for (int q = 0; q < 6; ++q) {
          float a = q * 6.2832f / 6 + 0.3f;
          vec3 p = c + vec3{std::sin(a), 0, std::cos(a)} * 0.78f;
          addProp(PR_CHAIR, p, a + kPi + rng.range(-0.15f, 0.15f), 0, 0.22f, 0.22f);
        }
      } break;
      case D_OFFICE: addProp(PR_CART, c, rng.range(0, 6.28f), 0, 0.3f, 0.5f); break;
      case D_CORRIDORS: {  // a row of lockers down one wall
        int wd = -1;
        for (int d = 0; d < 4; ++d) if (blocked(x, z, d) && !solidNext(x, z, d)) { wd = d; break; }
        if (wd < 0) break;
        vec3 along = dirD(wd < 2 ? PZ : PX);
        for (int q = -1; q <= 1; ++q) {
          vec3 p = c + dirD(wd) * 0.62f + along * (q * 0.58f);
          addProp(PR_LOCKER, p, std::atan2((float)kDX[wd], (float)kDZ[wd]), 0, 0.28f, 0.28f);
        }
      } break;
      case D_MAZE: {  // a dead end with one chair in it, facing the wall
        int wd = -1;
        for (int d = 0; d < 4; ++d) if (!blocked(x, z, d)) { wd = d ^ 1; break; }
        if (wd < 0) break;
        addProp(PR_CHAIR, c + dirD(wd) * 0.35f, std::atan2((float)kDX[wd], (float)kDZ[wd]) + kPi, 0, 0.25f, 0.25f);
      } break;
      default: break;
    }
  }
  if (std::getenv("BR9_ROUTEDBG")) std::fprintf(stderr, "[districts] %zu regions, %d landmarks\n", regionKind.size(), placed);
}

// The trail. It starts faint (footprints) and gets harder to miss.
void Level::trailDecals(Rng& rng) {
  cord.clear();
  int n = (int)routePath.size();
  if (n < 3) return;
  const bool balls = theme.special == Special::Playplace;
  const float y = std::min(1.4f, wallH * 0.48f);
  auto stepDir = [&](int a, int b) {
    for (int d = 0; d < 4; ++d)
      if (idx(a % W + kDX[d], a / W + kDZ[d]) == b) return d;
    return 0;
  };
  auto footprint = [&](vec3 at, int d, float jitter) {
    if (balls) return;
    vec3 rt = cross(dirD(d), vec3{0, 1, 0});
    Decal fd;
    fd.n = {0, 1, 0};
    fd.right = dirD(d);
    fd.pos = at + rt * jitter;
    fd.pos.y = floorAt(fd.pos.x, fd.pos.z) + 0.006f;
    fd.w = 0.95f; fd.h = 0.42f;
    fd.kind = DECAL_FOOTPRINTS;
    fd.tilt = rng.range(-0.12f, 0.12f);
    decals.push_back(fd);
  };
  auto wallTape = [&](int x, int z, int wallDir, vec3 pointAlong, float yy) {
    vec3 c = tileCenter(x, z, yy);
    vec3 dv = dirD(wallDir);
    Decal d;
    d.n = -dv;
    d.pos = c + dv * (kTile * 0.5f - kWallT * 0.5f - 0.006f);
    vec3 r = cross(vec3{0, 1, 0}, d.n);
    d.pos += r * (dot(r, pointAlong) * 0.45f);
    d.w = 0.62f; d.h = 0.5f; d.kind = DECAL_TAPE;
    d.flip = dot(r, pointAlong) < 0;
    d.tilt = rng.range(-0.05f, 0.05f);
    d.color = {0.05f, 0.2f, 0.8f};
    decals.push_back(d);
  };
  auto floorTape = [&](vec3 at, int d) {
    Decal fd;
    fd.n = {0, 1, 0};
    fd.right = dirD(d);
    fd.pos = at;
    fd.pos.y = floorAt(at.x, at.z) + (balls ? 0.17f : 0.007f);
    fd.w = 0.9f; fd.h = 0.06f;
    fd.kind = DECAL_STRIPE;
    fd.color = {0.05f, 0.2f, 0.8f};
    decals.push_back(fd);
  };

  int since = 0;
  for (int k = 1; k < n - 1; ++k) {
    float f = k / (float)(n - 1);
    int t = routePath[k], x = t % W, z = t / W;
    int din = stepDir(routePath[k - 1], t), d = stepDir(t, routePath[k + 1]);
    bool turn = d != din;
    bool wet = pool[t] != 0;
    // 1. footprints: patchy at first, then every tile
    if (f > 0.06f && !wet && rng.f01() < (f < 0.3f ? 0.6f : 0.95f)) {
      vec3 c = tileCenter(x, z) + dirD(din) * -0.5f;
      footprint(c, din, (pillar[t] ? 0.5f : 0.0f) + rng.range(-0.15f, 0.15f));
      if (turn) footprint(tileCenter(x, z) + dirD(d) * 0.45f, d, rng.range(-0.1f, 0.1f));
    }
    // 2. blue tape at every turn, and now and then on a straight
    ++since;
    if (f > 0.3f && (turn || since >= 4)) {
      bool done = false;
      if (turn && blocked(x, z, din) && !solidNext(x, z, din)) { wallTape(x, z, din, dirD(d), y); done = true; }
      if (!done)
        for (int w = 0; w < 4 && !done; ++w) {
          bool side = (kDX[w] != 0) != (kDX[d] != 0);
          if (side && blocked(x, z, w) && !solidNext(x, z, w)) { wallTape(x, z, w, dirD(d), y); done = true; }
        }
      if (!done && !wet && !pillar[t]) { floorTape(tileCenter(x, z) + dirD(d) * 0.3f, d); done = true; }
      if (done) since = 0;
    }
  }
  // 3. the cord: from halfway to the door, along one side of the way
  {
    int k0 = std::max(1, (int)(n * 0.5f));
    float side = rng.f01() < 0.5f ? 0.62f : -0.62f;
    auto lift = [&](vec3 p) { p.y = floorAt(p.x, p.z) + (balls ? 0.16f : 0.016f); return p; };
    for (int k = k0; k < n; ++k) {
      int t = routePath[k], x = t % W, z = t / W;
      int din = stepDir(routePath[k - 1], t);
      int d = k + 1 < n ? stepDir(t, routePath[k + 1]) : din;
      vec3 r = cross(dirD(din), vec3{0, 1, 0}) + cross(dirD(d), vec3{0, 1, 0});
      float rl = length(r);
      r = rl > 0.01f ? r * (1.0f / rl) : cross(dirD(d), vec3{0, 1, 0});
      vec3 p = tileCenter(x, z) + r * side + vec3{rng.range(-0.08f, 0.08f), 0, rng.range(-0.08f, 0.08f)};
      if (pillar[t]) p = tileCenter(x, z) + r * (side > 0 ? 0.75f : -0.75f);
      if (!cord.empty()) {  // step down into (and out of) the water at the tile edge
        vec3 a = cord.back(), m = (a + p) * 0.5f;
        vec3 ma = lift(m + (a - m) * 0.06f), mb = lift(m + (p - m) * 0.06f);
        ma.y = a.y; mb.y = lift(p).y;
        if (std::fabs(a.y - mb.y) > 0.05f) { cord.push_back(ma); cord.push_back(mb); }
      }
      cord.push_back(lift(p));
    }
    // right up to the taped door, and a work light left on the floor beside it
    vec3 door = tileCenter(exitX, exitZ) + dirD(exitDir) * (kTile * 0.5f - 0.22f);
    vec3 rt = cross(dirD(exitDir), vec3{0, 1, 0});
    cord.push_back(lift(door + rt * 0.55f));
    addProp(PR_LANTERN, lift(door + rt * 0.7f) - vec3{0, 0.016f, 0}, rng.range(0, 6.28f), 0, 0, 0);
  }
  // THE END IS NEAR, high on a wall you walk toward, most of the way there
  for (int k = (int)(n * 0.72f); k < n - 4; ++k) {
    int t = routePath[k], x = t % W, z = t / W;
    int din = stepDir(routePath[k - 1], t);
    if (!blocked(x, z, din) || solidNext(x, z, din)) continue;
    vec3 c = tileCenter(x, z, wallH - 0.5f);
    Decal d;
    d.n = -dirD(din);
    d.pos = c + dirD(din) * (kTile * 0.5f - kWallT * 0.5f - 0.006f);
    int side = din < 2 ? PZ : PX;  // a long wall gets the big version
    bool wide = blocked(x + kDX[side], z + kDZ[side], din) && blocked(x - kDX[side], z - kDZ[side], din) &&
                !blocked(x, z, side) && !blocked(x, z, side ^ 1);
    d.w = wide ? 3.4f : 1.9f; d.h = d.w * 160.0f / 1024.0f;
    d.kind = DECAL_ENDNEAR;
    decals.push_back(d);
    break;
  }
  // FOR SALE posters on the store's pillars
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      if (districtAt(x, z) != D_SHOP || !pillar[idx(x, z)]) continue;
      for (int f = 0; f < 4; ++f) {
        if (rng.f01() < 0.45f) continue;
        Decal d;
        d.n = dirD(f);
        d.pos = tileCenter(x, z, rng.range(1.25f, 1.6f)) + dirD(f) * (kPillar + 0.004f);
        d.w = 0.36f; d.h = 0.36f * 336.0f / 256.0f;
        d.kind = DECAL_FORSALE;
        d.tilt = rng.range(-0.04f, 0.04f);
        decals.push_back(d);
      }
    }
  // 4. a couple of trails that don't go anywhere good
  for (int dtr = 0; dtr < 2; ++dtr) {
    int k = (int)(n * rng.range(0.12f, 0.45f));
    if (k < 1 || k >= n - 1) continue;
    int c = routePath[k];
    std::vector<int> walk{c};
    std::vector<uint8_t> seen(W * H, 0);
    seen[c] = 1;
    for (int s = 0; s < 11; ++s) {
      int x = c % W, z = c / W, opts[4], m = 0;
      for (int d = 0; d < 4; ++d) {
        if (blocked(x, z, d)) continue;
        int nb = idx(x + kDX[d], z + kDZ[d]);
        if (seen[nb] || routeFrac[nb] >= 0 || pool[nb] || (!solid.empty() && solid[nb])) continue;
        opts[m++] = d;
      }
      if (!m) break;
      int d = opts[rng.next() % m];
      c = idx(x + kDX[d], z + kDZ[d]);
      seen[c] = 1;
      walk.push_back(c);
    }
    if (walk.size() < 5) continue;
    for (size_t s = 1; s < walk.size(); ++s) {
      int dd = stepDir(walk[s - 1], walk[s]);
      if (rng.f01() < 0.85f) footprint(tileCenter(walk[s] % W, walk[s] / W) + dirD(dd) * -0.5f, dd, rng.range(-0.15f, 0.15f));
    }
    if (!balls) {
      Decal bp;
      bp.n = {0, 1, 0};
      bp.right = {1, 0, 0};
      bp.pos = tileCenter(walk.back() % W, walk.back() / W);
      bp.pos.y = floorAt(bp.pos.x, bp.pos.z) + 0.005f;
      bp.w = bp.h = 1.4f;
      bp.kind = DECAL_BLOOD_POOL;
      bp.tilt = rng.range(0, 6.28f);
      decals.push_back(bp);
    }
  }
}

void Level::dumpMap(const char* path) const {
  const int S = 8;
  int iw = W * S, ih = H * S;
  std::vector<uint8_t> img((size_t)iw * ih * 3, 0);
  static const uint8_t col[D_COUNT][3] = {{150, 140, 100}, {200, 190, 120}, {120, 90, 60}, {100, 70, 110}, {40, 40, 50}, {90, 130, 150}, {140, 110, 80}, {200, 120, 160}, {170, 120, 60}};
  auto put = [&](int px, int py, uint8_t r, uint8_t g, uint8_t b) {
    if (px < 0 || py < 0 || px >= iw || py >= ih) return;
    uint8_t* q = &img[((size_t)py * iw + px) * 3];
    q[0] = r; q[1] = g; q[2] = b;
  };
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      int i = idx(x, z), k = districtAt(x, z);
      for (int py = 0; py < S; ++py)
        for (int px = 0; px < S; ++px) {
          const uint8_t* c = col[k];
          if (pool[i]) put(x * S + px, z * S + py, 40, 90, 140);
          else put(x * S + px, z * S + py, c[0], c[1], c[2]);
        }
      if (isPit(x, z)) for (int py = 2; py < 6; ++py) for (int px = 2; px < 6; ++px) put(x * S + px, z * S + py, 0, 0, 0);
      if (pillar[i]) for (int py = 3; py < 5; ++py) for (int px = 3; px < 5; ++px) put(x * S + px, z * S + py, 20, 20, 20);
      if (!solid.empty() && solid[i]) for (int py = 0; py < S; ++py) for (int px = 0; px < S; ++px) put(x * S + px, z * S + py, 10, 10, 10);
      if (!routeFrac.empty() && routeFrac[i] >= 0) for (int py = 3; py < 5; ++py) for (int px = 2; px < 6; ++px) put(x * S + px, z * S + py, 230, 30, 30);
      if (eWall[i]) for (int py = 0; py < S; ++py) put(x * S + S - 1, z * S + py, 0, 0, 0);
      if (sWall[i]) for (int px = 0; px < S; ++px) put(x * S + px, z * S + S - 1, 0, 0, 0);
    }
  for (const vec3& c : cord) put((int)(c.x / kTile * S), (int)(c.z / kTile * S), 255, 140, 0);
  for (int py = 1; py < 7; ++py) for (int px = 1; px < 7; ++px) { put(startX * S + px, startZ * S + py, 40, 80, 255); put(exitX * S + px, exitZ * S + py, 30, 220, 60); }
  if (FILE* f = std::fopen(path, "wb")) {
    std::fprintf(f, "P6\n%d %d\n255\n", iw, ih);
    std::fwrite(img.data(), 1, img.size(), f);
    std::fclose(f);
  }
}

// ---------------------------------------------------------------- the pit floor

void Level::carvePits(Rng& rng) {
  pit.assign(W * H, 0);
  if (district.empty()) return;
  auto inPits = [&](int x, int z) { return x >= 0 && z >= 0 && x < W && z < H && district[idx(x, z)] == D_PITS; };
  int n = 0;
  for (int z = 1; z < H - 1; ++z)
    for (int x = 1; x < W - 1; ++x) {
      int i = idx(x, z);
      if (!inPits(x, z) || pillar[i] || pool[i] || (!solid.empty() && solid[i])) continue;
      if (!inPits(x + 1, z) || !inPits(x - 1, z) || !inPits(x, z + 1) || !inPits(x, z - 1)) continue;  // solid floor round the edge
      if (routeFrac[i] >= 0) continue;  // the way across is solid
      if (std::abs(x - startX) <= 1 && std::abs(z - startZ) <= 1) continue;
      if (std::abs(x - exitX) <= 1 && std::abs(z - exitZ) <= 1) continue;
      if (rng.f01() < 0.04f) continue;  // the odd tile somebody filled in
      pit[i] = 1;
      ++n;
    }
  if (std::getenv("BR9_ROUTEDBG")) std::fprintf(stderr, "[districts] %d pits\n", n);
}

bool Level::overPit(float x, float z, float margin) const {
  if (pit.empty()) return false;
  int tx, tz;
  tileOf(x, z, tx, tz);
  if (!isPit(tx, tz)) return false;
  float lx = wrap({x, 0, z}).x - wx(tx) * kTile, lz = wrap({x, 0, z}).z - wz(tz) * kTile;
  return lx > kPitLo + margin && lx < kPitHi - margin && lz > kPitLo + margin && lz < kPitHi - margin;
}

void Level::prunePitProps() {
  if (pit.empty()) return;
  std::vector<PropInstance> keep;
  for (const PropInstance& p : props) {
    int tx, tz;
    tileOf(p.pos.x, p.pos.z, tx, tz);
    if (!isPit(tx, tz)) keep.push_back(p);
  }
  props.swap(keep);
  propsAtTile.assign(W * H, {});
  for (size_t k = 0; k < props.size(); ++k) {
    int tx, tz;
    tileOf(props[k].pos.x, props[k].pos.z, tx, tz);
    propsAtTile[idx(tx, tz)].push_back((int)k);
  }
}

bool Level::isStairUp(int x, int z) const {
  if (stairUp.empty()) return false;
  int i = idx(x, z);
  for (int s : stairUp) if (s == i) return true;
  return false;
}
