// Real-time synthesized audio through SDL (works on PipeWire, PulseAudio, ALSA).
#pragma once
#include <SDL.h>
#include <cstdint>
#include <vector>

enum class Sfx { Footstep, HeavyStep, Pickup, Paper, Battery, Drink, Click, ChaseSting, Death, Knock, Slam, Noclip, Brownout, MenuMove, MenuSelect, Giggle, Snarl, Splash, Alarm, Whoosh, Beep, Chime, PhoneRing, PowerDown, Spark, RegKey, Register, Coins, Breath, Zip, Birthday, Grunt, Clatter, RecClick };

class Audio {
 public:
  struct Params {
    float master = 0.8f;
    float hum = 0.3f;         // fluorescent ballast hum, follows how lit the player is
    float crackle = 0.0f;     // flickering lights nearby
    float droneGain = 0.0f, dronePan = 0.0f;   // the Tenant
    float staticGain = 0.0f, staticPan = 0.0f; // the thin place (exit beacon)
    float houndGain = 0.0f, houndPan = 0.0f;   // clicking, wet breathing
    float grinGain = 0.0f, grinPan = 0.0f;     // a thin, high shimmer
    float heartRate = 0.0f;   // beats per minute, 0 = off
    float heartGain = 0.0f;
    float breath = 0.0f;      // exhaustion
    float muffle = 0.0f;      // 0..1 low-pass on everything (menus, reading)
    float chase = 0.0f;       // chase music intensity
    float water = 0.0f;       // lapping water ambience
    float reverbMix = 1.0f;   // bigger in tiled rooms
    float muzak = 0.0f;       // store radio
    float tape = 0.0f;        // the camcorder itself: tape hiss, the motor, the head-switching buzz
    float breathRate = 0.35f; // your breathing: breaths per second
    float breathFear = 0.0f;  // 0 steady .. 1 ragged, catching, whimpering
  };

  bool init();
  bool initOffline(float rate = 48000.0f);  // no device: render() pulled by the caller (video capture)
  void renderOffline(float* out, int frames) { render(out, frames); }
  void shutdown();
  bool ok() const { return dev_ != 0 || offline_; }
  void set(const Params& p);
  void play(Sfx s, float gain = 1.0f, float pan = 0.0f, float pitch = 1.0f);
  // Recorded voice clips (16-bit mono PCM at `rate`). fx: 0 plain, 1 over the phone, 2 a thought (close,
  // dry), 3 wrong (slowed, dark, a long tail), 4 far away (muffled, mostly reverb). Returns its length in seconds.
  float playClip(const int16_t* pcm, int n, int rate, float gain = 1.0f, float pan = 0.0f, int fx = 0);
  bool clipPlaying() const { return !clips_.empty(); }

 private:
  struct Voice {
    Sfx type;
    float t = 0, gain = 1, pan = 0, pitch = 1;
    float lp = 0, lp2 = 0, hp = 0;
    float ph = 0, b1 = 0, l1 = 0, b2 = 0, l2 = 0;  // voice synth: glottal phase + two formant resonators
    uint32_t rng = 1;
  };
  static void callback(void* user, Uint8* stream, int len);
  void render(float* out, int frames);
  float voiceSample(Voice& v, bool& done);
  float noise(uint32_t& s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (s & 0xFFFFFF) / float(0x800000) - 1.0f; }

  SDL_AudioDeviceID dev_ = 0;
  bool offline_ = false;
  float rate_ = 48000.0f;
  Params target_, cur_;
  std::vector<Voice> voices_;
  struct ClipVoice {
    const int16_t* pcm = nullptr;
    int n = 0, fx = 0;
    double pos = 0, step = 1;
    float gain = 1, pan = 0, lp = 0, lp2 = 0, hp = 0;
  };
  std::vector<ClipVoice> clips_;
  uint32_t rng_ = 0x1234567;
  double time_ = 0;
  float humPh_[4] = {0, 0, 0, 0};
  float dronePh_[3] = {0, 0, 0};
  float droneLp_ = 0, staticLp_ = 0, staticHp_ = 0, breathLp_ = 0, roomLp_ = 0, crackleEnv_ = 0;
  float heartPh_ = 0, grinPh_[3] = {0, 0, 0}, houndLp_ = 0, clickEnv_ = 0;
  float beatPh_ = 0, bassPh_ = 0, bassLp_ = 0, waterLp_ = 0, waterLp2_ = 0;
  float muzPh_[3] = {0, 0, 0}, muzT_ = 0, muzLp_ = 0;
  float muffleL_ = 0, muffleR_ = 0;
  // the camcorder and your breathing
  float tapeHp_ = 0, tapeLp_ = 0, motorPh_ = 0, motorLp_ = 0, headPh_ = 0, headLp_ = 0, wowPh_ = 0;
  float brPh_ = 0, brLow1_ = 0, brBand1_ = 0, brLow2_ = 0, brBand2_ = 0, brGlot_ = 0, brJit_ = 1.0f;
  // Schroeder reverb
  std::vector<float> comb_[4], ap_[2];
  int combIdx_[4] = {0, 0, 0, 0}, apIdx_[2] = {0, 0};
  float combLp_[4] = {0, 0, 0, 0};
  float reverb(float in);
};
