// Drop-in photo textures (texload.cpp).
#pragma once
#include <string>

#include "texgen.h"

// Looks for textures/<name>.jpg|png; fills `out` (size x size RGBA, relief in alpha) if found.
bool loadPhotoTexture(const std::string& name, int size, Image& out);
