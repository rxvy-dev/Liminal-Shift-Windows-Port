// Drop-in photo textures (texload.cpp).
#pragma once
#include <string>

#include "texgen.h"

// Looks for textures/<name>.jpg|png; fills `out` (size x size RGBA, relief in alpha) if found.
bool loadPhotoTexture(const std::string& name, int size, Image& out);

// Finds a file the game ships with (e.g. "models", "clark.vam"): next to the .exe, in the install's
// share folder, or in the source tree's assets/. Empty if not found.
std::string findAsset(const std::string& folder, const std::string& file);
// Loads a .jpg/.png as RGBA8 (top row first). False if it can't.
bool loadImageFile(const std::string& path, Image& out);
