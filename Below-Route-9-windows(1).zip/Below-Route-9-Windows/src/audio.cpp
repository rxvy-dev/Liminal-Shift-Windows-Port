#include "audio.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

static constexpr float kTau = 6.28318530718f;
static constexpr float kPiF = 3.14159265359f;

bool Audio::init() {
  SDL_AudioSpec want{}, have{};
  want.freq = 48000;
  want.format = AUDIO_F32SYS;
  want.channels = 2;
  want.samples = 1024;
  want.callback = &Audio::callback;
  want.userdata = this;
  dev_ = SDL_OpenAudioDevice(nullptr, 0, &want, &have, SDL_AUDIO_ALLOW_FREQUENCY_CHANGE);
  if (!dev_) {
    std::fprintf(stderr, "[br9] audio disabled: %s\n", SDL_GetError());
    return false;
  }
  rate_ = (float)have.freq;
  const int combLen[4] = {1557, 1617, 1491, 1422};
  const int apLen[2] = {225, 556};
  float k = rate_ / 44100.0f;
  for (int i = 0; i < 4; ++i) comb_[i].assign((size_t)(combLen[i] * k * 1.6f), 0.0f);
  for (int i = 0; i < 2; ++i) ap_[i].assign((size_t)(apLen[i] * k), 0.0f);
  voices_.reserve(64);
  SDL_PauseAudioDevice(dev_, 0);
  return true;
}

bool Audio::initOffline(float rate) {
  offline_ = true;
  rate_ = rate;
  const int combLen[4] = {1557, 1617, 1491, 1422};
  const int apLen[2] = {225, 556};
  float k = rate_ / 44100.0f;
  for (int i = 0; i < 4; ++i) comb_[i].assign((size_t)(combLen[i] * k * 1.6f), 0.0f);
  for (int i = 0; i < 2; ++i) ap_[i].assign((size_t)(apLen[i] * k), 0.0f);
  voices_.reserve(64);
  return true;
}

void Audio::shutdown() {
  if (dev_) SDL_CloseAudioDevice(dev_);
  dev_ = 0;
}

void Audio::set(const Params& p) {
  if (!dev_) { if (offline_) target_ = p; return; }
  SDL_LockAudioDevice(dev_);
  target_ = p;
  SDL_UnlockAudioDevice(dev_);
}

void Audio::play(Sfx s, float gain, float pan, float pitch) {
  if (!dev_ && !offline_) return;
  if (dev_) SDL_LockAudioDevice(dev_);
  if (voices_.size() < 64) {
    Voice v;
    v.type = s;
    v.gain = gain;
    v.pan = std::clamp(pan, -1.0f, 1.0f);
    v.pitch = pitch;
    rng_ = rng_ * 1664525u + 1013904223u;
    v.rng = rng_ | 1u;
    voices_.push_back(v);
  }
  if (dev_) SDL_UnlockAudioDevice(dev_);
}

float Audio::playClip(const int16_t* pcm, int n, int rate, float gain, float pan, int fx) {
  if ((!dev_ && !offline_) || !pcm || n <= 0) return 0.0f;
  ClipVoice c;
  c.pcm = pcm; c.n = n; c.fx = fx;
  c.step = rate / (double)rate_ * (fx == 3 ? 0.88 : 1.0);  // the wrong ones come out slowed and lower
  c.gain = gain; c.pan = std::clamp(pan, -1.0f, 1.0f);
  if (dev_) SDL_LockAudioDevice(dev_);
  if (clips_.size() < 8) clips_.push_back(c);
  if (dev_) SDL_UnlockAudioDevice(dev_);
  return (float)(n / (rate * (fx == 3 ? 0.88 : 1.0)));
}

void Audio::callback(void* user, Uint8* stream, int len) {
  static_cast<Audio*>(user)->render(reinterpret_cast<float*>(stream), len / (int)(sizeof(float) * 2));
}

float Audio::reverb(float in) {
  float out = 0;
  for (int i = 0; i < 4; ++i) {
    auto& buf = comb_[i];
    int& idx = combIdx_[i];
    float y = buf[idx];
    combLp_[i] = y * 0.6f + combLp_[i] * 0.4f;
    buf[idx] = in + combLp_[i] * 0.80f;
    idx = (idx + 1) % (int)buf.size();
    out += y;
  }
  for (int i = 0; i < 2; ++i) {
    auto& buf = ap_[i];
    int& idx = apIdx_[i];
    float b = buf[idx];
    float y = -out * 0.5f + b;
    buf[idx] = out + b * 0.5f;
    idx = (idx + 1) % (int)buf.size();
    out = y;
  }
  return out * 0.18f;
}

// Each one-shot is a tiny synth patch. Returns a mono sample.
float Audio::voiceSample(Voice& v, bool& done) {
  const float dt = 1.0f / rate_;
  float t = v.t;
  v.t += dt;
  float s = 0;
  auto env = [&](float attack, float decay) {
    return (t < attack ? t / attack : std::exp(-(t - attack) / decay));
  };
  auto lowpass = [&](float x, float& state, float cutoff) {
    float a = 1.0f - std::exp(-kTau * cutoff / rate_);
    state += (x - state) * a;
    return state;
  };
  switch (v.type) {
    case Sfx::Footstep: {  // damp carpet: muffled thud + fibre scuff
      float n = lowpass(noise(v.rng), v.lp, 520.0f * v.pitch);
      float thump = std::sin(kTau * 68.0f * v.pitch * t) * std::exp(-t / 0.035f);
      s = (n * 1.6f * env(0.004f, 0.05f) + thump * 0.5f);
      done = t > 0.3f;
    } break;
    case Sfx::HeavyStep: {  // something tall and heavy on carpet
      float n = lowpass(noise(v.rng), v.lp, 260.0f * v.pitch);
      float thump = std::sin(kTau * 42.0f * v.pitch * t) * std::exp(-t / 0.11f);
      s = n * 2.2f * env(0.006f, 0.12f) + thump * 0.9f;
      done = t > 0.7f;
    } break;
    case Sfx::Pickup: {
      float e = env(0.005f, 0.35f);
      s = (std::sin(kTau * 660.0f * t) * 0.5f + std::sin(kTau * 990.0f * t) * 0.3f) * e * 0.35f;
      done = t > 1.5f;
    } break;
    case Sfx::Paper: {  // rustle: bursts of filtered noise
      float n = noise(v.rng);
      v.hp += (n - v.hp) * 0.25f;
      float burst = 0.5f + 0.5f * std::sin(kTau * 9.0f * t + std::sin(kTau * 3.0f * t) * 3.0f);
      s = (n - v.hp) * burst * std::exp(-t / 0.25f) * 0.6f;
      done = t > 0.7f;
    } break;
    case Sfx::Battery: case Sfx::Click: {
      float n = noise(v.rng);
      s = n * std::exp(-t / 0.004f) * 0.8f + std::sin(kTau * 2200.0f * t) * std::exp(-t / 0.01f) * 0.2f;
      if (v.type == Sfx::Battery && t > 0.12f) s += noise(v.rng) * std::exp(-(t - 0.12f) / 0.006f) * 0.8f;
      done = t > 0.25f;
    } break;
    case Sfx::Drink: {
      float gl = std::sin(kTau * (300.0f + 200.0f * std::sin(kTau * 6.0f * t)) * t);
      s = lowpass(gl * (0.5f + 0.5f * std::sin(kTau * 5.0f * t)), v.lp, 900.0f) * env(0.05f, 0.4f) * 0.4f;
      done = t > 1.2f;
    } break;
    case Sfx::ChaseSting: {  // dissonant swell + screech
      float sw = 0;
      const float f[4] = {55.0f, 58.27f, 82.41f, 87.31f};
      for (float fr : f) sw += std::fmod(fr * t, 1.0f) * 2.0f - 1.0f;
      sw = lowpass(sw, v.lp, 1400.0f);
      float scr = std::sin(kTau * (1500.0f - 500.0f * std::min(t, 1.0f)) * t) * 0.25f * std::exp(-t / 0.5f);
      s = (sw * 0.35f + scr + lowpass(noise(v.rng), v.lp2, 3000.0f) * 0.3f) * env(0.02f, 0.9f);
      done = t > 3.5f;
    } break;
    case Sfx::Death: {
      float n = noise(v.rng);
      s = (n * 0.9f + std::sin(kTau * 31.0f * t) * 0.8f) * env(0.003f, 0.8f);
      done = t > 2.5f;
    } break;
    case Sfx::Knock: {  // three distant knocks
      float k = 0;
      for (int i = 0; i < 3; ++i) {
        float tt = t - i * 0.32f;
        if (tt >= 0) k += std::sin(kTau * 110.0f * tt) * std::exp(-tt / 0.05f) + noise(v.rng) * std::exp(-tt / 0.012f) * 0.4f;
      }
      s = lowpass(k, v.lp, 600.0f) * 0.9f;
      done = t > 1.5f;
    } break;
    case Sfx::Slam: {
      s = lowpass(noise(v.rng) * std::exp(-t / 0.08f) + std::sin(kTau * 50.0f * t) * std::exp(-t / 0.25f), v.lp, 400.0f) * 1.2f;
      done = t > 1.8f;
    } break;
    case Sfx::Noclip: {
      float f = 900.0f * std::exp(-t * 1.5f) + 30.0f;
      s = std::sin(kTau * f * t) * 0.4f * env(0.3f, 1.2f) + noise(v.rng) * std::min(t / 1.5f, 1.0f) * 0.5f * std::exp(-std::max(0.0f, t - 2.0f) / 0.3f);
      done = t > 3.5f;
    } break;
    case Sfx::Brownout: {  // ballast thunk, power sag
      s = lowpass(std::sin(kTau * (60.0f - 25.0f * t) * t) * env(0.01f, 0.4f) + noise(v.rng) * std::exp(-t / 0.03f) * 0.5f, v.lp, 300.0f);
      done = t > 1.2f;
    } break;
    case Sfx::Giggle: {  // breathy, falling, wrong
      float f = 520.0f * std::exp(-t * 0.8f) * (1.0f + 0.25f * std::sin(kTau * 9.0f * t));
      float voice = std::sin(kTau * f * t) * 0.3f + lowpass(noise(v.rng), v.lp, 1800.0f) * 0.5f;
      float pulse = std::max(0.0f, std::sin(kTau * 7.0f * t));
      s = voice * pulse * env(0.05f, 0.9f);
      done = t > 2.2f;
    } break;
    case Sfx::Snarl: {
      float n = lowpass(noise(v.rng), v.lp, 700.0f);
      float growl = std::sin(kTau * (90.0f + 30.0f * std::sin(kTau * 23.0f * t)) * t);
      s = (n * 1.5f + growl * 0.6f) * (0.6f + 0.4f * std::sin(kTau * 31.0f * t)) * env(0.03f, 0.5f);
      done = t > 1.4f;
    } break;
    case Sfx::Splash: {  // a step in shallow water
      float n = noise(v.rng);
      v.hp += (n - v.hp) * 0.3f;
      float bub = std::sin(kTau * (600.0f + 900.0f * t) * v.pitch * t) * std::exp(-t / 0.05f) * 0.2f;
      s = ((n - v.hp) * 0.9f * env(0.005f, 0.12f) + bub) * 1.1f;
      done = t > 0.5f;
    } break;
    case Sfx::Alarm: {  // two-tone klaxon, three times
      float cyc = std::fmod(t, 0.7f);
      float f = cyc < 0.35f ? 440.0f : 330.0f;
      float sq = std::sin(kTau * f * t) > 0 ? 1.0f : -1.0f;
      s = lowpass(sq, v.lp, 1600.0f) * 0.22f * (t < 2.1f ? 1.0f : 0.0f);
      done = t > 2.2f;
    } break;
    case Sfx::Whoosh: {  // falling into the next level
      float n = lowpass(noise(v.rng), v.lp, 300.0f + 2500.0f * std::min(t, 1.5f));
      s = n * env(0.8f, 1.0f) * 1.5f;
      done = t > 3.5f;
    } break;
    case Sfx::Beep: {  // barcode scanner
      s = std::sin(kTau * 2950.0f * t) * 0.18f * (t < 0.09f ? 1.0f : 0.0f);
      done = t > 0.1f;
    } break;
    case Sfx::Chime: {  // door chime: two falling bell tones
      float a = std::sin(kTau * 1318.5f * t) * std::exp(-t / 0.5f);
      float t2 = std::max(0.0f, t - 0.32f);
      float b = t > 0.32f ? std::sin(kTau * 1046.5f * t2) * std::exp(-t2 / 0.7f) : 0.0f;
      s = (a + b) * 0.16f;
      done = t > 2.2f;
    } break;
    case Sfx::PhoneRing: {  // the far end ringing, twice
      float cyc = std::fmod(t, 3.0f);
      bool on = cyc < 1.2f && t < 5.5f;
      s = on ? (std::sin(kTau * 440.0f * t) + std::sin(kTau * 480.0f * t)) * 0.06f : 0.0f;
      done = t > 5.6f;
    } break;
    case Sfx::PowerDown: {  // everything spinning down at once
      float f = 120.0f * std::exp(-t * 0.9f) + 20.0f;
      v.lp += f / rate_;
      float hum = std::sin(kTau * v.lp) * std::exp(-t / 1.4f);
      float thunk = lowpass(noise(v.rng), v.hp, 200.0f) * std::exp(-t / 0.08f) * 3.0f;
      s = (hum * 0.45f + thunk) * 0.9f;
      done = t > 4.0f;
    } break;
    case Sfx::Spark: {
      float n = noise(v.rng);
      s = (std::fabs(n) > 0.6f ? n : 0.0f) * std::exp(-t / 0.12f) * 0.8f;
      done = t > 0.4f;
    } break;
    case Sfx::RegKey: {  // a plastic till key: click + short beep
      float click = lowpass(noise(v.rng), v.lp, 3000.0f) * std::exp(-t / 0.006f) * 1.4f;
      float beep = t > 0.01f && t < 0.06f ? std::sin(kTau * 2400.0f * t) * 0.08f : 0.0f;
      s = click + beep;
      done = t > 0.08f;
    } break;
    case Sfx::Register: {  // drawer springs open: solenoid thunk, slide rattle, bell
      float thunk = lowpass(noise(v.rng), v.lp, 400.0f) * std::exp(-t / 0.03f) * 2.5f;
      float slide = t > 0.03f && t < 0.28f ? lowpass(noise(v.rng), v.hp, 1800.0f) * 0.5f * (0.6f + 0.4f * std::sin(kTau * 60.0f * t)) : 0.0f;
      float tb = std::max(0.0f, t - 0.25f);
      float bell = t > 0.25f ? (std::sin(kTau * 2093.0f * tb) + 0.5f * std::sin(kTau * 3136.0f * tb)) * std::exp(-tb / 0.6f) * 0.13f : 0.0f;
      s = thunk + slide + bell;
      done = t > 1.6f;
    } break;
    case Sfx::Coins: {  // a few coins dropped into a cup
      float s2 = 0;
      for (int k = 0; k < 4; ++k) {
        float tk = t - k * 0.07f - (k % 2) * 0.02f;
        if (tk > 0) s2 += std::sin(kTau * (3200.0f + 700.0f * k) * tk) * std::exp(-tk / 0.05f) * 0.12f;
      }
      s = s2;
      done = t > 0.6f;
    } break;
    case Sfx::Breath: {  // breathing through a respirator: inhale, hiss, exhale
      float cyc = t / 2.4f;
      float in = cyc < 0.42f ? std::sin(kTau * 0.5f * cyc / 0.42f) : 0.0f;
      float out = cyc > 0.48f && cyc < 1.0f ? std::sin(kTau * 0.5f * (cyc - 0.48f) / 0.52f) : 0.0f;
      float n = noise(v.rng);
      v.lp += (n - v.lp) * 0.08f;
      v.hp += (n - v.hp) * 0.35f;
      float valve = cyc > 0.48f && cyc < 0.53f ? std::sin(kTau * 90.0f * t) * 0.15f : 0.0f;
      s = v.lp * in * 0.55f + (v.hp - v.lp) * out * 0.35f + valve;
      done = t > 2.4f;
    } break;
    case Sfx::Zip: {  // a long zipper
      float n = noise(v.rng);
      float teeth = std::fmod(t * (90.0f + 60.0f * t), 1.0f) < 0.3f ? 1.0f : 0.2f;
      s = n * teeth * (t < 0.9f ? 0.35f : 0.0f);
      done = t > 1.0f;
    } break;
    case Sfx::Grunt: {  // a hurt person getting up: a strained "nngh-uhh" through two vocal formants
      float len = 0.55f / std::max(0.6f, v.pitch);
      float u = t / len;
      float e = (u < 0.12f ? u / 0.12f : 1.0f) * (u > 0.55f ? std::max(0.0f, 1.0f - (u - 0.55f) / 0.45f) : 1.0f);
      e *= 0.75f + 0.25f * std::sin(kTau * 6.0f * t);  // shaky
      float f0 = (128.0f - 38.0f * u) * v.pitch * (1.0f + 0.02f * noise(v.rng));  // falls off as the breath runs out
      v.ph += f0 / rate_;
      if (v.ph >= 1.0f) v.ph -= 1.0f;
      float glot = (v.ph < 0.4f ? std::sin(kPiF * v.ph / 0.4f) : 0.0f) - 0.25f;  // pulsed vocal folds
      float src = glot + noise(v.rng) * 0.35f;  // and a lot of air
      float f1 = (u < 0.3f ? 320.0f : 620.0f) * (0.95f + 0.1f * v.pitch), f2 = u < 0.3f ? 900.0f : 1150.0f;  // "nn" -> "uh"
      auto svf = [&](float in, float fc, float q, float& low, float& band) {
        float f = 2.0f * std::sin(kPiF * fc / rate_);
        low += f * band;
        float high = in - low - q * band;
        band += f * high;
        return band;
      };
      float vo = svf(src, f1, 0.18f, v.l1, v.b1) * 0.9f + svf(src, f2, 0.22f, v.l2, v.b2) * 0.45f;
      s = std::tanh(vo * 0.9f) * e * 0.55f;
      done = t > len;
    } break;
    case Sfx::Clatter: {  // a camcorder hitting a hard floor: plastic crack, bounce, rattle
      float n = noise(v.rng);
      float hit = 0;
      const float at[4] = {0.0f, 0.13f, 0.21f, 0.26f};
      const float amp[4] = {1.0f, 0.45f, 0.25f, 0.12f};
      for (int k = 0; k < 4; ++k) {
        float dtk = t - at[k];
        if (dtk >= 0) hit += amp[k] * std::exp(-dtk / 0.018f) * (std::sin(kTau * 1900.0f * dtk) * 0.5f + n * 0.8f);
      }
      float thud = std::sin(kTau * 95.0f * t) * std::exp(-t / 0.06f);
      float rattle = (t > 0.05f && t < 0.5f) ? lowpass(n, v.lp, 3000.0f) * (std::fmod(t * 37.0f, 1.0f) < 0.25f ? 0.25f : 0.0f) * std::exp(-t / 0.2f) : 0.0f;
      s = hit * 0.7f + thud * 0.6f + rattle;
      done = t > 0.7f;
    } break;
    case Sfx::Birthday: {  // happy birthday on a slow, detuned music box, warbling like a worn tape
      static const float notes[] = {0, 0, 2, 0, 5, 4, -99, 0, 0, 2, 0, 7, 5};
      static const float lens[] = {0.36f, 0.12f, 0.48f, 0.48f, 0.48f, 0.96f, 0.3f, 0.36f, 0.12f, 0.48f, 0.48f, 0.48f, 1.1f};
      float acc = 0;
      int n = -1;
      float nt = 0;
      for (int i = 0; i < 13; ++i) { float L = lens[i] * 1.35f; if (t < acc + L) { n = i; nt = t - acc; break; } acc += L; }
      if (n < 0 || notes[n] < -50) { s = 0; done = t > 9.0f; break; }
      float wob = 1.0f + 0.012f * std::sin(t * 5.3f) + 0.02f * std::sin(t * 0.7f);
      float f = 392.0f * std::pow(2.0f, notes[n] / 12.0f) * wob * 0.94f;  // flat, slightly
      float e = std::exp(-nt / 0.5f) * (nt < 0.004f ? nt / 0.004f : 1.0f);
      s = (std::sin(kTau * f * t) + 0.4f * std::sin(kTau * f * 2.01f * t) + 0.15f * std::sin(kTau * f * 3.98f * t)) * e * 0.16f;
      done = t > 9.5f;
    } break;
    case Sfx::MenuMove: case Sfx::MenuSelect: {
      float fr = v.type == Sfx::MenuMove ? 1200.0f : 700.0f;
      s = (std::fmod(fr * t, 1.0f) < 0.5f ? 0.15f : -0.15f) * std::exp(-t / 0.03f);
      done = t > 0.15f;
    } break;
  }
  return s * v.gain;
}

void Audio::render(float* out, int frames) {
  const float dt = 1.0f / rate_;
  const float smooth = 1.0f - std::exp(-dt / 0.06f);
  for (int i = 0; i < frames; ++i) {
    // Smooth all continuous parameters to avoid zipper noise.
    cur_.master += (target_.master - cur_.master) * smooth;
    cur_.hum += (target_.hum - cur_.hum) * smooth;
    cur_.crackle += (target_.crackle - cur_.crackle) * smooth;
    cur_.droneGain += (target_.droneGain - cur_.droneGain) * smooth;
    cur_.dronePan += (target_.dronePan - cur_.dronePan) * smooth;
    cur_.staticGain += (target_.staticGain - cur_.staticGain) * smooth;
    cur_.staticPan += (target_.staticPan - cur_.staticPan) * smooth;
    cur_.heartGain += (target_.heartGain - cur_.heartGain) * smooth;
    cur_.heartRate += (target_.heartRate - cur_.heartRate) * smooth;
    cur_.breath += (target_.breath - cur_.breath) * smooth;
    cur_.muffle += (target_.muffle - cur_.muffle) * smooth;
    cur_.houndGain += (target_.houndGain - cur_.houndGain) * smooth;
    cur_.chase += (target_.chase - cur_.chase) * smooth * 0.3f;
    cur_.water += (target_.water - cur_.water) * smooth;
    cur_.reverbMix += (target_.reverbMix - cur_.reverbMix) * smooth;
    cur_.muzak += (target_.muzak - cur_.muzak) * smooth;
    cur_.houndPan += (target_.houndPan - cur_.houndPan) * smooth;
    cur_.grinGain += (target_.grinGain - cur_.grinGain) * smooth;
    cur_.grinPan += (target_.grinPan - cur_.grinPan) * smooth;

    float L = 0, R = 0, send = 0;
    auto pan = [&](float s, float p, float revSend) {
      float a = (p + 1.0f) * 0.25f * 3.14159265f;
      L += s * std::cos(a);
      R += s * std::sin(a);
      send += s * revSend;
    };

    // Fluorescent hum: 60 Hz mains + ballast harmonics, slight beating.
    {
      const float f[4] = {60.0f, 120.0f, 180.0f, 240.3f};
      const float a[4] = {0.30f, 0.55f, 0.18f, 0.12f};
      float h = 0;
      for (int k = 0; k < 4; ++k) {
        humPh_[k] += f[k] * dt;
        if (humPh_[k] > 1.0f) humPh_[k] -= 1.0f;
        h += std::sin(kTau * humPh_[k]) * a[k];
      }
      h += (humPh_[1] < 0.5f ? 0.04f : -0.04f);  // buzz
      float wob = 0.85f + 0.15f * std::sin((float)time_ * 0.7f);
      pan(h * cur_.hum * 0.06f * wob, 0.0f, 0.05f);
      // crackle from failing tubes
      if (cur_.crackle > 0.01f && (noise(rng_) * 0.5f + 0.5f) < cur_.crackle * 0.0009f) crackleEnv_ = 1.0f;
      crackleEnv_ *= 0.996f;
      pan(noise(rng_) * crackleEnv_ * 0.12f * cur_.crackle, std::sin((float)time_ * 1.3f) * 0.5f, 0.2f);
    }
    // Room tone: very quiet brown noise.
    roomLp_ += (noise(rng_) - roomLp_) * 0.002f;
    pan(roomLp_ * 0.35f, 0.0f, 0.0f);

    // The Tenant: low detuned drone with a breathing tremolo.
    if (cur_.droneGain > 0.0005f) {
      const float f[3] = {41.0f, 41.7f, 61.9f};
      float d = 0;
      for (int k = 0; k < 3; ++k) {
        dronePh_[k] += f[k] * dt;
        if (dronePh_[k] > 1.0f) dronePh_[k] -= 1.0f;
        d += dronePh_[k] * 2.0f - 1.0f;
      }
      droneLp_ += (d - droneLp_) * 0.02f;
      float breathe = 0.6f + 0.4f * std::sin((float)time_ * 2.1f) * std::sin((float)time_ * 0.37f);
      float rasp = noise(rng_) * (0.5f + 0.5f * std::sin((float)time_ * 1.6f)) * 0.15f;
      pan((droneLp_ * 0.5f + rasp) * breathe * cur_.droneGain, cur_.dronePan, 0.3f);
    }
    // The Hound: bursts of tongue clicks (it echolocates) over wet breathing.
    if (cur_.houndGain > 0.0005f) {
      float tt = std::fmod((float)time_, 1.7f);
      if (tt < 0.45f && std::fmod(tt, 0.06f) < dt) clickEnv_ = 1.0f;
      clickEnv_ *= 0.985f;
      float click = noise(rng_) * clickEnv_ * clickEnv_ * 1.2f;
      houndLp_ += (noise(rng_) - houndLp_) * 0.05f;
      float br = houndLp_ * (0.5f + 0.5f * std::sin((float)time_ * 5.5f)) * 0.8f;
      pan((click + br) * cur_.houndGain, cur_.houndPan, 0.35f);
    }
    // The Grin: detuned high tones beating against each other.
    if (cur_.grinGain > 0.0005f) {
      const float f[3] = {1318.5f, 1325.0f, 1977.0f};
      float g = 0;
      for (int k = 0; k < 3; ++k) {
        grinPh_[k] += f[k] * dt;
        if (grinPh_[k] > 1.0f) grinPh_[k] -= 1.0f;
        g += std::sin(kTau * grinPh_[k]) * (k == 2 ? 0.3f : 0.5f);
      }
      float trem = 0.5f + 0.5f * std::sin((float)time_ * 3.1f);
      pan(g * 0.05f * trem * cur_.grinGain, cur_.grinPan, 0.5f);
    }
    // Chase music: 150 bpm pulse, detuned low saw, ticking hats. Dread, not melody.
    if (cur_.chase > 0.002f) {
      beatPh_ += dt * 150.0f / 60.0f;
      if (beatPh_ >= 1.0f) beatPh_ -= 1.0f;
      float tb = beatPh_ * 60.0f / 150.0f;
      float kick = std::sin(kTau * (45.0f + 90.0f * std::exp(-tb * 30.0f)) * tb) * std::exp(-tb * 9.0f);
      float sixteenth = std::fmod(beatPh_ * 4.0f, 1.0f);
      float hat = noise(rng_) * std::exp(-sixteenth * 40.0f) * 0.15f;
      bassPh_ += dt * (36.7f + 1.5f * std::sin((float)time_ * 0.5f));
      if (bassPh_ > 1.0f) bassPh_ -= 1.0f;
      float saw = bassPh_ * 2.0f - 1.0f;
      bassLp_ += (saw - bassLp_) * 0.03f;
      float pump = 0.5f + 0.5f * (1.0f - std::exp(-tb * 6.0f));
      pan((kick * 0.9f + hat + bassLp_ * 0.6f * pump) * cur_.chase * 0.55f, 0.0f, 0.1f);
    }
    // Store radio: a slow, slightly warbly easy-listening loop through a tinny speaker.
    if (cur_.muzak > 0.002f) {
      static const float prog[4][3] = {{261.6f, 329.6f, 392.0f}, {220.0f, 261.6f, 329.6f}, {174.6f, 220.0f, 261.6f}, {196.0f, 246.9f, 293.7f}};
      static const float mel[16] = {659.3f, 0, 587.3f, 523.3f, 0, 440.0f, 523.3f, 0, 587.3f, 0, 523.3f, 493.9f, 0, 392.0f, 440.0f, 0};
      muzT_ += dt;
      int bar = (int)(muzT_ / 2.4f) % 4;
      float wob = 1.0f + 0.004f * std::sin((float)time_ * 5.3f);
      float pad = 0;
      for (int k = 0; k < 3; ++k) {
        muzPh_[k] += dt * prog[bar][k] * wob;
        if (muzPh_[k] > 1.0f) muzPh_[k] -= 1.0f;
        pad += std::sin(kTau * muzPh_[k]);
      }
      float step = std::fmod(muzT_, 9.6f) / 0.6f;
      int si = (int)step % 16;
      float st = std::fmod(muzT_, 0.6f);
      float m = mel[si] > 0 ? std::sin(kTau * mel[si] * wob * muzT_) * std::exp(-st / 0.35f) : 0.0f;
      float x = pad * 0.05f + m * 0.09f;
      muzLp_ += (x - muzLp_) * 0.25f;  // tinny ceiling speaker
      pan((x - muzLp_ * 0.7f) * cur_.muzak, 0.3f, 0.5f);
    }
    // Water lapping (Poolrooms).
    if (cur_.water > 0.002f) {
      waterLp_ += (noise(rng_) - waterLp_) * 0.02f;
      waterLp2_ += (waterLp_ - waterLp2_) * 0.01f;
      float lap = (waterLp_ - waterLp2_) * (0.6f + 0.4f * std::sin((float)time_ * 0.9f) * std::sin((float)time_ * 0.31f));
      pan(lap * 1.4f * cur_.water, std::sin((float)time_ * 0.2f) * 0.6f, 0.6f);
    }
    // The thin place: a low hollow hum, like wind across the mouth of a bottle, breathing.
    if (cur_.staticGain > 0.0005f) {
      float n = noise(rng_);
      staticLp_ += (n - staticLp_) * 0.012f;
      staticHp_ += (staticLp_ - staticHp_) * 0.004f;
      float t = (float)time_;
      float breath = 0.55f + 0.45f * std::sin(t * 1.3f) * std::sin(t * 0.47f + 1.0f);
      float drone = std::sin(t * 6.2831853f * 55.0f) * 0.25f + std::sin(t * 6.2831853f * 82.5f + std::sin(t * 0.7f)) * 0.12f;
      pan(((staticLp_ - staticHp_) * 6.0f + drone * 0.35f) * breath * cur_.staticGain, cur_.staticPan, 0.15f);
    }
    // Heartbeat.
    if (cur_.heartGain > 0.001f && cur_.heartRate > 1.0f) {
      heartPh_ += cur_.heartRate / 60.0f * dt;
      if (heartPh_ > 1.0f) heartPh_ -= 1.0f;
      float t1 = heartPh_ * 60.0f / std::max(cur_.heartRate, 1.0f);
      float t2 = t1 - 0.22f;
      float hb = std::sin(kTau * 52.0f * t1) * std::exp(-t1 / 0.06f);
      if (t2 > 0) hb += 0.7f * std::sin(kTau * 48.0f * t2) * std::exp(-t2 / 0.06f);
      pan(hb * cur_.heartGain * 0.8f, 0.0f, 0.0f);
    }
    // Exhausted breathing.
    if (cur_.breath > 0.01f) {
      breathLp_ += (noise(rng_) - breathLp_) * 0.08f;
      float cyc = std::sin((float)time_ * kTau * 0.55f);
      pan(breathLp_ * std::max(cyc, 0.0f) * cur_.breath * 0.6f, 0.0f, 0.05f);
    }

    // One-shots.
    for (size_t k = 0; k < voices_.size();) {
      bool done = false;
      float s = voiceSample(voices_[k], done);
      float rs = (voices_[k].type == Sfx::Knock || voices_[k].type == Sfx::Slam || voices_[k].type == Sfx::HeavyStep) ? 0.7f : 0.25f;
      if (voices_[k].type == Sfx::MenuMove || voices_[k].type == Sfx::MenuSelect) rs = 0.0f;
      pan(s, voices_[k].pan, rs);
      if (done) { voices_[k] = voices_.back(); voices_.pop_back(); }
      else ++k;
    }

    // Recorded voices.
    for (size_t k = 0; k < clips_.size();) {
      ClipVoice& c = clips_[k];
      int i0 = (int)c.pos;
      if (i0 + 1 >= c.n) { clips_[k] = clips_.back(); clips_.pop_back(); continue; }
      float f = (float)(c.pos - i0);
      float x = (c.pcm[i0] + (c.pcm[i0 + 1] - c.pcm[i0]) * f) / 32768.0f;
      c.pos += c.step;
      float send2 = 0.12f;
      switch (c.fx) {
        case 1: {  // a phone line: no lows, no highs, a little crunch
          c.hp += (x - c.hp) * 0.04f; x -= c.hp;
          c.lp += (x - c.lp) * 0.35f; x = std::tanh(c.lp * 2.2f) * 0.6f;
          send2 = 0.02f;
        } break;
        case 2: c.lp += (x - c.lp) * 0.6f; x = c.lp * 0.8f; send2 = 0.03f; break;  // inside your head
        case 3: c.lp += (x - c.lp) * 0.18f; c.lp2 += (c.lp - c.lp2) * 0.3f; x = c.lp2 * 1.3f; send2 = 0.7f; break;
        case 4: c.lp += (x - c.lp) * 0.12f; x = c.lp * 0.7f; send2 = 0.55f; break;
        default: break;
      }
      pan(x * c.gain, c.pan, send2);
      ++k;
    }

    float rv = reverb(send) * cur_.reverbMix;
    L += rv; R += rv;

    // Menu muffle: one-pole low-pass blended in.
    float a = 1.0f - std::exp(-kTau * 700.0f / rate_);
    muffleL_ += (L - muffleL_) * a;
    muffleR_ += (R - muffleR_) * a;
    L = L + (muffleL_ - L) * cur_.muffle;
    R = R + (muffleR_ - R) * cur_.muffle;

    L = std::tanh(L * cur_.master);
    R = std::tanh(R * cur_.master);
    out[i * 2] = L;
    out[i * 2 + 1] = R;
    time_ += dt;
  }
}
