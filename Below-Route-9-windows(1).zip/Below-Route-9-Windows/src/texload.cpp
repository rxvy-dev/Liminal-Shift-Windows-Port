// Photo textures you drop in yourself. If a picture with the right name sits in one of the texture
// folders, it's used instead of the generated surface: a real scanned carpet, wallpaper or ceiling
// tile (CC0 sets from Poly Haven or ambientCG work well). One picture covers one 2 m tile.
//
// Looked for, in order: $BR9_TEXTURES, ./textures next to where the game is run from, and
// ~/.local/share/below-route-9/textures (on Windows, %LOCALAPPDATA%\below-route-9\textures).
// Names: wallpaper, dark_wallpaper, carpet, dark_carpet, office_carpet, hotel_carpet,
// ceiling_tiles, concrete, concrete_floor, brick, tile, plaster, wood, vinyl ... (.jpg or .png).
// A matching <name>_height (or _disp / _displacement) picture is used for the relief if present;
// otherwise the relief is guessed from the picture's own light and dark.
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_JPEG
#define STBI_ONLY_PNG
#include "stb_image.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include "platform.h"
#include "texload.h"

namespace {

bool exists(const std::string& p) {
  if (FILE* f = std::fopen(p.c_str(), "rb")) { std::fclose(f); return true; }
  return false;
}

std::vector<std::string> folders() {
  std::vector<std::string> d;
  if (const char* e = std::getenv("BR9_TEXTURES")) d.push_back(e);
  d.push_back("textures");
  d.push_back(platform::dataDir() + "/textures");
  return d;
}

std::string find(const std::string& name) {
  for (const std::string& dir : folders())
    for (const char* ext : {".jpg", ".jpeg", ".png"}) {
      std::string p = dir + "/" + name + ext;
      if (exists(p)) return p;
    }
  return {};
}

// Box-filter down (or bilinear up) to size x size, RGBA8.
std::vector<uint8_t> resample(const uint8_t* src, int w, int h, int n, int size) {
  std::vector<uint8_t> out((size_t)size * size * 4);
  for (int y = 0; y < size; ++y)
    for (int x = 0; x < size; ++x) {
      float x0 = (float)x * w / size, x1 = (float)(x + 1) * w / size;
      float y0 = (float)y * h / size, y1 = (float)(y + 1) * h / size;
      int ix0 = (int)x0, ix1 = std::max(ix0 + 1, (int)std::ceil(x1));
      int iy0 = (int)y0, iy1 = std::max(iy0 + 1, (int)std::ceil(y1));
      float acc[4] = {0, 0, 0, 0};
      int cnt = 0;
      for (int yy = iy0; yy < iy1 && yy < h; ++yy)
        for (int xx = ix0; xx < ix1 && xx < w; ++xx) {
          const uint8_t* p = src + ((size_t)yy * w + xx) * n;
          for (int c = 0; c < 4; ++c) acc[c] += c < n ? p[c] : (c == 3 ? 255 : p[0]);
          ++cnt;
        }
      uint8_t* o = &out[((size_t)y * size + x) * 4];
      for (int c = 0; c < 4; ++c) o[c] = (uint8_t)(cnt ? acc[c] / cnt + 0.5f : 0);
      if (n == 1) o[1] = o[2] = o[0];
    }
  return out;
}

}  // namespace

bool loadPhotoTexture(const std::string& name, int size, Image& out) {
  std::string path = find(name);
  if (path.empty()) return false;
  int w, h, n;
  uint8_t* px = stbi_load(path.c_str(), &w, &h, &n, 0);
  if (!px) { std::fprintf(stderr, "[br9] couldn't read texture %s\n", path.c_str()); return false; }
  std::vector<uint8_t> rgba = resample(px, w, h, n, size);
  stbi_image_free(px);

  // the relief (alpha): a height map if there is one, else the picture's own luminance, high-passed
  std::vector<float> ht((size_t)size * size);
  std::string hp;
  for (const char* suf : {"_height", "_disp", "_displacement"})
    if (hp.empty()) hp = find(name + suf);
  bool haveH = false;
  if (!hp.empty()) {
    int hw, hh, hn;
    if (uint8_t* hpx = stbi_load(hp.c_str(), &hw, &hh, &hn, 1)) {
      std::vector<uint8_t> hr = resample(hpx, hw, hh, 1, size);
      stbi_image_free(hpx);
      for (size_t i = 0; i < ht.size(); ++i) ht[i] = hr[i * 4] / 255.0f;
      haveH = true;
    }
  }
  if (!haveH) {
    std::vector<float> lum(ht.size()), blur(ht.size());
    for (size_t i = 0; i < ht.size(); ++i)
      lum[i] = (0.3f * rgba[i * 4] + 0.59f * rgba[i * 4 + 1] + 0.11f * rgba[i * 4 + 2]) / 255.0f;
    const int r = std::max(2, size / 64);  // wraps: these tile
    std::vector<float> tmp(ht.size());
    for (int y = 0; y < size; ++y)
      for (int x = 0; x < size; ++x) {
        float s = 0;
        for (int k = -r; k <= r; ++k) s += lum[(size_t)y * size + ((x + k + size) % size)];
        tmp[(size_t)y * size + x] = s / (2 * r + 1);
      }
    for (int y = 0; y < size; ++y)
      for (int x = 0; x < size; ++x) {
        float s = 0;
        for (int k = -r; k <= r; ++k) s += tmp[(size_t)((y + k + size) % size) * size + x];
        blur[(size_t)y * size + x] = s / (2 * r + 1);
      }
    for (size_t i = 0; i < ht.size(); ++i) ht[i] = std::fmin(1.0f, std::fmax(0.0f, 0.5f + (lum[i] - blur[i]) * 2.2f));
  }
  out.w = out.h = size;
  out.px = std::move(rgba);
  for (size_t i = 0; i < ht.size(); ++i) out.px[i * 4 + 3] = (uint8_t)(ht[i] * 255.0f + 0.5f);
  std::fprintf(stderr, "[br9] photo texture: %s\n", path.c_str());
  return true;
}
