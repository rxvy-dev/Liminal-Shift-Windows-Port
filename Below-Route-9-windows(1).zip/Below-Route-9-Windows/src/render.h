// Rendering: forward PBR-ish world shader with GPU skinning, flashlight shadow
// map, SSAO, volumetric light, bloom chain, filmic tonemap/grade, FXAA, UI.
#pragma once
#include "gl.h"
#include "level.h"
#include "mathx.h"
#include "texgen.h"
#include <string>
#include <unordered_map>
#include <vector>

struct Shader {
  GLuint prog = 0;
  std::unordered_map<std::string, GLint> locs;
  bool build(const char* vs, const char* fs, std::string& err);
  GLint loc(const char* name);
  void use() const { glUseProgram(prog); }
  void set(const char* n, int v) { glUniform1i(loc(n), v); }
  void set(const char* n, float v) { glUniform1f(loc(n), v); }
  void set(const char* n, float a, float b) { glUniform2f(loc(n), a, b); }
  void set(const char* n, vec3 v) { glUniform3f(loc(n), v.x, v.y, v.z); }
  void set(const char* n, vec4 v) { glUniform4f(loc(n), v.x, v.y, v.z, v.w); }
  void set(const char* n, const mat4& m) { glUniformMatrix4fv(loc(n), 1, GL_FALSE, m.m); }
};

struct GpuMesh {
  GLuint vao = 0, vbo = 0, ibo = 0;
  GLsizei count = 0;
  void upload(const Mesh& m);
  void draw() const;
  void destroy();
};

GLuint makeTexture(const Image& img, bool mipmaps, bool repeat);

enum Material { MAT_WALL = 0, MAT_FLOOR = 1, MAT_CEIL = 2, MAT_PANEL = 3, MAT_PROP = 4, MAT_MODEL = 5, MAT_GLITCH = 6, MAT_TRIM = 7, MAT_DECAL = 8, MAT_WATER = 9, MAT_SCREEN = 10 };

struct PostParams {
  float time = 0, exposure = 1.0f, bloom = 1.0f, grain = 0.04f;
  float staticAmt = 0, fear = 0, fade = 0;
  bool vhs = true;
  // camera
  mat4 view, proj;
  vec3 camPos;
  // flashlight (for volumetrics)
  vec3 flashPos, flashDir;
  float flash = 0;
  float night = 0;  // camcorder NightShot: green, grainy, sees in the dark
  mat4 shadowVP;
  // ceiling light haze
  GLuint lightmap = 0, lightState = 0;
  float lmW = 1, lmH = 1, lmPerMeter = 4;
  vec3 fogColor;
  float wallH = 2.9f;
  vec3 lightColor{1.0f, 0.91f, 0.7f};
  // reflections and motion blur
  float floorGloss = 0.0f;  // 0 carpet .. 1 polished
  float wet = 0.0f;         // droplets on the lens
  vec3 gradeGain{1, 1, 1}, gradeLift{0, 0, 0};
  float motion = 0.0f;      // camera motion blur strength
  mat4 prevViewProj;
  bool hasPrev = false;
  // sunlight (Poolrooms)
  bool sunOn = false;
  mat4 sunVP;
  vec3 sunDir{0, 1, 0}, sunColor{0, 0, 0};
};

struct QualityPreset {
  float renderScale;
  int shadowSize;  // 0 = no shadows
  bool ssao, volumetrics, bloom, fxaa;
};
QualityPreset qualityPreset(int q);  // 0 low, 1 medium, 2 high, 3 ultra

class Renderer {
 public:
  bool init(std::string& err);
  void shutdown();
  void setQuality(int q);
  void resize(int winW, int winH);

  // Shadow pass from the flashlight. Draw casters with `shadow` bound.
  bool beginShadow(const mat4& lightVP);
  void endShadow();
  // Orthographic sun shadow map (separate target).
  bool beginSunShadow(const mat4& lightVP);
  GLuint sunTex = 0;
  static constexpr int kSunSize = 2048;

  void beginScene();
  void endScene();
  void present(const PostParams& p);

  // UI in window pixels, origin top-left.
  void beginUI();
  void rect(float x, float y, float w, float h, float r, float g, float b, float a);
  void text(const std::string& s, float x, float y, float scale, float r, float g, float b, float a = 1.0f);
  float textWidth(const std::string& s, float scale) const { return (float)s.size() * 8.0f * scale; }
  void endUI();
  void image(GLuint tex, float x, float y, float w, float h, float a = 1.0f);  // flushes queued UI first
  GLuint logoTex = 0;  // the title logo (built from logo_data.h)
  int logoW = 0, logoH = 0;

  bool readPixels(std::vector<uint8_t>& rgb, int& w, int& h);
  // UI drawn between these goes onto the tape: present() runs it through the same VHS
  // distortion, smear and noise as the picture (the camcorder OSD).
  // Textured quads from an RGBA atlas (x y u v r g b a per vertex, 6 vertices a quad), drawn in
  // UI order onto the current UI target. Used for the smooth title font.
  void sprites(GLuint tex, const std::vector<float>& verts);
  void beginTapeUI();
  void endTapeUI();

  Shader world, shadow;
  int winW = 1, winH = 1, rtW = 1, rtH = 1;
  GLuint shadowTex = 0;
  QualityPreset quality = qualityPreset(2);
  float maxAniso = 1.0f;

 private:
  struct Target { GLuint fbo = 0, tex = 0; int w = 0, h = 0; };
  Target makeTarget(int w, int h, GLenum ifmt, GLenum fmt, GLenum type, bool linear);
  void freeTarget(Target& t);
  void bindTarget(const Target& t);
  void fullscreen();

  Shader ssao_, vol_, comp_, down_, up_, tonemap_, fxaa_, ui_;
  GLuint sceneFbo_ = 0, sceneColor_ = 0, sceneDepth_ = 0, emptyVao_ = 0;
  GLuint shadowFbo_ = 0, sunFbo_ = 0;
  int shadowSize_ = 0;
  Target ao_, vol_t_, comp_t_, ldr_, tape_;
  GLuint uiFbo_ = 0;
  bool tapeUsed_ = false;
  std::vector<Target> bloom_;
  GLuint fontTex_ = 0, uiVao_ = 0, uiVbo_ = 0;
  std::vector<float> uiVerts_;
  void destroyTargets();
  void rebuildShadow();
};
