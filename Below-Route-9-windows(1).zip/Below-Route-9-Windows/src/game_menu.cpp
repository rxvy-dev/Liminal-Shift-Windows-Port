// Front end: the loading screen, the title screen and the menus.
// Left-aligned and quiet, like a film's title card over the slow drift through Level 0.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

#include "game.h"

#ifndef BR9_VERSION
#define BR9_VERSION "dev"
#endif
#ifndef BR9_COMMIT
#define BR9_COMMIT "source"
#endif

float menuTop(float winH);
float menuLine(float s);

namespace {
const char* kTips[] = {
    "THE LIGHTS HUM. WHEN THEY STOP HUMMING, STOP WALKING.",
    "THE PAINTED ARROWS LEAD TO THE BLUE TAPE.",
    "ALMOND WATER WITH A BLUE CAP IS SAFE TO DRINK.",
    "DO NOT RUN UNLESS IT HAS ALREADY SEEN YOU.",
    "HIDE IN A LOCKER. IT WON'T LOOK IF IT DIDN'T SEE YOU GET IN.",
    "IF IT'S SOMEBODY'S BIRTHDAY, GET UNDER A TABLE.",
    "TWO LOST TAPES ARE HIDDEN ON EVERY LEVEL.",
    "SOMETHING TALL STANDS VERY STILL IN LEVEL 0. DON'T LET IT GET CLOSE.",
    "THE GRIN ONLY MOVES WHEN YOU'RE NOT LOOKING. A BLINK COUNTS.",
    "LEVEL 0 DOES NOT REPEAT. IT ONLY RHYMES.",
};
constexpr int kTipN = (int)(sizeof(kTips) / sizeof(kTips[0]));

const char* describe(const std::string& label) {
  auto starts = [&](const char* p) { return label.compare(0, std::strlen(p), p) == 0; };
  if (starts("GO AGAIN") || starts("BEGIN")) return "SATURDAY AT SKY HIGH. STAY WHERE MOM AND DAD CAN SEE YOU";
  if (starts("CONTINUE")) return "PICK UP THE TAPE WHERE IT STOPPED";
  if (starts("FALL AGAIN")) return "ONE MORE RUN";
  if (starts("KEEP FALLING  -")) return "SEE ANY ENDING TO UNLOCK THE ENDLESS FALL";
  if (starts("KEEP FALLING")) return "ENDLESS: RANDOM LEVELS, DEEPER IS MEANER. ONE CATCH ENDS IT";
  if (starts("TODAY'S FALL")) return "THE SAME ENDLESS RUN FOR EVERYONE TODAY";
  if (starts("ARCHIVE")) return "LOST TAPES, SURVEY BADGES AND ENDINGS";
  if (starts("OPTIONS")) return "PICTURE, SOUND AND CONTROLS";
  if (starts("QUIT")) return "STOP THE TAPE";
  return "";
}
}  // namespace

void Game::drawLoading(float progress, const char* what) {
  if (!R_ || !win_) return;
  static float shown = 0.0f;
  if (progress >= 0.0f) shown = std::max(progress < 0.01f ? 0.0f : shown, progress);
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  float t = SDL_GetTicks() / 1000.0f;
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  glViewport(0, 0, R_->winW, R_->winH);
  glClearColor(0.012f, 0.012f, 0.01f, 1.0f);
  glClear(GL_COLOR_BUFFER_BIT);
  R_->beginUI();
  // tape noise: faint drifting lines and a slow rolling bar
  for (int i = 0; i < 90; ++i) {
    float y = hashf(i, (int)(t * 24.0f)) * H;
    float w = (0.2f + 0.8f * hashf(i, 7, (int)(t * 24.0f))) * W;
    float x = hashf(i, 3, (int)(t * 24.0f)) * (W - w);
    R_->rect(x, y, w, std::max(1.0f, s * 0.5f), 0.8f, 0.8f, 0.7f, 0.02f + 0.04f * hashf(i, 11, (int)(t * 24.0f)));
  }
  float roll = std::fmod(t * 0.18f, 1.2f) * H - H * 0.1f;
  R_->rect(0, roll, W, H * 0.06f, 0.8f, 0.8f, 0.7f, 0.025f);
  // the logo
  float cy = H * 0.42f;
  if (R_->logoTex) {
    float lw = std::min(W * 0.56f, H * 0.95f), lh = lw * R_->logoH / R_->logoW;
    float jx = hashf((int)(t * 10.0f), 5) > 0.94f ? (hashf((int)(t * 30.0f), 6) - 0.5f) * 8.0f * s : 0.0f;
    R_->image(R_->logoTex, W * 0.5f - lw * 0.5f + jx + 3 * s, cy - lh * 0.5f + 2 * s, lw, lh, 0.25f);
    R_->image(R_->logoTex, W * 0.5f - lw * 0.5f + jx, cy - lh * 0.5f, lw, lh, 0.95f);
    cy += lh * 0.5f;
  }
  R_->beginUI();  // image() flushed; keep drawing
  // progress: a segmented VCR-style bar
  float bw = std::min(W * 0.42f, 520.0f * s * 0.5f + W * 0.2f), bh = 5.0f * s;
  float bx = W * 0.5f - bw * 0.5f, by = cy + 34.0f * s;
  std::string label = what;
  int dots = (int)(t * 2.5f) % 4;
  label += std::string(dots, '.');
  vt(label, bx, by - 14.0f * s, s, 0.88f, 0.86f, 0.78f, 0.9f);
  R_->rect(bx, by, bw, bh, 1.0f, 1.0f, 1.0f, 0.07f);
  const int segs = 32;
  float sw = bw / segs;
  if (progress >= 0.0f) {
    char pct[16];
    std::snprintf(pct, sizeof pct, "%d%%", (int)std::round(shown * 100.0f));
    vt(pct, bx + bw - vw(pct, s), by - 14.0f * s, s, 0.95f, 0.82f, 0.3f, 0.95f);
    int lit = (int)std::floor(shown * segs + 0.001f);
    for (int i = 0; i < lit; ++i) R_->rect(bx + i * sw + 1.0f, by + 1.0f, sw - 2.0f, bh - 2.0f, 0.95f, 0.82f, 0.3f, 0.95f);
  } else {  // indeterminate: a block sweeping back and forth, like tape tracking
    float p = 0.5f + 0.5f * std::sin(t * 3.0f);
    int c = (int)(p * (segs - 4));
    for (int i = c; i < c + 4; ++i) R_->rect(bx + i * sw + 1.0f, by + 1.0f, sw - 2.0f, bh - 2.0f, 0.95f, 0.82f, 0.3f, 0.95f);
  }
  // a tip, changing every few seconds
  const char* tip = kTips[(int)(t / 4.0f) % kTipN];
  float tsc = s;
  while (vw(tip, tsc) > W * 0.9f && tsc > 1.0f) tsc -= 0.5f;
  vt(tip, W * 0.5f - vw(tip, tsc) * 0.5f, by + 30.0f * s, tsc, 0.6f, 0.58f, 0.5f, 0.75f);
  // camcorder corners
  float m = 22.0f * s;
  if (std::fmod(t, 1.2f) < 0.8f) vt("STANDBY", m, m, s, 0.9f, 0.9f, 0.85f, 0.85f);
  vt("TRACKING", W - m - vw("TRACKING", s), m, s, 0.9f, 0.9f, 0.85f, 0.6f);
  vt("PLEASE DO NOT TURN OFF THE CAMERA", m, H - m - 8.0f * s, s, 0.55f, 0.53f, 0.47f, 0.6f);
  R_->endUI();
  SDL_GL_SwapWindow(win_);
  SDL_PumpEvents();  // keep the window responsive while we work
}

void Game::drawMenu(const std::string& title, float alpha) {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  bool paused = screen_ == Screen::Paused;
  float x0 = std::max(28.0f * s, W * 0.075f);
  // darken the left side so the menu reads over the picture
  if (paused) R_->rect(0, 0, W, H, 0, 0, 0, 0.35f);
  const int strips = 28;
  float gw = W * 0.62f;
  for (int i = 0; i < strips; ++i) {
    float k = 1.0f - (float)i / strips;
    R_->rect(i * gw / strips, 0, gw / strips + 1.0f, H, 0.01f, 0.01f, 0.008f, (paused ? 0.75f : 0.62f) * std::pow(k, 1.5f) * alpha);
  }
  float top = menuTop(H), line = menuLine(s);
  if (!title.empty()) {
    vt(title, x0, top - 36.0f * s, s * 2.0f, 0.97f, 0.94f, 0.84f, alpha);
    R_->rect(x0, top - 14.0f * s, 46.0f * s, std::max(1.0f, s), 0.95f, 0.8f, 0.3f, 0.8f * alpha);
  }
  float ts = s * 1.5f;
  for (size_t i = 0; i < menu_.size(); ++i) {
    bool sel = (int)i == menuSel_;
    const std::string& label = menu_[i].label;
    bool locked = label.find("LOCKED") != std::string::npos;
    float y = top + i * line + 4.0f * s;
    float x = x0 + (sel ? 8.0f * s : 0.0f);
    if (sel) {
      float tw = vw(label, ts);
      R_->rect(x0 - 12.0f * s, y - 5.0f * s, tw + 32.0f * s, 8.0f * ts + 10.0f * s, 0.95f, 0.8f, 0.3f, 0.09f * alpha);
      R_->rect(x0 - 12.0f * s, y - 5.0f * s, 3.0f * s, 8.0f * ts + 10.0f * s, 0.98f, 0.84f, 0.32f, alpha);
    }
    float r = sel ? 1.0f : 0.68f, g = sel ? 0.95f : 0.66f, b = sel ? 0.86f : 0.6f;
    if (locked) { r *= 0.6f; g *= 0.6f; b *= 0.6f; }
    vt(label, x + 1.5f * s, y + 1.5f * s, ts, 0, 0, 0, 0.5f * alpha);  // soft shadow
    vt(label, x, y, ts, r, g, b, alpha);
  }
  if (paused && !optionsOpen_) {
    char buf[96];
    std::snprintf(buf, sizeof buf, "%s - %s", level_.theme.name.c_str(), level_.theme.title.c_str());
    vt(buf, x0, top - 64.0f * s, s, 0.95f, 0.8f, 0.3f, 0.85f * alpha);
    std::snprintf(buf, sizeof buf, "NOTES %d / %d", notesFound(), (int)level_.theme.notes.size());
    vt(buf, x0, H - 40.0f * s, s, 0.7f, 0.68f, 0.6f, alpha);
  }
}

void Game::drawTitle() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  float x0 = std::max(28.0f * s, W * 0.075f);
  R_->rect(0, 0, W, H, 0, 0, 0, 0.15f);
  if (archiveOpen_ && !optionsOpen_) {
    drawMenu("ARCHIVE", 1.0f);
    if (archiveView_) drawArchiveView();
  } else if (optionsOpen_) {
    drawMenu("OPTIONS", 1.0f);
  } else if (runOverShow_) {
    drawRunOver();
    drawMenu("", 1.0f);
  } else {
    drawMenu("", 1.0f);  // draws the shade first, so the logo sits on top of it
    // After you've finished it once, the title doesn't always say the same thing.
    bool alt = endingSeen_ && std::fmod(time_, 7.0f) > 6.3f;
    float jx = (hashf((int)(time_ * 12)) > 0.93f) ? (hashf((int)(time_ * 30), 1) - 0.5f) * 8.0f * s : 0.0f;
    float lw = std::min(W * 0.42f, H * 0.78f), lh = R_->logoTex ? lw * R_->logoH / R_->logoW : lw * 0.3f;
    float ly = H * 0.12f;
    if (!alt && R_->logoTex) {
      R_->image(R_->logoTex, x0 - lw * 0.03f + jx + 3 * s, ly + 2 * s, lw, lh, 0.3f);
      R_->image(R_->logoTex, x0 - lw * 0.03f + jx, ly, lw, lh, 1.0f);
    } else {
      std::string t = alt ? (endingLeft_ ? "YOU LEFT HIM" : "STILL 1996") : "BELOW ROUTE 9";
      float ts = lw / (8.0f * 13.0f);
      vt(t, x0 + jx + 2 * s, ly + lh * 0.3f, ts, 0.9f, 0.1f, 0.1f, 0.5f);
      vt(t, x0 + jx, ly + lh * 0.3f, ts, 0.95f, 0.92f, 0.82f);
    }
    if (endingSeen_) vt("NIGHT SHIFT #2 - SOMEONE HAS TO BE ON THE CLOCK", x0, ly + lh + 6.0f * s, s, 0.95f, 0.8f, 0.3f, 0.85f);  // the logo has its own tagline
    // what the highlighted item does
    if (menuSel_ >= 0 && menuSel_ < (int)menu_.size()) {
      const char* d = describe(menu_[menuSel_].label);
      if (*d) {  // beside the menu, level with the highlighted item
        float widest = 0;
        for (const MenuItem& mi : menu_) widest = std::max(widest, vw(mi.label, s * 1.5f));
        float dx = x0 + widest + 40.0f * s;
        float dy = menuTop(H) + menuSel_ * menuLine(s) + 4.0f * s + 2.0f * s;
        if (dx + vw(d, s) < W - 20.0f * s) {
          R_->rect(dx - 8.0f * s, dy - 6.0f * s, vw(d, s) + 16.0f * s, 20.0f * s, 0.0f, 0.0f, 0.0f, 0.55f);
          vt(d, dx, dy, s, 0.9f, 0.88f, 0.8f, 0.95f);
        }
      }
    }
  }
  // camcorder OSD in the corner: it's all on tape
  float m = 22.0f * s;
  int secs = (int)time_;
  char ctr[32];
  std::snprintf(ctr, sizeof ctr, "%d:%02d:%02d", secs / 3600, (secs / 60) % 60, secs % 60);
  vt("PLAY", W - m - vw("PLAY", s) - 12.0f * s, m, s, 0.92f, 0.92f, 0.88f, 0.8f);
  for (int k = 0; k < 7; ++k) {
    float h = (7 - k) * s;
    R_->rect(W - m - 8.0f * s + k * s, m + (7.0f * s - h) * 0.5f, s, h, 0.92f, 0.92f, 0.88f, 0.8f);
  }
  vt(ctr, W - m - vw(ctr, s), m + 14.0f * s, s, 0.92f, 0.92f, 0.88f, 0.6f);
  if (!optionsOpen_ && !archiveOpen_) drawTitleStats();
  std::string foot = std::string("v") + BR9_VERSION + "  " + BR9_COMMIT;
  vt(foot, W - m - vw(foot, s), H - m - 8.0f * s, s, 0.5f, 0.48f, 0.42f, 0.7f);
}
