// Lore you see happen, not just read: Theo's echo walking ahead of you in Level 0, Unit 3 floating
// in the Poolrooms, and on the far balcony of the courtyard, you, coming closer every time you look away.
#include <cmath>

#include "audio.h"
#include "game.h"

namespace {
const vec4 kTheo[4] = {{0.68f, 0.5f, 0.4f, 0}, {0.2f, 0.12f, 0.06f, 0}, {0.55f, 0.07f, 0.06f, 0}, {0.12f, 0.12f, 0.16f, 0}};
const vec4 kDanaEcho[4] = {{0.7f, 0.52f, 0.42f, 0}, {0.16f, 0.09f, 0.05f, 0}, {0.55f, 0.07f, 0.06f, 0}, {0.1f, 0.12f, 0.2f, 0}};
}  // namespace

void Game::loreReset() {
  loreState_ = 0;
  loreT_ = 0;
  loreAt_ = rng_.range(35.0f, 80.0f);
  unitPos_ = {0, 0, 0};
  hasUnit_ = false;
  if (levelIndex_ == 3) {  // Unit 3, face down in a pool a little way along the route
    int d0 = level_.exitDist[level_.idx(level_.startX, level_.startZ)];
    for (int i = 0; i < level_.W * level_.H; ++i) {
      int d = level_.exitDist[i];
      if (!level_.pool[i] || level_.solid[i] || level_.pillar[i] || d < 0 || d > d0 - 5 || d < d0 - 12) continue;
      unitPos_ = level_.tileCenter(i % level_.W, i / level_.W) + vec3{0.3f, 0, -0.2f};
      hasUnit_ = true;
      break;
    }
  }
  if (level_.court.on) {  // you, on the far side of the courtyard
    const auto& c = level_.court;
    echoPos_ = {(c.x0 + c.n * 0.5f) * Level::kTile, 0, (c.z0 - 0.5f) * Level::kTile};
    loreState_ = 10;
  }
}

void Game::loreUpdate(float dt) {
  if (screen_ != Screen::Playing) return;
  loreT_ += dt;
  // Level 0: Theo, still walking, thirty years later
  if (levelIndex_ == 0 && hazmat_) {
    if (loreState_ == 0 && loreT_ > loreAt_) {
      vec3 f = forward();
      int dir = std::fabs(f.x) > std::fabs(f.z) ? (f.x > 0 ? PX : NX) : (f.z > 0 ? PZ : NZ);
      int x, z;
      level_.tileOf(pos_.x, pos_.z, x, z);
      int n = 0;
      while (n < 10 && !level_.blocked(x, z, dir)) { x += kDX[dir]; z += kDZ[dir]; ++n; }
      if (n >= 6) {
        loreState_ = 1;
        loreT_ = 0;
        echoDir_ = {(float)kDX[dir], 0, (float)kDZ[dir]};
        int tx, tz;
        level_.tileOf(pos_.x, pos_.z, tx, tz);
        echoPos_ = level_.tileCenter(tx, tz) + echoDir_ * (Level::kTile * 3.5f);
        if (A_) A_->play(Sfx::Brownout, 0.5f);
      } else loreAt_ = loreT_ + 4.0f;
    } else if (loreState_ == 1) {
      if (loreT_ < 3.2f) echoPos_ += echoDir_ * (1.1f * dt);
      if (loreT_ > 3.4f && loreT_ - dt <= 3.4f) say("THEO", "It's still 1996 down here. Don't let them keep you.", 3.2f);
      if (loreT_ > 1.0f && loreT_ - dt <= 1.0f) say("YOU", "...Hello? Are you from the park?", 2.2f);
      vec3 d = level_.delta(pos_, echoPos_);
      if (loreT_ > 7.2f || std::sqrt(d.x * d.x + d.z * d.z) < 3.0f) {
        loreState_ = 2;
        if (A_) A_->play(Sfx::Brownout, 0.7f);
        say("YOU", "(Theo. That was Theo. From the poster by the front desk.)", 3.0f);
        fear_ = std::min(1.0f, fear_ + 0.3f);
      }
    }
  }
  // Level 188: she only moves when you can't see her.
  if (loreState_ == 10 && level_.court.on) {
    vec3 d = level_.delta(pos_, echoPos_);
    float dist = std::sqrt(d.x * d.x + d.z * d.z);
    vec3 f = forward();
    bool seen = dist > 0.01f && (f.x * d.x + f.z * d.z) / dist > 0.55f;
    echoCool_ -= dt;
    if (!seen && echoCool_ <= 0 && loreT_ > 6.0f) {
      echoCool_ = 0.8f;
      // step around the balcony toward you
      vec3 step = d * (1.0f / std::max(dist, 0.01f)) * std::min(3.5f, dist * 0.3f);
      vec3 np = echoPos_ + step;
      level_.collide(np, 0.3f);
      echoPos_ = np;
      if (A_) A_->play(Sfx::Footstep, 0.35f, 0, 0.7f);
    }
    if (dist < 4.5f) {
      loreState_ = 11;
      if (A_) A_->play(Sfx::Brownout, 0.8f);
      say("YOU", "(...That was me. That was my red shirt. That was me.)", 3.4f);
      fear_ = 1.0f;
    }
  }
}

void Game::loreDraw(Shader& S, vec3 cam) {
  S.set("uMat", MAT_MODEL);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  if (loreState_ == 1) {  // Theo: flickering like bad tape
    bool on = hashf((int)(time_ * 24.0f), 77) > 0.18f;
    if (on) {
      Npc n;
      n.active = true;
      for (int k = 0; k < 4; ++k) n.look4[k] = kTheo[k];
      n.pos = near(echoPos_, cam);
      bool turned = loreT_ > 3.2f;
      n.yaw = turned ? std::atan2(echoDir_.x, echoDir_.z) : std::atan2(-echoDir_.x, -echoDir_.z);
      n.speed = turned ? 0 : 1.1f;
      n.anim = loreT_ * 5.0f;
      drawNpc(S, n, n.pos);
    }
  }
  if (loreState_ == 10) {
    Npc n;
    n.active = true;
    for (int k = 0; k < 4; ++k) n.look4[k] = kDanaEcho[k];
    n.pos = near(echoPos_, cam);
    vec3 d = level_.delta(echoPos_, pos_);
    n.yaw = std::atan2(-d.x, -d.z);
    n.outfit = hazmat_ ? 3 : 0;
    drawNpc(S, n, n.pos);
  }
  if (hasUnit_) {  // Unit 3, face down, rocking on the water
    vec3 p = near(unitPos_, cam);
    p.y = -0.32f + 0.02f * std::sin(time_ * 0.8f);
    AnimInput in;
    in.time = 0;
    mat4 w = translate(p) * rotY(0.7f) * rotX(-kPi * 0.5f + 0.04f * std::sin(time_ * 0.6f)) * translate({0, -0.9f, 0});
    drawCreatureAt(S, CR_HAZMAT, w, in);
  }
}
