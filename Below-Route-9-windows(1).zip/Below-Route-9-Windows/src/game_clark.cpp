// Captain Clark (model and walk by ArthurPXL; see assets/models/CREDITS.txt). He's only ever in the
// Suburbs: an old sea captain on a peg leg, staggering across the hills between the houses, going
// nowhere. Get close and he stops, turns, and watches you until you've gone.
#include <algorithm>
#include <cmath>
#include <cstdio>

#include "game.h"
#include "texload.h"
#include "vam.h"

namespace {
float wrapPi(float a) { return std::remainder(a, 2.0f * kPi); }
}  // namespace

void Game::clarkReset() {
  clarkOn_ = level_.theme.special == Special::Suburbs;
  if (!clarkOn_) return;
  if (!clarkModel_) {
    clarkModel_ = new VamModel();
    std::string p = findAsset("models", "clark.vam");
    if (p.empty() || !clarkModel_->load(p)) std::fprintf(stderr, "[br9] couldn't load Captain Clark (models/clark.vam)\n");
  }
  if (!clarkModel_->ok()) { clarkOn_ = false; return; }
  // somewhere out on open ground, a good way off, in sight of the start
  vec3 best = pos_;
  for (int tries = 0; tries < 400; ++tries) {
    float a = rng_.range(0.0f, 6.2832f), r = rng_.range(18.0f, 34.0f);
    vec3 q = level_.wrap(pos_ + vec3{std::cos(a) * r, 0, std::sin(a) * r});
    int tx, tz;
    level_.tileOf(q.x, q.z, tx, tz);
    if (!level_.solid.empty() && level_.solid[level_.idx(tx, tz)]) continue;
    best = q;
    break;
  }
  clarkPos_ = best;
  clarkGoal_ = best;
  clarkYaw_ = rng_.range(-3.1f, 3.1f);
  clarkGoalT_ = 0;
  clarkPhase_ = 0;
  clarkStare_ = 0;
}

void Game::clarkUpdate(float dt) {
  if (!clarkOn_ || !clarkModel_ || !clarkModel_->ok()) return;
  vec3 toYou = level_.delta(clarkPos_, pos_);
  toYou.y = 0;
  float dYou = length(toYou);
  bool near = dYou < 9.0f && level_.lineOfSight(clarkPos_.x, clarkPos_.z, pos_.x, pos_.z, true);
  clarkStare_ = std::clamp(clarkStare_ + (near ? dt : -dt) * 1.5f, 0.0f, 1.0f);
  float speed = clarkModel_->stride / clarkModel_->loopSeconds;
  if (clarkStare_ > 0.5f) {
    // stop, and turn to face you, slowly
    float want = std::atan2(-toYou.x, -toYou.z);
    clarkYaw_ += wrapPi(want - clarkYaw_) * (1.0f - std::exp(-dt * 1.6f));
    clarkPhase_ = std::round(clarkPhase_ * 2.0f) / 2.0f + (clarkPhase_ - std::round(clarkPhase_ * 2.0f) / 2.0f) * std::exp(-dt * 3.0f);  // settle into a standing pose
    return;
  }
  // wander: pick somewhere across the grass, stagger toward it
  clarkGoalT_ -= dt;
  vec3 toGoal = level_.delta(clarkPos_, clarkGoal_);
  toGoal.y = 0;
  if (clarkGoalT_ <= 0.0f || length(toGoal) < 1.0f) {
    for (int tries = 0; tries < 60; ++tries) {
      float a = rng_.range(0.0f, 6.2832f), r = rng_.range(8.0f, 22.0f);
      vec3 q = level_.wrap(clarkPos_ + vec3{std::cos(a) * r, 0, std::sin(a) * r});
      int tx, tz;
      level_.tileOf(q.x, q.z, tx, tz);
      if (!level_.solid.empty() && level_.solid[level_.idx(tx, tz)]) continue;
      clarkGoal_ = q;
      break;
    }
    clarkGoalT_ = rng_.range(14.0f, 26.0f);
    toGoal = level_.delta(clarkPos_, clarkGoal_);
    toGoal.y = 0;
  }
  float want = std::atan2(-toGoal.x, -toGoal.z);
  want += 0.35f * std::sin(time_ * 0.9f) + 0.2f * std::sin(time_ * 2.3f + 1.0f);  // drunk: never quite straight
  clarkYaw_ += wrapPi(want - clarkYaw_) * (1.0f - std::exp(-dt * 1.2f));
  vec3 f{-std::sin(clarkYaw_), 0, -std::cos(clarkYaw_)};
  vec3 before = clarkPos_;
  clarkPos_ = clarkPos_ + f * (speed * dt);
  level_.collide(clarkPos_, 0.4f);
  clarkPos_ = level_.wrap(clarkPos_);
  vec3 moved = level_.delta(before, clarkPos_);
  float dist = std::sqrt(moved.x * moved.x + moved.z * moved.z);
  if (dist < speed * dt * 0.3f) clarkGoalT_ = std::min(clarkGoalT_, 0.5f);  // walked into a house: pick somewhere else
  clarkPhase_ += dist / std::max(clarkModel_->stride, 0.1f);
  // his steps: a boot, then the peg
  float step = std::floor(clarkPhase_ * 2.0f);
  if (step != clarkLastStep_ && A_ && dYou < 30.0f) {
    vec3 rt{std::cos(yaw_), 0, -std::sin(yaw_)};
    float pan = dYou > 0.01f ? dot(normalize(toYou * -1.0f), rt) : 0.0f;
    bool peg = std::fmod(step, 2.0f) > 0.5f;
    A_->play(peg ? Sfx::Click : Sfx::Footstep, (peg ? 0.9f : 0.7f) / (1.0f + dYou * 0.25f), pan, peg ? 0.45f : 0.75f);
  }
  clarkLastStep_ = step;
}

void Game::clarkDraw(Shader& S, vec3 cam) {
  if (!clarkOn_ || !clarkModel_ || !clarkModel_->ok()) return;
  vec3 at = near(clarkPos_, cam);
  vec3 d = at - cam;
  if (d.x * d.x + d.z * d.z > 90.0f * 90.0f) return;
  at.y = level_.floorAt(clarkPos_.x, clarkPos_.z);
  clarkModel_->pose(clarkPhase_);
  S.set("uSkinned", 0);
  S.set("uMat", MAT_PROP);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uUVScale", 1.0f);
  S.set("uRough", 0.8f);
  S.set("uBump", 0.0f);
  S.set("uEmissive", 0.0f);
  S.set("uModel", translate(at) * rotY(clarkYaw_));
  glDisable(GL_CULL_FACE);
  for (const VamModel::Mat& m : clarkModel_->mats) {
    glBindTexture(GL_TEXTURE_2D, m.gl ? m.gl : texWhite_);
    glBindVertexArray(clarkModel_->gpu.vao);
    glDrawElements(GL_TRIANGLES, (GLsizei)m.count, GL_UNSIGNED_INT, (void*)(size_t)(m.first * 4));
  }
  glBindVertexArray(0);
  glEnable(GL_CULL_FACE);
  S.set("uModel", mat4::identity());
}
