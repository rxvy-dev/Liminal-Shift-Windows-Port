// Down below: hiding in lockers, finding Ray and carrying him, and the endings.
#include "game.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace {
const vec4 kRayLook[4] = {{0.6f, 0.43f, 0.33f, 0}, {0.42f, 0.4f, 0.38f, 0}, {0.12f, 0.22f, 0.42f, 0}, {0.1f, 0.18f, 0.33f, 0}};

mat4 basisM(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}

const char* kRayCalling[] = {"Hello?! Is anybody there?", "KID?!", "Help! I can't walk!", "Somebody... please...",
                             "I can hear you! Over here!", "Is that you? Say something!"};
const char* kRayBegging[] = {"Kid? Hey, kid, where are you going?", "Don't leave me here! Please!", "I want to go home! I just want to go home!",
                             "I have a daughter! Please!", "KID! COME BACK!", "Please... don't let me die down here..."};
const char* kRayCarried[] = {"You're doing good. You're doing real good.", "My leg... don't worry about my leg. Keep going.",
                             "My daughter's birthday is Sunday. I promised her pancakes.", "Is it me or are the lights following us?",
                             "If you have to leave me... no. No, don't leave me.", "Left. I think it was left. I don't know anymore.",
                             "I filmed the whole thing. Nobody's gonna believe the tape.", "Thank you. I mean it. Thank you."};

enum Shot { SH_BLACK, SH_BASEMENT, SH_LOT, SH_AMBULANCE, SH_REUNION, SH_WORK, SH_BRICKED, SH_CHOICE, SH_CARD, SH_APT_TV, SH_TV_NEWS, SH_APT_OFF, SH_APT_WRONG, SH_TV_HALL, SH_FREAK, SH_WALL, SH_SUNRISE, SH_WINDOW, SH_HALL, SH_HALL_RAY, SH_HALL_CARRY,
           SH_NEWCLERK, SH_SUITDOOR, SH_NOTDAD, SH_VANTHING, SH_SURVEY, SH_UNMASK,
           // the trampoline park, after
           SH_PARK_GAP, SH_PARK_NIGHT, SH_PARK_REUNION, SH_PARK_RAY, SH_PARK_NOTDAD, SH_PARK_WALL, SH_PARK_NEWKID, SH_PARK_SUIT, SH_PARK_RAYWAVE };
const vec4 kMomShot[4] = {{0.66f, 0.5f, 0.4f, 0}, {0.32f, 0.2f, 0.1f, 0}, {0.62f, 0.2f, 0.26f, 0}, {0.08f, 0.09f, 0.14f, 0}};
const vec4 kDadShot[4] = {{0.62f, 0.46f, 0.36f, 0}, {0.16f, 0.11f, 0.07f, 0}, {0.18f, 0.3f, 0.22f, 0}, {0.16f, 0.17f, 0.22f, 0}};
const vec4 kYouKid[4] = {{0.62f, 0.45f, 0.35f, 0}, {0.3f, 0.2f, 0.1f, 0}, {0.8f, 0.12f, 0.1f, 0}, {0.12f, 0.15f, 0.3f, 0}};
const vec4 kDanaNow[4] = {{0.7f, 0.52f, 0.42f, 0}, {0.16f, 0.09f, 0.05f, 0}, {0.55f, 0.07f, 0.06f, 0}, {0.1f, 0.12f, 0.2f, 0}};
const vec4 kDanaOld[4] = {{0.66f, 0.5f, 0.41f, 0}, {0.56f, 0.54f, 0.5f, 0}, {0.86f, 0.74f, 0.14f, 0}, {0.84f, 0.72f, 0.14f, 0}};
const vec4 kRayWrong[4] = {{0.46f, 0.43f, 0.41f, 0}, {0.3f, 0.29f, 0.28f, 0}, {0.07f, 0.12f, 0.24f, 0}, {0.06f, 0.1f, 0.18f, 0}};
}  // namespace

// ================================================================ hiding

int Game::focusLocker() const {
  vec3 e = eye(), fw = forward();
  int best = -1;
  float bd = 1.7f;
  for (size_t i = 0; i < level_.props.size(); ++i) {
    const PropInstance& p = level_.props[i];
    if ((p.type != PR_LOCKER && p.type != PR_DESK) || p.anomaly) continue;
    float hy = p.type == PR_DESK ? 0.6f : 1.0f;
    vec3 d = level_.delta(e, p.pos + vec3{0, hy, 0});
    d.y = hy - e.y + p.pos.y;
    float dl = length(d);
    if (dl < bd && dot(d * (1.0f / dl), fw) > 0.6f) { bd = dl; best = (int)i; }
  }
  return best;
}

bool Game::underDesk() const { return hiding_ >= 0 && hiding_ < (int)level_.props.size() && level_.props[hiding_].type == PR_DESK; }

void Game::enterLocker(int prop) {
  if (level_.props[prop].type == PR_LOCKER && lockerScare(prop)) return;
  const PropInstance& p = level_.props[prop];
  hiding_ = prop;
  hideT_ = 0;
  hideYaw_ = p.yaw + kPi;  // looking out through the door slits
  vec3 door{-std::sin(p.yaw), 0, -std::cos(p.yaw)};  // model -Z
  hidePos_ = p.pos + door * 0.05f;
  hideYaw_ = std::atan2(-door.x, -door.z);
  yaw_ = hideYaw_;
  pitch_ = 0.05f;
  flashBeforeHide_ = flashOn_;
  flashOn_ = false;
  seenHiding_ = false;
  for (const Stalker& s : stalkers_) {
    if (!s.active() || !(s.state == Stalker::Chase || s.hunt > 0)) continue;
    // The Partygoers never look under tables. Birthday guests spawn already hunting you, so without this
    // any guest in view when you crawled under flagged you as "seen" and they walked up and caught you.
    if (p.type == PR_DESK && s.kind == CR_PARTYGOER) continue;
    vec3 d = level_.delta(pos_, s.pos);
    if (std::sqrt(d.x * d.x + d.z * d.z) < 7.0f && level_.lineOfSight(pos_.x, pos_.z, s.pos.x, s.pos.z)) seenHiding_ = true;
  }
  if (p.type == PR_DESK) {  // under the table, looking out past the tablecloth
    hidePos_ = p.pos + door * 0.12f;
    pitch_ = 0.0f;
    if (A_) A_->play(Sfx::Paper, 0.4f);
  } else if (A_) A_->play(Sfx::Slam, 0.35f, 0, 1.4f);
  if (seenHiding_) { toast_ = p.type == PR_DESK ? "THEY SAW YOU CRAWL UNDER" : "IT SAW YOU GET IN"; toastTime_ = 2.5f; }
}

void Game::leaveLocker() {
  if (hiding_ < 0) return;
  const PropInstance& p = level_.props[hiding_];
  vec3 door{-std::sin(p.yaw), 0, -std::cos(p.yaw)};
  pos_ = level_.wrap(p.pos + door * 0.75f);
  vel_ = {0, 0, 0};
  hiding_ = -1;
  flashOn_ = flashBeforeHide_ && battery_ > 0;
  if (A_) A_->play(Sfx::Slam, 0.3f, 0, 1.3f);
}

// ================================================================ Ray

void Game::placeRay() {
  if (levelIndex_ != rayLevel_ || rayState_ != 0) return;
  int d0 = level_.exitDist[level_.idx(level_.startX, level_.startZ)];
  std::vector<int> cands;
  for (int z = 0; z < level_.H; ++z)
    for (int x = 0; x < level_.W; ++x) {
      int i = level_.idx(x, z);
      int d = level_.exitDist[i];
      if (d < d0 * 0.35f || d > d0 * 0.65f || level_.pillar[i] || level_.pool[i] || level_.solid[i]) continue;
      bool wall = false;
      for (int k = 0; k < 4; ++k) wall |= level_.blocked(x, z, k);
      if (wall && level_.propsAtTile[i].empty()) cands.push_back(i);
    }
  if (cands.empty()) cands.push_back(level_.idx(level_.startX, level_.startZ));
  int c = cands[rng_.next() % cands.size()];
  int x = c % level_.W, z = c / level_.W;
  rayPos_ = level_.tileCenter(x, z);
  for (int k = 0; k < 4; ++k)
    if (level_.blocked(x, z, k)) { rayPos_.x += kDX[k] * 0.35f; rayPos_.z += kDZ[k] * 0.35f; rayYaw_ = std::atan2((float)kDX[k], (float)kDZ[k]); break; }
  rayTalk_ = 6.0f;
  std::fprintf(stderr, "[br9] Ray is on this level at (%.1f, %.1f)\n", rayPos_.x, rayPos_.z);
}

bool Game::rayInteract() {
  if (rayState_ > 1 || rayLevel_ != levelIndex_) return false;
  vec3 d = level_.delta(pos_, rayPos_);
  if (std::sqrt(d.x * d.x + d.z * d.z) > 1.7f) return false;
  bool first = rayState_ == 0;
  rayState_ = 2;
  rayBeg_ = 0;
  rayTalk_ = 25.0f;
  lines_.clear();
  lineTime_ = 0;
  if (first) {
    say("RAY", "A kid? Oh thank God. Thank God. I thought you were one of them. I'm Ray. I fix the lights at Route 9 Park.", 4.2f);
    say("RAY", "My leg's gone wrong. I can't stand on it.", 2.6f);
    say("RAY", "Just... get me home. Please. I'll hold on.", 2.8f);
  } else {
    say("RAY", "You came back. You came back.", 2.4f);
  }
  if (A_) A_->play(Sfx::Pickup, 0.6f, 0, 0.7f);
  return true;
}

void Game::rayPutDown() {
  if (rayState_ != 2) return;
  rayState_ = 1;
  rayLevel_ = levelIndex_;
  vec3 f = forward();
  rayPos_ = pos_ + vec3{f.x, 0, f.z} * 0.5f;
  level_.collide(rayPos_, 0.3f);
  rayPos_ = level_.wrap(rayPos_);
  rayYaw_ = yaw_;
  rayTalk_ = 9.0f;
  lines_.clear();
  lineTime_ = 0;
  say("RAY", "Wait, why are we stopping? Okay. Okay. Just... come back.", 3.2f);
}

void Game::rayUpdate(float dt) {
  rayTalk_ -= dt;
  if (rayState_ == 2) {  // on your back
    if (rayTalk_ <= 0 && lines_.empty()) { say("RAY", kRayCarried[rng_.next() % 8]); rayTalk_ = rng_.range(28.0f, 45.0f); }
    return;
  }
  if (rayLevel_ != levelIndex_ || rayState_ > 1) {
    if (rayState_ == 3 && rayTalk_ <= 0) {  // left behind: sometimes you think you hear him
      rayTalk_ = rng_.range(70.0f, 120.0f);
      if (lines_.empty()) say("???", "...kid...?", 2.2f);
    }
    return;
  }
  vec3 d = level_.delta(pos_, rayPos_);
  d.y = 0;
  float dist = length(d);
  if (rayTalk_ > 0 || !lines_.empty()) return;
  if (rayState_ == 0) {
    if (dist > 38.0f) { rayTalk_ = 4.0f; return; }
    vec3 f = forward(), fr{f.x, 0, f.z};
    fr = normalize(fr);
    vec3 dn = d * (1.0f / std::max(dist, 0.01f));
    float ahead = dot(dn, fr), side = dot(dn, vec3{-fr.z, 0, fr.x});
    const char* where = ahead > 0.7f ? "AHEAD" : (ahead < -0.6f ? "BEHIND YOU" : (side > 0 ? "TO THE RIGHT" : "TO THE LEFT"));
    std::string who = std::string("RAY (") + (dist > 20 ? "FAR, " : (dist < 9 ? "CLOSE, " : "")) + where + ")";
    say(who, kRayCalling[rng_.next() % 6], 2.8f);
    rayTalk_ = rng_.range(10.0f, 17.0f);
    if (dist < 25 && A_) A_->play(Sfx::Knock, 0.3f, side, 1.2f);
  } else if (dist > 9.0f) {  // you put him down and walked away
    say(dist > 22 ? "RAY (FAR BEHIND)" : "RAY", kRayBegging[rayBeg_++ % 6], 2.8f);
    rayTalk_ = rng_.range(6.0f, 9.0f);
  }
}

void Game::rayDraw(Shader& S, vec3 cam) {
  if (rayState_ == 2 && screen_ != Screen::Caught) {
    // His arms over your shoulders, hands locked across your chest.
    vec3 e = cam, f = forward();
    vec3 r = normalize(cross(f, vec3{0, 1, 0}));
    vec3 u = cross(r, f);
    float sway = std::sin(stepPhase_ * kPi) * 0.012f;
    S.set("uMat", MAT_PROP);
    S.set("uSkinned", 0);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    auto seg = [&](vec3 a, vec3 b, float th, vec3 col) {
      vec3 ax = b - a;
      float len = length(ax);
      vec3 uu = ax * (1.0f / len);
      vec3 rr = normalize(cross(uu, f));
      vec3 nn = cross(rr, uu);
      drawPart(basisM(rr * th, uu * len, nn * th, (a + b) * 0.5f), col);
    };
    for (int s = -1; s <= 1; s += 2) {
      vec3 shoulder = e + r * (0.22f * s) - u * 0.1f - f * 0.05f;
      vec3 elbow = e + r * (0.2f * s) - u * 0.24f + f * 0.22f + u * sway;
      vec3 wrist = e + r * (0.03f * s) - u * 0.27f + f * 0.38f + u * sway;
      seg(shoulder, elbow, 0.085f, {0.12f, 0.22f, 0.42f});
      seg(elbow, wrist, 0.07f, {0.11f, 0.2f, 0.38f});
      vec3 hand = wrist + r * (-0.04f * s) + f * 0.01f;
      drawPart(basisM(r * 0.085f, u * 0.05f, f * -0.1f, hand), {0.6f, 0.43f, 0.33f});
    }
    return;
  }
  if (rayLevel_ != levelIndex_ || rayState_ > 1) return;
  // Lying on his side on the floor, breathing, one hand over his leg.
  AnimInput in;
  in.time = time_;
  in.look = 0.3f * std::sin(time_ * 0.4f);
  vec3 at = near(rayPos_, cam);
  at.y = level_.floorAt(rayPos_.x, rayPos_.z) + 0.16f;
  mat4 w = translate(at) * rotY(rayYaw_) * rotZ(kPi * 0.5f - 0.12f) * translate({-0.15f, 0, 0});
  S.set("uMat", MAT_MODEL);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  drawCreatureAt(S, CR_WORKER, w, in, 0, kRayLook);
}

void Game::drawSubtitles() {
  if (lines_.empty()) return;
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  const Line& l = lines_.front();
  std::string t = l.who + ": " + l.text;
  float a = clampf(lineTime_ / 0.2f, 0, 1) * clampf((l.dur - lineTime_) / 0.3f, 0, 1);
  float sc = s;
  int perLine = std::max(12, (int)(W * 0.9f / (8.0f * sc)));
  std::vector<std::string> rows;
  std::string cur, word;
  auto flush = [&]() {
    if (word.empty()) return;
    if ((int)(cur.size() + word.size() + 1) > perLine && !cur.empty()) { rows.push_back(cur); cur.clear(); }
    cur += (cur.empty() ? "" : " ") + word;
    word.clear();
  };
  for (char c : t) { if (c == ' ') flush(); else word += c; }
  flush();
  if (!cur.empty()) rows.push_back(cur);
  bool ray = l.who.rfind("RAY", 0) == 0;
  bool ghost = l.who == "???";
  float lh = 11.0f * sc;
  float y0 = H * 0.8f;
  float maxW = 0;
  for (auto& r : rows) maxW = std::max(maxW, R_->textWidth(r, sc));
  R_->rect(W * 0.5f - maxW * 0.5f - 8 * s, y0 - 6 * s, maxW + 16 * s, rows.size() * lh + 10 * s, 0, 0, 0, 0.55f * a);
  for (size_t i = 0; i < rows.size(); ++i)
    R_->text(rows[i], W * 0.5f - R_->textWidth(rows[i], sc) * 0.5f, y0 + i * lh, sc, ray ? 0.6f : (ghost ? 0.6f : 1.0f),
             ray ? 0.8f : (ghost ? 0.6f : 0.95f), ray ? 1.0f : (ghost ? 0.6f : 0.85f), a * (ghost ? 0.6f : 1.0f));
}

void Game::updateLines(float dt) {
  if (lines_.empty()) return;
  lineTime_ += dt;
  if (lineTime_ > lines_.front().dur) { lines_.pop_front(); lineTime_ = 0; }
}

void Game::rayHUD() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  const char* key = usingPad_ ? "[A]" : "[E]";
  std::string prompt;
  if (hiding_ >= 0) {
    if (underDesk()) {
      // Under the table: the underside overhead, the tablecloth hem hanging at the sides.
      R_->rect(0, 0, W, H * 0.2f, 0.03f, 0.02f, 0.02f, 0.97f);
      for (int k = 0; k < 24; ++k) {  // scalloped hem
        float x = W * k / 24.0f, hgt = H * (0.03f + 0.02f * std::sin(k * 1.7f));
        R_->rect(x, H * 0.2f, W / 24.0f + 1, hgt, 0.5f, 0.12f, 0.22f, 0.95f);
      }
      R_->rect(0, 0, W * 0.09f, H, 0.45f, 0.1f, 0.2f, 0.93f);
      R_->rect(W * 0.91f, 0, W * 0.09f, H, 0.45f, 0.1f, 0.2f, 0.93f);
      std::string st = seenHiding_ ? "THEY SAW YOU" : "HIDDEN";
      R_->text(st, W * 0.5f - R_->textWidth(st, s) * 0.5f, H * 0.09f, s, seenHiding_ ? 1.0f : 0.6f, seenHiding_ ? 0.3f : 0.85f, seenHiding_ ? 0.25f : 0.6f, 0.9f);
      prompt = std::string(key) + " CRAWL OUT";
      R_->text(prompt, W * 0.5f - R_->textWidth(prompt, s) * 0.5f, H * 0.62f, s, 0.92f, 0.92f, 0.88f, 0.9f);
      return;
    }
    // Inside the locker: the world through six thin slits.
    float y0 = H * 0.36f, slit = H * 0.022f, gap = H * 0.034f, x0 = W * 0.18f, x1 = W * 0.82f;
    float a = 0.96f;
    R_->rect(0, 0, W, y0, 0.01f, 0.01f, 0.01f, a);
    float y = y0;
    for (int k = 0; k < 6; ++k) {
      R_->rect(0, y, x0, slit, 0.01f, 0.01f, 0.01f, a);
      R_->rect(x1, y, W - x1, slit, 0.01f, 0.01f, 0.01f, a);
      y += slit;
      R_->rect(0, y, W, gap, 0.01f, 0.01f, 0.01f, a);
      y += gap;
    }
    R_->rect(0, y, W, H - y, 0.01f, 0.01f, 0.01f, a);
    std::string st = seenHiding_ ? "IT SAW YOU" : "HIDDEN";
    R_->text(st, W * 0.5f - R_->textWidth(st, s) * 0.5f, H * 0.18f, s, seenHiding_ ? 1.0f : 0.6f, seenHiding_ ? 0.3f : 0.85f, seenHiding_ ? 0.25f : 0.6f, 0.9f);
    prompt = std::string(key) + " LEAVE THE LOCKER";
  } else {
    vec3 d = level_.delta(pos_, rayPos_);
    if (rayState_ <= 1 && rayLevel_ == levelIndex_ && std::sqrt(d.x * d.x + d.z * d.z) < 1.7f) prompt = std::string(key) + " CARRY RAY";
    else if (focusItem_ < 0 && focusLocker() >= 0)
      prompt = std::string(key) + (level_.props[focusLocker()].type == PR_DESK ? " HIDE UNDER THE TABLE" : " HIDE IN LOCKER");
    if (prompt.empty()) prompt = shockPrompt();
    if (prompt.empty() && levelIndex_ == kChoiceLevel) {
      static const char* names[3] = {" TAKE THE BLUE SLIDE", " TAKE THE YELLOW SLIDE", " TAKE THE GREEN SLIDE"};
      int t = focusTube();
      if (t >= 0) prompt = std::string(key) + names[t];
    }
    // Stealth readout.
    bool dark = !flashOn_ && playerLight_ < 0.25f && !level_.theme.outdoor;
    std::string st = dark && crouch_ ? "IN THE DARK" : (dark ? "DIM" : "");
    if (!st.empty()) R_->text(st, W * 0.5f - R_->textWidth(st, s) * 0.5f, H - 24 * s, s, 0.55f, 0.75f, 0.6f, 0.7f);
  }
  if (rayState_ == 2) {
    std::string t = usingPad_ ? "RAY LEANING ON YOU  [Y] LET GO" : "RAY LEANING ON YOU  [G] LET GO";
    R_->text(t, 12 * s, H - 40 * s, s, 0.6f, 0.8f, 1.0f, 0.75f);
  }
  if (!prompt.empty()) R_->text(prompt, W * 0.5f - R_->textWidth(prompt, s) * 0.5f, H * 0.62f, s, 0.92f, 0.92f, 0.88f, 0.95f);
  drawSubtitles();
}

// ================================================================ endings
// Told in the engine itself: slow camera moves through real places, the camcorder
// still rolling, captions typed over the footage.

namespace {
int shotLevel(int shot) {
  switch (shot) {
    case SH_APT_TV: case SH_TV_NEWS: case SH_APT_OFF: case SH_WALL: case SH_SUNRISE: case SH_WINDOW: return kAptLevel;
    case SH_APT_WRONG: case SH_TV_HALL: case SH_FREAK: return kAptWrongLevel;
    case SH_HALL: case SH_HALL_RAY: case SH_HALL_CARRY: case SH_SURVEY: case SH_UNMASK: return 0;
    case SH_PARK_GAP: case SH_PARK_NIGHT: case SH_PARK_REUNION: case SH_PARK_RAY: case SH_PARK_NOTDAD: case SH_PARK_WALL:
    case SH_PARK_NEWKID: case SH_PARK_SUIT: case SH_PARK_RAYWAVE: return kParkLevel;
    default: return 1000;  // black frames: keep whatever is loaded
  }
}
float yawTo(vec3 f, vec3 t) { return std::atan2(-(t.x - f.x), -(t.z - f.z)); }
float pitchTo(vec3 f, vec3 t) { vec3 d = t - f; return std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)); }
const vec4 kDaughter[4] = {{0.66f, 0.48f, 0.38f, 0}, {0.3f, 0.18f, 0.08f, 0}, {0.75f, 0.35f, 0.45f, 0}, {0.15f, 0.2f, 0.35f, 0}};
const vec4 kMedic[4] = {{0.45f, 0.31f, 0.22f, 0}, {0.04f, 0.03f, 0.03f, 0}, {0.1f, 0.14f, 0.3f, 0}, {0.07f, 0.09f, 0.17f, 0}};
}  // namespace

void Game::drawNpc(Shader& S, const Npc& n, vec3 pos) {
  AnimInput in;
  in.time = time_ + n.pos.x;
  in.phase = n.anim;
  in.speed = n.speed / 1.3f;
  in.look = n.look;
  in.sit = n.sit;
  in.hug = n.hug;
  mat4 w = n.lie ? translate(pos + vec3{0, 0.16f, 0}) * rotY(n.yaw) * rotZ(kPi * 0.5f - 0.12f) * translate({-0.15f, 0, 0})
                 : translate(pos) * rotY(n.yaw) * scale({n.size, n.size, n.size});
  static const CreatureId kOutfit[4] = {CR_HUMAN, CR_SUIT, CR_WORKER, CR_HAZMAT};
  in.hold = (n.item >= 0 && !n.itemDown) ? 1.0f : 0.0f;
  in.offer = n.offer;
  in.cross = (n.state == 4 && n.rude >= 2) ? 1.0f : 0.0f;
  if (n.state == 4 && n.rude >= 2) in.look += 0.35f * std::sin(time_ * 7.0f) * std::max(0.0f, std::sin(time_ * 0.9f + n.pos.x));  // shaking their head
  drawCreatureAt(S, kOutfit[n.outfit & 3], w, in, 0, n.outfit == 3 ? nullptr : n.look4);
  drawHeldItem(S, n, kOutfit[n.outfit & 3]);
}

void Game::beginEnding() {
  screen_ = Screen::Ending;
  screenTime_ = 0;
  setMouseCapture(false);
  slides_.clear();
  slide_ = 0;
  slideT_ = 0;
  slideOut_ = -1;
  choice_ = 0;
  lines_.clear();
  auto add = [&](int sc, const std::string& t, float autoT = 0, float fx = 0, int param = 0) { slides_.push_back({sc, t, autoT, fx, param}); };
  add(SH_BLACK, "You fell up.", 2.5f, 1.0f);
  add(SH_PARK_GAP, "You came up out of the gap behind the pad. Route 9 Park was dark. The clock over the front desk said 3:14 in the morning.", 0, 0, rayState_ == 2 ? 1 : 0);
  if (chooseYellow_) {  // the yellow slide
    slides_.clear();
    add(SH_BLACK, "You slid for a long time. Long enough to forget which way was up.", 3.0f, 1.0f);
    add(SH_SURVEY, "There were three of them waiting at the bottom. Yellow suits. A red hose. Level 0, again.");
    add(SH_SURVEY, "\"Unit 4,\" one of them said into a radio. \"The kid made it. Same as last time.\"", 0, 0, 1);
    add(SH_UNMASK, "The one in front pulled off the hood. It was you. Thirty years older. Tired in a way you didn't have a word for yet.");
    add(SH_BLACK, "\"Somebody has to stay by the back wall,\" you said. \"The gap only stays shut while one of us is down here.\"");
    add(SH_BLACK, "\"Go back up. Go bounce. When Mom says ten more minutes, go. Don't go near the back wall.\"");
    add(SH_BLACK, "\"And this time...\" You looked at the others. They were all you. \"...this time, don't take the yellow slide.\"", 0, 0.2f);
    add(SH_PARK_NEWKID, "Saturday, October 24, 1998. 2:00 PM. Route 9 Park. A kid in a red shirt kicks their shoes into the cubbies.");
    add(SH_CARD, "ENDING: UNIT 4");
    endingId_ = 4;
    addStinger();
  } else if (rayState_ == 2 && wentBack_) {
    slides_.pop_back();
    add(SH_PARK_GAP, "You went back down for him. You found him. You got him out, the whole way, one step at a time.", 0, 0, 2);
    add(SH_PARK_NOTDAD, "His daughter was waiting at the front desk. She ran to him. Then she stopped.");
    add(SH_PARK_NOTDAD, "\"That's not my dad.\"", 0, 0.15f, 1);
    add(SH_BLACK, "Ray's camcorder was still in his jacket. You watched the tape that night, under your covers.");
    add(SH_BLACK, "On the tape, Ray is still down there. Sitting against the wall in the dark. Calling for you. Begging you to come back for him.", 0, 0.1f);
    add(SH_PARK_RAYWAVE, "The man you brought out still comes to Route 9 Park every Saturday. He sits at the tables. He's a little taller every week. He waves at you from across the court, the whole time you're there.");
    add(SH_CARD, "ENDING: WENT BACK");
    endingId_ = 2;
    addStinger();
  } else if (rayState_ == 2) {
    add(SH_PARK_RAY, "Ray was still holding on to you. He was laughing, or crying. Both. The paramedics said his leg was broken in four places. He kept asking them if they were real.");
    add(SH_PARK_REUNION, "His daughter got there before the ambulance left. He told her about the yellow rooms. She just held on.", 0, 0, 1);
    add(SH_PARK_REUNION, "Your mom didn't let go of you for an hour. Your dad kept saying your name, like he was checking it still worked.");
    add(SH_PARK_WALL, "Route 9 Park closed a month later. Ray went back one night and bricked up the back wall himself.");
    add(SH_SUNRISE, "Some nights you still hear the hum. But you're never the only one who remembers it.");
    add(SH_CARD, "ENDING: BROUGHT HIM HOME");
    endingId_ = 1;
    addStinger();
  } else {
    add(SH_PARK_NIGHT, leftRay_ ? "The doors were locked. Somewhere under the court, you could still hear him. Begging."
                                : "The doors were locked. Nobody else came up after you. You sat on the edge of the court in your socks and waited.");
    buildEndingB(false);
  }
  startSlide();
}

void Game::addStinger() {
  // After the credits: what this footage actually is.
  auto add = [&](int sc, const std::string& t, float autoT = 0, float fx = 0, int param = 0) { slides_.push_back({sc, t, autoT, fx, param}); };
  add(SH_BLACK, "This tape was found in the lost-and-found box at Route 9 Park, in October 2026.");
  add(SH_BLACK, "The tape is dated October 24, 1998.");
  add(SH_BLACK, "Route 9 Park did not open until 2004.");
  add(SH_BLACK, "No child has ever been reported missing there.");
  add(SH_BLACK, "The camera was still recording.", 4.0f, 0.15f);
}

void Game::buildEndingB(bool goBack) {
  auto add = [&](int sc, const std::string& t, float autoT = 0, float fx = 0, int param = 0) { slides_.push_back({sc, t, autoT, fx, param}); };
  if (goBack) {
    add(SH_HALL, "You put your hand on the wall behind the pad. It wasn't quite solid. You went back down.");
    add(SH_HALL_RAY, "It took eleven hours. You found him where you left him. He didn't believe you were real either.");
    add(SH_HALL_CARRY, "You got him out, one step at a time. You don't remember most of it.");
    add(SH_PARK_REUNION, "His daughter was asleep in his van in the parking lot. She'd been waiting all night.", 0, 0, 1);
    add(SH_PARK_WALL, "Route 9 Park closed a month later. The back wall is bricked over now.");
    add(SH_CARD, "ENDING: WENT BACK");
    endingId_ = 2;
    addStinger();
  } else {
    add(SH_PARK_REUNION, "Mom found you at six, when the cleaners let her in. She'd been in the parking lot all night. Dad was still out driving, looking.");
    add(SH_APT_TV, "At home the TV was on all day. Nobody turned it off. Nobody wanted it quiet.");
    add(SH_TV_NEWS, "CHILD FOUND SAFE AT TRAMPOLINE PARK. They used your school picture. You looked like somebody else.");
    add(SH_APT_OFF, "Mom turned it off. The hum didn't stop.", 0, 0.1f);
    add(SH_APT_WRONG, "The wallpaper was the wrong yellow. Hadn't it always been white?", 0, 0.25f);
    add(SH_TV_HALL, "The TV was showing a hallway. The TV was off.", 0, 0.22f);
    add(SH_FREAK, "This isn't real.", 1.1f, 0.85f, 0);
    add(SH_FREAK, "THIS ISN'T REAL.", 0.8f, 1.0f, 1);
    add(SH_FREAK, "Which one is real?", 0.8f, 1.0f, 2);
    add(SH_FREAK, "How would you even know?", 0.8f, 1.0f, 0);
    add(SH_FREAK, "HOW WOULD YOU KNOW", 0.6f, 1.0f, 1);
    add(SH_BLACK, "", 1.6f, 0.0f);
    add(SH_WALL, "You put your hands flat on the wall. You counted to ten, like the school counsellor said. You breathed.", 0, 0.35f, 1);
    add(SH_WALL, "It was solid. Paint. Drywall. The pencil marks where Dad measures you every birthday. Your house.", 0, 0.0f, 0);
    add(SH_SUNRISE, "The sun came up. Birds. The garbage truck. Mom making coffee downstairs.");
    add(SH_WINDOW, "You were home. You were really, actually home. You cried for a long time, and then you had cereal.");
    add(SH_BLACK, "The next Saturday, Dad said maybe it would help to go back. Face it. Just for ten minutes.");
    add(SH_PARK_NEWKID, "There was already a kid by the back wall. Your age. Your red shirt. Bouncing right where you'd been.");
    add(SH_BLACK, "\"Oh, that's a regular,\" said the guy at the front desk. \"Comes every Saturday. Sweet kid. Never says a word.\"");
    add(SH_PARK_SUIT, "He told you about the other regular. Somebody in a yellow suit who stands by the back wall at 3:14 every night, after closing, staring at the court. It never comes any closer.");
    add(SH_PARK_SUIT, "He thinks it's trying to warn somebody.", 0, 0.1f, 1);
    add(SH_BLACK, leftRay_ ? "You looked down. Yellow sleeves. Black gloves. Somewhere under the court, someone was still calling for you."
                           : "You looked down. Yellow sleeves. Black gloves. You had never taken the suit off.", 0, 0.25f);
    add(SH_CARD, "ENDING: PICK-UP TIME");
    endingId_ = 3;
    addStinger();
  }
}

void Game::startSlide() {
  hasPrevVP_ = false;
  slideT_ = 0;
  slideOut_ = -1;
  if (slide_ >= (int)slides_.size()) return;
  const Slide& sl = slides_[slide_];
  int lv = shotLevel(sl.scene);
  if (lv != 1000 && lv != levelIndex_) {
    loadLevel(lv, level_.seed ? level_.seed : 4242u);
    stalkers_.clear();
    grins_.clear();
    items_.clear();
    lines_.clear();
  }
  setupShot(sl);
}

void Game::setupShot(const Slide& sl) {
  customers_.clear();
  ray_ = Npc();
  tvMode_ = -1;
  bricked_ = ambulance_ = shotArms_ = shotFlash_ = false;
  flashOn_ = false;
  battery_ = 1.0f;
  hasFlashlight_ = true;
  carrying_ = false;
  shotLight_ = 1.0f;
  shotFlicker_ = 0;
  shotTint_ = {1, 1, 1};
  shotFov_ = 62.0f;
  shotDur_ = 10.0f;
  winMode_ = -1;
  auto cam = [&](vec3 from, vec3 to, vec3 lookA, vec3 lookB) {
    shotFrom_ = from; shotTo_ = to;
    shotYaw0_ = yawTo(from, lookA); shotYaw1_ = yawTo(to, lookB);
    shotPitch0_ = pitchTo(from, lookA); shotPitch1_ = pitchTo(to, lookB);
    shotYaw1_ = shotYaw0_ + std::remainder(shotYaw1_ - shotYaw0_, 2.0f * kPi);
  };
  auto actor = [&](vec3 p, float yaw, const vec4* look, int sit = 0, float hug = 0, float size = 1, bool lie = false) {
    Npc n;
    n.active = true; n.pos = p; n.yaw = yaw; n.sit = sit; n.hug = hug; n.size = size; n.lie = lie;
    for (int k = 0; k < 4; ++k) n.look4[k] = look[k];
    if (look == kRayLook || look == kMedic) n.outfit = 2;
    return n;
  };
  const Level::AptSpots& ap = level_.apt;
  auto C = [&](float x, float z, float y = 0) { return level_.tileCenter((int)x, (int)z, y) + vec3{(x - (int)x) * Level::kTile, 0, (z - (int)z) * Level::kTile}; };
  parkFamily_ = parkKids_ = false;
  const Level::ParkSpots& pk = level_.park;
  // park positions: G the gap (floor), K the middle of the court, T the tables
  vec3 G = level_.tileCenter(pk.crevX, pk.crevZ) + vec3{0, 0, -0.55f};
  vec3 K = level_.tileCenter((pk.x0 + pk.x1) / 2, pk.z0 + 2);
  vec3 T = level_.tileCenter((pk.x0 + pk.x1) / 2, pk.z1 - 2);
  vec3 up{0, 1, 0};
  switch (sl.scene) {
    case SH_PARK_GAP: {  // climbing out from behind the pad, at night, the court empty
      cam(G + vec3{0.15f, 0.12f, 0.05f}, G + vec3{0.1f, 1.05f, 0.55f}, K + up * 0.3f, K + up * 0.8f);
      shotLight_ = 0.16f;
      shotTint_ = {0.75f, 0.85f, 1.0f};
      shotDur_ = 11.0f;
      if (sl.param >= 1) {
        ray_ = actor(G + vec3{1.3f, 0, 0.9f}, kPi * 0.3f, kRayLook, 0, 0, 1, true);
        if (sl.param == 2) { ray_.lie = false; ray_.sit = 1; ray_.yaw = kPi; ray_.pos = G + vec3{1.0f, 0, 1.4f}; }
      }
    } break;
    case SH_PARK_NIGHT: {  // the court at night from the edge, the tables beyond
      cam(K + vec3{-2.0f, 0.75f, 2.6f}, K + vec3{-1.2f, 0.7f, 3.2f}, T + up * 0.8f, T + vec3{1.0f, 0.8f, 0});
      shotLight_ = 0.18f;
      shotTint_ = {0.75f, 0.85f, 1.0f};
    } break;
    case SH_PARK_REUNION: {
      vec3 p = level_.tileCenter((pk.x0 + pk.x1) / 2, pk.z0 + 6);
      if (sl.param == 1) {  // Ray and his daughter, on the edge of the court
        ray_ = actor(p, -kPi * 0.5f, kRayLook, 1, 0.8f);
        customers_.push_back(actor(p + vec3{0.55f, 0, 0.0f}, kPi * 0.5f, kDaughter, 2, 1.0f, 0.74f));
        cam(p + vec3{1.4f, 1.0f, 1.6f}, p + vec3{1.1f, 0.95f, 1.2f}, p + vec3{0.3f, 0.6f, 0}, p + vec3{0.25f, 0.6f, 0});
      } else {  // Mom on her knees in front of you, holding on; Dad behind her
        customers_.push_back(actor(p, 0.0f, kMomShot, 2, 1.0f));
        customers_.push_back(actor(p + vec3{0.9f, 0, 1.3f}, 0.3f, kDadShot));
        cam(p + vec3{0.25f, 1.0f, -1.5f}, p + vec3{0.1f, 1.0f, -1.2f}, p + vec3{0, 1.05f, 0}, p + vec3{0.05f, 1.1f, 0});
        shotFov_ = 55.0f;
      }
      shotLight_ = 0.85f;
      shotTint_ = {1.0f, 0.93f, 0.85f};
    } break;
    case SH_PARK_RAY: {  // Ray on the edge of the court, a paramedic kneeling
      vec3 rp = level_.tileCenter((pk.x0 + pk.x1) / 2 - 2, pk.z0 + 5);
      ray_ = actor(rp, -kPi * 0.5f, kRayLook, 1);
      customers_.push_back(actor(rp + vec3{0.85f, 0, 0.15f}, kPi * 0.5f, kMedic, 2));
      cam(rp + vec3{1.6f, 1.2f, 2.2f}, rp + vec3{1.2f, 1.1f, 1.7f}, rp + vec3{0.3f, 0.6f, 0}, rp + vec3{0.3f, 0.55f, 0});
      shotLight_ = 0.7f;
    } break;
    case SH_PARK_NOTDAD: {  // she ran to him, and then she stopped
      vec3 rp = level_.tileCenter((pk.x0 + pk.x1) / 2, pk.z0 + 6);
      ray_ = actor(rp, -kPi * 0.5f, kRayLook, 1);
      customers_.push_back(actor(rp + vec3{sl.param ? 1.9f : 1.0f, 0, 0.1f}, kPi * 0.5f, kDaughter, 0, 0, 0.74f));
      if (sl.param == 0) cam(rp + vec3{1.6f, 1.0f, 1.7f}, rp + vec3{1.3f, 0.95f, 1.3f}, rp + vec3{0.5f, 0.7f, 0}, rp + vec3{0.6f, 0.7f, 0});
      else {  // slowly round to his face. He's smiling.
        ray_.look = 0.5f;
        cam(rp + vec3{1.5f, 0.9f, 0.8f}, rp + vec3{0.9f, 0.8f, 0.6f}, rp + vec3{0, 0.95f, 0}, rp + vec3{0, 0.95f, 0});
        shotFov_ = 44.0f;
      }
      shotLight_ = 0.75f;
    } break;
    case SH_PARK_WALL: {  // the back wall, bricked up where the gap was
      cam(G + vec3{-1.8f, 1.3f, 4.2f}, G + vec3{-1.0f, 1.25f, 3.2f}, G + up * 0.6f, G + up * 0.7f);
      bricked_ = true;
      shotLight_ = 0.6f;
    } break;
    case SH_PARK_NEWKID: {  // a Saturday: a kid in a red shirt bouncing right where you were
      parkKids_ = true;
      parkFamily_ = true;
      Npc kid = actor(G + vec3{0.0f, 0.55f, 0.75f}, kPi, kYouKid, 0, 0, 0.6f);
      customers_.push_back(kid);
      cam(K + vec3{1.5f, 1.2f, 4.5f}, K + vec3{1.0f, 1.2f, 3.6f}, G + up * 1.0f, G + up * 0.9f);
      shotLight_ = 1.0f;
      shotFov_ = 50.0f;
    } break;
    case SH_PARK_SUIT: {  // after closing: something in a yellow suit by the back wall, staring at the court
      Npc n = actor(G + vec3{0.0f, 0, 0.9f}, kPi, kMomShot);
      n.outfit = 3;
      customers_.push_back(n);
      if (sl.param == 0) cam(T + vec3{0, 1.5f, 0}, T + vec3{-0.4f, 1.5f, -0.3f}, G + up * 1.5f, G + up * 1.5f);
      else cam(K + vec3{0.6f, 1.4f, 2.0f}, K + vec3{0.2f, 1.45f, 0.6f}, G + up * 1.6f, G + up * 1.6f);
      shotLight_ = 0.2f;
      shotTint_ = {0.75f, 0.85f, 1.0f};
      shotFov_ = sl.param ? 48.0f : 60.0f;
    } break;
    case SH_PARK_RAYWAVE: {  // at the tables, waving at you. Every Saturday.
      parkKids_ = true;
      Npc n = actor(T + vec3{1.0f, 0, 0.4f}, kPi, kRayWrong, 0, 0, 1.22f);
      n.outfit = 2;
      n.offer = 0.8f;  // a slow wave
      customers_.push_back(n);
      vec3 e = K + vec3{0.5f, 1.1f, 0.0f};
      cam(e, e + vec3{0.2f, 0, 0.35f}, T + vec3{1.0f, 2.0f, 0.4f}, T + vec3{1.0f, 2.1f, 0.4f});
      shotLight_ = 1.0f;
      shotFov_ = 52.0f;
    } break;
    case SH_APT_TV: {
      cam(ap.couchEye + vec3{0.2f, 0.05f, 0.1f}, ap.couchEye + vec3{-0.9f, -0.1f, 0}, ap.tvScreen, ap.tvScreen + vec3{0, -0.1f, 0});
      tvMode_ = 1;
      shotLight_ = 0.16f;
      shotFlash_ = true;
      winMode_ = 2;
    } break;
    case SH_TV_NEWS: {
      cam(ap.tvScreen + ap.tvNormal * 1.4f + vec3{0, 0.05f, 0.1f}, ap.tvScreen + ap.tvNormal * 0.7f, ap.tvScreen, ap.tvScreen);
      tvMode_ = 1;
      shotLight_ = 0.04f;
      shotFlash_ = true;
      winMode_ = 2;
    } break;
    case SH_APT_OFF: case SH_APT_WRONG: case SH_FREAK: case SH_SUNRISE: {
      vec3 c = ap.cornerEye;
      vec3 look = ap.tvScreen + vec3{0.6f, -0.3f, 0.4f};
      int angle = sl.scene == SH_FREAK ? sl.param : 0;
      if (angle == 1) cam(ap.couchEye + vec3{0.1f, 0.2f, 0}, ap.couchEye + vec3{0, 0.1f, 0}, ap.windowCenter, ap.windowCenter + vec3{0.5f, 0.3f, 0});
      else if (angle == 2) cam(ap.wallEye + vec3{0, 0, -0.6f}, ap.wallEye, ap.wallEye + vec3{0, 0.3f, 2.0f}, ap.wallEye + vec3{0.2f, 0.6f, 2.0f});
      else cam(c, c + vec3{-0.35f, -0.05f, -0.3f}, look, look + vec3{0, 0, -0.3f});
      tvMode_ = 0;
      winMode_ = sl.scene == SH_SUNRISE ? 3 : 2;
      shotLight_ = sl.scene == SH_SUNRISE ? 0.35f : 0.9f;
      if (sl.scene == SH_SUNRISE) shotTint_ = {1.0f, 0.72f, 0.48f};
      shotFlicker_ = sl.scene == SH_APT_WRONG ? 0.25f : (sl.scene == SH_FREAK ? 0.7f : (sl.scene == SH_APT_OFF ? 0.06f : 0.0f));
      if (sl.scene == SH_FREAK) { tvMode_ = 3; shotFov_ = 74.0f; }
    } break;
    case SH_TV_HALL: {
      cam(ap.tvScreen + ap.tvNormal * 1.2f + vec3{0, 0.1f, -0.2f}, ap.tvScreen + ap.tvNormal * 0.55f, ap.tvScreen, ap.tvScreen);
      tvMode_ = 2;
      shotLight_ = 0.6f;
      shotFlicker_ = 0.3f;
      winMode_ = 2;
    } break;
    case SH_WALL: {
      vec3 e = ap.wallEye;
      cam(e + vec3{0, 0, -0.25f}, e, e + vec3{0, -0.05f, 2.0f}, e + vec3{0, -0.15f, 2.0f});
      shotLight_ = 0.8f;
      shotFov_ = 58.0f;
      winMode_ = 2;
    } break;
    case SH_WINDOW: {
      vec3 w = ap.windowCenter;
      cam(w + vec3{0.4f, 0.1f, 2.2f}, w + vec3{0.15f, 0.0f, 1.1f}, w, w + vec3{0.1f, -0.05f, 0});
      winMode_ = 3;
      shotLight_ = 0.3f;
      shotTint_ = {1.0f, 0.72f, 0.48f};
    } break;
    case SH_HALL: case SH_HALL_RAY: case SH_HALL_CARRY: {
      vec3 s0 = level_.tileCenter(level_.startX, level_.startZ, 1.62f);
      vec3 f{-std::sin(checkpointYaw_), 0, -std::cos(checkpointYaw_)};
      vec3 end = s0 + f * (sl.scene == SH_HALL_RAY ? 1.2f : 6.0f);
      level_.collide(end, 0.3f);
      end.y = 1.62f;
      cam(s0, end, s0 + f * 10.0f, end + f * 10.0f);
      flashOn_ = true;
      if (sl.scene == SH_HALL_RAY) {
        vec3 rp = s0 + f * 4.6f;
        level_.collide(rp, 0.3f);
        rp.y = 0;
        ray_ = actor(rp, checkpointYaw_ + 1.2f, kRayLook, 0, 0, 1, true);
        cam(s0, end, rp + vec3{0, 0.3f, 0}, rp + vec3{0, 0.2f, 0});
      }
      if (sl.scene == SH_HALL_CARRY) { shotArms_ = true; shotFov_ = 70.0f; }
    } break;
    case SH_SURVEY: case SH_UNMASK: {  // at the bottom of the yellow slide
      vec3 s0 = level_.tileCenter(level_.startX, level_.startZ, 0.0f);
      vec3 f{-std::sin(checkpointYaw_), 0, -std::cos(checkpointYaw_)};
      vec3 sd{f.z, 0, -f.x};
      float back = std::atan2(f.x, f.z);  // facing you
      for (int k = 0; k < 3; ++k) {
        vec3 p = s0 + f * (2.6f + (k == 0 ? 0.0f : 0.7f)) + sd * ((k - 1) * 0.9f);
        Npc n = actor(p, back, kDanaNow);
        n.outfit = 3;
        if (k == 1 && sl.scene == SH_UNMASK) { n = actor(s0 + f * 1.5f, back, kDanaOld); n.outfit = 0; }
        if (k == 2 && sl.param == 1) n.offer = 0.6f;  // talking into a radio
        customers_.push_back(n);
      }
      if (sl.scene == SH_SURVEY) cam(s0 + vec3{0, 0.45f, 0}, s0 + vec3{0, 0.55f, 0} + f * 0.3f, s0 + f * 3.0f + vec3{0, 1.6f, 0}, s0 + f * 3.0f + vec3{0, 1.7f, 0});
      else {
        vec3 face = s0 + f * 1.5f + vec3{0, 1.68f, 0};
        cam(s0 + vec3{0, 1.2f, 0} - f * 0.2f, s0 + vec3{0, 1.45f, 0} + f * 0.35f, face, face);
        shotFov_ = 40.0f;
      }
      flashOn_ = sl.scene == SH_SURVEY;  // close on her face, the flashlight just blows her out
      shotLight_ = 1.0f;
    } break;
    default: break;
  }
  if (winMode_ >= 2) {
    if (texAptWin_) glDeleteTextures(1, &texAptWin_);
    texAptWin_ = makeTexture(texgen::viewWindow(512, 448, 5, winMode_), true, false);
  }
  if (!texNews_) {
    texNews_ = makeTexture(texgen::tvNews(256, 192), true, false);
    texHall_ = makeTexture(texgen::tvHall(256, 192), true, false);
    Image br = texgen::brick(256, 77);
    texBrick_ = makeTexture(br, true, true);
    texSign_ = makeTexture(texgen::paintText("DO NOT OPEN", 512, 128, 91), true, false);
  }
  updateLights(0);
}

void Game::endingLights() {
  if (levelIndex_ >= 0 || slide_ >= (int)slides_.size()) return;
  int sc = slides_[slide_].scene;
  for (size_t i = 0; i < level_.lights.size() && i < lightState_.size(); ++i) {
    const Light& L = level_.lights[i];
    float s = shotLight_;
    if (shotFlicker_ > 0 && hashf((int)i, (int)(time_ * 9.0f), 41) < shotFlicker_ * 0.35f) s *= 0.15f;
    lightState_[i] = s;
  }
  lightTint_ = shotTint_;
  if (ambulance_) {
    bool red = std::fmod(time_, 0.6f) < 0.3f;
    lightTint_ = red ? vec3{1.0f, 0.75f, 0.72f} : vec3{0.75f, 0.8f, 1.0f};
  }
  if (sc == SH_FREAK && std::fmod(time_, 0.5f) < 0.08f) lightTint_ = {1.0f, 0.25f, 0.2f};
}

void Game::endingCamera(vec3& pos, vec3& dir, float& fov, PostParams& pp) {
  if (slide_ >= (int)slides_.size()) { pp.fade = 1; return; }
  const Slide& sl = slides_[slide_];
  float t = clampf(slideT_ / shotDur_, 0, 1);
  t = t * t * (3.0f - 2.0f * t);
  pos = lerp(shotFrom_, shotTo_, t);
  float yaw = lerpf(shotYaw0_, shotYaw1_, t), pitch = lerpf(shotPitch0_, shotPitch1_, t);
  // A handheld camera: it breathes, and when you panic it shakes.
  float br = 0.006f + sl.fx * 0.02f;
  yaw += std::sin(time_ * 0.7f) * br + (hashf((int)(time_ * 24.0f), 51) - 0.5f) * sl.fx * sl.fx * 0.06f;
  pitch += std::sin(time_ * 1.1f) * br * 0.8f + (hashf((int)(time_ * 24.0f), 52) - 0.5f) * sl.fx * sl.fx * 0.05f;
  pos.y += std::sin(time_ * 1.3f) * 0.006f;
  if (sl.scene == SH_HALL_CARRY) pos.y += std::sin(slideT_ * 4.0f) * 0.025f;
  yaw_ = yaw;
  pitch_ = pitch;
  dir = {-std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
  fov = shotFov_;
  float fadeIn = (sl.autoAdvance > 0 && sl.autoAdvance < 1.2f) ? 1.0f : clampf(slideT_ / 1.0f, 0, 1);
  float fadeOut = slideOut_ >= 0 ? 1.0f - clampf(slideOut_ / 0.45f, 0, 1) : 1.0f;
  pp.fade = 1.0f - fadeIn * fadeOut;
  if (sl.scene == SH_BLACK || sl.scene == SH_CARD) pp.fade = 1.0f;
  pp.staticAmt = sl.fx * 0.45f + (sl.scene == SH_TV_HALL ? 0.1f : 0.0f);
  pp.fear = sl.fx;
  pp.exposure = sl.scene == SH_APT_TV || sl.scene == SH_TV_NEWS ? 1.6f : 1.0f;
  if (sl.scene == SH_HALL || sl.scene == SH_HALL_RAY || sl.scene == SH_HALL_CARRY) pp.exposure = 1.2f;
}

void Game::endingDraw(Shader& S, vec3 cam) {
  // Apartment, the park and the Backrooms.
  if (inPark() && bricked_ && texBrick_) {  // where the gap was: fresh brick, a sign
    const Level::ParkSpots& pk = level_.park;
    vec3 c = near(level_.tileCenter(pk.crevX, pk.crevZ), cam) + vec3{0, 0, -(Level::kTile * 0.5f - Level::kWallT * 0.5f - 0.02f)};
    auto quad = [&](vec3 cc, vec3 n, float w, float h) {
      vec3 r = cross(vec3{0, 1, 0}, n);
      S.set("uModel", basisM(r * w, vec3{0, h, 0}, n, cc));
      quad_.draw();
    };
    S.set("uSkinned", 0);
    glBindTexture(GL_TEXTURE_2D, texBrick_);
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    S.set("uEmissive", 0.35f);
    quad(c + vec3{0, 1.2f, 0}, {0, 0, 1}, 2.0f, 2.4f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glBindTexture(GL_TEXTURE_2D, texSign_);
    S.set("uMat", MAT_DECAL);
    S.set("uTint", vec3{0.55f, 0.04f, 0.03f});
    S.set("uFlipU", 0);
    quad(c + vec3{0, 1.5f, 0.01f}, {0, 0, 1}, 1.4f, 0.35f);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    S.set("uTint", vec3{1, 1, 1});
    S.set("uEmissive", 0.0f);
  }
  S.set("uMat", MAT_MODEL);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  for (const Npc& n : customers_) if (n.active) drawNpc(S, n, near(n.pos, cam));
  if (ray_.active) drawNpc(S, ray_, near(ray_.pos, cam));
  if (shotArms_) { int keep = rayState_; rayState_ = 2; rayDraw(S, cam); rayState_ = keep; }
  if (level_.theme.layout == Layout::Apartment) {
    const Level::AptSpots& ap = level_.apt;
    auto quad = [&](vec3 c, vec3 n, float w, float h) {
      vec3 r = cross(vec3{0, 1, 0}, n);
      S.set("uModel", basisM(r * w, vec3{0, h, 0}, n, c));
      quad_.draw();
    };
    S.set("uSkinned", 0);
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    glBindTexture(GL_TEXTURE_2D, texAptWin_);
    S.set("uEmissive", winMode_ == 3 ? 1.8f : 0.7f);
    quad(ap.windowCenter, {0, 0, 1}, 3.4f, 1.35f);
    vec3 sc = ap.tvScreen + ap.tvNormal * 0.012f;
    if (tvMode_ == 1 || tvMode_ == 2) {
      glBindTexture(GL_TEXTURE_2D, tvMode_ == 1 ? texNews_ : texHall_);
      S.set("uEmissive", 1.4f + 0.2f * hashf((int)(time_ * 12.0f), 61));
      quad(sc, ap.tvNormal, 0.5f, 0.37f);
    } else if (tvMode_ == 3) {
      S.set("uMat", MAT_GLITCH);
      S.set("uGlitch", 0.9f);
      glBindTexture(GL_TEXTURE_2D, texWhite_);
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      quad(sc, ap.tvNormal, 0.5f, 0.37f);
      glDisable(GL_BLEND);
    } else {
      glBindTexture(GL_TEXTURE_2D, texWhite_);
      S.set("uEmissive", 0.0f);
      quad(sc, ap.tvNormal, 0.5f, 0.37f);
    }
    S.set("uEmissive", 0.0f);
    S.set("uModel", mat4::identity());
  }
}

bool Game::endingFlash(vec3& pos, vec3& dir, float& intensity) {
  if (!shotFlash_ || level_.theme.layout != Layout::Apartment) return false;
  const Level::AptSpots& ap = level_.apt;
  pos = ap.tvScreen + ap.tvNormal * 0.15f;
  dir = normalize(ap.tvNormal + vec3{0, -0.12f, 0});
  intensity = 2.0f * (0.75f + 0.25f * hashf((int)(time_ * 7.0f), 62));
  return true;
}

void Game::endingInput(int dir, bool accept) {
  if (slide_ >= (int)slides_.size() || slideOut_ >= 0) return;
  const Slide& sl = slides_[slide_];
  if (sl.scene == SH_CHOICE && slide_ == (int)slides_.size() - 1) {
    if (dir) { choice_ = 1 - choice_; if (A_) A_->play(Sfx::MenuMove, 0.4f); }
    if (accept && slideT_ > 1.0f) {
      if (A_) A_->play(Sfx::MenuSelect, 0.5f);
      buildEndingB(choice_ == 0);
      slideOut_ = 0;
    }
    return;
  }
  if (!accept) return;
  float full = 0.8f + sl.text.size() * 0.03f;
  if (slideT_ < full) { slideT_ = full; return; }  // finish the typing first
  if (sl.autoAdvance > 0) return;
  slideOut_ = 0;
  if (A_) A_->play(Sfx::MenuMove, 0.3f);
}

void Game::updateEnding(float dt) {
  slideT_ += dt;
  if (slide_ < (int)slides_.size()) {
    const Slide& sl = slides_[slide_];
    if (sl.autoAdvance > 0 && slideT_ > sl.autoAdvance && slideOut_ < 0) {
      if (sl.autoAdvance < 1.2f) { ++slide_; startSlide(); if (A_ && slide_ < (int)slides_.size() && slides_[slide_].fx > 0.8f) A_->play(Sfx::Slam, 0.5f, 0, 0.8f); }
      else slideOut_ = 0;
    }
    if (slide_ < (int)slides_.size() && slides_[slide_].scene == SH_CARD && slideT_ > 9.0f && slideOut_ < 0) slideOut_ = 0;
    if (slideOut_ >= 0) {
      slideOut_ += dt;
      if (slideOut_ > 0.45f) { ++slide_; startSlide(); }
    }
  }
  if (slide_ >= (int)slides_.size()) {
    std::fprintf(stderr, "[br9] ending finished\n");
    saveEndingFlag(endingId_ ? endingId_ : 3);
    if (opt_.screenshot.empty()) std::remove((platform::dataDir() + "/save.ini").c_str());  // the story is over; no stale CONTINUE
    loadLevel(0, (level_.seed * 2654435761u) | 1u);
    screen_ = Screen::Title;
    menuSel_ = 0;
    saveProgress();
  }
}

void Game::endingAudio(Audio::Params& p) {
  p.muffle = 0;
  p.master = settings.volume * 0.85f;
  p.hum = 0; p.water = 0; p.chase = 0; p.muzak = 0; p.droneGain = p.houndGain = p.grinGain = 0; p.staticGain = 0;
  if (slide_ >= (int)slides_.size()) return;
  const Slide& sl = slides_[slide_];
  switch (sl.scene) {
    case SH_PARK_GAP: case SH_PARK_NIGHT: case SH_PARK_SUIT: p.hum = 0.35f; break;
    case SH_PARK_REUNION: case SH_PARK_RAY: case SH_PARK_WALL: case SH_PARK_NOTDAD: p.hum = 0.12f; break;
    case SH_PARK_NEWKID: case SH_PARK_RAYWAVE: p.muzak = 0.7f; p.hum = 0.1f; break;
    case SH_APT_OFF: p.hum = 0.35f; break;
    case SH_APT_WRONG: p.hum = 0.7f; break;
    case SH_TV_HALL: p.hum = 0.85f; p.staticGain = 0.3f; break;
    case SH_FREAK: p.hum = 1.2f; p.staticGain = 0.55f; break;
    case SH_HALL: case SH_HALL_RAY: case SH_HALL_CARRY: p.hum = 0.45f; break;
    default: break;
  }
  if (sl.fx > 0.05f) { p.heartRate = 80.0f + sl.fx * 85.0f; p.heartGain = sl.fx; p.breath = sl.fx * 0.8f; }
  if (sl.scene == SH_WALL && sl.param == 1) { p.heartRate = 110; p.heartGain = 0.6f; p.breath = 0.7f; }
}

void Game::drawEnding() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  if (slide_ >= (int)slides_.size()) { R_->rect(0, 0, W, H, 0, 0, 0, 1); return; }
  const Slide& sl = slides_[slide_];
  float bar = H * 0.11f;  // cinema bars
  R_->rect(0, 0, W, bar, 0, 0, 0, 1);
  R_->rect(0, H - bar, W, bar, 0, 0, 0, 1);
  if (sl.scene == SH_CARD) {
    R_->rect(0, 0, W, H, 0, 0, 0, 1);
    std::string t = "BELOW ROUTE 9";
    float ts = std::min(s * 4.0f, W * 0.8f / (13.0f * 8.0f));
    float a = clampf(slideT_ / 1.5f, 0, 1);
    R_->text(t, W * 0.5f - R_->textWidth(t, ts) * 0.5f, H * 0.36f, ts, 0.95f, 0.92f, 0.82f, a);
    float a2 = clampf((slideT_ - 1.5f) / 1.0f, 0, 1);
    R_->text(sl.text, W * 0.5f - R_->textWidth(sl.text, s) * 0.5f, H * 0.52f, s, 0.9f, 0.3f, 0.25f, a2);
    std::string th = "THANK YOU FOR WORKING THE NIGHT SHIFT";
    R_->text(th, W * 0.5f - R_->textWidth(th, s) * 0.5f, H * 0.62f, s, 0.6f, 0.6f, 0.55f, clampf((slideT_ - 3.0f) / 1.0f, 0, 1));
    return;
  }
  // Caption: typed out and wrapped in the lower bar (or huge and shaking when you panic).
  float boxW = W * 0.8f;
  float sc = s;
  int perLine = std::max(10, (int)(boxW / (8.0f * sc)));
  size_t shown = std::min(sl.text.size(), (size_t)std::max(0.0f, (slideT_ - 0.6f) / 0.03f));
  if (sl.autoAdvance > 0 && sl.autoAdvance < 1.5f) shown = sl.text.size();
  std::vector<std::string> rows;
  std::string cur, word;
  auto flushWord = [&]() {
    if (word.empty()) return;
    if ((int)(cur.size() + word.size() + (cur.empty() ? 0 : 1)) > perLine) { rows.push_back(cur); cur.clear(); }
    cur += (cur.empty() ? "" : " ") + word;
    word.clear();
  };
  for (size_t i = 0; i < shown; ++i) {
    if (sl.text[i] == ' ') flushWord();
    else word += sl.text[i];
  }
  flushWord();
  if (!cur.empty()) rows.push_back(cur);
  bool big = sl.fx > 0.8f;
  float rs = big ? sc * 2.2f : sc;
  float lh = 12.0f * rs;
  float y0 = big ? H * 0.45f : H - bar * 0.5f - rows.size() * lh * 0.5f + 2 * s;
  if (sl.scene == SH_BLACK && !big) y0 = H * 0.48f - rows.size() * lh * 0.5f;
  float fadeOut = slideOut_ >= 0 ? 1.0f - clampf(slideOut_ / 0.45f, 0, 1) : 1.0f;
  for (size_t i = 0; i < rows.size(); ++i) {
    float tw = R_->textWidth(rows[i], rs);
    float jx = big ? (hashf((int)(time_ * 40.0f), (int)i) - 0.5f) * 8.0f * s : 0.0f;
    R_->text(rows[i], W * 0.5f - tw * 0.5f + jx, y0 + i * lh, rs, big ? 1.0f : 0.93f, big ? 0.3f : 0.91f, big ? 0.25f : 0.84f, fadeOut);
  }
  if (sl.scene == SH_CHOICE && slide_ == (int)slides_.size() - 1 && slideT_ > 1.0f) {
    const char* opts[2] = {"GO BACK DOWN FOR HIM", "GO HOME"};
    for (int i = 0; i < 2; ++i) {
      std::string o = (choice_ == i ? "> " : "  ") + std::string(opts[i]) + (choice_ == i ? " <" : "  ");
      R_->text(o, W * 0.5f - R_->textWidth(o, s * 1.5f) * 0.5f, H * 0.42f + i * 22 * s, s * 1.5f, choice_ == i ? 1.0f : 0.6f,
               choice_ == i ? 0.85f : 0.6f, choice_ == i ? 0.4f : 0.55f, fadeOut);
    }
    return;
  }
  float full = 0.8f + sl.text.size() * 0.03f;
  if (sl.autoAdvance <= 0 && slideT_ > full && std::fmod(time_, 1.0f) < 0.6f && slideOut_ < 0) {
    std::string c = usingPad_ ? "[A]" : "[E]";
    R_->text(c, W - R_->textWidth(c, s) - 16 * s, H - bar * 0.5f - 4 * s, s, 0.7f, 0.7f, 0.65f);
  }
}
