// Meta progression: the reasons to go back down.
//   - Lost tapes: two hidden VHS tapes on every Backrooms level (16 total). They stay found.
//   - Survey badges: little goals with a pop-up, kept across every save.
//   - Endings tracker: which of the four ways out you've seen.
//   - KEEP FALLING: endless mode, unlocked after your first ending. Random levels forever,
//     each deeper one meaner than the last. One catch and the run is over.
//   - TODAY'S FALL: the same endless run for everyone on the same day (date seed).
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>

#include "audio.h"
#include "game.h"

namespace {

struct Badge { const char* name; const char* desc; };
const Badge kBadges[] = {
    {"CLOCKED IN", "Survive the night shift at the Quik-Stop"},
    {"NOCLIPPED", "Fall out of Level 0"},
    {"PAPER TRAIL", "Read every note on one level"},
    {"BE KIND, REWIND", "Find a lost tape"},
    {"ARCHIVIST", "Find all 16 lost tapes"},
    {"BROUGHT HIM HOME", "See an ending"},
    {"WENT BACK", "See an ending"},
    {"CLOCKED OUT", "See an ending"},
    {"UNIT 4", "See an ending"},
    {"SUITED UP", "Put on the yellow suit"},
    {"PARTY POOPER", "Live through a birthday party"},
    {"GHOST", "Escape a level without getting caught"},
    {"IN AND OUT", "Escape a level in under 3 minutes"},
    {"KEEP FALLING", "Reach depth 5 in KEEP FALLING"},
    {"BOTTOMLESS", "Reach depth 15 in KEEP FALLING"},
    {"EMPLOYEE OF THE MONTH", "Serve 8 customers in one shift"},
};
constexpr int kBadgeN = (int)(sizeof(kBadges) / sizeof(kBadges[0]));

struct Ending { const char* name; const char* hint; };
const Ending kEndings[4] = {
    {"BROUGHT HIM HOME", "Somebody is still down there. Carry him."},
    {"WENT BACK", "At the end, trust the one that says EXIT."},
    {"CLOCKED OUT", "At the end, choose the colour of a tape."},
    {"UNIT 4", "At the end, choose the colour of a suit."},
};

const char* kLevelNames[8] = {"LEVEL 0", "LEVEL 1", "LEVEL 2", "LEVEL 37", "LEVEL 6", "LEVEL 188", "LEVEL FUN =)", "LEVEL !"};

struct Tape { const char* title; const char* body; };
// Camcorder transcripts. Two per level, in level order.
const Tape kTapes[16] = {
    {"ORIENTATION",
     "UNIT 1: Threshold survey, day one. Carpet's\n"
     "damp. Smells like a basement that never got\n"
     "to be a basement.\n\n"
     "UNIT 4: The hum is sixty hertz.\n"
     "UNIT 1: So there's power. Somebody's paying\n"
     "the electric bill. [laughter]\n\n"
     "[TAPE SKIPS]\n\n"
     "UNIT 1: Nine hours walking. The camp is where\n"
     "we left it. We left it four hours ago.\n"
     "The other way."},
    {"THE TALL ONE",
     "[FRAME BY FRAME, 00:41]\n\n"
     "Something in the doorway. Taller than the\n"
     "doorway. It doesn't duck.\n\n"
     "THEO: Count the frames where it isn't there.\n\n"
     "[THERE ARE NONE]\n\n"
     "THEO: It was there when we set up camp.\n"
     "It was there before the camp.\n"
     "I think the camp is set up around it."},
    {"QUIK-STOP CAM 2",
     "[03:14:07  CAM 2  REGISTER]\n\n"
     "RAY: Dana, it's your old man. If you get this,\n"
     "the night guy found it first. Tell him the\n"
     "cooler door. Never open the cooler after 3.\n\n"
     "[THE CLERK ON THE MONITOR TURNS AROUND]\n"
     "[IT'S YOU]\n\n"
     "[THE DATE STAMP SAYS 1996]\n"
     "[YOU STARTED THIS JOB LAST WEEK]"},
    {"WAREHOUSE INVENTORY",
     "UNIT 2: Crates. All stamped QUIK-STOP.\n"
     "All the same order number.\n\n"
     "  31 CASES ALMOND WATER\n"
     "  1 HAZMAT SUIT, YELLOW, SIZE L\n\n"
     "UNIT 2: The name tag on the suit says--\n"
     "[STATIC]\n"
     "UNIT 2: It's ours. It's the one Unit 4 is\n"
     "wearing. Unit 4 is standing right behind\n"
     "me. Unit 4, why are there two of--\n"
     "[TAPE ENDS]"},
    {"PRESSURE",
     "The pipes knock in threes. Ray says that's\n"
     "the boiler.\n\n"
     "There's no boiler.\n\n"
     "Theo knocked back once. Three times.\n"
     "Everything went quiet. Every pipe on the\n"
     "level, quiet.\n\n"
     "Then something on the other side knocked\n"
     "back four."},
    {"HOME VIDEO - 1989",
     "[A BIRTHDAY PARTY. DANA TURNS SEVEN.]\n"
     "[RAY HOLDS THE CAMERA. EVERYONE SINGS.]\n\n"
     "[BEHIND THE CAKE, IN THE HALLWAY, SOMEONE IN\n"
     " A YELLOW SUIT IS WAVING.]\n"
     "[NOBODY AT THE PARTY LOOKS AT IT.]\n\n"
     "RAY: Who invited the bee?\n"
     "DANA: He comes every year, Daddy.\n"
     "RAY: ...Every year?\n"
     "DANA: He says next year it's your turn."},
    {"UNIT 3",
     "Unit 3 went for a swim.\n\n"
     "We told her the water's warm because\n"
     "something is keeping it warm. She said\n"
     "that's how pools work.\n\n"
     "Her suit is floating in the shallow end.\n"
     "She isn't in it.\n\n"
     "The suit is still waving."},
    {"SUNLIGHT",
     "There's sun in here. Real sun.\n\n"
     "Theo clocked the shadows: they haven't moved\n"
     "in eleven hours. Either the sun is painted\n"
     "on, or we are.\n\n"
     "Something on the spiral stairs was counting\n"
     "us as we went up. It got to five.\n\n"
     "There are four of us."},
    {"[NO VIDEO]",
     "[BLACK SCREEN. AUDIO ONLY.]\n\n"
     "[Breathing. Two people. Then one. Then two\n"
     " again, but the second is wrong: it breathes\n"
     " in when Theo breathes out.]\n\n"
     "THEO: Keep the light on me.\n"
     "THEO: Keep the light on me.\n"
     "THEO: Why is the light on YOU? You don't have\n"
     "a fla--\n"
     "[TAPE ENDS]"},
    {"BATTERY LOG",
     "BATTERIES LEFT: 3\n"
     "BATTERIES LEFT: 2\n"
     "BATTERIES LEFT: 2\n"
     "BATTERIES LEFT: 4\n\n"
     "Why do we have more.\n"
     "Who is leaving us batteries.\n\n"
     "Somebody wants us to keep walking.\n"
     "Somebody wants to keep watching."},
    {"ROOM 1996",
     "Every room in this hotel is number 1996.\n"
     "The phones ring at 3:14.\n\n"
     "I picked one up. It was Dana. Grown up.\n\n"
     "DANA: Dad? Dad, the night guy came home.\n"
     "He doesn't remember the store. He keeps\n"
     "asking what level this is.\n\n"
     "DANA: Dad, he won't take the suit off."},
    {"THE BALCONY",
     "There's a woman on the far balcony.\n"
     "She only moves when the camera blinks.\n\n"
     "I've been holding the record button for six\n"
     "minutes. My eyes hurt. My eyes hurt.\n\n"
     "She's closer. I didn't blink. I DIDN'T--\n\n"
     "[CUT]"},
    {"=)",
     "PARTY PLANNING COMMITTEE - MINUTES\n\n"
     "  ITEM 1: GUEST LIST\n"
     "  ITEM 2: YOU\n"
     "  ITEM 3: YOU ARE INVITED\n"
     "  ITEM 4: YOU WERE ALWAYS INVITED\n"
     "  ITEM 5: HIDE UNDER THE TABLE\n"
     "          IT'S MORE FUN IF YOU HIDE =)\n\n"
     "  MOTION CARRIED. EVERYONE SMILED."},
    {"HAPPY BIRTHDAY",
     "Theo's birthday is tomorrow. He didn't tell\n"
     "anyone. They found out anyway.\n\n"
     "We heard singing three rooms away.\n\n"
     "They had a cake with his name on it.\n"
     "They had a cake with all our names on it.\n\n"
     "They had a cake with yours."},
    {"UNIT 4 - FINAL",
     "UNIT 4: I'm the last one.\n\n"
     "The exit's right there. Blue tape on the wall.\n"
     "If I go through, I come out at the Quik-Stop,\n"
     "1996, at the start of somebody's shift.\n\n"
     "I'll take the job. I'll keep the suit.\n\n"
     "Somebody has to be on the clock."},
    {"FOR THE NIGHT GUY",
     "If you found all of these, you've been\n"
     "walking a long time.\n\n"
     "Ray isn't your dad. Dana isn't your daughter.\n"
     "The suit is yours. It was always going to be\n"
     "yours.\n\n"
     "Look at the name tag. Please.\n"
     "Look at the name tag.\n\n"
     "                                       - U4"},
};

int dayNumber() { return (int)(std::time(nullptr) / 86400); }

uint32_t mix(uint32_t x) {
  x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16;
  return x;
}

}  // namespace

int Game::tapeCount() { return 16; }
int Game::badgeCount() { return kBadgeN; }

void Game::loadProfile() {
  platform::KeyValueFile f;
  if (f.load(platform::dataDir() + "/profile.ini")) {
    profile_.tapes = (uint32_t)f.geti("tapes", 0);
    profile_.badges = (uint32_t)f.geti("badges", 0);
    profile_.endings = f.geti("endings", 0);
    profile_.bestDepth = f.geti("best_depth", 0);
    profile_.runs = f.geti("runs", 0);
    profile_.dailyDay = f.geti("daily_day", 0);
    profile_.dailyBest = f.geti("daily_best", 0);
    profile_.falls = f.geti("falls", 0);
  }
  // Older installs: you've already seen an ending, so it counts.
  if (endingSeen_ >= 1 && endingSeen_ <= 4) profile_.endings |= 1 << (endingSeen_ - 1);
  for (int i = 0; i < 4; ++i)
    if (profile_.endings & (1 << i)) profile_.badges |= 1u << (5 + i);
  if (profile_.dailyDay != dayNumber()) { profile_.dailyDay = dayNumber(); profile_.dailyBest = 0; }
}

void Game::saveProfile() {
  if (!opt_.screenshot.empty()) return;
  platform::KeyValueFile f;
  f.seti("tapes", (int)profile_.tapes);
  f.seti("badges", (int)profile_.badges);
  f.seti("endings", profile_.endings);
  f.seti("best_depth", profile_.bestDepth);
  f.seti("runs", profile_.runs);
  f.seti("daily_day", profile_.dailyDay);
  f.seti("daily_best", profile_.dailyBest);
  f.seti("falls", profile_.falls);
  f.save(platform::dataDir() + "/profile.ini");
}

void Game::unlockBadge(int id) {
  if (id < 0 || id >= kBadgeN || (profile_.badges >> id) & 1u) return;
  profile_.badges |= 1u << id;
  badgeQueue_.push_back(id);
  std::fprintf(stderr, "[br9] badge: %s\n", kBadges[id].name);
  saveProfile();
}

void Game::metaEnding(int id) {
  if (id < 1 || id > 4) return;
  profile_.endings |= 1 << (id - 1);
  unlockBadge(4 + id);
  saveProfile();
}

void Game::metaEscaped(bool fromStore) {
  ++profile_.falls;
  if (fromStore) unlockBadge(0);
  else {
    if (levelIndex_ == 0) unlockBadge(1);
    if (deaths_ == levelDeaths_) unlockBadge(11);
    if (prevTime_ < 180.0f) unlockBadge(12);
  }
  saveProfile();
}

void Game::metaTapeFound(int id) {
  profile_.tapes |= 1u << id;
  int n = __builtin_popcount(profile_.tapes & 0xFFFFu);
  char buf[64];
  std::snprintf(buf, sizeof buf, "LOST TAPE %d/16 FOUND", n);
  toast_ = buf;
  toastTime_ = 3.0f;
  readingTape_ = id;
  screen_ = Screen::Reading;
  screenTime_ = 0;
  setMouseCapture(false);
  if (A_) { A_->play(Sfx::Click, 0.8f); A_->play(Sfx::Beep, 0.35f, 0, 0.35f); }
  unlockBadge(3);
  if (n >= 16) unlockBadge(4);
  saveProfile();
}

// ------------------------------------------------------------------ endless

void Game::startEndless(bool daily) {
  endless_ = true;
  daily_ = daily;
  lastDaily_ = daily;
  depth_ = 1;
  runOverShow_ = false;
  endlessSeed_ = daily ? (mix((uint32_t)dayNumber() * 2654435761u + 77u) | 1u) : (((uint32_t)std::time(nullptr) * 2246822519u) ^ (uint32_t)(time_ * 1000.0f)) | 1u;
  ++profile_.runs;
  saveProfile();
  startNewGame();
  toast_ = daily ? "TODAY'S FALL - DEPTH 1" : "KEEP FALLING - DEPTH 1";
  toastTime_ = 3.5f;
}

void Game::endlessTheme(Theme& th) const {
  // Deeper is meaner: hunts come sooner and more often, fewer supplies, more company.
  int d = std::max(0, depth_ - 1);
  th.firstSpawn *= std::max(0.3f, 1.0f - 0.07f * d);
  if (th.huntEvery > 0) th.huntEvery *= std::max(0.35f, 1.0f - 0.06f * d);
  th.batteries = std::max(3, th.batteries - d / 2);
  th.waters = std::max(2, th.waters - d / 3);
  th.darkZones += d;
  if (th.tenants > 0 || d >= 6) th.tenants += d / 5;
  if (th.hounds > 0 || d >= 9) th.hounds += d / 7;
  th.grins += d / 3;
  th.stilts = std::min(th.stilts + d / 6, 4);
}

void Game::endlessNext(uint32_t nextSeed) {
  ++depth_;
  if (depth_ > profile_.bestDepth) profile_.bestDepth = depth_;
  if (daily_ && depth_ > profile_.dailyBest) profile_.dailyBest = depth_;
  if (depth_ >= 5) unlockBadge(13);
  if (depth_ >= 15) unlockBadge(14);
  saveProfile();
  // A different level every time; the date seed makes TODAY'S FALL the same for everyone.
  int nl = (int)(mix(nextSeed ^ (uint32_t)depth_ * 977u) % (uint32_t)(kLevelCount - 1));
  if (levelIndex_ >= 0 && nl >= levelIndex_) ++nl;
  loadLevel(nl, nextSeed);
  battery_ = std::max(battery_, 0.6f);
  flashOn_ = true;
  fear_ = 0;
  exposure_ = 1.0f;
  char buf[48];
  std::snprintf(buf, sizeof buf, "DEPTH %d", depth_);
  toast_ = buf;
  toastTime_ = 3.0f;
  std::fprintf(stderr, "[br9] endless: depth %d -> level %d\n", depth_, nl);
  startPlunge();
}

void Game::endlessOver() {
  runOverDepth_ = depth_;
  runOverRecord_ = depth_ >= profile_.bestDepth && depth_ > 1;
  if (depth_ > profile_.bestDepth) profile_.bestDepth = depth_;
  if (daily_ && depth_ > profile_.dailyBest) profile_.dailyBest = depth_;
  saveProfile();
  std::fprintf(stderr, "[br9] endless run over at depth %d (best %d)\n", depth_, profile_.bestDepth);
  endless_ = false;
  runOverShow_ = true;
  hiding_ = -1;
  screen_ = Screen::Title;
  screenTime_ = 0;
  menuSel_ = 0;
  setMouseCapture(false);
}

// ------------------------------------------------------------------ menus

void Game::buildArchiveMenu() {
  int sel = ((archiveSel_ % 16) + 16) % 16;
  bool found = (profile_.tapes >> sel) & 1u;
  char buf[96];
  std::snprintf(buf, sizeof buf, "< TAPE %02d/16 >  %s", sel + 1, found ? kTapes[sel].title : (std::string("NOT FOUND - ") + kLevelNames[sel / 2]).c_str());
  menu_.push_back({buf, [this](int d) {
    if (d < 0) archiveSel_ = (archiveSel_ + 15) % 16;
    else if (d > 0) archiveSel_ = (archiveSel_ + 1) % 16;
    else if ((profile_.tapes >> archiveSel_) & 1u) { archiveView_ = 1; archiveT_ = 0; if (A_) A_->play(Sfx::Click, 0.7f); }
  }});
  std::snprintf(buf, sizeof buf, "BADGES  %d/%d", __builtin_popcount(profile_.badges), kBadgeN);
  menu_.push_back({buf, [this](int d) { if (d == 0) { archiveView_ = 2; archiveT_ = 0; } }});
  std::snprintf(buf, sizeof buf, "ENDINGS  %d/4", __builtin_popcount((unsigned)profile_.endings & 15u));
  menu_.push_back({buf, [this](int d) { if (d == 0) { archiveView_ = 3; archiveT_ = 0; } }});
  menu_.push_back({"BACK", [this](int d) { if (d == 0) { archiveOpen_ = false; menuSel_ = 0; } }});
}

bool Game::archiveInput(bool any) {
  if (!archiveView_) return false;
  if (any) { archiveView_ = 0; if (A_) A_->play(Sfx::MenuMove, 0.4f); }
  return true;
}

// ------------------------------------------------------------------ drawing

void Game::drawTape(int id, float t, bool archive) {
  if (id < 0 || id >= 16) return;
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  R_->rect(0, 0, W, H, 0, 0, 0, archive ? 0.85f : 0.78f);
  float pw = 50 * 8.0f * s, ph = 17 * 12.0f * s;
  if (pw > W * 0.95f) { s = std::max(1.0f, s - 1); pw = 50 * 8.0f * s; ph = 17 * 12.0f * s; }
  float px = (W - pw) * 0.5f, py = (H - ph) * 0.5f;
  // a little CRT: dark blue VCR screen, scanlines, on-screen display
  R_->rect(px - 4 * s, py - 4 * s, pw + 8 * s, ph + 8 * s, 0.1f, 0.1f, 0.1f, 1.0f);
  R_->rect(px, py, pw, ph, 0.02f, 0.03f, 0.09f, 1.0f);
  for (float y = py; y < py + ph; y += 3 * s) R_->rect(px, y, pw, std::max(1.0f, s * 0.6f), 0, 0, 0, 0.35f);
  float roll = std::fmod(time_ * 40.0f, ph);
  R_->rect(px, py + roll, pw, 6 * s, 0.6f, 0.7f, 1.0f, 0.04f);
  char hdr[96];
  std::snprintf(hdr, sizeof hdr, "TAPE %02d - %s", id + 1, kTapes[id].title);
  vt(hdr, px + 12 * s, py + 10 * s, s, 0.55f, 0.75f, 1.0f);
  bool blink = std::fmod(time_, 1.0f) < 0.6f;
  std::string play = blink ? "PLAY >" : "PLAY";
  vt(play, px + pw - vw("PLAY >", s) - 12 * s, py + 10 * s, s, 0.55f, 0.75f, 1.0f);
  int secs = (int)t;
  char ctr[32];
  std::snprintf(ctr, sizeof ctr, "0:%02d:%02d", (secs / 60) % 60, secs % 60);
  vt(ctr, px + pw - vw(ctr, s) - 12 * s, py + ph - 18 * s, s, 0.55f, 0.75f, 1.0f, 0.8f);
  vt(kLevelNames[id / 2], px + 12 * s, py + ph - 18 * s, s, 0.55f, 0.75f, 1.0f, 0.6f);
  std::string body = kTapes[id].body;
  size_t n = std::min(body.size(), (size_t)std::max(0.0f, (t - 0.4f) * 55.0f));
  vt(body.substr(0, n), px + 12 * s, py + 30 * s, s, 0.86f, 0.88f, 0.92f);
  std::string f = archive ? (usingPad_ ? "[A] BACK" : "[ENTER] BACK") : (usingPad_ ? "[A] STOP" : "[E] STOP");
  vt(f, W * 0.5f - vw(f, s) * 0.5f, py + ph + 14 * s, s, 0.9f, 0.9f, 0.85f, 0.8f);
}

void Game::drawArchiveView() {
  if (archiveView_ == 1) { drawTape(archiveSel_, archiveT_, true); return; }
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  R_->rect(0, 0, W, H, 0.02f, 0.02f, 0.015f, 0.95f);
  if (archiveView_ == 2) {
    int cols = 62;
    float pw = cols * 8.0f * s;
    if (pw > W * 0.95f) { s = std::max(1.0f, s - 1); pw = cols * 8.0f * s; }
    float lh = 13.0f * s, ph = (kBadgeN + 4) * lh;
    float px = (W - pw) * 0.5f, py = (H - ph) * 0.5f;
    char buf[96];
    std::snprintf(buf, sizeof buf, "SURVEY BADGES  %d/%d", __builtin_popcount(profile_.badges), kBadgeN);
    vt(buf, W * 0.5f - vw(buf, s * 1.5f) * 0.5f, py, s * 1.5f, 0.95f, 0.9f, 0.6f);
    for (int i = 0; i < kBadgeN; ++i) {
      bool got = (profile_.badges >> i) & 1u;
      bool secret = i >= 5 && i <= 8 && !got;
      float y = py + (i + 2) * lh;
      std::string mark = got ? "[X] " : "[ ] ";
      std::string name = secret ? "???" : kBadges[i].name;
      vt(mark + name, px, y, s, got ? 1.0f : 0.5f, got ? 0.85f : 0.5f, got ? 0.35f : 0.48f);
      vt(kBadges[i].desc, px + 27 * 8.0f * s, y, s, got ? 0.85f : 0.45f, got ? 0.82f : 0.45f, got ? 0.75f : 0.42f);
    }
  } else if (archiveView_ == 3) {
    float pw = 56 * 8.0f * s;
    if (pw > W * 0.95f) { s = std::max(1.0f, s - 1); pw = 56 * 8.0f * s; }
    float lh = 14.0f * s;
    float px = (W - pw) * 0.5f, py = H * 0.3f;
    char buf[64];
    std::snprintf(buf, sizeof buf, "ENDINGS  %d/4", __builtin_popcount((unsigned)profile_.endings & 15u));
    vt(buf, W * 0.5f - vw(buf, s * 1.5f) * 0.5f, py, s * 1.5f, 0.95f, 0.9f, 0.6f);
    for (int i = 0; i < 4; ++i) {
      bool got = profile_.endings & (1 << i);
      float y = py + (2 + i * 2.2f) * lh;
      std::string name = std::string(got ? "[X] " : "[ ] ") + (got ? kEndings[i].name : "???");
      vt(name, px, y, s * 1.2f, got ? 1.0f : 0.55f, got ? 0.85f : 0.55f, got ? 0.35f : 0.5f);
      vt(got ? "SEEN" : kEndings[i].hint, px + 24 * s, y + lh * 1.05f, s, 0.6f, 0.58f, 0.52f);
    }
  }
  std::string f = usingPad_ ? "[A] BACK" : "[ENTER] BACK";
  vt(f, W * 0.5f - vw(f, s) * 0.5f, H - 40 * s, s, 0.9f, 0.9f, 0.85f, 0.8f);
}

void Game::drawBadgePopup() {
  if (badgeQueue_.empty()) return;
  int id = badgeQueue_.front();
  const float T = 4.2f;
  float s = ui(), W = (float)R_->winW;
  float in = clampf(badgeT_ / 0.35f, 0, 1), out = clampf((T - badgeT_) / 0.4f, 0, 1);
  float k = std::min(in, out);
  float bw = std::max(vw(kBadges[id].desc, s), vw(kBadges[id].name, s * 1.5f)) + 64 * s;
  float bh = 46 * s;
  float bx = W - (bw + 14 * s) * (1.0f - (1.0f - k) * (1.0f - k)), by = 42 * s;
  R_->rect(bx + 3 * s, by + 3 * s, bw, bh, 0, 0, 0, 0.5f * k);
  R_->rect(bx, by, bw, bh, 0.07f, 0.06f, 0.04f, 0.92f * k);
  R_->rect(bx, by, 4 * s, bh, 1.0f, 0.82f, 0.2f, k);
  // a little yellow survey badge
  float cx = bx + 26 * s, cy = by + bh * 0.5f;
  R_->rect(cx - 12 * s, cy - 12 * s, 24 * s, 24 * s, 1.0f, 0.82f, 0.2f, k);
  R_->rect(cx - 9 * s, cy - 9 * s, 18 * s, 18 * s, 0.12f, 0.1f, 0.05f, k);
  vt("4", cx - 4 * s, cy - 4 * s, s, 1.0f, 0.82f, 0.2f, k);
  vt("BADGE UNLOCKED", bx + 48 * s, by + 7 * s, s, 1.0f, 0.82f, 0.3f, k * 0.85f);
  vt(kBadges[id].name, bx + 48 * s, by + 18 * s, s * 1.5f, 0.97f, 0.94f, 0.85f, k);
  vt(kBadges[id].desc, bx + 48 * s, by + 33 * s, s, 0.7f, 0.68f, 0.6f, k);
}

void Game::drawRunOver() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  float a = clampf(screenTime_ / 0.6f, 0, 1);
  auto center = [&](const std::string& str, float y, float sc, float r, float g, float b, float al) {
    vt(str, W * 0.5f - vw(str, sc) * 0.5f, y, sc, r, g, b, al);
  };
  R_->rect(0, H * 0.08f, W, H * 0.34f, 0, 0, 0, 0.55f * a);
  center(lastDaily_ ? "TODAY'S FALL IS OVER" : "YOU STOPPED FALLING", H * 0.11f, s * 1.5f, 0.9f, 0.35f, 0.3f, a);
  char buf[64];
  std::snprintf(buf, sizeof buf, "DEPTH %d", runOverDepth_);
  float big = std::min(s * 5.0f, W * 0.8f / (8.0f * 9.0f));
  center(buf, H * 0.17f, big, 0.95f, 0.92f, 0.82f, a);
  if (runOverRecord_ && std::fmod(time_, 0.8f) < 0.55f) center("NEW RECORD", H * 0.17f + 9 * big, s * 1.5f, 1.0f, 0.82f, 0.25f, a);
  std::snprintf(buf, sizeof buf, "BEST %d    TODAY %d    RUNS %d", profile_.bestDepth, profile_.dailyBest, profile_.runs);
  center(buf, H * 0.33f, s, 0.7f, 0.68f, 0.6f, a);
  // dangle the next goal
  std::string next;
  if (runOverDepth_ < 5 && !((profile_.badges >> 13) & 1u)) next = "NEXT BADGE: REACH DEPTH 5";
  else if (!((profile_.badges >> 14) & 1u)) next = "NEXT BADGE: REACH DEPTH 15";
  else { std::snprintf(buf, sizeof buf, "BEAT DEPTH %d", profile_.bestDepth); next = buf; }
  center(next, H * 0.37f, s, 0.85f, 0.75f, 0.45f, a * (0.6f + 0.4f * std::sin(time_ * 3.0f)));
}

void Game::drawTitleStats() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  char buf[128];
  std::snprintf(buf, sizeof buf, "ENDINGS %d/4    TAPES %d/16    BADGES %d/%d    DEEPEST %d", __builtin_popcount((unsigned)profile_.endings & 15u),
                __builtin_popcount(profile_.tapes & 0xFFFFu), __builtin_popcount(profile_.badges), kBadgeN, profile_.bestDepth);
  float x0 = std::max(28.0f * s, W * 0.075f);
  vt(buf, x0, H - 30.0f * s, s, 0.85f, 0.75f, 0.45f, 0.8f);
}

void Game::drawEndlessHUD() {
  if (!endless_) return;
  float s = ui(), W = (float)R_->winW;
  char buf[64];
  std::snprintf(buf, sizeof buf, "%s  DEPTH %d   BEST %d", daily_ ? "TODAY'S FALL" : "KEEP FALLING", depth_,
                std::max(daily_ ? profile_.dailyBest : profile_.bestDepth, depth_));
  vt(buf, W * 0.5f - vw(buf, s) * 0.5f, 12 * s, s, 0.95f, 0.85f, 0.45f, 0.85f);
}
