// A Backrooms level: an endless (toroidal) tile grid with thin walls on tile
// edges, pillars, pools, ceiling lights with an indexed lightmap, props, painted
// clues, collision, line of sight and pathfinding. Walking off one side brings
// you back on the other, and the renderer draws each chunk at its nearest copy,
// so there is never an edge.
#pragma once
#include "mathx.h"
#include "theme.h"
#include <cstdint>
#include <vector>

struct Light {
  vec3 pos;
  int id = 0;
  float intensity = 1;
  int kind = 0;  // 0 steady, 1 flickering, 2 dead
  float phase = 0;
};

struct AABB2 { float x0, z0, x1, z1; };

struct Mesh {
  // Vertex layout: pos(3) normal(3) uv(2) aux(2: ambient occlusion, light id / palette)
  // Skinned meshes append bones(4: index0, index1, weight0, weight1) -> stride 14.
  int stride = 10;
  std::vector<float> v;
  std::vector<uint32_t> idx;
  void quad(vec3 a, vec3 b, vec3 c, vec3 d, vec3 n, vec2 ua, vec2 ub, vec2 uc, vec2 ud,
            float aoA, float aoB, float aoC, float aoD, float lightId = -1);
};

enum Dir { PX = 0, NX = 1, PZ = 2, NZ = 3 };

// Furniture and clutter. `type` matches PropId in creatures.h.
struct PropInstance {
  int type = 0;
  vec3 pos;
  float yaw = 0, roll = 0;
  float halfX = 0, halfZ = 0;  // collision half extents (0 = walk-through)
  int variant = 0;             // colour scheme (shelf stock, etc.)
  int anomaly = 0;             // 0 normal; 1 in a wall, 2 sinking, 3 falling through, 4 floating
  float phase = 0;
};

// Named places in the Quik-Stop (store level only).
struct StoreSpots {
  vec3 door, counterCustomer, counterClerk, registerPos, phone, basementDoor, basementArrive, backFromBasement;
  vec3 breaker, flashlight, boxPickup, exitSign;
  float clerkYaw = 0, basementYaw = 0;
  std::vector<vec3> browse;
  std::vector<float> browseYaw;
  std::vector<vec3> shelfSlots;   // restock targets (centre of an empty facing)
  std::vector<vec3> spills;
  std::vector<int> emergencyLights;
  std::vector<vec3> windows;      // centre of each front window (door is index 0)
};

// Spray paint on a wall face.
enum DecalKind { DECAL_ARROW = 0, DECAL_EXIT, DECAL_NOT_THIS_WAY, DECAL_X, DECAL_BLOOD_DRAG, DECAL_BLOOD_SPLAT, DECAL_BLOOD_POOL, DECAL_HANDPRINT,
                 DECAL_LETTER, DECAL_STRIPE = DECAL_LETTER + 8, DECAL_MURAL, DECAL_FOOTPRINTS, DECAL_TAPE, DECAL_ENDNEAR, DECAL_FORSALE, DECAL_STAIN, DECAL_GRAFFITI };  // letters A-H stencilled on garage piers
inline bool isBloodDecal(int k) { return k >= DECAL_BLOOD_DRAG && k <= DECAL_HANDPRINT; }
struct Decal {
  vec3 pos, n;      // centre on the surface, surface normal
  vec3 right{0, 0, 0};  // decal +u direction (zero = derive from the wall normal)
  float w = 1, h = 0.5f;
  int kind = 0;     // DecalKind, graffiti = DECAL_GRAFFITI + phrase index
  bool flip = false;
  float tilt = 0;
  vec3 color{-1, -1, -1};  // custom paint (the choice walls); negative = theme paint
};

struct ChunkMeshes {
  Mesh walls, floor, ceiling, panels, trim, water;
  Mesh walls2, floor2, ceiling2;  // zone-1/2 surfaces (store back room, basement)
  vec3 center;
};

class Level {
 public:
  static constexpr float kTile = 2.0f;
  static constexpr float kWallT = 0.16f;
  static constexpr float kPillar = 0.36f;
  static constexpr float kPoolDepth = 0.5f;
  static constexpr int kLmPerMeter = 4;
  static constexpr int kChunk = 8;

  Theme theme;
  float wallH = 2.9f;
  int W = 0, H = 0;
  float periodX = 0, periodZ = 0;  // world size; it wraps around
  uint32_t seed = 0;
  std::vector<uint8_t> eWall, sWall, pillar, pool;
  std::vector<uint8_t> sky;          // Poolrooms: skylight wells in the ceiling
  std::vector<vec3> stairwells;      // spiral stairs up through a round hole (centre, at a tile corner)
  std::vector<vec3> tunnels, tunnelN;  // round tunnel mouths at the waterline
  std::vector<vec3> drains;
  std::vector<vec3> bunting, buntingN;  // party streamers along the tops of walls
  void partyFeatures(Rng& rng);
  static constexpr float kSkyWell = 0.55f;  // how far up the skylight shafts go
  void poolFeatures(Rng& rng);
  bool isSky(int x, int z) const { return !sky.empty() && sky[idx(x, z)] != 0; }
  bool isStairwell(int x, int z) const;
  std::vector<uint8_t> solid;  // tiles nothing walks into (store fixtures, outside the building)
  std::vector<uint8_t> narrow; // Count On Me corridors: 1 = runs along z, 2 = along x (a metre wide)
  bool startYawSet = false;
  float startYaw = 0;
  // special levels (level_special.cpp)
  void specialLayout(Rng& rng);  // after the maze is carved
  void specialStart();           // after the start tile is picked
  void specialProps(Rng& rng);   // after lights and props
  void specialDecals(Rng& rng);  // after the decals
  float terrainH(float x, float z) const;  // rolling hills (outdoor levels)
  bool isNarrow(int x, int z) const { return !narrow.empty() && narrow[idx(x, z)] != 0; }
  int mural = -1;                // tile the mural hangs over (Count On Me), -1 none
  std::vector<uint8_t> zone;   // 0 main surfaces, 1 back room, 2 basement
  StoreSpots store;
  vec3 tubes[3];  // choice room slide mouths: 0 blue (home), 1 yellow (???), 2 red (back for Ray)
  struct Courtyard { bool on = false; int x0 = 0, z0 = 0, n = 0; float floorY = -12.0f, topY = 9.0f; float startYaw = 0; } court;
  bool solidNext(int x, int z, int d) const;
  void carveCourtyard(Rng& rng);
  struct AptSpots {
    vec3 tvScreen, tvNormal, couchEye, wallEye, wallNormal, cornerEye, windowCenter, doorEye;
    float couchYaw = 0, cornerYaw = 0, wallYaw = 0;
    std::vector<vec3> windows;  // centres, all on the north wall (facing +z into the room)
  } apt;
  std::vector<Light> lights;
  std::vector<int> lightAtTile;
  int lmW = 0, lmH = 0;
  std::vector<float> lightmap;  // RGBA32F texels: idA, wA, idB, wB
  // Bounce light: the fixtures' light diffused through the open space, a few metres round corners
  // and down corridors, the way it fills a real room (2 texels a metre, walls block it).
  int giW = 0, giH = 0;
  std::vector<float> indirect;
  void bakeIndirect();
  int startX = 0, startZ = 0;
  int exitX = 0, exitZ = 0, exitDir = 0;
  int campX = -1, campZ = -1;
  std::vector<int> exitDist;    // BFS distance (tiles) to the exit
  std::vector<PropInstance> props;
  std::vector<std::vector<int>> propsAtTile;
  std::vector<Decal> decals;
  // Lit green EXIT signs hung over the last stretch of the way out. arrow: 0 straight on, 1 right, 2 left.
  struct ExitSign { vec3 pos, n, right; int arrow = 0; };
  std::vector<ExitSign> exitSigns;
  void closeEdges();  // finite levels: wall off the wrap seam and reconnect anything it cut off
  // Districts (level_districts.cpp): each level is split into areas that look and play differently.
  enum District { D_PLAIN = 0, D_HALL, D_MAZE, D_OLD, D_DARK, D_OFFICE, D_CORRIDORS, D_PITS, D_SHOP, D_COUNT };
  // The pit floor: a grid of narrow walkways over square holes that go down further than your light does.
  static constexpr float kPitLo = 0.34f, kPitHi = 1.66f, kPitDepth = 3.4f;
  std::vector<uint8_t> pit;
  bool isPit(int x, int z) const { return !pit.empty() && pit[idx(x, z)] != 0; }
  bool overPit(float x, float z, float margin) const;
  void carvePits(Rng& rng);        // after the route (the way out stays solid floor)
  void prunePitProps();            // nothing stands over a hole
  // Stairs to nowhere: an old wooden staircase going up into a black hole in the ceiling.
  std::vector<int> stairUp;        // the tile the stairs reach the ceiling in (no ceiling there)
  bool isStairUp(int x, int z) const;
  // The trampoline park (the start): the hall, its court of beds, the gap by the back wall.
  std::vector<uint8_t> bed;        // 1 trampoline bed, 2 foam pit
  bool isBed(int x, int z) const { return !bed.empty() && bed[idx(x, z)] == 1; }
  bool isFoam(int x, int z) const { return !bed.empty() && bed[idx(x, z)] == 2; }
  struct ParkSpots {
    int x0 = 0, z0 = 0, x1 = 0, z1 = 0;  // the hall, inclusive
    int crevX = 0, crevZ = 0;             // the bed with the gap behind its pad
    vec3 mom, dad;
    float momYaw = 0, dadYaw = 0;
    std::vector<vec3> kids;
  } park;
  std::vector<uint8_t> district;   // per tile
  std::vector<int> routePath;      // the way out: tiles from the start to the exit
  std::vector<float> routeFrac;    // per tile: how far along the route (0..1), -1 off it
  std::vector<vec3> cord;          // an orange extension cord along the last half of the route
  void carveDistricts(Rng& rng);   // after the maze is carved
  void computeRoute();             // after the exit is picked
  void districtLights(Rng& rng);   // after the lights
  void districtProps(Rng& rng);    // after the props
  void trailDecals(Rng& rng);      // footprints, tape, the cord
  void dumpMap(const char* path) const;
  int districtAt(int x, int z) const { return district.empty() ? 0 : district[idx(x, z)]; }

  void generate(uint32_t seed, int w, int h, const Theme& th);

  // --- wrapping
  int wx(int x) const { return ((x % W) + W) % W; }
  int wz(int z) const { return ((z % H) + H) % H; }
  int idx(int x, int z) const { return wz(z) * W + wx(x); }
  vec3 wrap(vec3 p) const;
  vec3 delta(vec3 from, vec3 to) const;  // shortest vector from -> to on the torus
  vec3 nearest(vec3 p, vec3 ref) const { return ref + delta(ref, p); }

  bool blocked(int x, int z, int dir) const;
  bool hasPillar(int x, int z) const { return pillar[idx(x, z)] != 0; }
  bool isPool(int x, int z) const { return pool[idx(x, z)] != 0; }
  float floorAt(float x, float z) const;

  vec3 tileCenter(int x, int z, float y = 0) const { return {(wx(x) + 0.5f) * kTile, y, (wz(z) + 0.5f) * kTile}; }
  void tileOf(float x, float z, int& tx, int& tz) const;

  bool lineOfSight(float ax, float az, float bx, float bz, bool pillarsBlock = true) const;
  void collide(vec3& p, float radius) const;
  float distToSolid(float x, float z) const;

  std::vector<int> bfs(int sx, int sz) const;
  bool nextStep(int sx, int sz, int gx, int gz, int& nx, int& nz) const;

  float lightAt(float x, float z, const std::vector<float>& states) const;

  vec3 exitFaceCenter() const;
  vec3 exitFaceNormal() const;
  int distToExit(float x, float z) const;

  void buildChunks(std::vector<ChunkMeshes>& out) const;

 private:
  void boxesNear(float x, float z, float r, std::vector<AABB2>& out) const;
  void bakeLightmap();
  void ensureConnected();
  void carveLayout(Rng& rng);
  void generateStore(Rng& rng);
  void generateApartment(Rng& rng);
  void generateChoice(Rng& rng);
  void placeLights(Rng& rng);
  void placeProps(Rng& rng);
  void placeDecals(Rng& rng);
  void bloodTrails(Rng& rng);  // something was dragged through here
  void addProp(int type, vec3 pos, float yaw, float roll, float hx, float hz);
  float lmTexel(int i, int j, const std::vector<float>& st) const;
  void setWall(int x, int z, int dir, uint8_t v);
  void buildTile(int x, int z, ChunkMeshes& m) const;
};

extern const int kDX[4];
extern const int kDZ[4];
