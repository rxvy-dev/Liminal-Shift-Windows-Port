# Builds assets/textures/ from CC0 photo scans (ambientCG, via the Source-2-Public-Domain-Textures
# mirror). The scans give real surface detail; the colour is pulled back to the game's own palette
# so every level keeps its look, only the surfaces stop looking generated.
#
#   python3 tools/make_textures.py SCANS_DIR assets/textures
#
# SCANS_DIR holds <Name>.jpg (colour) and <Name>_disp.png (height) for: Carpet011, PaintedPlaster004,
# PaintedPlaster017, Concrete003, Concrete017, Concrete034, Tiles036.
import os, sys
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter

SRC, OUT = sys.argv[1], sys.argv[2]
N = 1024
os.makedirs(OUT, exist_ok=True)


def load(name, gray=False, size=N):
    im = Image.open(os.path.join(SRC, name)).convert('L' if gray else 'RGB')
    w, h = im.size
    if w != h:  # 2:1 scans: repeat to a square so the texel scale stays the same
        k = max(w, h) // min(w, h)
        sq = Image.new(im.mode, (max(w, h), max(w, h)))
        for i in range(k):
            sq.paste(im, (0, i * h) if w > h else (i * w, 0))
        im = sq
    im = im.resize((size, size), Image.LANCZOS)
    a = np.asarray(im).astype(np.float32) / 255.0
    return a


def wrap_blur(a, r):
    """Gaussian blur that wraps around (the textures tile)."""
    if a.ndim == 2:
        return gaussian_filter(a, r, mode='wrap')
    return np.stack([gaussian_filter(a[..., c], r, mode='wrap') for c in range(a.shape[2])], -1)


def lum(a):
    return a[..., 0] * 0.3 + a[..., 1] * 0.59 + a[..., 2] * 0.11


def detail(a, r, strength=1.0):
    """The photo's own light and dark around its local average: 1.0 = no change."""
    L = lum(a)
    d = L / np.maximum(wrap_blur(L, r), 1e-3)
    return 1.0 + (d - 1.0) * strength


def normalize(h):
    lo, hi = np.percentile(h, 1), np.percentile(h, 99)
    return np.clip((h - lo) / max(hi - lo, 1e-4), 0, 1)


def save(name, rgb, height=None):
    rgb = np.clip(rgb, 0, 1)
    Image.fromarray((rgb * 255 + 0.5).astype(np.uint8)).save(os.path.join(OUT, name + '.jpg'), quality=90, subsampling=0)
    if height is not None:
        Image.fromarray((np.clip(height, 0, 1) * 255 + 0.5).astype(np.uint8)).save(os.path.join(OUT, name + '_height.jpg'), quality=92)
    print('wrote', name)


def fbm(n, period, octaves, seed):
    rng = np.random.default_rng(seed)
    out = np.zeros((n, n), np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        p = period * (2 ** o)
        g = rng.random((p, p)).astype(np.float32)
        im = Image.fromarray(np.tile(g, (2, 2)), 'F').resize((n * 2, n * 2), Image.BICUBIC)
        a = np.asarray(im)[n // 2:n // 2 + n, n // 2:n // 2 + n]
        out += a * amp
        tot += amp
        amp *= 0.5
    return out / tot


yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
U, V = (xx + 0.5) / N, (yy + 0.5) / N


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


# ------------------------------------------------------------------ carpet (Level 0): tan, going brown
c = load('Carpet011.jpg')
ch = normalize(load('Carpet011_disp.png', True))
c = wrap_blur(c, 0.8)                        # 1 m of carpet: the scan's single fibres are below what you'd see
d = detail(c, 24, 0.7)                       # tufts and pile from the scan
big = wrap_blur(lum(c), 90)
big = 1.0 + (big / big.mean() - 1.0) * 0.6   # the scan's own wear, softened
tone = 1.0 + (fbm(N, 3, 4, 7) - 0.5) * 0.08
base = np.array([0.63, 0.545, 0.29]) * 0.93
rgb = base * (d * big * tone)[..., None]
# a little of the scan's fleck colour: fibres aren't all one dye
chroma = c / np.maximum(lum(c)[..., None], 1e-3)
rgb *= 1.0 + (chroma - chroma.mean((0, 1))).mean(-1, keepdims=True) * 0.0  # (the scan's green fleck is left out)
save('carpet', rgb, ch * 0.75 + 0.25 * normalize(lum(c)))

# ------------------------------------------------------------------ wallpaper (Level 0): the printed feather column
p = load('PaintedPlaster004.jpg')
ph = normalize(load('PaintedPlaster004_disp.png', True))
cols, reps = 13.0, 9.0   # the print reads from across a room, like the photo
cu = U * cols
col = np.floor(cu)
su = cu - col
sv = np.mod(V * reps + np.where(col.astype(int) & 1, 0.5, 0.0), 1.0)
cx = (su - 0.5) * 2
ax = np.abs(cx)
c1 = np.abs(sv - (0.22 + ax * 0.34))
c2 = np.abs(sv - (0.42 + ax * 0.30))
stroke1 = smooth(0.05, 0.022, c1) * smooth(0.92, 0.7, ax)
stroke2 = smooth(0.042, 0.018, c2) * smooth(0.62, 0.45, ax)
stem = smooth(0.06, 0.025, ax) * smooth(0.08, 0.14, sv) * smooth(0.62, 0.52, sv)
dot = smooth(0.05, 0.02, np.hypot(cx * 0.5, sv - 0.8))
motif = np.minimum(1, np.maximum(np.maximum(stroke1, stroke2), np.maximum(stem * 0.8, dot * 0.7)))
# printed ink isn't perfect: it skips where the paper's tooth is high
ink_break = smooth(0.25, 0.6, fbm(N, 96, 2, 21) * 0.6 + ph * 0.4)
motif *= 0.75 + 0.25 * ink_break
line = np.exp(-(np.minimum(su, 1 - su) * 90) ** 2) * 0.5
su2 = np.mod(U, 0.5)
sd = np.minimum(su2, 0.5 - su2)
seam = np.exp(-(sd * N / 1.2) ** 2)
lift = np.where(su2 < 0.5 - su2, 0.0, np.exp(-((0.5 - su2) * N / 3.0) ** 2))
paper = detail(wrap_blur(p, 0.6), 6, 0.3)     # the plaster scan stands in for paper tooth and old paste
age = wrap_blur(lum(p), 60)
age = 1.0 + (age / age.mean() - 1.0) * 0.25  # faint uneven fading
k = paper * age - seam * 0.12 + lift * 0.04
r, g, b = 0.84 * k, 0.77 * k, 0.46 * k   # old mustard paper, not lime
m = motif * 0.5 + line * 0.25
r = r + (0.60 - r) * m
g = g + (0.64 - g) * m
b = b + (0.58 - b) * m
height = 0.5 + motif * 0.12 + (ph - 0.5) * 0.35 - seam * 0.25 + lift * 0.2
save('wallpaper', np.stack([r, g, b], -1), height)

# ------------------------------------------------------------------ ceiling tiles: 2x4 ft fissured mineral fibre in a T-bar grid
t = load('Concrete003.jpg')
th = normalize(load('Concrete003_disp.png', True))
tu = np.mod(U * 2, 1.0)
eu = np.minimum(tu, 1 - tu) * 0.6
ev = np.minimum(V, 1 - V) * 1.2
edge = np.minimum(eu, ev)
bar = smooth(0.016, 0.009, edge)
shade = smooth(0.04, 0.016, edge) * (1 - bar)
hp = th - wrap_blur(th, 3)                    # only the small pits, not the big aggregate
pits = smooth(-0.025, -0.09, hp) * 0.8        # read as the tile's fissures and pinholes
fiss = detail(t, 3, 0.18)
tone = (fbm(N, 2, 4, 9) - 0.5)
k = (0.9 - pits * 0.09 - shade * 0.16 + tone * 0.04) * fiss
r, g, b = 0.86 * k, 0.83 * k, 0.64 * k   # off-white board, yellowed
r = r + (0.97 - r) * bar; g = g + (0.96 - g) * bar; b = b + (0.86 - b) * bar
h = 0.6 - pits * 0.3 - shade * 0.3 - bar * 0.25 + (th - 0.5) * 0.1
save('ceiling_tiles', np.stack([r, g, b], -1), h)

# ------------------------------------------------------------------ concrete walls / ceilings (garage, tunnels)
cw = load('Concrete034.jpg')
cwh = normalize(load('Concrete034_disp.png', True))
L = lum(cw)
k = 0.56 * (L / L.mean()) ** 0.9
seamH = smooth(0.006, 0.0, np.abs(np.mod(V * 2 + 0.5, 1.0) - 0.5) - 0.495 + 0.006)
tuu, tvv = np.mod(U * 2, 1.0) - 0.5, np.mod(V * 2, 1.0) - 0.5
tie = smooth(0.03, 0.02, np.sqrt(tuu ** 2 + tvv ** 2))   # form-tie holes
k = k * (1 - seamH * 0.15 - tie * 0.3)
save('concrete', np.stack([k, k * 0.985, k * 0.96], -1), cwh * 0.8 + 0.1 - tie * 0.4)
kc = k * 0.9
save('concrete_ceiling', np.stack([kc, kc * 0.985, kc * 0.97], -1), cwh * 0.8 + 0.1 - tie * 0.4)

# ------------------------------------------------------------------ concrete floor (warehouse) and the garage deck
cf = load('Concrete017.jpg')
cfh = normalize(load('Concrete017_disp.png', True))
L = lum(cf)
k = 0.5 * (L / L.mean())
joint = smooth(0.004, 0.0, np.minimum(np.minimum(U, 1 - U), np.minimum(V, 1 - V)))
k = k * (1 - joint * 0.2)
save('concrete_floor', np.stack([k, k * 0.98, k * 0.95], -1), cfh * 0.8 + 0.1 - joint * 0.5)
# the parking deck: same slab, darker, tyre tracks and oil
wob = (fbm(N, 2, 3, 5) - 0.5) * 0.06
track = lambda cpos: smooth(0.05, 0.02, np.abs(U - cpos + wob))
tracks = np.maximum(track(0.3), track(0.62)) * (0.55 + 0.45 * fbm(N, 4, 3, 9))
oil = smooth(0.7, 0.85, fbm(N, 5, 4, 13)) * 0.6
kp = 0.46 * (L / L.mean()) * (1 - tracks * 0.35 - oil * 0.4)
save('parking_floor', np.stack([kp * 0.98, kp, kp * 1.02], -1), cfh * 0.8 + 0.1)

# ------------------------------------------------------------------ pool tile: small white glazed tiles, pale grout (Poolrooms)
pt = load('Tiles036.jpg')
pth = normalize(load('Tiles036_disp.png', True))
L = lum(pt)
k = np.clip(0.92 * (L / np.percentile(L, 90)), 0, 1.05)
save('pool_tile', np.stack([k * 0.97, k * 0.98, k * 0.96], -1), pth)

# ------------------------------------------------------------------ plaster (apartment) and office drywall
pl = load('PaintedPlaster017.jpg')
plh = normalize(load('PaintedPlaster017_disp.png', True))
dpl = detail(pl, 30, 0.8)
k = 0.8 * dpl
save('plaster', np.stack([k * 0.93, k * 0.9, k * 0.84], -1), 0.5 + (plh - 0.5) * 0.6)
k = detail(pl, 30, 0.5) * (1 + (fbm(N, 3, 3, 4) - 0.5) * 0.04)
save('office_wall', np.stack([0.80 * k, 0.74 * k, 0.62 * k], -1), 0.5 + (plh - 0.5) * 0.4)
