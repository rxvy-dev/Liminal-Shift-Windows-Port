// The landing. After the hundred-foot drop the camcorder flies out of your hands, cracks
// against the floor and lands on its side, still recording. From down there you watch
// yourself lying in a heap, groaning; you sit up, crawl over, a hand comes at the lens,
// and the picture swings up and around to your eye. Then you're playing.
#include <algorithm>
#include <cmath>

#include "audio.h"
#include "game.h"

namespace {
const vec4 kYouLook[4] = {{0.62f, 0.45f, 0.36f, 0}, {0.12f, 0.09f, 0.07f, 0}, {0.36f, 0.06f, 0.07f, 0}, {0.1f, 0.1f, 0.11f, 0}};
// timeline, seconds after hitting the floor
constexpr float kHit = 0.45f, kSettle = 0.78f, kSitUp = 3.3f, kCrawl = 4.1f, kReach = 5.0f, kLift = 5.8f, kDone = 6.55f;  // ~5 s on the floor
float wrapA(float a) { return std::remainder(a, 2.0f * kPi); }
mat4 frameD(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}
float ease(float x) { x = std::clamp(x, 0.0f, 1.0f); return x * x * (3.0f - 2.0f * x); }
float span(float t, float a, float b) { return std::clamp((t - a) / (b - a), 0.0f, 1.0f); }
void orient(float yaw, float pitch, float roll, vec3& dir, vec3& up) {
  dir = {-std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
  vec3 r = normalize(cross(dir, vec3{0, 1, 0}));
  vec3 u0 = cross(r, dir);
  up = u0 * std::cos(roll) + r * std::sin(roll);
}
}  // namespace

void Game::startDrop() {
  dropping_ = true;
  dropT_ = 0;
  dropCue_ = 0;
  dropBody_ = pos_;
  // Where does the camera end up? A metre and a half ahead, on dry floor, not through a wall.
  vec3 best = pos_;
  float bestD = -1;
  const float tryAngles[8] = {0, 1, -1, 2, -2, 3, -3, 4};  // straight ahead first, then fanning out
  for (int k = 0; k < 8; ++k) {
    float a = yaw_ + tryAngles[k] * (kPi / 4.0f);
    vec3 f{-std::sin(a), 0, -std::cos(a)};
    vec3 p = pos_ + f * 1.75f;
    level_.collide(p, 0.25f);
    vec3 d = level_.delta(pos_, p);
    float dl = std::sqrt(d.x * d.x + d.z * d.z);
    bool dry = level_.floorAt(p.x, p.z) > -0.05f;
    // it has to be able to see you from down there: nothing between it and where you fell
    bool clear = true;
    for (int i = 1; i < 8 && clear; ++i) {
      vec3 q = pos_ + d * (i / 8.0f);
      vec3 q0 = q;
      level_.collide(q, 0.12f);
      vec3 moved = level_.delta(q0, q);
      clear = moved.x * moved.x + moved.z * moved.z < 0.0025f;
    }
    if (dry && clear && dl > 1.35f) { best = p; bestD = dl; break; }
    if (dry && dl * (clear ? 1.0f : 0.4f) > bestD) { best = p; bestD = dl * (clear ? 1.0f : 0.4f); }
  }
  dropCam_ = best;
  vec3 d = level_.delta(dropBody_, dropCam_);
  d.y = 0;
  float dl = std::max(0.3f, std::sqrt(d.x * d.x + d.z * d.z));
  vec3 dn = d * (1.0f / dl);
  dropBodyYaw_ = std::atan2(-dn.x, -dn.z);  // you end up facing your camera
  dropKneel_ = dropBody_ + dn * std::max(0.0f, dl - 0.78f);
  dropStartYaw_ = yaw_;
  if (A_) { A_->play(Sfx::Slam, 1.2f, 0, 0.6f); A_->play(Sfx::HeavyStep, 1.3f, 0, 0.7f); }
}

void Game::dropSkip() {
  if (dropping_ && dropT_ > 0.9f && dropT_ < kLift) dropT_ = kLift;
}

void Game::updateDrop(float dt) {
  dropT_ += dt;
  float t = dropT_;
  auto cue = [&](int i, float at, Sfx s, float g, float pitch) {
    if (t >= at && !(dropCue_ & (1 << i))) { dropCue_ |= 1 << i; if (A_) A_->play(s, g, 0, pitch); }
  };
  cue(0, kHit, Sfx::Clatter, 1.0f, 1.0f);
  cue(1, kSettle - 0.05f, Sfx::Clatter, 0.35f, 1.0f);
  cue(2, 1.0f, Sfx::Grunt, 0.9f, 0.95f);       // "nngh..."
  cue(3, kSitUp + 0.1f, Sfx::Grunt, 1.0f, 0.82f);  // sitting up hurts
  cue(4, kCrawl + 0.25f, Sfx::Grunt, 0.7f, 1.12f);
  cue(5, kReach + 0.15f, Sfx::Footstep, 0.6f, 1.6f);  // fingers on the floor
  cue(6, kLift + 0.05f, Sfx::Click, 0.6f, 1.0f);      // grabbed
  cue(7, kLift + 0.4f, Sfx::Grunt, 0.55f, 1.25f);     // short exhale getting up
  cue(8, 2.2f, Sfx::Grunt, 0.75f, 0.88f);             // still down there
  if (t >= kDone) {
    dropping_ = false;
    vec3 p = dropKneel_;
    level_.collide(p, 0.3f);
    resetPlayer(level_.wrap(p), dropBodyYaw_);
    screen_ = Screen::Playing;
    screenTime_ = 0;
    landDip_ = 0.2f;
    fear_ = 0.5f;
    hintTimer_ = 9.0f;
    hasPrevVP_ = false;
    if (wentBack_ && rayState_ != 2) { toast_ = "FIND RAY. BRING HIM HOME."; toastTime_ = 5.0f; }
    saveProgress();
  }
}

void Game::dropCamera(vec3& camPos, vec3& camDir, vec3& camUp, float& fov, PostParams& pp) {
  float t = dropT_;
  float floorY = level_.floorAt(dropCam_.x, dropCam_.z);
  float camFloorYaw = dropBodyYaw_ + kPi;  // lying on its side, looking back at you
  const float rollF = 1.38f, pitchF = 0.1f;
  vec3 dir, up;
  vec3 at;
  if (t < kSettle) {
    // knocked out of your hands: tumbling, hit, one bounce, still
    float u = std::min(1.0f, t / kHit);
    vec3 start = dropBody_ + vec3{0, 1.4f, 0};
    vec3 land = dropCam_ + vec3{0, 0.1f, 0};
    vec3 mid = level_.delta(start, land);
    at = start + mid * (t < kHit ? u * 0.9f : 0.9f + 0.1f * span(t, kHit, kSettle));
    float y = t < kHit ? 1.4f - 1.3f * u * u : 0.1f + 0.14f * std::sin(kPi * span(t, kHit, kSettle));
    at.y = floorY + y;
    float w = 1.0f - span(t, 0, kSettle);
    float yawT = dropStartYaw_ + wrapA(camFloorYaw - dropStartYaw_) * ease(span(t, 0, kSettle));
    float pitch = pitchF - 0.3f + std::sin(t * 17.0f) * 1.1f * w * w;
    float roll = rollF * ease(span(t, 0.1f, kSettle)) + std::sin(t * 13.0f) * 1.3f * w * w;
    orient(yawT, pitch, roll, dir, up);
    pp.staticAmt = std::max(pp.staticAmt, t > kHit && t < kHit + 0.12f ? 0.7f : 0.0f);
  } else if (t < kLift) {
    at = dropCam_;
    at.y = floorY + 0.1f;
    float wob = (t < kSettle + 0.25f) ? std::sin((t - kSettle) * 40.0f) * 0.05f * (1.0f - (t - kSettle) / 0.25f) : 0.0f;
    float nudge = t > kReach + 0.3f ? 0.04f * std::sin(t * 31.0f) : 0.0f;  // a hand bumping it
    orient(camFloorYaw, pitchF + wob, rollF + nudge, dir, up);
  } else {
    // picked up, swung round to your eye
    float u = ease(span(t, kLift, kDone));
    vec3 floorP = dropCam_ + vec3{0, floorY + 0.1f, 0};
    vec3 eyeP = dropKneel_ + vec3{0, level_.floorAt(dropKneel_.x, dropKneel_.z) + 1.55f, 0};
    vec3 dd = level_.delta(floorP, eyeP);
    at = floorP + dd * u;
    at.y = floorP.y + (eyeP.y - floorP.y) * (1.0f - (1.0f - u) * (1.0f - u));  // up fast, then settles
    float yawT = camFloorYaw - kPi * ease(span(t, kLift + 0.05f, kDone - 0.1f));
    float pitch = pitchF * (1.0f - u) - 0.5f * std::sin(kPi * u) * 0.6f;
    float roll = rollF * (1.0f - ease(span(t, kLift, kLift + 0.45f))) + std::sin(t * 21.0f) * 0.06f * (1.0f - u);
    orient(yawT, pitch, roll, dir, up);
    pp.staticAmt = std::max(pp.staticAmt, t < kLift + 0.08f ? 0.35f : 0.0f);
  }
  // the hand closes over the lens
  float cover = span(t, kLift - 0.2f, kLift) * (1.0f - span(t, kLift + 0.05f, kLift + 0.3f));
  pp.exposure = 1.05f * (1.0f - 0.85f * cover);
  camPos = at;
  camDir = dir;
  camUp = up;
  fov = 84.0f;
  pp.fear = 0.35f;
}

void Game::dropDraw(Shader& S, vec3 cam) {
  if (!dropping_) return;
  float t = dropT_;
  if (t > kLift + 0.25f) return;  // the camera's at your eye now
  CreatureId id = hazmat_ ? CR_HAZMAT : CR_WORKER;
  const vec4* look = hazmat_ ? nullptr : kYouLook;
  AnimInput in;
  in.time = time_;
  vec3 b = near(dropBody_, cam);
  float yaw = dropBodyYaw_;
  mat4 w;
  if (t < kSitUp) {  // in a heap on your side, the odd twitch
    in.sit = 1;
    float tw = (t > 0.9f && t < 1.3f) ? 0.06f * std::sin(t * 30.0f) : 0.0f;
    w = translate(b + vec3{0, 0.16f, 0}) * rotY(yaw) * rotZ(kPi * 0.5f - 0.12f + tw) * translate({-0.15f, 0, 0});  // on your side, across the shot
  } else if (t < kCrawl) {  // sitting up, slowly
    in.sit = 1;
    float k = ease(span(t, kSitUp, kCrawl));
    float yy = yaw;
    w = translate(b + vec3{0, 0.16f * (1.0f - k), 0}) * rotY(yy) * rotZ((kPi * 0.5f - 0.12f) * (1.0f - k)) * translate({-0.15f * (1.0f - k), 0, 0});
    in.look = 0.3f * std::sin(t * 2.0f);
  } else {  // on your knees, shuffling over, reaching
    in.sit = 2;
    float k = ease(span(t, kCrawl, kReach));
    vec3 kn = near(dropKneel_, cam);
    vec3 p = b + (kn - b) * k;
    p.y = level_.floorAt(p.x, p.z) + 0.03f * std::fabs(std::sin(t * 9.0f)) * (k < 1.0f ? 1.0f : 0.0f);
    float lean = 0.25f * span(t, kReach - 0.2f, kLift);
    in.offer = span(t, kReach, kLift);
    w = translate(p) * rotY(yaw) * rotX(-lean);
  }
  drawCreatureAt(S, id, w, in, 0, look);
  // The hand that comes for the lens.
  if (t > kReach && t < kLift) {
    float k = ease(span(t, kReach, kLift));
    vec3 c = near(dropCam_, cam);
    c.y = level_.floorAt(c.x, c.z) + 0.1f;
    vec3 kn = near(dropKneel_, cam);
    vec3 shoulder = kn + vec3{0, 0.9f, 0};
    vec3 to = c - shoulder;
    vec3 dir = normalize(to);
    float dist = 0.27f + 0.45f * (1.0f - k);  // fingertips stop just short of the lens (closer clips through)
    vec3 fist = c - dir * dist;
    fist = fist + vec3{std::sin(t * 23.0f), std::sin(t * 17.0f + 1.0f), 0} * 0.003f;  // a shaky hand
    vec3 r = normalize(cross(dir, vec3{0, 1, 0}));
    vec3 u = cross(r, dir);
    vec4 cols[4] = {kYouLook[2], kYouLook[0], {0.28f, 0.04f, 0.05f, 0}, {0.78f, 0.6f, 0.55f, 0}};
    if (hazmat_) { cols[0] = {0.86f, 0.74f, 0.14f, 0}; cols[1] = {0.012f, 0.012f, 0.012f, 0}; cols[2] = {0.015f, 0.015f, 0.015f, 0}; cols[3] = {0.02f, 0.02f, 0.02f, 0}; }
    Model& md = creatures::prop(PR_REACH);
    vec4 keep[4];
    for (int i = 0; i < 4; ++i) { keep[i] = md.region[i]; md.region[i] = cols[i]; }
    glDisable(GL_CULL_FACE);
    S.set("uMat", MAT_MODEL);
    S.set("uSkinned", 0);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    drawModel(S, md, frameD(r, u, dir * -1.0f, fist));
    glEnable(GL_CULL_FACE);
    for (int i = 0; i < 4; ++i) md.region[i] = keep[i];
  }
}

// The title card while the camcorder lies on the floor: big white letters with a heavy black
// outline, drawn onto the tape so they bend and smear with the picture.
void Game::dropHUD() {
  if (!dropping_) return;
  float t = dropT_;
  float a = std::clamp((t - 0.9f) / 0.35f, 0.0f, 1.0f) * std::clamp((4.9f - t) / 0.6f, 0.0f, 1.0f);
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  if (a > 0.0f) {
    bool first = levelIndex_ == 0 || (endless_ && depth_ == 1);
    std::string title = first ? "LIMINAL SHIFT" : level_.theme.name;
    // VCR OSD Mono, white, thin black outline and a soft shadow, a bit above centre (like the photo)
    float px = std::min(W * 0.068f, W * 0.72f / (0.6f * (float)title.size()));
    float tw = vcrWidth(title, px);
    vcrText(title, W * 0.5f - tw * 0.5f, H * 0.43f - px * 0.5f, px, 0.97f, 0.97f, 0.95f, a, px * 0.035f, px * 0.06f);
  }
  if (t > 1.2f && t < kLift) {
    std::string sk = usingPad_ ? "[A] GET UP" : "[E] GET UP";
    vt(sk, W * 0.5f - vw(sk, s) * 0.5f, H * 0.86f, s, 0.85f, 0.85f, 0.8f, 0.5f);
  }
}
