#include "platform.h"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace fs = std::filesystem;

namespace platform {

static std::string ensure(const std::string& base) {
  std::string dir = base + "/liminal-shift";
  std::error_code ec;
  fs::create_directories(dir, ec);
  return dir;
}

#ifdef _WIN32
// Windows: settings in %APPDATA%\liminal-shift, saves in %LOCALAPPDATA%\liminal-shift.
static std::string winBase(const char* var, const char* fallbackUnderProfile) {
  const char* v = std::getenv(var);
  if (v && *v) return v;
  const char* profile = std::getenv("USERPROFILE");
  return std::string(profile && *profile ? profile : ".") + "/" + fallbackUnderProfile;
}
std::string configDir() { return ensure(winBase("APPDATA", "AppData/Roaming")); }
std::string dataDir() { return ensure(winBase("LOCALAPPDATA", "AppData/Local")); }
#else
static std::string xdg(const char* var, const char* fallbackUnderHome) {
  const char* v = std::getenv(var);
  std::string base;
  if (v && *v && v[0] == '/') {
    base = v;
  } else {
    const char* home = std::getenv("HOME");
    base = std::string(home && *home ? home : "/tmp") + "/" + fallbackUnderHome;
  }
  return ensure(base);
}
std::string configDir() { return xdg("XDG_CONFIG_HOME", ".config"); }
std::string dataDir() { return xdg("XDG_DATA_HOME", ".local/share"); }
#endif

bool KeyValueFile::load(const std::string& path) {
  std::ifstream in(path);
  if (!in) return false;
  std::string line;
  while (std::getline(in, line)) {
    if (line.empty() || line[0] == '#' || line[0] == '[') continue;
    auto eq = line.find('=');
    if (eq == std::string::npos) continue;
    auto trim = [](std::string s) {
      size_t a = s.find_first_not_of(" \t\r"), b = s.find_last_not_of(" \t\r");
      return a == std::string::npos ? std::string() : s.substr(a, b - a + 1);
    };
    values[trim(line.substr(0, eq))] = trim(line.substr(eq + 1));
  }
  return true;
}

bool KeyValueFile::save(const std::string& path) const {
  std::string tmp = path + ".tmp";
  {
    std::ofstream out(tmp);
    if (!out) return false;
    out << "# LIMINAL SHIFT\n";
    for (auto& [k, v] : values) out << k << " = " << v << "\n";
  }
  std::error_code ec;
  fs::rename(tmp, path, ec);  // atomic replace so a crash never corrupts saves
  return !ec;
}

float KeyValueFile::getf(const std::string& k, float def) const {
  auto it = values.find(k);
  if (it == values.end()) return def;
  try { return std::stof(it->second); } catch (...) { return def; }
}
int KeyValueFile::geti(const std::string& k, int def) const {
  auto it = values.find(k);
  if (it == values.end()) return def;
  try { return std::stoi(it->second); } catch (...) { return def; }
}
std::string KeyValueFile::gets(const std::string& k, const std::string& def) const {
  auto it = values.find(k);
  return it == values.end() ? def : it->second;
}
void KeyValueFile::setf(const std::string& k, float v) { std::ostringstream o; o << v; values[k] = o.str(); }
void KeyValueFile::seti(const std::string& k, int v) { values[k] = std::to_string(v); }

}  // namespace platform
