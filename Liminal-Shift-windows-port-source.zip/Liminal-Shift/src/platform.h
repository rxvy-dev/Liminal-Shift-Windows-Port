// XDG-compliant paths and simple key=value persistence.
#pragma once
#include <map>
#include <string>

namespace platform {

std::string configDir();  // $XDG_CONFIG_HOME/liminal-shift or ~/.config/liminal-shift
std::string dataDir();    // $XDG_DATA_HOME/liminal-shift   or ~/.local/share/liminal-shift

struct KeyValueFile {
  std::map<std::string, std::string> values;
  bool load(const std::string& path);
  bool save(const std::string& path) const;
  float getf(const std::string& k, float def) const;
  int geti(const std::string& k, int def) const;
  std::string gets(const std::string& k, const std::string& def) const;
  void setf(const std::string& k, float v);
  void seti(const std::string& k, int v);
};

}  // namespace platform
