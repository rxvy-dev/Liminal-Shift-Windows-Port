#include "level.h"
#include <algorithm>
#include <cmath>
#include <queue>
#include <cstdio>
#include <cstdlib>

const int kDX[4] = {1, -1, 0, 0};
const int kDZ[4] = {0, 0, 1, -1};

// ---------------------------------------------------------------- Mesh

void Mesh::quad(vec3 a, vec3 b, vec3 c, vec3 d, vec3 n, vec2 ua, vec2 ub, vec2 uc, vec2 ud,
                float aoA, float aoB, float aoC, float aoD, float lightId) {
  uint32_t base = (uint32_t)(v.size() / stride);
  auto push = [&](vec3 p, vec2 uv, float ao) { v.insert(v.end(), {p.x, p.y, p.z, n.x, n.y, n.z, uv.x, uv.y, ao, lightId}); };
  push(a, ua, aoA); push(b, ub, aoB); push(c, uc, aoC); push(d, ud, aoD);
  idx.insert(idx.end(), {base, base + 1, base + 2, base, base + 2, base + 3});
}

// ---------------------------------------------------------------- edges (wrapping)

namespace {
struct EdgeView {
  const Level& L;
  // Wall on the vertical grid line x = cx between z and z+1 (east wall of tile cx-1).
  bool v(int cx, int z) const { return L.eWall[L.idx(cx - 1, z)] == 1; }  // 2 = invisible (collision only)
  // Wall on the horizontal grid line z = cz between x and x+1 (south wall of tile cz-1).
  bool h(int x, int cz) const { return L.sWall[L.idx(x, cz - 1)] == 1; }
  bool post(int cx, int cz) const { return v(cx, cz - 1) || v(cx, cz) || h(cx - 1, cz) || h(cx, cz); }
};
vec3 dirVec(int d) { return {(float)kDX[d], 0, (float)kDZ[d]}; }
}  // namespace

bool Level::blocked(int x, int z, int dir) const {
  if (!solid.empty() && solid[idx(x + kDX[dir], z + kDZ[dir])]) return true;
  switch (dir) {
    case PX: return eWall[idx(x, z)] != 0;
    case NX: return eWall[idx(x - 1, z)] != 0;
    case PZ: return sWall[idx(x, z)] != 0;
    default: return sWall[idx(x, z - 1)] != 0;
  }
}

void Level::setWall(int x, int z, int dir, uint8_t val) {
  switch (dir) {
    case PX: eWall[idx(x, z)] = val; break;
    case NX: eWall[idx(x - 1, z)] = val; break;
    case PZ: sWall[idx(x, z)] = val; break;
    default: sWall[idx(x, z - 1)] = val; break;
  }
}

vec3 Level::wrap(vec3 p) const {
  p.x = std::fmod(p.x, periodX); if (p.x < 0) p.x += periodX;
  p.z = std::fmod(p.z, periodZ); if (p.z < 0) p.z += periodZ;
  return p;
}

vec3 Level::delta(vec3 from, vec3 to) const {
  vec3 d = to - from;
  d.x -= periodX * std::round(d.x / periodX);
  d.z -= periodZ * std::round(d.z / periodZ);
  return d;
}

void Level::tileOf(float x, float z, int& tx, int& tz) const {
  tx = wx((int)std::floor(x / kTile));
  tz = wz((int)std::floor(z / kTile));
}

float Level::floorAt(float x, float z) const {
  int tx, tz;
  tileOf(x, z, tx, tz);
  return isPool(tx, tz) ? -kPoolDepth : 0.0f;
}

int Level::distToExit(float x, float z) const {
  int tx, tz;
  tileOf(x, z, tx, tz);
  return exitDist.empty() ? 0 : exitDist[idx(tx, tz)];
}

// ---------------------------------------------------------------- generation

void Level::generate(uint32_t s, int w, int h, const Theme& th) {
  theme = th;
  wallH = th.wallH;
  seed = s; W = w; H = h;
  periodX = W * kTile; periodZ = H * kTile;
  Rng rng(s * 2654435761u + 12345u + (uint32_t)th.index * 7777u);
  solid.assign(W * H, 0);
  zone.assign(W * H, 0);
  sky.assign(W * H, 0);
  stairwells.clear(); tunnels.clear(); tunnelN.clear(); drains.clear(); bunting.clear(); buntingN.clear();
  if (th.layout == Layout::Choice) {
    generateChoice(rng);
    bakeLightmap();
    return;
  }
  if (th.layout == Layout::Apartment) {
    generateApartment(rng);
    bakeLightmap();
    return;
  }
  if (th.layout == Layout::Store) {
    generateStore(rng);
    bakeLightmap();
    return;
  }
  carveLayout(rng);
  if (th.layout == Layout::Pools) poolFeatures(rng);
  if (th.party) for (int i = 0; i < W * H; ++i) zone[i] = hashf((i % W) / 5, (i / W) / 5, (int)s + 77) < 0.45f ? 1 : 0;  // orange rooms, yellow rooms
  court = Courtyard();
  if (th.courtyard > 0) carveCourtyard(rng);

  for (int tries = 0; tries < 500 && !court.on; ++tries) {
    startX = rng.irange(0, W - 1);
    startZ = rng.irange(0, H - 1);
    if (!pillar[idx(startX, startZ)] && !pool[idx(startX, startZ)] && !solid[idx(startX, startZ)]) break;
  }
  // Exit: one of the farthest reachable tiles with a wall to lean on.
  {
    std::vector<int> d = bfs(startX, startZ);
    int maxd = *std::max_element(d.begin(), d.end());
    std::vector<int> cands;
    for (int i = 0; i < W * H; ++i) {
      if (d[i] < maxd * 0.8f || pillar[i] || pool[i] || solid[i]) continue;
      int x = i % W, z = i / W;
      for (int dir = 0; dir < 4; ++dir)
        if (blocked(x, z, dir) && !solidNext(x, z, dir)) { cands.push_back(i); break; }
    }
    int pick = cands.empty() ? (int)(std::max_element(d.begin(), d.end()) - d.begin()) : cands[rng.next() % cands.size()];
    exitX = pick % W; exitZ = pick / W;
    exitDir = 0;
    for (int dir = 0; dir < 4; ++dir) if (blocked(exitX, exitZ, dir) && !solidNext(exitX, exitZ, dir)) { exitDir = dir; break; }
  }
  exitDist = bfs(exitX, exitZ);

  placeLights(rng);
  placeProps(rng);
  placeDecals(rng);
  bakeLightmap();
}

void Level::carveLayout(Rng& rng) {
  eWall.assign(W * H, 1);
  sWall.assign(W * H, 1);
  pillar.assign(W * H, 0);
  pool.assign(W * H, 0);
  const Theme& t = theme;

  // 1. Perfect maze on the torus.
  {
    std::vector<uint8_t> seen(W * H, 0);
    std::vector<int> stack{0};
    seen[0] = 1;
    while (!stack.empty()) {
      int c = stack.back(), cx = c % W, cz = c / W;
      int opts[4], n = 0;
      for (int d = 0; d < 4; ++d)
        if (!seen[idx(cx + kDX[d], cz + kDZ[d])]) opts[n++] = d;
      if (!n) { stack.pop_back(); continue; }
      int d = opts[rng.next() % n];
      setWall(cx, cz, d, 0);
      int ni = idx(cx + kDX[d], cz + kDZ[d]);
      seen[ni] = 1;
      stack.push_back(ni);
    }
  }
  // 2. Braid.
  for (int i = 0; i < W * H; ++i) {
    if (rng.f01() < t.braid) eWall[i] = 0;
    if (rng.f01() < t.braid) sWall[i] = 0;
  }
  // 3. Long hallways walled on both sides.
  int hmin = t.layout == Layout::Tunnels ? 10 : 7, hmax = t.layout == Layout::Tunnels ? 24 : 16;
  for (int k = 0; k < t.hallways; ++k) {
    bool alongX = rng.f01() < 0.5f;
    int len = rng.irange(hmin, hmax);
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    bool flooded = t.pools && rng.f01() < 0.4f;
    for (int i = 0; i < len; ++i) {
      int cx = alongX ? x + i : x, cz = alongX ? z : z + i;
      if (alongX) { setWall(cx, cz, PX, 0); setWall(cx, cz, PZ, 1); setWall(cx, cz, NZ, 1); }
      else        { setWall(cx, cz, PZ, 0); setWall(cx, cz, PX, 1); setWall(cx, cz, NX, 1); }
      if (flooded && i > 1 && i < len - 2) pool[idx(cx, cz)] = 1;
    }
  }
  // 4. Rooms.
  int rmin = 3, rmax = 9, pstep = 3;
  switch (t.layout) {
    case Layout::Warehouse: rmin = 5; rmax = 12; pstep = 2; break;
    case Layout::Tunnels: rmin = 2; rmax = 4; break;
    case Layout::Pools: rmin = 4; rmax = 10; break;
    case Layout::Halls: rmin = 2; rmax = 6; break;
    default: break;
  }
  for (int k = 0; k < t.rooms; ++k) {
    int rw = rng.irange(rmin, rmax), rh = rng.irange(rmin, rmax);
    int rx = rng.irange(0, W - 1), rz = rng.irange(0, H - 1);
    bool pillars = rw >= 5 && rh >= 5 && rng.f01() < t.pillarChance;
    bool hasPool = t.pools && rw >= 4 && rh >= 4;
    for (int z = rz; z < rz + rh; ++z)
      for (int x = rx; x < rx + rw; ++x) {
        if (x < rx + rw - 1) setWall(x, z, PX, 0);
        if (z < rz + rh - 1) setWall(x, z, PZ, 0);
        bool inner = x > rx && z > rz && x < rx + rw - 1 && z < rz + rh - 1;
        if (pillars && (x - rx) % pstep == 1 % pstep && (z - rz) % pstep == 1 % pstep && inner) pillar[idx(x, z)] = 1;
        if (hasPool && inner) pool[idx(x, z)] = 1;
      }
  }
  if (t.pools) {  // extra basins scattered through open space
    for (int k = 0; k < 26; ++k) {
      int pw = rng.irange(2, 5), ph = rng.irange(2, 5), px = rng.irange(0, W - 1), pz = rng.irange(0, H - 1);
      for (int z = pz; z < pz + ph; ++z)
        for (int x = px; x < px + pw; ++x) {
          if (x < px + pw - 1) setWall(x, z, PX, 0);
          if (z < pz + ph - 1) setWall(x, z, PZ, 0);
          pool[idx(x, z)] = 1;
        }
    }
  }
  // Pools never contain pillars (keeps the water readable and walkable).
  if (!t.roundPillars) for (int i = 0; i < W * H; ++i) if (pool[i]) pillar[i] = 0;
  ensureConnected();
}

bool Level::isStairwell(int x, int z) const {
  if (solid.empty() || !solid[idx(x, z)]) return false;
  for (const vec3& c : stairwells) {
    int cx = (int)std::lround(c.x / kTile), cz = (int)std::lround(c.z / kTile);
    for (int dz = -1; dz <= 0; ++dz)
      for (int dx = -1; dx <= 0; ++dx)
        if (idx(cx + dx, cz + dz) == idx(x, z)) return true;
  }
  return false;
}

// The Poolrooms: nearly everything flooded, raised tile walkways, round columns standing in the
// water, skylights, spiral stairs up through round holes, tunnels at the waterline, drains.
void Level::poolFeatures(Rng& rng) {
  auto openAll = [&](int x, int z) {
    for (int k = 0; k < 4; ++k) if (blocked(x, z, k)) return false;
    return true;
  };
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      int i = idx(x, z);
      bool walk = (x % 6 == 0) || (z % 7 == 0) || hashf(x / 2, z / 2, (int)seed + 3) < 0.07f;
      pool[i] = walk ? 0 : 1;
    }
  // columns standing in the water, on a loose grid in open rooms
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x)
      if (x % 3 == 1 && z % 3 == 1 && openAll(x, z) && hashf(x, z, (int)seed + 9) < 0.45f) pillar[idx(x, z)] = 1;
  // spiral stairwells: a clear 2x2 block in a big open space
  for (int tries = 0; tries < 400 && stairwells.size() < 3; ++tries) {
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    bool ok = true;
    for (int dz = -1; dz <= 2 && ok; ++dz)
      for (int dx = -1; dx <= 2 && ok; ++dx) {
        int i = idx(x + dx, z + dz);
        if (!openAll(x + dx, z + dz) || solid[i]) ok = false;
        if (dx >= 0 && dx <= 1 && dz >= 0 && dz <= 1 && pillar[i]) ok = false;
      }
    for (const vec3& c : stairwells) {
      float ddx = std::fabs(c.x - (x + 1) * kTile), ddz = std::fabs(c.z - (z + 1) * kTile);
      ddx = std::min(ddx, periodX - ddx); ddz = std::min(ddz, periodZ - ddz);
      if (ddx + ddz < 30.0f) ok = false;
    }
    if (!ok) continue;
    for (int dz = 0; dz <= 1; ++dz)
      for (int dx = 0; dx <= 1; ++dx) {
        int i = idx(x + dx, z + dz);
        solid[i] = 1; pool[i] = 1; pillar[i] = 0;
      }
    stairwells.push_back({(x + 1) * kTile, 0, (z + 1) * kTile});
  }
  // skylight wells
  // skylights: big 4x4 m openings (2x2 tiles) where the ceiling is clear
  for (int z = 0; z < H; z += 2)
    for (int x = 0; x < W; x += 2) {
      if (hashf(x, z, (int)seed + 21) > 0.13f) continue;
      bool ok = true;
      for (int dz = 0; dz <= 1; ++dz)
        for (int dx = 0; dx <= 1; ++dx) {
          int i = idx(x + dx, z + dz);
          if (pillar[i] || solid[i]) ok = false;
        }
      if (!ok) continue;
      for (int dz = 0; dz <= 1; ++dz)
        for (int dx = 0; dx <= 1; ++dx) sky[idx(x + dx, z + dz)] = 1;
    }
  // tunnel mouths in walls that meet the water, and drains on the pool floor
  for (int tries = 0; tries < 3000 && tunnels.size() < 22; ++tries) {
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    if (!pool[idx(x, z)] || solid[idx(x, z)]) continue;
    int d = rng.irange(0, 3);
    if (!blocked(x, z, d) || solidNext(x, z, d)) continue;
    vec3 n{(float)-kDX[d], 0, (float)-kDZ[d]};
    vec3 c = tileCenter(x, z, -0.1f) - n * (kTile * 0.5f - kWallT * 0.5f - 0.006f);
    tunnels.push_back(c);
    tunnelN.push_back(n);
  }
  for (int tries = 0; tries < 2000 && drains.size() < 40; ++tries) {
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    if (!pool[idx(x, z)] || solid[idx(x, z)] || pillar[idx(x, z)]) continue;
    drains.push_back(tileCenter(x, z, -kPoolDepth + 0.006f) + vec3{rng.range(-0.5f, 0.5f), 0, rng.range(-0.5f, 0.5f)});
  }
  // pool floors take the green mosaic (zone 1 picks the second set of surfaces)
  for (int i = 0; i < W * H; ++i) zone[i] = pool[i] ? 1 : 0;
  ensureConnected();
}

// Level Fun: party tables to crawl under, balloon arches over the doorways, bunting on the walls.
void Level::partyFeatures(Rng& rng) {
  auto freeT = [&](int x, int z) {
    int i = idx(x, z);
    if (pillar[i] || pool[i] || solid[i] || !propsAtTile[i].empty()) return false;
    if (std::abs(x - startX) <= 1 && std::abs(z - startZ) <= 1) return false;
    if (x == exitX && z == exitZ) return false;
    return true;
  };
  // tables: plenty of them, so there's always one close when the singing starts
  int placed = 0;
  for (int tries = 0; tries < 4000 && placed < 70; ++tries) {
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    if (!freeT(x, z)) continue;
    // keep a corridor clear: only in tiles with at least three open sides (rooms)
    int open = 0;
    for (int d = 0; d < 4; ++d) open += blocked(x, z, d) ? 0 : 1;
    if (open < 3) continue;
    // face the open front toward the longest open stretch, so from underneath you can see them coming
    int bestD = 0, bestRun = -1;
    for (int d = 0; d < 4; ++d) {
      int run = 0, cx = x, cz = z;
      while (run < 6 && !blocked(cx, cz, d)) { cx += kDX[d]; cz += kDZ[d]; ++run; }
      run = run * 4 + rng.irange(0, 2);
      if (run > bestRun) { bestRun = run; bestD = d; }
    }
    float yaw = std::atan2(-(float)kDX[bestD], -(float)kDZ[bestD]);
    addProp(25, tileCenter(x, z) + vec3{rng.range(-0.2f, 0.2f), 0, rng.range(-0.2f, 0.2f)}, yaw, 0, 0.64f, 0.4f);
    props.back().variant = rng.irange(0, 3);
    ++placed;
  }
  // balloon arches across corridor tiles (walls on two opposite sides)
  int arches = 0;
  for (int z = 0; z < H && arches < 45; ++z)
    for (int x = 0; x < W && arches < 45; ++x) {
      int i = idx(x, z);
      if (pillar[i] || pool[i] || solid[i] || !propsAtTile[i].empty()) continue;
      bool ew = blocked(x, z, PX) && blocked(x, z, NX) && !blocked(x, z, PZ) && !blocked(x, z, NZ);
      bool ns = blocked(x, z, PZ) && blocked(x, z, NZ) && !blocked(x, z, PX) && !blocked(x, z, NX);
      if (!(ew || ns) || hashf(x, z, (int)seed + 41) > 0.28f) continue;
      addProp(26, tileCenter(x, z), ew ? 0.0f : kPi * 0.5f, 0, 0, 0);
      ++arches;
    }
  std::fprintf(stderr, "[liminal] party: %d tables, %d balloon arches\n", placed, arches);
  // bunting high on the walls
  for (int tries = 0; tries < 3000 && bunting.size() < 90; ++tries) {
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    int d = rng.irange(0, 3);
    if (!blocked(x, z, d) || solidNext(x, z, d)) continue;
    vec3 n{(float)-kDX[d], 0, (float)-kDZ[d]};
    bunting.push_back(tileCenter(x, z, wallH - 0.38f) - n * (kTile * 0.5f - kWallT * 0.5f - 0.01f));
    buntingN.push_back(n);
  }
}

void Level::ensureConnected() {
  for (int guard = 0; guard < W * H; ++guard) {
    std::vector<int> d = bfs(0, 0);
    bool fixed = false, all = true;
    for (int i = 0; i < W * H && !fixed; ++i) {
      if (d[i] >= 0) continue;
      all = false;
      int x = i % W, z = i / W;
      for (int dir = 0; dir < 4; ++dir)
        if (d[idx(x + kDX[dir], z + kDZ[dir])] >= 0) { setWall(x, z, dir, 0); fixed = true; break; }
    }
    if (all) return;
  }
}

void Level::placeLights(Rng& rng) {
  const Theme& t = theme;
  struct Zone { float x, z, r; };
  std::vector<Zone> dark;
  auto tdist = [&](float ax, float az, float bx, float bz) {
    float dx = std::fabs(ax - bx), dz = std::fabs(az - bz);
    dx = std::min(dx, W - dx); dz = std::min(dz, H - dz);
    return std::sqrt(dx * dx + dz * dz);
  };
  for (int k = 0; k < t.darkZones; ++k) {
    Zone zn{};
    for (int tries = 0; tries < 50; ++tries) {
      zn = {rng.range(0, (float)W), rng.range(0, (float)H), rng.range(t.darkRadius * 0.7f, t.darkRadius * 1.4f)};
      if (tdist(zn.x, zn.z, (float)startX, (float)startZ) > zn.r + 9) break;
    }
    dark.push_back(zn);
  }
  lights.clear();
  lightAtTile.assign(W * H, -1);
  const int sp = std::max(1, t.lightSpacing);
  for (int z = 0; z < H; z += sp)
    for (int x = 0; x < W; x += sp) {
      if (!solid.empty() && solid[idx(x, z)]) continue;
      if (isSky(x, z)) continue;
      Light L;
      vec3 c = tileCenter(x, z, wallH - 0.02f);
      L.pos = {c.x, c.y, c.z - 0.25f};
      L.id = (int)lights.size();
      L.intensity = rng.range(0.85f, 1.1f) * t.lightIntensity;
      L.phase = rng.range(0, 100);
      float r = rng.f01();
      L.kind = r < t.deadChance ? 2 : (r < t.deadChance + t.flickerChance ? 1 : 0);
      for (auto& zn : dark)
        if (tdist((float)x, (float)z, zn.x, zn.z) < zn.r) L.kind = 2;
      if (std::abs(x - startX) <= sp && std::abs(z - startZ) <= sp) L.kind = t.deadChance > 0.5f ? 1 : 0;  // a lit spawn
      lightAtTile[idx(x, z)] = L.id;
      lights.push_back(L);
    }
  // Daylight spilling down the skylight wells and stairwells: baked bounce, no fixture.
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x)
      if (isSky(x, z)) {
        Light L;
        L.pos = tileCenter(x, z, wallH - 0.05f);
        L.id = (int)lights.size();
        L.intensity = 1.9f * t.lightIntensity;
        lights.push_back(L);
      }
  for (const vec3& c : stairwells) {
    Light L;
    L.pos = {c.x, wallH - 0.05f, c.z};
    L.id = (int)lights.size();
    L.intensity = 2.4f * t.lightIntensity;
    lights.push_back(L);
  }
}

void Level::addProp(int type, vec3 pos, float yaw, float roll, float hx, float hz) {
  PropInstance p;
  p.type = type; p.pos = wrap(pos); p.yaw = yaw; p.roll = roll;
  float c = std::fabs(std::cos(yaw)), s = std::fabs(std::sin(yaw));
  p.halfX = hx * c + hz * s;
  p.halfZ = hx * s + hz * c;
  int tx, tz;
  tileOf(p.pos.x, p.pos.z, tx, tz);
  propsAtTile[idx(tx, tz)].push_back((int)props.size());
  props.push_back(p);
}

// Types follow PropId: 0 chair 1 box 2 bag 3 lantern 4 can 5 cooler.
void Level::placeProps(Rng& rng) {
  const Theme& t = theme;
  props.clear();
  propsAtTile.assign(W * H, {});
  auto freeTile = [&](int& x, int& z) {
    for (int k = 0; k < 60; ++k) {
      x = rng.irange(0, W - 1); z = rng.irange(0, H - 1);
      int i = idx(x, z);
      if (pillar[i] || pool[i] || solid[i] || !propsAtTile[i].empty()) continue;
      if (std::abs(x - startX) <= 1 && std::abs(z - startZ) <= 1) continue;
      if (x == exitX && z == exitZ) continue;
      return true;
    }
    return false;
  };
  auto nearWall = [&](int x, int z, float& yaw) {
    vec3 c = tileCenter(x, z);
    for (int d = 0; d < 4; ++d)
      if (blocked(x, z, d)) {
        c.x += kDX[d] * 0.55f; c.z += kDZ[d] * 0.55f;
        yaw = std::atan2((float)kDX[d], (float)kDZ[d]);
        return c;
      }
    yaw = rng.range(0, 6.28f);
    return c;
  };
  int x, z;
  for (int i = 0; i < t.chairs; ++i) {
    if (!freeTile(x, z)) continue;
    float yaw;
    vec3 p = nearWall(x, z, yaw);
    p.x += rng.range(-0.3f, 0.3f); p.z += rng.range(-0.3f, 0.3f);
    yaw += rng.range(-0.6f, 0.6f);
    if (rng.f01() < 0.3f) addProp(0, {p.x, 0.3f, p.z}, yaw, kPi * 0.5f, 0.45f, 0.4f);
    else addProp(0, p, yaw, 0, 0.3f, 0.3f);
  }
  int maxStack = t.layout == Layout::Warehouse ? 3 : 2;
  for (int i = 0; i < t.boxes; ++i) {
    if (!freeTile(x, z)) continue;
    float yaw;
    vec3 p = nearWall(x, z, yaw);
    int n = rng.irange(1, maxStack + 1);
    for (int k = 0; k < n; ++k) {
      vec3 q = p;
      if (k == 1 || k == 3) q.y = 0.38f;
      if (k >= 2) { q.x += std::cos(yaw) * 0.55f; q.z -= std::sin(yaw) * 0.55f; }
      addProp(1, q, yaw + rng.range(-0.25f, 0.25f), 0, 0.25f, 0.2f);
    }
  }
  for (int i = 0; i < t.coolers; ++i) {
    if (!freeTile(x, z)) continue;
    float yaw;
    vec3 p = nearWall(x, z, yaw);
    addProp(5, p, yaw, 0, 0.19f, 0.19f);
  }
  if (t.camp) {
    std::vector<int> d = bfs(startX, startZ);
    int maxd = *std::max_element(d.begin(), d.end());
    std::vector<int> cands;
    for (int i = 0; i < W * H; ++i)
      if (d[i] >= maxd / 4 && d[i] <= maxd / 2 && !pillar[i] && !pool[i] && propsAtTile[i].empty() && i != idx(exitX, exitZ))
        cands.push_back(i);
    if (!cands.empty()) {
      int c = cands[rng.next() % cands.size()];
      campX = c % W; campZ = c / W;
      vec3 cc = tileCenter(campX, campZ);
      addProp(2, {cc.x - 0.2f, 0, cc.z + 0.35f}, 0.2f, 0, 0, 0);
      addProp(3, {cc.x + 0.55f, 0, cc.z - 0.2f}, 0, 0, 0, 0);
      addProp(4, {cc.x + 0.35f, 0, cc.z - 0.45f}, 1.0f, 0, 0, 0);
      addProp(4, {cc.x + 0.7f, 0.033f, cc.z + 0.1f}, 0.3f, kPi * 0.5f, 0, 0);
      addProp(1, {cc.x - 0.6f, 0, cc.z - 0.55f}, 0.4f, 0, 0.25f, 0.2f);
    }
  }
  // Lockers: somewhere to hide. Backs to a wall, door facing the room.
  for (int i = 0; i < t.lockers; ++i) {
    if (!freeTile(x, z)) continue;
    float yaw = 0;
    int wd = -1;
    for (int d = 0; d < 4; ++d) if (blocked(x, z, d) && !solidNext(x, z, d)) { wd = d; break; }
    if (wd < 0) continue;
    vec3 c = tileCenter(x, z);
    c.x += kDX[wd] * 0.62f; c.z += kDZ[wd] * 0.62f;
    yaw = std::atan2((float)kDX[wd], (float)kDZ[wd]);  // the door (-Z in model space) faces away from the wall
    addProp(11, c, yaw, 0, 0.28f, 0.28f);
  }
  if (t.party) partyFeatures(rng);
  // Furniture caught halfway through a noclip.
  static const int kinds[] = {0, 0, 0, 1, 1, 5, 12};
  for (int i = 0; i < t.anomalies; ++i) {
    if (!freeTile(x, z)) continue;
    int type = kinds[rng.next() % 7];
    int an = rng.irange(1, 5);
    float yaw = rng.range(0, 6.28f);
    vec3 c = tileCenter(x, z);
    if (an == 1) {  // half inside a wall
      int wd = -1;
      for (int d = 0; d < 4; ++d) if (blocked(x, z, d) && !solidNext(x, z, d)) { wd = d; break; }
      if (wd < 0) an = 2;
      else { c.x += kDX[wd] * 0.95f; c.z += kDZ[wd] * 0.95f; c.y = rng.range(0.0f, 0.9f); }
    }
    if (an == 2) c.y = -rng.range(0.2f, 0.45f);
    if (an == 3) c.y = wallH;
    if (an == 4) c.y = rng.range(0.6f, 1.3f);
    addProp(type, c, yaw, an == 3 ? kPi : rng.range(-0.5f, 0.5f) * (an == 1 || an == 2 ? 1.0f : 0.3f), 0, 0);
    props.back().anomaly = an;
    props.back().phase = rng.range(0, 100);
  }
}

// Painted clues. The Survey marks the route to the thin place with arrows on the
// walls (pointing along the real shortest path), writes EXIT on the wall itself,
// warns off dead ends, and leaves the usual graffiti.
void Level::placeDecals(Rng& rng) {
  decals.clear();
  const float y = std::min(1.45f, wallH * 0.5f);
  auto addOnWall = [&](int x, int z, int wallDir, int kind, float w, float h, float yy, vec3 pointAlong, float jitter) {
    vec3 c = tileCenter(x, z, yy);
    vec3 dv = dirVec(wallDir);
    Decal d;
    d.n = -dv;
    d.pos = c + dv * (kTile * 0.5f - kWallT * 0.5f - 0.006f);
    vec3 r = cross(vec3{0, 1, 0}, d.n);
    d.pos += r * jitter;
    d.w = w; d.h = h; d.kind = kind;
    d.flip = dot(r, pointAlong) < 0;
    d.tilt = rng.range(-0.06f, 0.06f);
    decals.push_back(d);
  };
  // The painted route: the cheapest walk to the exit, where wading through deep water
  // and squeezing past pillars cost extra. (The pure shortest path in the Poolrooms ran
  // straight across pools, where no arrow can be painted, so the trail just stopped.)
  std::vector<int> route(W * H, 1 << 29);
  {
    using QE = std::pair<int, int>;
    std::priority_queue<QE, std::vector<QE>, std::greater<QE>> q;
    route[idx(exitX, exitZ)] = 0;
    q.push({0, idx(exitX, exitZ)});
    while (!q.empty()) {
      auto [c, i] = q.top(); q.pop();
      if (c > route[i]) continue;
      int x = i % W, z = i / W;
      for (int d = 0; d < 4; ++d) {
        if (blocked(x, z, d)) continue;
        int n = idx(x + kDX[d], z + kDZ[d]);
        int step = 2 + (pool[n] ? 7 : 0) + (pillar[n] ? 2 : 0);
        if (c + step < route[n]) { route[n] = c + step; q.push({c + step, n}); }
      }
    }
  }
  std::vector<int> path;
  {
    int cx = startX, cz = startZ;
    path.push_back(idx(cx, cz));
    for (int guard = 0; guard < W * H && route[idx(cx, cz)] > 0; ++guard) {
      int best = -1, bc = route[idx(cx, cz)];
      for (int d = 0; d < 4; ++d) {
        if (blocked(cx, cz, d)) continue;
        int c = route[idx(cx + kDX[d], cz + kDZ[d])];
        if (c < bc) { bc = c; best = d; }
      }
      if (best < 0) break;
      cx = wx(cx + kDX[best]); cz = wz(cz + kDZ[best]);
      path.push_back(idx(cx, cz));
    }
  }
  if (std::getenv("LIMINAL_ROUTEDBG")) { int wet = 0; for (int i : path) wet += pool[i]; std::fprintf(stderr, "[route] %zu tiles, %d in water, ends at exit: %d\n", path.size(), wet, path.back() == idx(exitX, exitZ)); }
  std::vector<uint8_t> onPath(W * H, 0);
  for (int i : path) onPath[i] = 1;
  auto stepDir = [&](int a, int b) {
    for (int d = 0; d < 4; ++d)
      if (idx(a % W + kDX[d], a / W + kDZ[d]) == b) return d;
    return 0;
  };
  int since = 99;
  for (size_t i = 0; i + 1 < path.size(); ++i) {
    int t = path[i], x = t % W, z = t / W;
    int d = stepDir(t, path[i + 1]);
    int din = i > 0 ? stepDir(path[i - 1], t) : d;
    bool turn = d != din;
    ++since;
    // Right before a turn, an arrow pointing straight on would point at a wall (or off a balcony):
    // leave it for the turn tile, which always gets one.
    bool turnNext = i + 2 < path.size() && stepDir(path[i + 1], path[i + 2]) != d;
    if (!turn && turnNext) continue;
    if (!turn && since < 3) continue;
    // Walls parallel to the direction of travel; at a turn, prefer the wall you are facing.
    int cands[2], n = 0;
    for (int k = 0; k < 4; ++k) {
      bool perpendicular = (kDX[k] != 0) != (kDX[d] != 0);
      if (perpendicular && blocked(x, z, k) && !solidNext(x, z, k)) cands[n++] = k;
    }
    if (!n) {
      // Open floor: paint the arrow on the carpet/concrete instead.
      if ((since >= 2 || turn || theme.pools) && !pool[t] && !pillar[t]) {
        Decal fd;
        fd.n = {0, 1, 0};
        fd.right = dirVec(d);
        fd.pos = tileCenter(x, z, 0.004f);
        fd.w = theme.pools ? 1.3f : 1.1f; fd.h = theme.pools ? 0.65f : 0.55f;
        fd.kind = DECAL_ARROW;
        fd.tilt = rng.range(-0.1f, 0.1f);
        decals.push_back(fd);
        since = 0;
      }
      continue;
    }
    int wall = cands[0];
    if (n == 2) wall = (turn && (cands[1] == din)) ? cands[1] : (turn && cands[0] == din ? cands[0] : cands[rng.next() % 2]);
    addOnWall(x, z, wall, DECAL_ARROW, 0.95f, 0.48f, y + rng.range(-0.15f, 0.15f), dirVec(d), rng.range(-0.3f, 0.3f));
    since = 0;
  }
  if (std::getenv("LIMINAL_ROUTEDBG")) {  // gaps between arrows along the route
    std::vector<int> marked;
    for (size_t i = 0; i < path.size(); ++i) {
      vec3 c = tileCenter(path[i] % W, path[i] / W);
      for (const Decal& dc : decals) {
        vec3 dd = delta(c, dc.pos);
        if (dc.kind == DECAL_ARROW && std::fabs(dd.x) < 1.05f && std::fabs(dd.z) < 1.05f) { marked.push_back((int)i); break; }
      }
    }
    int last = 0;
    for (int m : marked) { if (m - last > 6) std::fprintf(stderr, "[route] gap %d tiles before path step %d (tile %d,%d)\n", m - last, m, path[m] % W, path[m] / W); last = m; }
    if ((int)path.size() - last > 6) std::fprintf(stderr, "[route] gap %d tiles before the exit\n", (int)path.size() - last);
  }
  // EXIT, painted right over the thin place.
  addOnWall(exitX, exitZ, exitDir, DECAL_EXIT, 1.3f, 0.42f, std::min(2.25f, wallH - 0.35f), {1, 0, 0}, 0);
  // Dead ends off the route.
  for (int i = 0; i < W * H; ++i) {
    if (onPath[i] || pillar[i] || pool[i] || solid[i]) continue;
    int x = i % W, z = i / W, walls = 0, open = 0;
    for (int d = 0; d < 4; ++d) { if (blocked(x, z, d)) ++walls; else open = d; }
    if (walls != 3 || rng.f01() > 0.55f) continue;
    int back = open ^ 1;  // the wall facing the way in
    addOnWall(x, z, back, rng.f01() < 0.6f ? DECAL_NOT_THIS_WAY : DECAL_X, rng.f01() < 0.6f ? 1.5f : 0.7f, 0.5f, y, {1, 0, 0}, 0);
  }
  // Flavour graffiti.
  int phrases = (int)theme.graffiti.size();
  for (int k = 0; k < 18 && phrases > 0; ++k) {
    int x = rng.irange(0, W - 1), z = rng.irange(0, H - 1);
    int d = rng.irange(0, 3);
    if (!blocked(x, z, d) || pillar[idx(x, z)] || solid[idx(x, z)] || solidNext(x, z, d)) continue;
    addOnWall(x, z, d, DECAL_GRAFFITI + rng.irange(0, phrases - 1), 1.5f, 0.38f, y + rng.range(-0.3f, 0.4f), {1, 0, 0}, rng.range(-0.3f, 0.3f));
  }
  bloodTrails(rng);
}

// ---------------------------------------------------------------- queries

std::vector<int> Level::bfs(int sx, int sz) const {
  std::vector<int> d(W * H, -1);
  std::queue<int> q;
  int s = idx(sx, sz);
  d[s] = 0;
  q.push(s);
  while (!q.empty()) {
    int c = q.front(); q.pop();
    int x = c % W, z = c / W;
    for (int dir = 0; dir < 4; ++dir) {
      if (blocked(x, z, dir)) continue;
      int n = idx(x + kDX[dir], z + kDZ[dir]);
      if (d[n] < 0) { d[n] = d[c] + 1; q.push(n); }
    }
  }
  return d;
}

bool Level::nextStep(int sx, int sz, int gx, int gz, int& nx, int& nz) const {
  if (idx(sx, sz) == idx(gx, gz)) { nx = sx; nz = sz; return true; }
  std::vector<int> d = bfs(gx, gz);
  int best = d[idx(sx, sz)];
  if (best < 0) return false;
  nx = sx; nz = sz;
  for (int dir = 0; dir < 4; ++dir) {
    if (blocked(sx, sz, dir)) continue;
    int v = d[idx(sx + kDX[dir], sz + kDZ[dir])];
    if (v >= 0 && v < best) { best = v; nx = wx(sx + kDX[dir]); nz = wz(sz + kDZ[dir]); }
  }
  return true;
}

bool Level::lineOfSight(float ax, float az, float bx, float bz, bool pillarsBlock) const {
  vec3 dd = delta({ax, 0, az}, {bx, 0, bz});
  bx = ax + dd.x; bz = az + dd.z;
  int tx = (int)std::floor(ax / kTile), tz = (int)std::floor(az / kTile);
  int ex = (int)std::floor(bx / kTile), ez = (int)std::floor(bz / kTile);
  float dx = dd.x, dz = dd.z;
  int stepX = dx > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
  float tMaxX = std::fabs(dx) < 1e-6f ? 1e9f : (((tx + (stepX > 0)) * kTile) - ax) / dx;
  float tMaxZ = std::fabs(dz) < 1e-6f ? 1e9f : (((tz + (stepZ > 0)) * kTile) - az) / dz;
  float tDX = std::fabs(dx) < 1e-6f ? 1e9f : kTile / std::fabs(dx);
  float tDZ = std::fabs(dz) < 1e-6f ? 1e9f : kTile / std::fabs(dz);
  float len2 = dx * dx + dz * dz;
  auto pillarHit = [&](int x, int z) {
    if (!pillarsBlock || !hasPillar(x, z)) return false;
    float cx = (x + 0.5f) * kTile, cz = (z + 0.5f) * kTile;
    float t = len2 > 0 ? clampf(((cx - ax) * dx + (cz - az) * dz) / len2, 0, 1) : 0;
    float px = ax + dx * t - cx, pz = az + dz * t - cz;
    return px * px + pz * pz < kPillar * kPillar * 0.8f;
  };
  EdgeView e{*this};
  for (int guard = 0; guard < W + H + 4; ++guard) {
    if (pillarHit(tx, tz)) return false;
    if (tx == ex && tz == ez) return true;
    if (std::fabs(tMaxX - tMaxZ) < 1e-4f && tMaxX <= 1.0f) {
      if (e.post(tx + (stepX > 0), tz + (stepZ > 0))) return false;
      tx += stepX; tz += stepZ; tMaxX += tDX; tMaxZ += tDZ;
      continue;
    }
    if (tMaxX < tMaxZ) {
      if (tMaxX > 1) return true;
      if (blocked(tx, tz, stepX > 0 ? (int)PX : (int)NX)) return false;
      tx += stepX; tMaxX += tDX;
    } else {
      if (tMaxZ > 1) return true;
      if (blocked(tx, tz, stepZ > 0 ? (int)PZ : (int)NZ)) return false;
      tz += stepZ; tMaxZ += tDZ;
    }
  }
  return true;
}

// Boxes around (x, z) in the same (possibly unwrapped) coordinate frame as x, z.
void Level::boxesNear(float x, float z, float r, std::vector<AABB2>& out) const {
  out.clear();
  EdgeView e{*this};
  const float t = kWallT * 0.5f;
  int x0 = (int)std::floor((x - r) / kTile) - 1, x1 = (int)std::floor((x + r) / kTile) + 1;
  int z0 = (int)std::floor((z - r) / kTile) - 1, z1 = (int)std::floor((z + r) / kTile) + 1;
  for (int uz = z0; uz <= z1; ++uz)
    for (int ux = x0; ux <= x1; ++ux) {
      float X = ux * kTile, Z = uz * kTile;
      (void)e;
      // every wall blocks, drawn or not (the store's glass front is drawn separately)
      if (eWall[idx(ux - 1, uz)]) out.push_back({X - t, Z, X + t, Z + kTile});
      if (sWall[idx(ux, uz - 1)]) out.push_back({X, Z - t, X + kTile, Z + t});
      // and so does anything marked solid: the courtyard void past the railing, the edge of the lot
      if (!solid.empty() && solid[idx(ux, uz)]) out.push_back({X, Z, X + kTile, Z + kTile});
      if (hasPillar(ux, uz)) {
        float cx = X + kTile * 0.5f, cz = Z + kTile * 0.5f;
        out.push_back({cx - kPillar, cz - kPillar, cx + kPillar, cz + kPillar});
      }
      float ox = X - wx(ux) * kTile, oz = Z - wz(uz) * kTile;
      for (int pi : propsAtTile[idx(ux, uz)]) {
        const PropInstance& p = props[pi];
        if (p.halfX > 0) out.push_back({p.pos.x + ox - p.halfX, p.pos.z + oz - p.halfZ, p.pos.x + ox + p.halfX, p.pos.z + oz + p.halfZ});
      }
    }
}

void Level::collide(vec3& p, float radius) const {
  std::vector<AABB2> boxes;
  boxesNear(p.x, p.z, radius + 0.5f, boxes);
  for (int iter = 0; iter < 3; ++iter) {
    for (auto& b : boxes) {
      float cx = clampf(p.x, b.x0, b.x1), cz = clampf(p.z, b.z0, b.z1);
      float dx = p.x - cx, dz = p.z - cz;
      float d2 = dx * dx + dz * dz;
      if (d2 >= radius * radius) continue;
      if (d2 > 1e-8f) {
        float d = std::sqrt(d2);
        p.x = cx + dx / d * radius;
        p.z = cz + dz / d * radius;
      } else {
        float l = p.x - b.x0, r = b.x1 - p.x, u = p.z - b.z0, dn = b.z1 - p.z;
        float m = std::min(std::min(l, r), std::min(u, dn));
        if (m == l) p.x = b.x0 - radius; else if (m == r) p.x = b.x1 + radius;
        else if (m == u) p.z = b.z0 - radius; else p.z = b.z1 + radius;
      }
    }
  }
}

float Level::distToSolid(float x, float z) const {
  std::vector<AABB2> boxes;
  boxesNear(x, z, 1.2f, boxes);
  float best = 1e9f;
  for (auto& b : boxes) {
    float dx = std::max(std::max(b.x0 - x, 0.0f), x - b.x1);
    float dz = std::max(std::max(b.z0 - z, 0.0f), z - b.z1);
    best = std::min(best, std::sqrt(dx * dx + dz * dz));
  }
  return best;
}

vec3 Level::exitFaceNormal() const { return -dirVec(exitDir); }

vec3 Level::exitFaceCenter() const {
  vec3 c = tileCenter(exitX, exitZ, wallH * 0.5f);
  return c + dirVec(exitDir) * (kTile * 0.5f - kWallT * 0.5f - 0.01f);
}

// ---------------------------------------------------------------- lighting

void Level::bakeLightmap() {
  lmW = W * (int)kTile * kLmPerMeter;
  lmH = H * (int)kTile * kLmPerMeter;
  lightmap.assign((size_t)lmW * lmH * 4, 0.0f);
  const float R = 9.0f + theme.lightSpacing * 1.5f;
  const float hh = std::max(1.5f, wallH - 0.4f);
  const float h2 = hh * hh;
  const float norm = (1.0f + 0.18f * h2) / (1.0f + 0.18f * 6.25f);  // same peak brightness at any ceiling height
  const int tileR = (int)std::ceil(R / kTile);
  for (int j = 0; j < lmH; ++j)
    for (int i = 0; i < lmW; ++i) {
      float px = (i + 0.5f) / kLmPerMeter, pz = (j + 0.5f) / kLmPerMeter;
      int tx = (int)std::floor(px / kTile), tz = (int)std::floor(pz / kTile);
      int ida = -1, idb = -1;
      float wa = 0, wb = 0, rest = 0;
      for (int uz = tz - tileR; uz <= tz + tileR; ++uz)
        for (int ux = tx - tileR; ux <= tx + tileR; ++ux) {
          int li = lightAtTile[idx(ux, uz)];
          if (li < 0) continue;
          const Light& L = lights[li];
          if (L.kind == 2) continue;
          float lx = L.pos.x + (ux - wx(ux)) * kTile, lz = L.pos.z + (uz - wz(uz)) * kTile;
          float dx = lx - px, dz = lz - pz;
          float dh2 = dx * dx + dz * dz;
          if (dh2 > R * R) continue;
          float w = L.intensity * 2.2f * norm / (1.0f + 0.18f * (dh2 + h2));
          w *= 1.0f - smoothstepf(R * 0.65f, R, std::sqrt(dh2));
          if (w < 0.004f) continue;
          if (!lineOfSight(px, pz, lx, lz, true)) continue;
          if (w > wa) { rest += wb; idb = ida; wb = wa; ida = li; wa = w; }
          else if (w > wb) { rest += wb; idb = li; wb = w; }
          else rest += w;
        }
      float* t = &lightmap[((size_t)j * lmW + i) * 4];
      if (idb < 0 && ida >= 0) idb = ida;
      t[0] = (float)std::max(ida, 0); t[1] = wa;
      t[2] = (float)std::max(idb, 0); t[3] = wb + rest;
    }
}

float Level::lmTexel(int i, int j, const std::vector<float>& st) const {
  i = ((i % lmW) + lmW) % lmW;
  j = ((j % lmH) + lmH) % lmH;
  const float* t = &lightmap[((size_t)j * lmW + i) * 4];
  return t[1] * st[(size_t)t[0]] + t[3] * st[(size_t)t[2]];
}

float Level::lightAt(float x, float z, const std::vector<float>& st) const {
  float fx = x * kLmPerMeter - 0.5f, fz = z * kLmPerMeter - 0.5f;
  int i = (int)std::floor(fx), j = (int)std::floor(fz);
  float ax = fx - i, az = fz - j;
  float a = lmTexel(i, j, st), b = lmTexel(i + 1, j, st), c = lmTexel(i, j + 1, st), d = lmTexel(i + 1, j + 1, st);
  return lerpf(lerpf(a, b, ax), lerpf(c, d, ax), az);
}

// ---------------------------------------------------------------- meshes

void Level::buildChunks(std::vector<ChunkMeshes>& out) const {
  int cw = (W + kChunk - 1) / kChunk, ch = (H + kChunk - 1) / kChunk;
  out.assign((size_t)cw * ch, {});
  for (int cz = 0; cz < ch; ++cz)
    for (int cx = 0; cx < cw; ++cx) {
      ChunkMeshes& m = out[(size_t)cz * cw + cx];
      m.center = {(cx + 0.5f) * kChunk * kTile, wallH * 0.5f, (cz + 0.5f) * kChunk * kTile};
      for (int z = cz * kChunk; z < std::min(H, (cz + 1) * kChunk); ++z)
        for (int x = cx * kChunk; x < std::min(W, (cx + 1) * kChunk); ++x) buildTile(x, z, m);
    }
}

void Level::buildTile(int x, int z, ChunkMeshes& M) const {
  if (!zone.empty() && zone[idx(x, z)] == 3) return;  // open air: the atrium, outside the store
  EdgeView e{*this};
  const vec3 up{0, 1, 0};
  const float t = kWallT * 0.5f;
  const Theme& th = theme;
  bool baseboards = th.wall == Surf::Wallpaper || th.wall == Surf::DarkWallpaper;
  bool outlets = th.layout == Layout::Office || th.layout == Layout::Halls || th.layout == Layout::Warehouse || th.layout == Layout::Store;
  auto zoneOf = [&](int tx, int tz) { return zone.empty() ? 0 : (int)zone[idx(tx, tz)]; };
  Mesh* wallMesh = &M.walls;
  int faceZone = 0;
  float faceY0 = 0.0f;
  auto facing = [&](int tx, int tz) {
    faceZone = zoneOf(tx, tz);
    wallMesh = faceZone ? &M.walls2 : &M.walls;
    faceY0 = (!pool.empty() && isPool(tx, tz)) ? -kPoolDepth : 0.0f;  // walls run down into the water
  };

  auto cylinder = [&](vec3 a, vec3 b, float r, float pal) {
    vec3 ax = normalize(b - a);
    vec3 u = std::fabs(ax.y) > 0.9f ? vec3{1, 0, 0} : vec3{0, 1, 0};
    vec3 s1 = normalize(cross(ax, u)), s2 = cross(ax, s1);
    const int N = 8;
    for (int k = 0; k < N; ++k) {
      float a0 = k * 2 * kPi / N, a1 = (k + 1) * 2 * kPi / N;
      vec3 n0 = s1 * std::cos(a0) + s2 * std::sin(a0), n1 = s1 * std::cos(a1) + s2 * std::sin(a1);
      vec3 nm = normalize(n0 + n1);
      M.trim.quad(a + n0 * r, a + n1 * r, b + n1 * r, b + n0 * r, nm, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, pal);
    }
  };

  auto face = [&](vec3 centerBottom, vec3 n, float halfW, float y0, float y1, bool decor) {
    vec3 r = cross(up, n);
    vec3 a = centerBottom - r * halfW, b = centerBottom + r * halfW;
    const float ys[4] = {y0, y0 + 0.35f, y1 - 0.25f, y1};
    const float ao[4] = {0.50f, 0.95f, 1.0f, 0.72f};
    float ua = dot(a, r), ub = dot(b, r);
    for (int s = 0; s < 3; ++s) {
      vec3 a0{a.x, ys[s], a.z}, b0{b.x, ys[s], b.z}, b1{b.x, ys[s + 1], b.z}, a1{a.x, ys[s + 1], a.z};
      wallMesh->quad(a0, b0, b1, a1, n, {ua, ys[s]}, {ub, ys[s]}, {ub, ys[s + 1]}, {ua, ys[s + 1]}, ao[s], ao[s], ao[s + 1], ao[s + 1]);
    }
    if (!decor) return;
    if (baseboards || (th.layout == Layout::Store && faceZone == 0)) {
      const float bh = 0.09f, bd = 0.012f;
      vec3 o = n * bd;
      M.trim.quad(a + o, b + o, b + o + up * bh, a + o + up * bh, n, {ua, 0}, {ub, 0}, {ub, bh}, {ua, bh}, 0.55f, 0.55f, 0.85f, 0.85f, 0);
      M.trim.quad(a + up * bh + o, b + up * bh + o, b + up * bh, a + up * bh, up, {ua, 0}, {ub, 0}, {ub, bd}, {ua, bd}, 0.9f, 0.9f, 0.8f, 0.8f, 0);
    }
    if (outlets && halfW > 0.5f && hashf((int)(centerBottom.x * 10), (int)(centerBottom.z * 10), 77) < 0.08f) {
      vec3 c = centerBottom + r * (hashf((int)(centerBottom.x * 7), (int)(centerBottom.z * 7)) - 0.5f) * halfW + up * 0.32f + n * 0.006f;
      vec3 rr = r * 0.035f, uu = up * 0.058f;
      M.trim.quad(c - rr - uu, c + rr - uu, c + rr + uu, c - rr + uu, n, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, 2);
      for (int k = -1; k <= 1; k += 2) {
        vec3 sc = c + up * (0.022f * k) + n * 0.001f;
        M.trim.quad(sc - r * 0.012f - up * 0.006f, sc + r * 0.012f - up * 0.006f, sc + r * 0.012f + up * 0.006f, sc - r * 0.012f + up * 0.006f, n,
                    {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, 4);
      }
    }
    if ((th.pipes || faceZone == 2) && halfW > 0.5f) {
      // Two runs along the wall near the ceiling, sometimes a riser.
      cylinder(a + n * 0.13f + up * (wallH - 0.28f), b + n * 0.13f + up * (wallH - 0.28f), 0.07f, 5);
      cylinder(a + n * 0.1f + up * (wallH - 0.52f), b + n * 0.1f + up * (wallH - 0.52f), 0.042f, 6);
      if (hashf((int)(centerBottom.x * 3), (int)(centerBottom.z * 3), 41) < 0.25f) {
        vec3 c = centerBottom + r * 0.3f + n * 0.09f;
        cylinder(c, c + up * (wallH - 0.28f), 0.05f, 5);
      }
    }
  };

  float X = x * kTile, Z = z * kTile;
  // Walls on this tile's west (x line) and north (z line) edges, both sides.
  if (e.v(x, z)) {
    float mz = Z + kTile * 0.5f, hw = kTile * 0.5f - t;
    facing(x, z);
    face({X + t, 0, mz}, {1, 0, 0}, hw, faceY0, wallH, true);
    facing(x - 1, z);
    face({X - t, 0, mz}, {-1, 0, 0}, hw, faceY0, wallH, true);
  }
  if (e.h(x, z)) {
    float mx = X + kTile * 0.5f, hw = kTile * 0.5f - t;
    facing(x, z);
    face({mx, 0, Z + t}, {0, 0, 1}, hw, faceY0, wallH, true);
    facing(x, z - 1);
    face({mx, 0, Z - t}, {0, 0, -1}, hw, faceY0, wallH, true);
  }
  facing(x, z);
  if (e.post(x, z)) {
    if (!e.h(x, z)) face({X + t, 0, Z}, {1, 0, 0}, t, 0, wallH, false);
    if (!e.h(x - 1, z)) face({X - t, 0, Z}, {-1, 0, 0}, t, 0, wallH, false);
    if (!e.v(x, z)) face({X, 0, Z + t}, {0, 0, 1}, t, 0, wallH, false);
    if (!e.v(x, z - 1)) face({X, 0, Z - t}, {0, 0, -1}, t, 0, wallH, false);
  }
  if (hasPillar(x, z) && th.roundPillars) {
    // a tiled column, standing in the water if there is any
    vec3 c{X + kTile * 0.5f, 0, Z + kTile * 0.5f};
    const float R = 0.43f, y0 = isPool(x, z) ? -kPoolDepth : 0.0f;
    const int N = 28;
    for (int k = 0; k < N; ++k) {
      float a0 = k * 2 * kPi / N, a1 = (k + 1) * 2 * kPi / N;
      vec3 n0{std::cos(a0), 0, std::sin(a0)}, n1{std::cos(a1), 0, std::sin(a1)};
      vec3 p0 = c + n0 * R, p1 = c + n1 * R;
      float u0 = a0 * R, u1 = a1 * R;
      // two bands so the AO darkens toward the floor
      const float ys[3] = {y0, y0 + 0.5f, wallH};
      const float ao[3] = {0.55f, 0.95f, 0.9f};
      for (int b = 0; b < 2; ++b)
        M.walls.quad({p1.x, ys[b], p1.z}, {p0.x, ys[b], p0.z}, {p0.x, ys[b + 1], p0.z}, {p1.x, ys[b + 1], p1.z}, normalize(n0 + n1),
                     {u1, ys[b]}, {u0, ys[b]}, {u0, ys[b + 1]}, {u1, ys[b + 1]}, ao[b], ao[b], ao[b + 1], ao[b + 1]);
    }
  } else if (hasPillar(x, z)) {
    vec3 c{X + kTile * 0.5f, 0, Z + kTile * 0.5f};
    face({c.x + kPillar, 0, c.z}, {1, 0, 0}, kPillar, 0, wallH, false);
    face({c.x - kPillar, 0, c.z}, {-1, 0, 0}, kPillar, 0, wallH, false);
    face({c.x, 0, c.z + kPillar}, {0, 0, 1}, kPillar, 0, wallH, false);
    face({c.x, 0, c.z - kPillar}, {0, 0, -1}, kPillar, 0, wallH, false);
  }

  if (zoneOf(x, z) == 4) return;  // outside the building: its wall, nothing else
  // Floor (sunken for pools), ceiling, water.
  bool pl = isPool(x, z);
  float fy = pl ? -kPoolDepth : 0.0f;
  const int res = 4;
  const float step = kTile / res;
  float aoGrid[res + 1][res + 1];
  for (int j = 0; j <= res; ++j)
    for (int i = 0; i <= res; ++i) aoGrid[j][i] = 0.42f + 0.58f * smoothstepf(0.0f, 0.75f, distToSolid(X + i * step, Z + j * step));
  for (int j = 0; j < res; ++j)
    for (int i = 0; i < res; ++i) {
      float x0 = X + i * step, x1 = x0 + step, z0 = Z + j * step, z1 = z0 + step;
      float a00 = aoGrid[j][i], a10 = aoGrid[j][i + 1], a01 = aoGrid[j + 1][i], a11 = aoGrid[j + 1][i + 1];
      float fa = pl ? 0.85f : 1.0f;
      (zoneOf(x, z) ? M.floor2 : M.floor).quad({x0, fy, z1}, {x1, fy, z1}, {x1, fy, z0}, {x0, fy, z0}, {0, 1, 0}, {x0, z1}, {x1, z1}, {x1, z0}, {x0, z0},
                   a01 * fa, a11 * fa, a10 * fa, a00 * fa);
      auto cao = [](float a) { return 0.55f + 0.45f * a; };
      float y = wallH;
      if (isSky(x, z) || isStairwell(x, z)) continue;  // open to the light above
      (zoneOf(x, z) ? M.ceiling2 : M.ceiling).quad({x0, y, z0}, {x1, y, z0}, {x1, y, z1}, {x0, y, z1}, {0, -1, 0},
                     {x0 + 0.25f, z0 + 0.25f}, {x1 + 0.25f, z0 + 0.25f}, {x1 + 0.25f, z1 + 0.25f}, {x0 + 0.25f, z1 + 0.25f},
                     cao(a00), cao(a10), cao(a11), cao(a01));
    }
  if (isSky(x, z)) {  // the skylight well: four tiled walls going up into the light
    float y0 = wallH, y1 = wallH + kSkyWell;
    vec3 cs[4] = {{X, 0, Z}, {X + kTile, 0, Z}, {X + kTile, 0, Z + kTile}, {X, 0, Z + kTile}};
    const int nbx[4] = {0, 1, 0, -1}, nbz[4] = {-1, 0, 1, 0};  // the neighbour across each edge
    for (int k = 0; k < 4; ++k) {
      if (isSky(x + nbx[k], z + nbz[k])) continue;  // one big opening, no wall between
      vec3 a = cs[k], b = cs[(k + 1) % 4];
      vec3 mid = (a + b) * 0.5f, cc{X + kTile * 0.5f, 0, Z + kTile * 0.5f};
      vec3 n = normalize(cc - mid);
      vec3 r = cross(up, n);
      float ua = dot(a, r), ub = dot(b, r);
      M.walls.quad({a.x, y0, a.z}, {b.x, y0, b.z}, {b.x, y1, b.z}, {a.x, y1, a.z}, n, {ua, y0}, {ub, y0}, {ub, y1}, {ua, y1}, 0.8f, 0.8f, 1, 1);
    }
  }
  if (pl) {
    float wy = -0.1f;
    M.water.quad({X, wy, Z + kTile}, {X + kTile, wy, Z + kTile}, {X + kTile, wy, Z}, {X, wy, Z}, {0, 1, 0},
                 {X, Z + kTile}, {X + kTile, Z + kTile}, {X + kTile, Z}, {X, Z}, 1, 1, 1, 1);
    // Pool walls where the floor steps up to a dry neighbour.
    for (int d = 0; d < 4; ++d) {
      if (isPool(x + kDX[d], z + kDZ[d])) continue;
      vec3 c = vec3{X + kTile * 0.5f, 0, Z + kTile * 0.5f} + dirVec(d) * (kTile * 0.5f - (blocked(x, z, d) ? t : 0.0f));
      vec3 n = -dirVec(d);
      vec3 r = cross(up, n);
      vec3 a = c - r * (kTile * 0.5f), b = c + r * (kTile * 0.5f);
      float ua = dot(a, r), ub = dot(b, r);
      M.walls.quad(vec3{a.x, -kPoolDepth, a.z}, vec3{b.x, -kPoolDepth, b.z}, vec3{b.x, 0, b.z}, vec3{a.x, 0, a.z}, n,
                   {ua, -kPoolDepth}, {ub, -kPoolDepth}, {ub, 0}, {ua, 0}, 0.55f, 0.55f, 0.9f, 0.9f);
      // a lip of coping tiles
      M.trim.quad(vec3{a.x, 0.004f, a.z}, vec3{b.x, 0.004f, b.z}, vec3{b.x, 0.004f, b.z} - n * 0.12f, vec3{a.x, 0.004f, a.z} - n * 0.12f,
                  up, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, 2);
    }
  }

  // Light fixture with a metal frame.
  int li = lightAtTile[idx(x, z)];
  if (li >= 0) {
    const Light& L = lights[li];
    float hw = th.panelW * 0.5f, hl = th.panelL * 0.5f;
    float x0 = L.pos.x - hw, x1 = L.pos.x + hw, z0 = L.pos.z - hl, z1 = L.pos.z + hl;
    float y = wallH - 0.012f;
    M.panels.quad({x0, y, z0}, {x1, y, z0}, {x1, y, z1}, {x0, y, z1}, {0, -1, 0}, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, (float)L.id);
    const float fw = 0.035f, fy2 = wallH - 0.03f;
    auto flat = [&](float ax, float az, float bx, float bz) {
      M.trim.quad({ax, fy2, az}, {bx, fy2, az}, {bx, fy2, bz}, {ax, fy2, bz}, {0, -1, 0}, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, 1);
    };
    flat(x0 - fw, z0 - fw, x1 + fw, z0);
    flat(x0 - fw, z1, x1 + fw, z1 + fw);
    flat(x0 - fw, z0, x0, z1);
    flat(x1, z0, x1 + fw, z1);
    auto side = [&](vec3 a, vec3 b, vec3 nn) {
      M.trim.quad(a, b, b + vec3{0, 0.03f, 0}, a + vec3{0, 0.03f, 0}, nn, {0, 0}, {1, 0}, {1, 1}, {0, 1}, 0.7f, 0.7f, 1, 1, 1);
    };
    side({x1 + fw, fy2, z0 - fw}, {x0 - fw, fy2, z0 - fw}, {0, 0, -1});
    side({x0 - fw, fy2, z1 + fw}, {x1 + fw, fy2, z1 + fw}, {0, 0, 1});
    side({x0 - fw, fy2, z0 - fw}, {x0 - fw, fy2, z1 + fw}, {-1, 0, 0});
    side({x1 + fw, fy2, z1 + fw}, {x1 + fw, fy2, z0 - fw}, {1, 0, 0});
  } else if (th.ceiling == Surf::CeilingTiles && hashf(x, z, (int)seed) < 0.12f) {
    // Air return vent.
    vec3 c{X + kTile * 0.5f + 0.5f, wallH - 0.005f, Z + kTile * 0.5f + 0.5f};
    float h = 0.24f;
    M.trim.quad({c.x - h, c.y, c.z - h}, {c.x + h, c.y, c.z - h}, {c.x + h, c.y, c.z + h}, {c.x - h, c.y, c.z + h}, {0, -1, 0},
                {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, 3);
    for (int k = 0; k < 9; ++k) {
      float zz = c.z - h + 0.03f + k * (2 * h - 0.06f) / 8.0f;
      M.trim.quad({c.x - h + 0.02f, c.y - 0.004f, zz - 0.006f}, {c.x + h - 0.02f, c.y - 0.004f, zz - 0.006f},
                  {c.x + h - 0.02f, c.y - 0.004f, zz + 0.006f}, {c.x - h + 0.02f, c.y - 0.004f, zz + 0.006f}, {0, -1, 0},
                  {0, 0}, {1, 0}, {1, 1}, {0, 1}, 1, 1, 1, 1, 1);
    }
  }
}

// ---------------------------------------------------------------- the Quik-Stop
//
//   z=2  ##########  front wall: windows, glass door at x=6
//        F . . . . . . . C K     F freezers, C counter, K clerk
//        F S S S S S S . . .     S shelf gondolas (aisles at z=3,5,7)
//        F . . . . . . . . .
//        F S S S S S S . . .
//   z=8  F . . . . . . . . .
//   z=9  D . . . . . . . . L     back room (zone 1), D basement door, L locker
//   z=10 . B B . . . P . . .     B boxes, P phone       basement (zone 2): x 13-14, z 3-7
void Level::generateStore(Rng& rng) {
  eWall.assign(W * H, 0);
  sWall.assign(W * H, 0);
  pillar.assign(W * H, 0);
  pool.assign(W * H, 0);
  props.clear();
  propsAtTile.assign(W * H, {});
  decals.clear();
  store = StoreSpots();
  auto inside = [](int x, int z) { return (x >= 2 && x <= 11 && z >= 2 && z <= 10) || (x >= 13 && x <= 14 && z >= 3 && z <= 7); };
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) solid[idx(x, z)] = inside(x, z) ? 0 : 1;
  // Building shell, back-room partition (doorway at x=10), and the basement.
  for (int z = 2; z <= 10; ++z) { setWall(2, z, NX, 1); setWall(11, z, PX, 1); }
  for (int x = 2; x <= 11; ++x) { setWall(x, 2, NZ, 1); setWall(x, 10, PZ, 1); if (x != 10) setWall(x, 8, PZ, 1); }
  for (int z = 3; z <= 7; ++z) { setWall(13, z, NX, 1); setWall(14, z, PX, 1); }
  for (int x = 13; x <= 14; ++x) { setWall(x, 3, NZ, 1); setWall(x, 7, PZ, 1); }
  for (int x = 2; x <= 11; ++x) for (int z = 9; z <= 10; ++z) zone[idx(x, z)] = 1;
  for (int x = 13; x <= 14; ++x) for (int z = 3; z <= 7; ++z) zone[idx(x, z)] = 2;
  // The front is glass (drawn by the game) with a door you can walk out of. Everything that
  // isn't the building is open air: no floors or ceilings of its own, so the lot and the sky show.
  for (int x = 2; x <= 11; ++x) setWall(x, 2, NZ, x == 6 ? 0 : 2);  // invisible: the glass is drawn separately
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x)
      if (!inside(x, z)) zone[idx(x, z)] = 3;
  // Tiles that own the building's outer walls draw the walls but nothing else.
  for (int z = 2; z <= 10; ++z) zone[idx(12, z)] = 4;
  for (int x = 2; x <= 11; ++x) zone[idx(x, 11)] = 4;
  for (int z = 3; z <= 7; ++z) zone[idx(15, z)] = 4;
  for (int x = 13; x <= 14; ++x) zone[idx(x, 8)] = 4;
  // The lot and Route 9 are walkable (x -16..44 m, z -36..4 m); past that, you can't leave.
  for (int z = -18; z <= 1; ++z)
    for (int x = -8; x <= 21; ++x) solid[idx(x, z)] = 0;

  auto C = [&](int x, int z, float y = 0) { return tileCenter(x, z, y); };
  // Shelving gondolas (types follow PropId: 6 shelf, 7 counter, 8 freezer, 9 panel, 10 boiler, 11 locker, 12 cart).
  for (int row : {4, 6})
    for (int x = 3; x <= 8; ++x) {
      solid[idx(x, row)] = 1;
      addProp(6, C(x, row), 0, 0, 1.0f, 0.46f);
      props.back().variant = rng.irange(0, 5);
    }
  // Freezers along the west wall, glass facing the aisle.
  for (int z = 3; z <= 7; ++z) {
    solid[idx(2, z)] = 1;
    for (int k = -1; k <= 1; k += 2) {
      vec3 c = C(2, z);
      addProp(8, {4.0f + kWallT * 0.5f + 0.42f, 0, c.z + k * 0.5f}, -kPi * 0.5f, 0, 0.42f, 0.5f);
    }
  }
  // Counter with register; the clerk stands east of it.
  solid[idx(10, 3)] = 1;
  addProp(7, C(10, 3), kPi * 0.5f, 0, 0.38f, 1.0f);
  store.registerPos = C(10, 3, 1.02f) + vec3{0.15f, 0, 0};
  store.counterClerk = C(11, 3) + vec3{-0.55f, 0, 0};
  store.clerkYaw = kPi * 0.5f;  // facing west, toward the customers
  store.counterCustomer = C(9, 3) + vec3{0.35f, 0, 0};
  store.flashlight = C(11, 3, 0.0f) + vec3{0.35f, 0, -0.75f};
  // Carts by the door.
  addProp(12, C(3, 2) + vec3{0, 0, -0.2f}, 0.15f, 0, 0.35f, 0.5f);
  addProp(12, C(4, 2) + vec3{-0.5f, 0, -0.2f}, 0.1f, 0, 0.35f, 0.5f);
  // Back room: stock, a locker, the phone, the basement door.
  for (int x : {3, 4, 7}) {
    solid[idx(x, 10)] = 1;
    vec3 c = C(x, 10) + vec3{0, 0, 0.35f};
    addProp(1, c, 0.1f, 0, 0.25f, 0.2f);
    addProp(1, c + vec3{0.55f, 0, 0}, -0.1f, 0, 0.25f, 0.2f);
    addProp(1, c + vec3{0.2f, 0.38f, 0}, 0.3f, 0, 0.25f, 0.2f);
  }
  addProp(11, C(11, 9) + vec3{0.6f, 0, 0.3f}, kPi * 0.5f, 0, 0.27f, 0.27f);
  store.phone = C(8, 10, 1.45f) + vec3{0, 0, kTile * 0.5f - kWallT * 0.5f - 0.05f};
  store.boxPickup = C(6, 9) + vec3{0, 0, 0.6f};
  store.basementDoor = C(2, 9, 1.05f) + vec3{-(kTile * 0.5f - kWallT * 0.5f - 0.01f), 0, 0};
  store.backFromBasement = C(2, 9) + vec3{0.3f, 0, 0};
  // Basement: boiler, breaker panel on the east wall, arrival at the stairs.
  solid[idx(13, 3)] = 1;
  addProp(10, C(13, 3), 0.3f, 0, 0.45f, 0.45f);
  store.breaker = C(14, 5, 1.45f) + vec3{kTile * 0.5f - kWallT * 0.5f - 0.07f, 0, 0};
  addProp(9, {store.breaker.x, 0, store.breaker.z}, kPi * 0.5f, 0, 0, 0);
  store.basementArrive = C(13, 7) + vec3{0, 0, 0.3f};
  store.basementYaw = 0;  // looking north into the basement
  // Front: door at x=6, windows either side.
  store.door = C(6, 2) + vec3{0, 0, -0.4f};
  store.windows.push_back(C(6, 2, 1.15f) + vec3{0, 0, -(kTile * 0.5f - kWallT * 0.5f - 0.01f)});
  for (int x : {3, 4, 5, 7, 8, 9, 10, 11})
    store.windows.push_back(C(x, 2, 1.55f) + vec3{0, 0, -(kTile * 0.5f - kWallT * 0.5f - 0.01f)});
  store.exitSign = C(6, 2, 2.65f) + vec3{0, 0, -(kTile * 0.5f - kWallT * 0.5f - 0.02f)};
  // Where customers browse, where things go on shelves, where people spill things.
  for (int z : {3, 5, 7})
    for (int x = 3; x <= 8; ++x) {
      store.browse.push_back(C(x, z));
      store.browseYaw.push_back(z == 7 ? 0.0f : kPi);
      store.spills.push_back(C(x, z) + vec3{rng.range(-0.4f, 0.4f), 0, rng.range(-0.3f, 0.3f)});
    }
  for (int row : {4, 6})
    for (int x = 3; x <= 8; ++x)
      for (int side = -1; side <= 1; side += 2) store.shelfSlots.push_back(C(x, row, 0.95f) + vec3{rng.range(-0.5f, 0.5f), 0, side * 0.5f});

  // Lights: a grid over the sales floor, two in back, one bare fixture in the basement,
  // and battery emergency lights that only come on when the power dies.
  lights.clear();
  lightAtTile.assign(W * H, -1);
  auto addLight = [&](int x, int z, int kind, float inten) {
    Light L;
    vec3 c = C(x, z, wallH - 0.02f);
    L.pos = {c.x, c.y, c.z - 0.25f};
    L.id = (int)lights.size();
    L.kind = kind;
    L.intensity = inten;
    L.phase = rng.range(0, 100);
    lightAtTile[idx(x, z)] = L.id;
    lights.push_back(L);
    return L.id;
  };
  for (int z : {3, 5, 7})
    for (int x : {3, 5, 7, 9, 11}) addLight(x, z, 0, theme.lightIntensity);
  addLight(4, 9, 0, 1.0f);
  addLight(9, 10, 0, 1.0f);
  addLight(14, 5, 0, 0.8f);
  store.emergencyLights.push_back(addLight(6, 2, 3, 0.9f));
  store.emergencyLights.push_back(addLight(11, 9, 3, 0.9f));
  store.emergencyLights.push_back(addLight(13, 6, 3, 0.7f));

  // Signage.
  auto sign = [&](vec3 pos, vec3 n, float w, float h, int phrase) {
    Decal d;
    d.pos = pos; d.n = n; d.w = w; d.h = h; d.kind = DECAL_GRAFFITI + phrase;
    decals.push_back(d);
  };
  float off = kTile * 0.5f - kWallT * 0.5f - 0.006f;
  sign(C(9, 8, 2.55f) + vec3{0, 0, off}, {0, 0, -1}, 1.6f, 0.3f, 0);                    // EMPLOYEES ONLY
  sign(store.basementDoor + vec3{0.01f, 1.35f, 0}, {1, 0, 0}, 1.1f, 0.25f, 1);          // BASEMENT
  sign(C(2, 5, 2.7f) + vec3{-off, 0, 0}, {1, 0, 0}, 2.2f, 0.4f, 4);                     // FROZEN FOODS
  sign(C(11, 5, 2.6f) + vec3{off, 0, 0}, {-1, 0, 0}, 2.6f, 0.55f, 5);                   // QUIK-STOP
  sign(C(11, 7, 1.75f) + vec3{off, 0, 0}, {-1, 0, 0}, 1.3f, 0.26f, 6);                  // MISSING: THEO KERR
  sign(C(11, 7, 1.45f) + vec3{off, 0, 0}, {-1, 0, 0}, 1.2f, 0.22f, 7);                  // LAST SEEN 10/24/96
  sign(C(6, 10, 1.6f) + vec3{0, 0, off}, {0, 0, -1}, 1.3f, 0.26f, 6);
  startX = 11; startZ = 3;
  exitX = 14; exitZ = 5; exitDir = PX;
  exitDist.assign(W * H, 0);
}

// Dana's apartment: one living room (x 2..5, z 2..4), a kitchenette (x 6, z 3..4).
void Level::generateApartment(Rng& rng) {
  eWall.assign(W * H, 0);
  sWall.assign(W * H, 0);
  pillar.assign(W * H, 0);
  pool.assign(W * H, 0);
  props.clear();
  propsAtTile.assign(W * H, {});
  decals.clear();
  apt = AptSpots();
  auto inside = [](int x, int z) { return (x >= 2 && x <= 5 && z >= 2 && z <= 4) || (x == 6 && z >= 3 && z <= 4); };
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) solid[idx(x, z)] = inside(x, z) ? 0 : 1;
  for (int z = 2; z <= 4; ++z) setWall(2, z, NX, 1);
  setWall(5, 2, PX, 1);
  for (int z = 3; z <= 4; ++z) setWall(6, z, PX, 1);
  for (int x = 2; x <= 5; ++x) setWall(x, 2, NZ, 1);
  setWall(6, 3, NZ, 1);
  for (int x = 2; x <= 6; ++x) setWall(x, 4, PZ, 1);
  for (int z = 3; z <= 4; ++z) zone[idx(6, z)] = 1;
  auto C = [&](int x, int z, float y = 0) { return tileCenter(x, z, y); };
  float off = kTile * 0.5f - kWallT * 0.5f;
  // TV on the west wall, couch facing it, table between, lamp in the corner.
  vec3 tvBase = C(2, 3) + vec3{-off + 0.3f, 0, 0.4f};
  addProp(14, tvBase, -kPi * 0.5f, 0, 0.3f, 0.7f);
  apt.tvScreen = tvBase + vec3{0.225f, 0.74f, 0};
  apt.tvNormal = {1, 0, 0};
  vec3 couch = C(4, 3) + vec3{0.4f, 0, 0.4f};
  addProp(13, couch, kPi * 0.5f, 0, 0.45f, 1.05f);
  addProp(15, C(3, 3) + vec3{0.4f, 0, 0.4f}, kPi * 0.5f, 0, 0.3f, 0.5f);
  addProp(16, C(5, 4) + vec3{0.55f, 0, 0.55f}, 0, 0, 0.15f, 0.15f);
  addProp(1, C(5, 2) + vec3{0.5f, 0, -0.4f}, 0.2f, 0, 0.25f, 0.2f);   // a box you never unpacked
  addProp(7, C(6, 4) + vec3{0.45f, 0, 0}, -kPi * 0.5f, 0, 0.38f, 1.0f);
  apt.couchEye = couch + vec3{0.05f, 1.12f, 0};
  apt.couchYaw = kPi * 0.5f;  // looking west, at the TV
  apt.cornerEye = C(5, 4, 1.75f) + vec3{0.6f, 0, 0.6f};
  apt.cornerYaw = std::atan2(0.85f, 0.75f);  // toward the north-west corner
  apt.wallEye = C(3, 4, 1.5f) + vec3{0, 0, off - 0.45f};
  apt.wallNormal = {0, 0, -1};
  apt.wallYaw = kPi;  // facing +z: the south wall
  apt.doorEye = C(5, 3, 1.62f);
  for (int x : {3, 4}) apt.windows.push_back(C(x, 2, 1.45f) + vec3{0, 0, -off + 0.004f});
  apt.windowCenter = (apt.windows[0] + apt.windows[1]) * 0.5f;
  lights.clear();
  lightAtTile.assign(W * H, -1);
  auto addLight = [&](int x, int z, float inten) {
    Light L;
    vec3 c = C(x, z, wallH - 0.02f);
    L.pos = {c.x + 1.0f, c.y, c.z};
    L.id = (int)lights.size();
    L.kind = 0;
    L.intensity = inten;
    L.phase = rng.range(0, 100);
    lightAtTile[idx(x, z)] = L.id;
    lights.push_back(L);
  };
  addLight(3, 3, theme.lightIntensity);
  addLight(6, 3, theme.lightIntensity * 0.6f);
  startX = 4; startZ = 3;
  exitX = 2; exitZ = 2; exitDir = NZ;
  exitDist.assign(W * H, 0);
}

// Level 188: an open atrium in the middle of the hotel corridors, ringed by a balcony.
void Level::carveCourtyard(Rng& rng) {
  int n = theme.courtyard;
  int x0 = W / 2 - n / 2, z0 = H / 2 - n / 2;
  court.on = true; court.x0 = x0; court.z0 = z0; court.n = n;
  for (int z = z0 - 1; z <= z0 + n; ++z)
    for (int x = x0 - 1; x <= x0 + n; ++x) {
      int i = idx(x, z);
      pillar[i] = 0; pool[i] = 0;
      bool inside = x >= x0 && x < x0 + n && z >= z0 && z < z0 + n;
      if (inside) { solid[i] = 1; zone[i] = 3; eWall[i] = 0; sWall[i] = 0; }
    }
  // The balcony ring: open all the way round, with a few doorways out into the corridors.
  for (int z = z0 - 1; z <= z0 + n; ++z)
    for (int x = x0 - 1; x <= x0 + n; ++x) {
      bool ring = (x == x0 - 1 || x == x0 + n || z == z0 - 1 || z == z0 + n);
      if (!ring) continue;
      bool sideX = (z == z0 - 1 || z == z0 + n);  // runs along x
      if (sideX && x < x0 + n) setWall(x, z, PX, 0);
      if (!sideX || x == x0 - 1 || x == x0 + n) { if (z < z0 + n) setWall(x, z, PZ, 0); }
      // every side faces the void; the outer side is mostly wall with doorways
      int out = z == z0 - 1 ? NZ : (z == z0 + n ? PZ : (x == x0 - 1 ? NX : PX));
      setWall(x, z, out, rng.f01() < 0.22f ? 0 : 1);
    }
  // start on the balcony, looking across the atrium
  startX = x0 + n / 2; startZ = z0 + n;
  court.startYaw = 0.0f;  // facing -z: across the courtyard
}

bool Level::solidNext(int x, int z, int d) const { return !solid.empty() && solid[idx(x + kDX[d], z + kDZ[d])]; }

// The last room: a wide, quiet Lobby room. Three slides in the back wall.
void Level::generateChoice(Rng& rng) {
  eWall.assign(W * H, 0); sWall.assign(W * H, 0);
  pillar.assign(W * H, 0); pool.assign(W * H, 0);
  props.clear(); propsAtTile.assign(W * H, {}); decals.clear();
  auto inside = [](int x, int z) { return x >= 2 && x <= 8 && z >= 2 && z <= 6; };
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      solid[idx(x, z)] = inside(x, z) ? 0 : 1;
      if (!inside(x, z)) continue;
      for (int d = 0; d < 4; ++d)
        if (!inside(x + kDX[d], z + kDZ[d])) setWall(x, z, d, 1);
    }
  auto C = [&](int x, int z, float y = 0) { return tileCenter(x, z, y); };
  float off = kTile * 0.5f - kWallT * 0.5f;
  auto marker = [&](vec3 pos, float w, float h, int kind, float tilt = 0) {
    Decal d; d.pos = pos + vec3{0, 0, 0.006f}; d.n = {0, 0, 1}; d.w = w; d.h = h; d.kind = kind; d.color = {0.06f, 0.05f, 0.04f}; d.tilt = tilt;
    decals.push_back(d);
  };
  for (int k = 0; k < 3; ++k) {
    tubes[k] = C(3 + k * 2, 2, 1.15f) + vec3{0, 0, -off};
    addProp(17, tubes[k] + vec3{0, 0, 0.005f}, kPi, 0, 0, 0);
    props.back().variant = k;
  }
  // Scrawled in marker, like the famous photo: THIS WAY (with a curly arrow), ? ? ?, EXIT :)
  marker(tubes[0] + vec3{0.1f, 1.02f, 0}, 2.5f, 0.6f, DECAL_GRAFFITI + 0, 0.03f);        // THIS WAY
  marker(tubes[0] + vec3{-1.0f, 0.35f, 0}, 0.95f, 0.48f, DECAL_ARROW, -0.75f);           // arrow curling into it
  marker(tubes[1] + vec3{-0.68f, 0.68f, 0}, 2.8f, 0.52f, DECAL_GRAFFITI + 1, 0.25f);      // ?
  marker(tubes[1] + vec3{0.0f, 1.08f, 0}, 3.0f, 0.56f, DECAL_GRAFFITI + 1, -0.08f);        //   ?
  marker(tubes[1] + vec3{0.7f, 0.72f, 0}, 2.8f, 0.52f, DECAL_GRAFFITI + 1, -0.3f);      //     ?
  marker(tubes[2] + vec3{0.2f, 1.02f, 0}, 2.3f, 0.6f, DECAL_GRAFFITI + 2, -0.04f);      // EXIT :)
  lights.clear(); lightAtTile.assign(W * H, -1);
  for (int x : {3, 5, 7})
    for (int z : {3, 5}) {
      Light L; vec3 c = C(x, z, wallH - 0.02f);
      L.pos = c; L.id = (int)lights.size(); L.kind = 0; L.intensity = 1.0f; L.phase = rng.range(0, 100);
      lightAtTile[idx(x, z)] = L.id; lights.push_back(L);
    }
  startX = 5; startZ = 6;
  exitX = 5; exitZ = 6; exitDir = PZ;
  exitDist.assign(W * H, 0);
}


// Blood: on most levels something was dragged a few rooms and left at a wall. Drag smears along
// the way, splatter at the turns, a pool at the end with handprints sliding down the wall, and
// the odd print by a dead end. None in the Quik-Stop, the apartment or the choice room.
void Level::bloodTrails(Rng& rng) {
  if (theme.index < 0 || theme.layout == Layout::Store) return;
  const vec3 kBlood{0.2f, 0.012f, 0.008f};
  auto ok = [&](int x, int z) {
    int i = idx(x, z);
    return !pillar[i] && !pool[i] && (solid.empty() || !solid[i]) && (zone.empty() || zone[i] < 3) && !isSky(x, z);
  };
  auto floorDecal = [&](vec3 at, vec3 along, float w, float h, int kind, float tilt) {
    Decal d;
    d.n = {0, 1, 0};
    d.right = along;
    d.pos = vec3{at.x, floorAt(at.x, at.z) + 0.005f, at.z};
    d.w = w; d.h = h; d.kind = kind; d.tilt = tilt; d.color = kBlood;
    decals.push_back(d);
  };
  auto wallPrint = [&](int x, int z, int dir, float y, float jitter, float size) {
    vec3 c = tileCenter(x, z, y);
    vec3 dv = dirVec(dir);
    Decal d;
    d.n = -dv;
    d.pos = c + dv * (kTile * 0.5f - kWallT * 0.5f - 0.007f) + cross(vec3{0, 1, 0}, d.n) * jitter;
    d.w = size; d.h = size; d.kind = DECAL_HANDPRINT; d.tilt = rng.range(-0.35f, 0.35f); d.color = kBlood;
    decals.push_back(d);
  };
  int trails = (rng.next() % 100 < 70 ? 1 : 0) + (rng.next() % 100 < 30 ? 1 : 0);
  for (int t = 0; t < trails; ++t) {
    int x = 0, z = 0, tries = 0;
    do { x = (int)(rng.next() % W); z = (int)(rng.next() % H); } while ((!ok(x, z) || (std::abs(x - startX) < 4 && std::abs(z - startZ) < 4)) && ++tries < 200);
    if (tries >= 200) continue;
    int dir = (int)(rng.next() % 4), len = 6 + (int)(rng.next() % 9);
    for (int step = 0; step < len; ++step) {
      // keep going mostly straight; turn when blocked or now and then
      int nd = dir;
      if (blocked(x, z, nd) || !ok(x + kDX[nd], z + kDZ[nd]) || rng.next() % 100 < 22) {
        int cand[4], n = 0;
        for (int k = 0; k < 4; ++k)
          if (k != (dir ^ 1) && !blocked(x, z, k) && ok(x + kDX[k], z + kDZ[k])) cand[n++] = k;
        if (!n) break;
        nd = cand[rng.next() % n];
      }
      vec3 a = tileCenter(x, z), along = dirVec(nd);
      if (nd != dir || step == 0) floorDecal(a + vec3{rng.range(-0.2f, 0.2f), 0, rng.range(-0.2f, 0.2f)}, along, 0.9f, 0.9f, DECAL_BLOOD_SPLAT, rng.range(0, 6.28f));
      // the drag mark runs from this tile's centre into the next one (u = 1 is where it fades)
      floorDecal(a + along * (kTile * 0.5f), along * -1.0f, kTile * 1.05f, 0.62f, DECAL_BLOOD_DRAG, rng.range(-0.08f, 0.08f));
      dir = nd;
      x = wx(x + kDX[dir]); z = wz(z + kDZ[dir]);
    }
    // the end: a pool, and if there's a wall here, hands sliding down it
    vec3 end = tileCenter(x, z);
    floorDecal(end + vec3{rng.range(-0.25f, 0.25f), 0, rng.range(-0.25f, 0.25f)}, vec3{1, 0, 0}, 1.5f, 1.5f, DECAL_BLOOD_POOL, rng.range(0, 6.28f));
    for (int k = 0; k < 4; ++k)
      if (blocked(x, z, k) && !solidNext(x, z, k)) {
        int prints = 2 + (int)(rng.next() % 3);
        for (int p = 0; p < prints; ++p) wallPrint(x, z, k, rng.range(0.35f, 1.25f), rng.range(-0.6f, 0.6f), rng.range(0.2f, 0.26f));
        break;
      }
  }
  // a few lone handprints near dead ends
  int lone = (int)(rng.next() % 3);
  for (int i = 0, tries = 0; i < lone && tries < 300; ++tries) {
    int x = (int)(rng.next() % W), z = (int)(rng.next() % H);
    if (!ok(x, z)) continue;
    int walls = 0, wd = -1;
    for (int k = 0; k < 4; ++k) if (blocked(x, z, k) && !solidNext(x, z, k)) { ++walls; wd = k; }
    if (walls < 3 || wd < 0) continue;
    wallPrint(x, z, wd, rng.range(0.6f, 1.4f), rng.range(-0.4f, 0.4f), 0.22f);
    ++i;
  }
}
