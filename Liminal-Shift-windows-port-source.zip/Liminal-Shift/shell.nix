# Build environment for NixOS:  nix-shell --run "cmake -S . -B build && cmake --build build"
{ pkgs ? import <nixpkgs> {} }:
pkgs.mkShell {
  nativeBuildInputs = [ pkgs.cmake pkgs.pkg-config pkgs.gcc ];
  buildInputs = [ pkgs.SDL2 pkgs.libGL ];
  # SDL loads libGL / libEGL / audio backends at runtime.
  LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath [ pkgs.libGL pkgs.libpulseaudio pkgs.pipewire pkgs.alsa-lib pkgs.wayland pkgs.libxkbcommon ];
}
