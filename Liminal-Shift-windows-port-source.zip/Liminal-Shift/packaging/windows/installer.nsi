; LIMINAL SHIFT - Windows installer (NSIS 3, Modern UI 2).
; Built by build-windows.sh:  makensis -DVERSION=1.1.0 -DSTAGE=... -DOUTFILE=... installer.nsi
Unicode True
!include "MUI2.nsh"

!ifndef VERSION
  !define VERSION "1.1.0"
!endif
!ifndef PUBLISHER
  !define PUBLISHER "rxvy"
!endif
!ifndef STAGE
  !error "pass -DSTAGE=<dir with liminal-shift.exe, SDL2.dll, LICENSE.txt ...>"
!endif
!ifndef OUTFILE
  !define OUTFILE "Liminal-Shift-Setup-${VERSION}.exe"
!endif

!define APPNAME   "LIMINAL SHIFT"
!define EXENAME   "liminal-shift.exe"
!define REGKEY    "Software\LiminalShift"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\LiminalShift"

Name        "${APPNAME}"
OutFile     "${OUTFILE}"
BrandingText "${APPNAME} ${VERSION}"
SetCompressor /SOLID lzma

; Per-user install: no admin prompt, nothing outside the user's profile is touched.
RequestExecutionLevel user
InstallDir "$LOCALAPPDATA\Programs\Liminal Shift"
InstallDirRegKey HKCU "${REGKEY}" "InstallDir"

VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName"     "${APPNAME}"
VIAddVersionKey "FileDescription" "${APPNAME} installer"
VIAddVersionKey "FileVersion"     "${VERSION}"
VIAddVersionKey "ProductVersion"  "${VERSION}"
VIAddVersionKey "LegalCopyright"  "MIT License"

; ---- wizard look ----
!define MUI_ICON   "liminal-shift.ico"
!define MUI_UNICON "liminal-shift.ico"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "header.bmp"
!define MUI_WELCOMEFINISHPAGE_BITMAP   "welcome.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "welcome.bmp"
!define MUI_ABORTWARNING

!define MUI_WELCOMEPAGE_TITLE "Welcome to ${APPNAME}"
!define MUI_WELCOMEPAGE_TEXT  "You're Dana, working the last closing shift of the week at the Quik-Stop on Route 9.$\r$\n$\r$\nAt 10:00 the power dies.$\r$\n$\r$\nThis wizard will install ${APPNAME} ${VERSION} on your computer. It needs a GPU with OpenGL 3.3 (anything from roughly 2010 on).$\r$\n$\r$\nClick Next to continue."

!define MUI_FINISHPAGE_TITLE "${APPNAME} is installed"
!define MUI_FINISHPAGE_RUN "$INSTDIR\${EXENAME}"
!define MUI_FINISHPAGE_RUN_TEXT "Play ${APPNAME} now"
!define MUI_FINISHPAGE_RUN_NOTCHECKED
!define MUI_FINISHPAGE_NOREBOOTSUPPORT

!define MUI_UNCONFIRMPAGE_TEXT_TOP "${APPNAME} will be removed from your computer.$\r$\n$\r$\nYour saves and settings (in %LOCALAPPDATA%\liminal-shift and %APPDATA%\liminal-shift) are kept, so reinstalling picks up where you left off."

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "${STAGE}\LICENSE.txt"
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; ---- install ----
Section "${APPNAME} (required)" SecGame
  SectionIn RO
  SetOutPath "$INSTDIR"
  File "${STAGE}\${EXENAME}"
  File "${STAGE}\SDL2.dll"
  File "${STAGE}\LICENSE.txt"
  File "${STAGE}\THIRD_PARTY_NOTICES.txt"
  File "${STAGE}\README.txt"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  WriteRegStr HKCU "${REGKEY}" "InstallDir" "$INSTDIR"
  ; "Apps & features" entry
  WriteRegStr   HKCU "${UNINSTKEY}" "DisplayName"          "${APPNAME}"
  WriteRegStr   HKCU "${UNINSTKEY}" "DisplayVersion"       "${VERSION}"
  WriteRegStr   HKCU "${UNINSTKEY}" "Publisher"            "${PUBLISHER}"
  WriteRegStr   HKCU "${UNINSTKEY}" "DisplayIcon"          "$INSTDIR\${EXENAME}"
  WriteRegStr   HKCU "${UNINSTKEY}" "InstallLocation"      "$INSTDIR"
  WriteRegStr   HKCU "${UNINSTKEY}" "UninstallString"      '"$INSTDIR\Uninstall.exe"'
  WriteRegStr   HKCU "${UNINSTKEY}" "QuietUninstallString" '"$INSTDIR\Uninstall.exe" /S'
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoRepair" 1
  SectionGetSize ${SecGame} $0
  WriteRegDWORD HKCU "${UNINSTKEY}" "EstimatedSize" $0
SectionEnd

Section "Start Menu shortcuts" SecStart
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortcut  "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\${EXENAME}" "" "$INSTDIR\${EXENAME}" 0
  CreateShortcut  "$SMPROGRAMS\${APPNAME}\Uninstall ${APPNAME}.lnk" "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Desktop shortcut" SecDesktop
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\${EXENAME}" "" "$INSTDIR\${EXENAME}" 0
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecGame}    "The game itself."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecStart}   "Add ${APPNAME} to the Start Menu."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecDesktop} "Put a ${APPNAME} shortcut on your desktop."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

; ---- uninstall (saves/settings are deliberately left alone) ----
Section "Uninstall"
  Delete "$INSTDIR\${EXENAME}"
  Delete "$INSTDIR\SDL2.dll"
  Delete "$INSTDIR\LICENSE.txt"
  Delete "$INSTDIR\THIRD_PARTY_NOTICES.txt"
  Delete "$INSTDIR\README.txt"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir  "$INSTDIR"

  Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"
  Delete "$SMPROGRAMS\${APPNAME}\Uninstall ${APPNAME}.lnk"
  RMDir  "$SMPROGRAMS\${APPNAME}"
  Delete "$DESKTOP\${APPNAME}.lnk"

  DeleteRegKey HKCU "${UNINSTKEY}"
  DeleteRegKey HKCU "${REGKEY}"
SectionEnd
