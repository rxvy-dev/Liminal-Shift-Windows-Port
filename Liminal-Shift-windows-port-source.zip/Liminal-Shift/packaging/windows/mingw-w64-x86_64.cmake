# Cross-compile for 64-bit Windows from Linux with MinGW-w64.
# The game uses std::thread, so the compiler must use the *posix* thread model:
#   Debian/Ubuntu: x86_64-w64-mingw32-g++-posix      Fedora: x86_64-w64-mingw32-g++ (already posix)
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR x86_64)

find_program(LIMINAL_MINGW_CXX NAMES x86_64-w64-mingw32-g++-posix x86_64-w64-mingw32-g++)
find_program(LIMINAL_MINGW_CC  NAMES x86_64-w64-mingw32-gcc-posix x86_64-w64-mingw32-gcc)
find_program(LIMINAL_MINGW_RC  NAMES x86_64-w64-mingw32-windres)
if(NOT LIMINAL_MINGW_CXX OR NOT LIMINAL_MINGW_CC OR NOT LIMINAL_MINGW_RC)
  message(FATAL_ERROR "MinGW-w64 cross compiler not found (Fedora: sudo dnf install mingw64-gcc-c++)")
endif()
set(CMAKE_CXX_COMPILER ${LIMINAL_MINGW_CXX})
set(CMAKE_C_COMPILER   ${LIMINAL_MINGW_CC})
set(CMAKE_RC_COMPILER  ${LIMINAL_MINGW_RC})

set(CMAKE_FIND_ROOT_PATH /usr/x86_64-w64-mingw32 /usr/x86_64-w64-mingw32/sys-root/mingw)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY BOTH)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE BOTH)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE BOTH)
