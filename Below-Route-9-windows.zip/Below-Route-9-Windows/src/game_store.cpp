// The Quik-Stop: a ten-minute closing shift that goes very wrong.
//
//   9:00 PM  shift starts. Ring people up, restock, mop. Muzak.
//   ~9:48    a customer who isn't quite right stares at the back room.
//   ~9:54    the lights start to stutter. The freezers hum louder.
//   10:00    the power dies. Find the flashlight. Call Ray.
//            Ray arrives, you take him down to the basement panel, hold the light,
//            the wiring goes nowhere, the walls turn to static, the floor lets go.
#include "game.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>


namespace {
mat4 basis(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}
constexpr float kShiftLength = 600.0f;  // ten real minutes

const char* kGreetings[] = {"Just these, thanks.", "Pump four too, please.", "You guys sell batteries?", "Can I get a pack of gum?",
                            "Is the coffee fresh?", "Cold in here tonight.", "Long shift?", "Do you have the big ice?",
                            "Just the lottery ticket.", "Twenty on pump two."};
const char* kThanks[] = {"Thanks.", "Have a good one.", "Night.", "Appreciate it.", "Keep the change.", "Stay warm."};
const char* kWalkouts[] = {"Forget it. You're useless.", "Unbelievable. I'm going to the Shell.", "Worst service on Route 9. Congrats.",
                           "Enjoy your little shift.", "I'm calling your manager. Tomorrow. First thing.", "You know what? Keep it."};
// Waiting at the counter, getting worse: a nudge, then annoyed, then rude, then furious.
const char* kNudge[] = {"Excuse me?", "Hello?", "Um. Hi?", "Anybody?"};
const char* kAnnoyed[] = {"Hello? Anybody working here?", "Do you work here or not?", "I can see you, you know.", "Ma'am. Ma'am."};
const char* kRude[] = {"Come ON. I don't have all night.", "Are you serious right now?", "Unbelievable. Today of all days.", "What is WRONG with this place?"};
const char* kFurious[] = {"I'm writing a complaint. I'm getting your name.", "This is why nobody comes here.", "You're the slowest cashier I've ever seen.",
                          "Hurry UP. My car's running."};
const char* kCashWait[] = {"Are you gonna take the money or what?", "It's money. You take it. That's the job.", "My arm's getting tired here."};
const char* kLine[] = {"This line isn't moving.", "Can we hurry it up up there?!", "Seriously? One cashier?"};

vec4 randomLook(Rng& rng, int slot) {
  static const vec4 skins[] = {{0.72f, 0.53f, 0.42f, 0}, {0.55f, 0.38f, 0.28f, 0}, {0.36f, 0.24f, 0.17f, 0}, {0.8f, 0.62f, 0.5f, 0}, {0.24f, 0.15f, 0.1f, 0}};
  static const vec4 hairs[] = {{0.05f, 0.035f, 0.025f, 0}, {0.25f, 0.15f, 0.07f, 0}, {0.6f, 0.45f, 0.22f, 0}, {0.45f, 0.44f, 0.42f, 0}, {0.02f, 0.02f, 0.02f, 0}};
  static const vec4 tops[] = {{0.45f, 0.08f, 0.07f, 0}, {0.1f, 0.2f, 0.45f, 0}, {0.15f, 0.3f, 0.15f, 0}, {0.6f, 0.55f, 0.45f, 0},
                              {0.08f, 0.08f, 0.09f, 0}, {0.5f, 0.35f, 0.1f, 0}, {0.35f, 0.15f, 0.35f, 0}};
  static const vec4 legs[] = {{0.1f, 0.13f, 0.25f, 0}, {0.06f, 0.06f, 0.07f, 0}, {0.3f, 0.25f, 0.17f, 0}, {0.22f, 0.22f, 0.24f, 0}};
  switch (slot) {
    case 0: return skins[rng.next() % 5];
    case 1: return hairs[rng.next() % 5];
    case 2: return tops[rng.next() % 7];
    default: return legs[rng.next() % 4];
  }
}

std::string clockText(float t) {
  int mins = (int)(t / kShiftLength * 60.0f);
  if (t >= kShiftLength) mins = 60;
  int h = 9 + mins / 60, m = mins % 60;
  char buf[16];
  std::snprintf(buf, sizeof buf, "%d:%02d PM", h, m);
  return buf;
}
}  // namespace

void Game::say(const std::string& who, const std::string& text, float dur) {
  if (dur <= 0) dur = 1.6f + text.size() * 0.055f;
  lines_.push_back({who, text, dur});
}

void Game::storeBegin() {
  const StoreSpots& st = level_.store;
  storePhase_ = StorePhase::Shift;
  shiftTime_ = phaseTime_ = 0;
  power_ = 1;
  customers_.clear();
  ray_ = Npc();
  lines_.clear();
  lineTime_ = 0;
  hasFlashlight_ = false;
  flashOn_ = false;
  carrying_ = strangeDone_ = knockDone_ = false;
  restockSlot_ = spill_ = -1;
  served_ = walkouts_ = 0;
  nextCustomer_ = 4; nextRestock_ = 45; nextSpill_ = 130;
  holdProgress_ = holdLight_ = fade_ = 0;
  resetPlayer(st.counterClerk, st.clerkYaw);
  objective_ = "CLOSING SHIFT. KEEP THE STORE RUNNING UNTIL 10:00.";
  say("DANA", "(Last shift this week. One more hour.)", 3.5f);
  say("RADIO", "...and that's ninety-four point one, your late-night easy listening.", 4.0f);

  if (!texWindow_) {
    texWindow_ = makeTexture(texgen::nightWindow(512, 384, 7, false), true, false);
    texDoor_ = makeTexture(texgen::nightWindow(384, 512, 11, true), true, false);
    texWoodDoor_ = makeTexture(texgen::woodDoor(256, 512, 3), true, false);
    Image pud;
    pud.w = pud.h = 128;
    pud.px.resize(128 * 128 * 4);
    for (int y = 0; y < 128; ++y)
      for (int x = 0; x < 128; ++x) {
        float u = (x - 64) / 64.0f, v = (y - 64) / 64.0f;
        float r = std::sqrt(u * u + v * v) + 0.18f * std::sin(std::atan2(v, u) * 3.0f + 1.0f) + 0.08f * std::sin(std::atan2(v, u) * 7.0f);
        float a = clampf((0.85f - r) * 6.0f, 0, 1);
        size_t i = ((size_t)y * 128 + x) * 4;
        pud.px[i] = pud.px[i + 1] = pud.px[i + 2] = 255;
        pud.px[i + 3] = (uint8_t)(a * 255);
      }
    texPuddle_ = makeTexture(pud, true, false);
  }
}

void Game::spawnCustomer(bool strange) {
  const StoreSpots& st = level_.store;
  Npc n;
  n.active = true;
  // they come in off the lot: from the pumps, or along the sidewalk
  int from = rng_.irange(0, 2);
  if (from == 0) n.pos = {rng_.range(12.0f, 20.0f), 0, rng_.range(-15.0f, -11.0f)};
  else n.pos = {from == 1 ? -6.0f : 34.0f, 0, rng_.range(2.5f, 3.3f)};
  n.yaw = kPi;
  for (int k = 0; k < 4; ++k) n.look4[k] = randomLook(rng_, k);
  float o = rng_.f01();
  n.outfit = o < 0.5f ? 0 : (o < 0.75f ? 2 : 1);
  if (n.outfit == 1) {  // a suit: dark, matching jacket and trousers
    static const vec4 suits[] = {{0.07f, 0.075f, 0.09f, 0}, {0.16f, 0.15f, 0.13f, 0}, {0.05f, 0.07f, 0.13f, 0}, {0.2f, 0.2f, 0.21f, 0}};
    n.look4[2] = n.look4[3] = suits[rng_.next() % 4];
  }
  n.browseLeft = rng_.irange(1, 3);
  int b = rng_.next() % st.browse.size();
  n.target = st.browse[b];
  n.timer = (float)b;
  n.next = strange ? 10 : 1;
  n.state = 20;
  n.strange = strange;
  if (strange) {
    n.outfit = 1;
    n.look4[0] = {0.62f, 0.6f, 0.58f, 0};
    n.look4[1] = {0.3f, 0.3f, 0.3f, 0};
    n.look4[2] = {0.42f, 0.4f, 0.32f, 0};
    n.look4[3] = {0.3f, 0.28f, 0.22f, 0};
    n.target = level_.tileCenter(10, 8);
  }
  customers_.push_back(n);
}

void Game::npcWalk(Npc& n, vec3 goal, float spd, float dt) {
  int sx, sz, gx, gz, nx, nz;
  level_.tileOf(n.pos.x, n.pos.z, sx, sz);
  level_.tileOf(goal.x, goal.z, gx, gz);
  vec3 aim = goal;
  if ((sx != gx || sz != gz) && level_.nextStep(sx, sz, gx, gz, nx, nz)) aim = level_.tileCenter(nx, nz);
  vec3 d = aim - n.pos;
  d.y = 0;
  float len = length(d);
  n.speed = 0;
  if (len > 0.05f) {
    vec3 dir = d * (1.0f / len);
    vec3 before = n.pos;
    n.pos += dir * std::min(len, spd * dt);
    // step around the player instead of through them
    vec3 away = n.pos - pos_;
    away.y = 0;
    float ad = length(away);
    if (ad < 0.55f && ad > 1e-3f) n.pos += away * ((0.55f - ad) / ad);
    level_.collide(n.pos, 0.25f);
    n.speed = length(n.pos - before) / std::max(dt, 1e-4f);
    float ty = std::atan2(-dir.x, -dir.z);
    n.yaw += std::remainder(ty - n.yaw, 2.0f * kPi) * std::min(1.0f, dt * 8.0f);
  }
  n.anim += n.speed * dt * (2.0f * kPi / 2.6f);
}

void Game::powerOut() {
  power_ = 0;
  storePhase_ = StorePhase::FindLight;
  phaseTime_ = 0;
  if (A_) A_->play(Sfx::PowerDown, 1.0f);
  objective_ = "FIND THE FLASHLIGHT (UNDER THE COUNTER)";
  for (Npc& n : customers_)
    if (n.active && n.state < 6) { n.state = 6; n.target = level_.store.door; }
    else if (n.active && n.state == 20) { n.state = 23; n.target = n.pos + vec3{0, 0, -12.0f}; }  // sees the dark windows, turns back
    else if (n.active && n.state == 21) { n.state = 6; }
  if (!customers_.empty()) say("CUSTOMER", "Whoa. Guess you're closed.", 2.5f);
  say("DANA", "...No. No no no. Not tonight.", 2.8f);
  restockSlot_ = spill_ = -1;
  carrying_ = false;
  saleStage_ = 0; cashHeld_ = false; drawerTarget_ = 0;
  setRegisterText("");
}

void Game::beginFall() {
  storePhase_ = StorePhase::Fall;
  phaseTime_ = 0;
  screen_ = Screen::Noclip;
  screenTime_ = 0;
  noclipFall_ = 0;
  lines_.clear();
  if (A_) { A_->play(Sfx::Noclip, 1.0f); A_->play(Sfx::Death, 0.4f); }
}

std::string Game::storePrompt() {
  const StoreSpots& st = level_.store;
  auto near2 = [&](vec3 p, float r) { vec3 d = p - pos_; d.y = 0; return length(d) < r; };
  const char* key = usingPad_ ? "[A]" : "[E]";
  std::string k = key;
  switch (storePhase_) {
    case StorePhase::Shift: {
      bool waiting = false;
      for (const Npc& n : customers_) if (n.active && n.state == 4) waiting = true;
      if (waiting && near2(st.counterClerk, 1.3f)) {
        if (saleStage_ == 0) return k + " HOLD TO RING IT UP";
        if (saleStage_ == 1) return k + " TAKE THE CASH";
        if (saleStage_ == 2 && cashHeld_) return k + " PUT IT IN THE DRAWER";
      }
      if (restockSlot_ >= 0 && !carrying_ && near2(st.boxPickup, 1.4f)) return k + " PICK UP STOCK BOX";
      if (carrying_ && near2(st.shelfSlots[restockSlot_], 1.7f)) return k + " STOCK THE SHELF";
      if (spill_ >= 0 && near2(st.spills[spill_], 1.3f)) return k + " HOLD TO MOP";
      break;
    }
    case StorePhase::FindLight:
      if (near2(st.flashlight, 1.4f)) return k + " TAKE FLASHLIGHT";
      break;
    case StorePhase::CallRay:
      if (near2(st.phone, 1.5f)) return k + " CALL RAY'S REPAIR";
      break;
    case StorePhase::MeetRay:
      if (ray_.active && near2(ray_.pos, 2.2f)) return k + " TALK TO RAY";
      break;
    case StorePhase::LeadRay:
      if (near2(st.basementDoor, 1.5f)) return k + " GO DOWN TO THE BASEMENT";
      break;
    default: break;
  }
  return "";
}

void Game::storeInteract() {
  const StoreSpots& st = level_.store;
  auto near2 = [&](vec3 p, float r) { vec3 d = p - pos_; d.y = 0; return length(d) < r; };
  switch (storePhase_) {
    case StorePhase::Shift: {
      int waiting = -1;
      for (size_t i = 0; i < customers_.size(); ++i)
        if (customers_[i].active && customers_[i].state == 4) { waiting = (int)i; break; }
      if (waiting >= 0 && near2(st.counterClerk, 1.3f) && saleStage_ == 1) {
        cashHeld_ = true;
        customers_[waiting].offer = 0;
        saleStage_ = 2;
        drawerTarget_ = 1;
        if (A_) { A_->play(Sfx::Paper, 0.35f); A_->play(Sfx::Register, 0.7f, 0.1f); }
        break;
      }
      if (waiting >= 0 && near2(st.counterClerk, 1.3f) && saleStage_ == 2 && cashHeld_) {
        Npc& c = customers_[waiting];
        cashHeld_ = false;
        totalTaken_ += c.price;
        float paid = c.price < 5 ? 5.0f : (c.price < 10 ? 10.0f : 20.0f);
        char buf[48];
        std::snprintf(buf, sizeof buf, "CHANGE $%.2f", paid - c.price);
        setRegisterText(buf);
        toast_ = buf;
        toastTime_ = 2.2f;
        if (A_) { A_->play(Sfx::Coins, 0.6f, 0.1f); A_->play(Sfx::Paper, 0.25f); }
        drawerCloseAt_ = time_ + 0.9f;
        if (c.rude == 0 && c.waited < 8.0f) say("CUSTOMER", "Wow, that was fast. Thanks!", 2.0f);
        else if (c.rude >= 3) say("CUSTOMER", "Finally. Was that so hard?", 2.2f);
        else if (c.rude >= 2) say("CUSTOMER", "...Yeah. Whatever. Thanks.", 2.2f);
        else say("CUSTOMER", kThanks[rng_.next() % 6]);
        c.itemDown = false;  // takes it with them
        c.state = 6;
        c.target = st.door;
        ++served_;
        if (served_ >= 8) unlockBadge(15);
        saleStage_ = 0;
        break;
      }
      if (restockSlot_ >= 0 && !carrying_ && near2(st.boxPickup, 1.4f)) {
        carrying_ = true;
        if (A_) A_->play(Sfx::Paper, 0.5f);
      } else if (carrying_ && near2(st.shelfSlots[restockSlot_], 1.7f)) {
        carrying_ = false;
        restockSlot_ = -1;
        nextRestock_ = shiftTime_ + rng_.range(70.0f, 110.0f);
        toast_ = "SHELF STOCKED";
        toastTime_ = 2;
        if (A_) A_->play(Sfx::Battery, 0.5f);
      }
    } break;
    case StorePhase::FindLight:
      if (near2(st.flashlight, 1.4f)) {
        hasFlashlight_ = true;
        flashOn_ = true;
        battery_ = 1.0f;
        if (A_) A_->play(Sfx::Click, 0.7f);
        storePhase_ = StorePhase::CallRay;
        phaseTime_ = 0;
        objective_ = "CALL RAY'S REPAIR (PHONE IN THE BACK ROOM)";
        say("DANA", "Okay. Okay. The number's on the phone.", 2.5f);
      }
      break;
    case StorePhase::CallRay:
      if (near2(st.phone, 1.5f)) {
        if (A_) A_->play(Sfx::PhoneRing, 0.6f);
        say("PHONE", "(ring... ring...)", 2.6f);
        say("RAY", "Ray's Repair, this is Ray.", 2.2f);
        say("DANA", "Hi, this is the Quik-Stop on Route 9. Everything just went dark.", 3.6f);
        say("RAY", "Whole building? Freezers too?", 2.2f);
        say("DANA", "Everything. It just... stopped. There was a noise first, like a hum.", 3.8f);
        say("RAY", "Panel's in the basement, I bet. I'm ten minutes out. Don't touch anything.", 4.0f);
        storePhase_ = StorePhase::WaitRay;
        phaseTime_ = 0;
        objective_ = "WAIT FOR RAY";
      }
      break;
    case StorePhase::MeetRay:
      if (ray_.active && near2(ray_.pos, 2.2f)) {
        say("RAY", "Evening. You the one who called?", 2.4f);
        say("DANA", "Yeah. Dana. Thanks for coming out so late.", 2.8f);
        say("RAY", "Mind if I film? Insurance makes me record every job.", 3.2f);
        say("RAY", "Basement's through the back? Lead the way.", 2.8f);
        storePhase_ = StorePhase::LeadRay;
        phaseTime_ = 0;
        objective_ = "TAKE RAY TO THE BASEMENT DOOR (BACK ROOM)";
      }
      break;
    case StorePhase::LeadRay:
      if (near2(st.basementDoor, 1.5f)) {
        fade_ = 1.0f;
        if (A_) A_->play(Sfx::Slam, 0.4f);
        resetPlayer(st.basementArrive, st.basementYaw);
        flashOn_ = true;
        ray_.pos = st.basementArrive + vec3{0.7f, 0, 0.2f};
        ray_.yaw = 0;
        storePhase_ = StorePhase::Basement;
        phaseTime_ = 0;
        objective_ = "STAY WITH RAY";
        say("RAY", "Watch the last step. It's loose.", 2.4f);
      }
      break;
    default: break;
  }
}

void Game::storeUpdate(float dt) {
  const StoreSpots& st = level_.store;
  phaseTime_ += dt;
  outsideUpdate(dt);
  if (fade_ > 0) fade_ = std::max(0.0f, fade_ - dt * 1.2f);
  bool held = keys_[SDL_SCANCODE_E] || (pad_ && SDL_GameControllerGetButton(pad_, SDL_CONTROLLER_BUTTON_A));
  auto near2 = [&](vec3 p, float r) { vec3 d = p - pos_; d.y = 0; return length(d) < r; };


  if (storePhase_ == StorePhase::Shift) {
    shiftTime_ += dt;
    // Customers come in through the night.
    int inside = 0;
    for (const Npc& n : customers_) if (n.active) ++inside;
    if (shiftTime_ >= nextCustomer_ && inside < 3 && shiftTime_ < kShiftLength - 30) {
      spawnCustomer();
      nextCustomer_ = shiftTime_ + rng_.range(22.0f, 42.0f);
    }
    if (!strangeDone_ && shiftTime_ > 470) { strangeDone_ = true; spawnCustomer(true); }
    if (restockSlot_ < 0 && shiftTime_ >= nextRestock_ && shiftTime_ < kShiftLength - 40) {
      restockSlot_ = rng_.next() % st.shelfSlots.size();
      toast_ = "NEW TASK: RESTOCK";
      toastTime_ = 2.5f;
    }
    if (spill_ < 0 && shiftTime_ >= nextSpill_ && shiftTime_ < kShiftLength - 40) {
      spill_ = rng_.next() % st.spills.size();
      toast_ = "NEW TASK: CLEAN UP A SPILL";
      toastTime_ = 2.5f;
      if (A_) A_->play(Sfx::Splash, 0.6f, 0.4f);
    }
    // Hold-to-do tasks: ringing up and mopping.
    int waiting = -1;
    for (size_t i = 0; i < customers_.size(); ++i)
      if (customers_[i].active && customers_[i].state == 4) { waiting = (int)i; break; }
    bool working = false;
    if (held && waiting >= 0 && saleStage_ == 0 && near2(st.counterClerk, 1.3f)) {
      working = true;
      holdProgress_ += dt / 2.2f;
      if (time_ - lastBeep_ > 0.2f) {
        lastBeep_ = time_;
        if (A_) A_->play(Sfx::RegKey, 0.6f, 0.1f);
        // the display counts up as you key it in
        char buf[24];
        std::snprintf(buf, sizeof buf, "$%.2f", customers_[waiting].price * std::min(1.0f, holdProgress_ * 1.1f));
        setRegisterText(buf);
      }
      if (holdProgress_ >= 1.0f) {
        Npc& c = customers_[waiting];
        char buf[48];
        std::snprintf(buf, sizeof buf, "$%.2f", c.price);
        setRegisterText(buf);
        std::snprintf(buf, sizeof buf, "TOTAL $%.2f", c.price);
        toast_ = buf;
        toastTime_ = 2.5f;
        if (A_) A_->play(Sfx::Beep, 0.5f);
        saleStage_ = 1;
        c.patience = std::max(c.patience, 30.0f);
        static const char* kPay[] = {"Here.", "Keep the change. ...Actually, no.", "Do you take twenties?", "Here you go.", "Sorry, it's a little wet."};
        say("CUSTOMER", kPay[rng_.next() % 5], 2.0f);
        holdProgress_ = 0;
      }
    } else if (held && spill_ >= 0 && near2(st.spills[spill_], 1.3f)) {
      working = true;
      holdProgress_ += dt / 3.0f;
      if (time_ - lastBeep_ > 0.6f) { lastBeep_ = time_; if (A_) A_->play(Sfx::Splash, 0.25f); }
      if (holdProgress_ >= 1.0f) {
        spill_ = -1;
        nextSpill_ = shiftTime_ + rng_.range(120.0f, 170.0f);
        toast_ = "SPILL CLEANED";
        toastTime_ = 2.0f;
        holdProgress_ = 0;
      }
    }
    if (!working) holdProgress_ = std::max(0.0f, holdProgress_ - dt * 2.0f);
    drawer_ += (drawerTarget_ - drawer_) * std::min(1.0f, dt * 9.0f);
    if (drawerCloseAt_ > 0 && time_ >= drawerCloseAt_) { drawerTarget_ = 0; drawerCloseAt_ = -1; if (A_) A_->play(Sfx::Slam, 0.12f, 0.1f); }
    // The last few minutes go wrong.
    if (shiftTime_ > 560 && shiftTime_ - dt <= 560) say("DANA", "(Is it just me or are the lights louder?)", 3.0f);
    if (shiftTime_ > 585 && shiftTime_ - dt <= 585) say("DANA", "(Almost done. Almost done.)", 2.5f);
    if (shiftTime_ >= kShiftLength) powerOut();
  } else if (storePhase_ == StorePhase::WaitRay) {
    if (!knockDone_ && phaseTime_ > 14) {
      knockDone_ = true;
      if (A_) A_->play(Sfx::Knock, 0.8f, -0.6f);
      say("DANA", "...Hello?", 1.8f);
      say("DANA", "(That came from downstairs.)", 2.6f);
    }
    if (phaseTime_ > 25.0f && phaseTime_ - dt <= 25.0f && A_) A_->play(Sfx::Whoosh, 0.35f, 0.3f);  // tyres on the lot
    if (phaseTime_ > 26.5f && phaseTime_ - dt <= 26.5f) say("DANA", "(Headlights. That's him.)", 2.4f);
    if (phaseTime_ > 31.5f && !ray_.active) {
      ray_.active = true;
      ray_.pos = kVanPark + vec3{1.25f, 0, 0.6f};  // out the driver's door
      ray_.yaw = kPi;
      rayWalkIn_ = 1;
      if (A_) A_->play(Sfx::Slam, 0.35f, 0.3f);
      ray_.look4[0] = {0.6f, 0.43f, 0.33f, 0};
      ray_.look4[1] = {0.42f, 0.4f, 0.38f, 0};   // grey hair
      ray_.look4[2] = {0.12f, 0.22f, 0.42f, 0};  // work jacket
      ray_.look4[3] = {0.1f, 0.18f, 0.33f, 0};   // coveralls
    }
    if (ray_.active && rayWalkIn_ == 1) {  // across the lot to the door
      vec3 goal{st.door.x, 0, 3.2f};
      npcWalk(ray_, goal, 1.35f, dt);
      if (length(goal - ray_.pos) < 0.3f) {
        rayWalkIn_ = 2;
        if (A_) A_->play(Sfx::Chime, 0.7f, -0.3f);
        say("RAY", "Hello? Quik-Stop? It's Ray.", 2.4f);
      }
    } else if (ray_.active && rayWalkIn_ == 2) {
      npcWalk(ray_, st.door, 1.2f, dt);
      if (length(st.door - ray_.pos) < 0.3f) {
        rayWalkIn_ = 0;
        storePhase_ = StorePhase::MeetRay;
        phaseTime_ = 0;
        objective_ = "MEET RAY AT THE FRONT";
      }
    }
  }

  // Customers.
  for (Npc& n : customers_) {
    if (!n.active) continue;
    n.total += dt;
    switch (n.state) {
      case 1:  // walking to a shelf
        npcWalk(n, n.target, 1.25f, dt);
        if (length(n.target - n.pos) < 0.35f) { n.state = 2; n.timer = rng_.range(3.0f, 7.0f); }
        break;
      case 2: {  // browsing
        n.speed = 0;
        n.timer -= dt;
        int b = 0;
        float bd = 1e9f;
        for (size_t i = 0; i < st.browse.size(); ++i) {
          float d = length(st.browse[i] - n.pos);
          if (d < bd) { bd = d; b = (int)i; }
        }
        n.yaw += std::remainder(st.browseYaw[b] - n.yaw, 2.0f * kPi) * std::min(1.0f, dt * 4.0f);
        n.look = 0.4f * std::sin(n.total * 0.7f);
        if (n.timer <= 0) {
          if (--n.browseLeft > 0) { n.state = 1; n.target = st.browse[rng_.next() % st.browse.size()]; }
          else {
            n.state = 3;
            n.target = st.counterCustomer;
            n.item = rng_.irange(0, 3);
            n.itemColor = rng_.irange(0, 3);
            static const float base[4] = {0.89f, 1.29f, 1.09f, 0.75f};
            n.price = base[n.item] * (1 + rng_.irange(0, 2)) + 0.01f * rng_.irange(0, 9);
            if (A_) A_->play(Sfx::Paper, 0.25f, 0.2f);
          }
        }
      } break;
      case 3: {  // to the register (queue behind anyone already there)
        int ahead = 0;
        for (const Npc& o : customers_) if (&o != &n && o.active && o.state == 4) ++ahead;
        vec3 spot = st.counterCustomer + vec3{-0.9f * ahead, 0, 0.3f * ahead};
        npcWalk(n, spot, 1.3f, dt);
        if (ahead && length(spot - n.pos) < 0.5f) {
          n.waited += dt;
          if (n.rude == 0 && n.waited > 14.0f) { say("CUSTOMER", kLine[rng_.next() % 3], 2.4f); n.rude = 1; }
        }
        if (length(spot - n.pos) < 0.35f) {
          n.state = ahead ? 3 : 4;
          if (!ahead) {
            n.patience = 45;
            n.waited = n.rude ? 12.0f : 0.0f;
            n.itemDown = true;  // sets it on the counter
            saleStage_ = 0;
            say("CUSTOMER", kGreetings[rng_.next() % 10]);
          }
        }
      } break;
      case 4:  // waiting at the counter
        n.speed = 0;
        n.waited += dt;
        {
          const float stages[4] = {9.0f, 17.0f, 25.0f, 34.0f};
          if (n.rude < 4 && n.waited > stages[n.rude]) {
            bool away = !near2(st.counterClerk, 3.0f);
            const char* line;
            if (saleStage_ == 1 && n.rude >= 1) line = kCashWait[rng_.next() % 3];
            else if (away && n.rude >= 1) line = n.rude >= 3 ? "Where did you GO?! I'm standing right here!" : "Hello?! Where'd you go?";
            else if (n.rude == 0) line = kNudge[rng_.next() % 4];
            else if (n.rude == 1) line = kAnnoyed[rng_.next() % 4];
            else if (n.rude == 2) line = kRude[rng_.next() % 4];
            else line = kFurious[rng_.next() % 4];
            say("CUSTOMER", line, 2.6f);
            if (n.rude >= 1 && A_) A_->play(Sfx::Knock, 0.25f + 0.12f * n.rude, -0.2f);  // knuckles on the counter
            if (n.rude >= 2) fear_ = std::min(0.4f, fear_ + 0.05f);
            ++n.rude;
          }
        }
        n.offer += ((saleStage_ == 1 ? 1.0f : 0.0f) - n.offer) * std::min(1.0f, dt * 5.0f);
        n.yaw += std::remainder(-kPi * 0.5f - n.yaw, 2.0f * kPi) * std::min(1.0f, dt * 4.0f);
        n.look = 0.2f * std::sin(n.total * 0.5f);
        n.patience -= dt;
        if (n.patience < 0) {
          say("CUSTOMER", kWalkouts[rng_.next() % 6], 3.0f);
          if (A_) A_->play(Sfx::Slam, 0.35f, -0.2f);
          ++walkouts_;
          n.item = -1; n.itemDown = false; n.offer = 0;  // leaves it on the counter and goes
          if (saleStage_ > 0) { saleStage_ = 0; drawerTarget_ = 0; cashHeld_ = false; setRegisterText("QUIK-STOP"); }
          n.state = 6;
          n.target = st.door;
        }
        break;
      case 6:  // leaving
        npcWalk(n, st.door, 1.5f, dt);
        if (length(st.door - n.pos) < 0.5f) {
          n.state = 22;
          if (A_) A_->play(Sfx::Chime, 0.35f, -0.3f);
        }
        break;
      case 20: {  // crossing the lot to the door
        vec3 g{st.door.x, 0, 3.2f};
        npcWalk(n, g, 1.3f, dt);
        if (length(g - n.pos) < 0.35f) { n.state = 21; if (A_) A_->play(Sfx::Chime, 0.5f, -0.3f); }
      } break;
      case 21:
        npcWalk(n, st.door, 1.2f, dt);
        if (length(st.door - n.pos) < 0.3f) n.state = n.next;
        break;
      case 22: {  // out the door
        vec3 g{st.door.x, 0, 3.0f};
        npcWalk(n, g, 1.4f, dt);
        if (length(g - n.pos) < 0.35f) {
          n.state = n.strange ? 24 : 23;
          n.target = n.strange ? vec3{14.5f, 0, -7.5f} : ((rng_.f01() < 0.5f) ? vec3{rng_.range(12.0f, 20.0f), 0, -13.0f} : vec3{(rng_.f01() < 0.5f) ? -8.0f : 36.0f, 0, 2.8f});
        }
      } break;
      case 23:  // gone into the night
        npcWalk(n, n.target, 1.4f, dt);
        if (length(n.target - n.pos) < 0.5f) n.active = false;
        break;
      case 24: {  // ...except him. He stops in the lot and watches the window.
        npcWalk(n, n.target, 0.9f, dt);
        if (length(n.target - n.pos) < 0.4f) {
          n.speed = 0;
          vec3 d = eye() - n.pos;
          n.yaw += std::remainder(std::atan2(-d.x, -d.z) - n.yaw, 2.0f * kPi) * std::min(1.0f, dt * 2.0f);
        }
        if (storePhase_ != StorePhase::Shift) n.active = false;  // when the lights go, so does he
      } break;
      case 10:  // the customer who isn't right: walks to the back doorway and stares
        npcWalk(n, n.target, 0.8f, dt);
        if (length(n.target - n.pos) < 0.4f) { n.state = 11; n.timer = 10.5f; }
        break;
      case 11:
        n.speed = 0;
        n.yaw += std::remainder(kPi - n.yaw, 2.0f * kPi) * std::min(1.0f, dt * 2.0f);  // facing the back room
        n.timer -= dt;
        if (n.timer < 6 && n.timer + dt >= 6) say("CUSTOMER", "Your basement's humming.", 2.6f);
        if (n.timer < 3 && n.timer + dt >= 3) say("CUSTOMER", "Can you hear it? It knows your name.", 3.0f);
        if (n.timer < 1.2f && n.timer + dt >= 1.2f) say("CUSTOMER", "The last clerk heard it too. Theo. Nice kid.", 3.0f);
        if (n.timer <= 0) { n.state = 6; n.target = st.door; }
        break;
      default: break;
    }
  }

  // Ray.
  if (ray_.active) {
    ray_.total += dt;
    vec3 toP = pos_ - ray_.pos;
    toP.y = 0;
    switch (storePhase_) {
      case StorePhase::MeetRay:
        if (length(toP) > 2.0f) npcWalk(ray_, pos_, 1.3f, dt);
        else { ray_.speed = 0; ray_.yaw += std::remainder(std::atan2(-toP.x, -toP.z) - ray_.yaw, 2.0f * kPi) * std::min(1.0f, dt * 4.0f); }
        break;
      case StorePhase::LeadRay:
        if (length(toP) > 1.7f) npcWalk(ray_, pos_, length(toP) > 4 ? 2.6f : 1.5f, dt);
        else ray_.speed = 0;
        break;
      case StorePhase::Basement: {
        vec3 spot = st.breaker + vec3{-0.75f, 0, 0};
        spot.y = 0;
        npcWalk(ray_, spot, 1.0f, dt);
        if (length(spot - ray_.pos) < 0.3f) {
          ray_.yaw += std::remainder(-kPi * 0.5f - ray_.yaw, 2.0f * kPi) * std::min(1.0f, dt * 3.0f);
          if (phaseTime_ > 3.5f && lines_.empty()) {
            say("RAY", "Huh. Every breaker's on.", 2.2f);
            say("RAY", "Shine that light over here for me, would you?", 2.8f);
            storePhase_ = StorePhase::HoldLight;
            phaseTime_ = 0;
            objective_ = "HOLD YOUR FLASHLIGHT ON THE PANEL";
          }
        }
      } break;
      case StorePhase::HoldLight: {
        ray_.speed = 0;
        vec3 toPanel = st.breaker - eye();
        float aimed = dot(normalize(toPanel), forward());
        if (flashOn_ && aimed > 0.93f && length(toPanel) < 5.0f) {
          float before = holdLight_;
          holdLight_ = std::min(1.0f, holdLight_ + dt / 10.0f);
          if (before < 0.2f && holdLight_ >= 0.2f) say("RAY", "That's... these wires don't go anywhere.", 2.8f);
          if (before < 0.45f && holdLight_ >= 0.45f) say("DANA", "What do you mean?", 1.6f);
          if (before < 0.65f && holdLight_ >= 0.65f) say("RAY", "I mean there's no other side. It's just wall. It's just... more basement.", 3.6f);
          if (before < 0.9f && holdLight_ >= 0.9f) say("RAY", "Do you hear that?", 2.0f);
          if (holdLight_ >= 1.0f) {
            storePhase_ = StorePhase::Wrong;
            phaseTime_ = 0;
            objective_ = "";
            say("DANA", "Ray. The floor. Ray, the floor's—", 2.4f);
            if (A_) A_->play(Sfx::Brownout, 1.0f);
          }
        }
      } break;
      case StorePhase::Wrong:
        ray_.speed = 0;
        ray_.yaw += std::remainder(std::atan2(-toP.x, -toP.z) - ray_.yaw, 2.0f * kPi) * std::min(1.0f, dt * 3.0f);
        if (phaseTime_ > 4.2f) beginFall();
        break;
      default: break;
    }
  }
  customers_.erase(std::remove_if(customers_.begin(), customers_.end(), [](const Npc& n) { return !n.active; }), customers_.end());
}

void Game::storeLights() {
  const StoreSpots& st = level_.store;
  float wrong = storePhase_ == StorePhase::Wrong ? phaseTime_ : 0.0f;
  for (size_t i = 0; i < level_.lights.size() && i < lightState_.size(); ++i) {
    const Light& L = level_.lights[i];
    bool emergency = std::find(st.emergencyLights.begin(), st.emergencyLights.end(), (int)i) != st.emergencyLights.end();
    float s = emergency ? (power_ > 0.5f ? 0.0f : 0.55f) : power_;
    // In the last minutes before ten, the lights start to stutter.
    if (power_ > 0.5f && shiftTime_ > 540 && !emergency) {
      float f = hashf((int)i, (int)(time_ * 9.0f), 3);
      if (f < (shiftTime_ - 540) / 300.0f) s *= 0.25f;
    }
    // The basement bulb comes back on when Ray's there, and then goes wrong.
    if (L.pos.x > 26.0f && L.pos.z < 16.0f && !emergency &&
        (storePhase_ == StorePhase::Basement || storePhase_ == StorePhase::HoldLight || storePhase_ == StorePhase::Wrong)) {
      s = 0.0f;
      if (wrong > 0) s = hashf((int)(time_ * 18.0f), 5) < 0.5f ? 1.2f : 0.0f;
    }
    lightState_[i] = s;
  }
  lightTint_ = power_ > 0.5f ? vec3{1, 1, 1} : vec3{1.0f, 0.18f, 0.12f};
}

void Game::storeDraw(Shader& S, vec3 cam) {
  const StoreSpots& st = level_.store;
  S.set("uMat", MAT_MODEL);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  // People.
  for (const Npc& n : customers_)
    if (n.active) drawNpc(S, n, n.pos);
  if (ray_.active && screen_ == Screen::Ending) drawNpc(S, ray_, ray_.pos);
  else if (ray_.active) {
    AnimInput in;
    in.time = time_;
    in.phase = ray_.anim;
    in.speed = ray_.speed / 1.3f;
    in.carry = storePhase_ == StorePhase::HoldLight ? 0.6f : 0.0f;
    vec3 p = ray_.pos;
    bool draw = true;
    if (screen_ == Screen::Noclip) {  // he falls with you, and then he isn't there
      p.y -= noclipFall_ * 1.15f + 0.3f;
      draw = screenTime_ < 1.6f && hashf((int)(time_ * 30.0f)) > screenTime_ * 0.5f;
    }
    if (draw) drawCreature(S, CR_WORKER, p, ray_.yaw, in, 0, ray_.look4);
  }

  // Flat things: windows, door, basement door, phone, flashlight, stock, glow, puddles.
  S.set("uMat", MAT_SCREEN);
  S.set("uUVScale", 1.0f);
  S.set("uSkinned", 0);
  S.set("uTint", vec3{1, 1, 1});
  auto panel = [&](vec3 c, vec3 n, float w, float h, GLuint tex, float emissive) {
    vec3 up{0, 1, 0};
    vec3 r = cross(up, n);
    mat4 m = mat4::identity();
    m.m[0] = r.x * w; m.m[1] = r.y * w; m.m[2] = r.z * w;
    m.m[4] = 0; m.m[5] = h; m.m[6] = 0;
    m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
    m.m[12] = c.x; m.m[13] = c.y; m.m[14] = c.z;
    glBindTexture(GL_TEXTURE_2D, tex);
    S.set("uEmissive", emissive);
    S.set("uModel", m);
    quad_.draw();
  };
  panel(st.basementDoor, {1, 0, 0}, 0.95f, 2.1f, texWoodDoor_, 0.0f);
  // Phone on the back wall.
  S.set("uMat", MAT_PROP);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  drawPart(translate(st.phone) * scale({0.18f, 0.26f, 0.06f}), {0.75f, 0.72f, 0.62f});
  drawPart(translate(st.phone + vec3{-0.05f, 0.02f, -0.045f}) * rotZ(0.1f) * scale({0.05f, 0.22f, 0.05f}), {0.7f, 0.68f, 0.6f});
  if (!hasFlashlight_) {  // flashlight on the shelf under the counter
    vec3 f = st.flashlight + vec3{0, 0.55f, 0};
    drawPart(translate(f) * rotX(kPi * 0.5f) * scale({0.04f, 0.22f, 0.04f}), {0.06f, 0.06f, 0.07f});
    drawPart(translate(f + vec3{0, 0, -0.12f}) * scale({0.06f, 0.06f, 0.04f}), {0.5f, 0.5f, 0.45f}, storePhase_ == StorePhase::FindLight ? 0.4f : 0.0f);
  }
  S.set("uMat", MAT_MODEL);
  if (restockSlot_ >= 0 && !carrying_) drawModel(S, creatures::prop(PR_BOX), translate(st.boxPickup) * rotY(0.3f));
  if (carrying_) {
    vec3 f = forward();
    vec3 hp = eye() + vec3{f.x, 0, f.z} * 0.55f - vec3{0, 0.75f, 0};
    drawModel(S, creatures::prop(PR_BOX), translate(hp) * rotY(yaw_) * scale({0.7f, 0.7f, 0.7f}));
  }
  drawRegister(S);
  drawStoreOutside(S, cam);
  S.set("uMat", MAT_MODEL);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  // Blended overlays: restock target glow, spill puddle, static on the basement walls.
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDepthMask(GL_FALSE);
  if (carrying_ && restockSlot_ >= 0) {
    S.set("uMat", MAT_DECAL);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    vec3 p = st.shelfSlots[restockSlot_];
    float pulse = 0.6f + 0.4f * std::sin(time_ * 5.0f);
    S.set("uTint", vec3{1.0f, 0.85f, 0.3f});
    S.set("uEmissive", 1.5f * pulse);
    S.set("uFlipU", 0);
    vec3 n{0, 0, p.z > level_.tileCenter(0, 4).z ? 1.0f : -1.0f};
    mat4 m = translate(p) * scale({0.5f, 0.3f, 1.0f});
    if (n.z < 0) m = translate(p) * rotY(kPi) * scale({0.5f, 0.3f, 1.0f});
    S.set("uModel", m);
    quad_.draw();
  }
  if (spill_ >= 0) {
    S.set("uMat", MAT_DECAL);
    glBindTexture(GL_TEXTURE_2D, texPuddle_);
    S.set("uTint", vec3{0.28f, 0.16f, 0.04f});
    S.set("uEmissive", 0.0f);
    vec3 p = st.spills[spill_] + vec3{0, 0.005f, 0};
    mat4 m = basis(vec3{1.1f, 0, 0}, vec3{0, 0, -0.9f}, vec3{0, 1, 0}, p);
    S.set("uModel", m);
    quad_.draw();
  }
  if (storePhase_ == StorePhase::Wrong || (screen_ == Screen::Noclip && storePhase_ == StorePhase::Fall)) {
    float g = clampf(phaseTime_ / 4.0f, 0.2f, 1.0f);
    S.set("uMat", MAT_GLITCH);
    S.set("uGlitch", g);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    vec3 c = level_.tileCenter(13, 5);
    float hw = level_.wallH * 0.5f;
    S.set("uModel", translate({c.x - 0.92f, hw, c.z}) * scale({0.01f, level_.wallH, 9.6f}));
    cube_.draw();
    S.set("uModel", translate({c.x + 2.92f, hw, c.z}) * scale({0.01f, level_.wallH, 9.6f}));
    cube_.draw();
    S.set("uModel", translate({c.x + 1.0f, 0.01f, c.z}) * scale({3.8f, 0.01f, 9.6f * g}));
    cube_.draw();
  }
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
}

void Game::storeHUD() {
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  float m = 12.0f * s, sz = 8.0f * s;
  const float wr = 0.92f, wg = 0.92f, wb = 0.88f;
  // Shift card, top left.
  std::string clock = storePhase_ == StorePhase::Shift ? clockText(shiftTime_) : "10:0" + std::to_string(std::min(9, (int)(phaseTime_ / 60.0f) + 1)) + " PM";
  float y = m;
  R_->rect(m - 4 * s, m - 4 * s, 250 * s, (storePhase_ == StorePhase::Shift ? 66 : 34) * s, 0, 0, 0, 0.45f);
  R_->text("QUIK-STOP #114   " + clock, m, y, s, 1.0f, 0.85f, 0.35f);
  y += sz * 1.6f;
  if (storePhase_ == StorePhase::Shift) {
    int waiting = 0;
    for (const Npc& n : customers_) if (n.active && n.state == 4) ++waiting;
    char buf[64];
    std::snprintf(buf, sizeof buf, "- SERVE CUSTOMERS   %s", waiting ? "(WAITING!)" : "");
    R_->text(buf, m, y, s, waiting ? 1.0f : wr, waiting ? 0.6f : wg, waiting ? 0.4f : wb);
    y += sz * 1.4f;
    if (restockSlot_ >= 0) {
      R_->text(carrying_ ? "- STOCK THE GLOWING SHELF" : "- GET THE STOCK BOX (BACK ROOM)", m, y, s, wr, wg, wb);
      y += sz * 1.4f;
    }
    if (spill_ >= 0) {
      std::snprintf(buf, sizeof buf, "- MOP THE SPILL IN AISLE %d", spill_ % 6 + 1);
      R_->text(buf, m, y, s, wr, wg, wb);
      y += sz * 1.4f;
    }
    std::snprintf(buf, sizeof buf, "SERVED %d   WALKOUTS %d", served_, walkouts_);
    R_->text(buf, m, m + 54 * s, s, 0.7f, 0.68f, 0.6f);
  } else if (!objective_.empty()) {
    R_->text("> " + objective_, m, y, s, 1.0f, 0.95f, 0.8f);
  }
  // Crosshair, prompt, hold bar.
  R_->rect(W * 0.5f - s, H * 0.5f - s, 2 * s, 2 * s, 1, 1, 1, 0.35f);
  std::string prompt = storePrompt();
  if (!prompt.empty()) R_->text(prompt, W * 0.5f - R_->textWidth(prompt, s) * 0.5f, H * 0.62f, s, wr, wg, wb, 0.95f);
  if (holdProgress_ > 0.01f) {
    float bw = 140 * s, bx = W * 0.5f - bw * 0.5f, by = H * 0.62f + 14 * s;
    R_->rect(bx, by, bw, 4 * s, 1, 1, 1, 0.2f);
    R_->rect(bx, by, bw * holdProgress_, 4 * s, 1.0f, 0.85f, 0.35f, 0.9f);
  }
  if (storePhase_ == StorePhase::HoldLight) {
    float bw = 160 * s, bx = W * 0.5f - bw * 0.5f, by = H * 0.7f;
    R_->rect(bx, by, bw, 4 * s, 1, 1, 1, 0.2f);
    R_->rect(bx, by, bw * holdLight_, 4 * s, 0.95f, 0.95f, 0.8f, 0.9f);
  }
  if (hasFlashlight_ && !flashOn_) R_->text("[F] FLASHLIGHT", W - m - R_->textWidth("[F] FLASHLIGHT", s), m, s, wr, wg, wb, 0.7f);
  drawSubtitles();
  if (toastTime_ > 0) R_->text(toast_, W * 0.5f - R_->textWidth(toast_, s) * 0.5f, H * 0.2f, s, wr, wg, wb, clampf(toastTime_, 0, 1));
  if (fade_ > 0) R_->rect(0, 0, W, H, 0, 0, 0, clampf(fade_, 0, 1));
}
