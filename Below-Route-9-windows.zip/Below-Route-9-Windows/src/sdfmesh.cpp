#include "sdfmesh.h"
#include <algorithm>
#include <cmath>
#include <functional>
#include <thread>
#include <vector>

namespace {
// Split [0, n) across the CPU's cores. The SDFs are pure functions, so sampling is safe in parallel.
void parallelFor(int n, const std::function<void(int, int)>& fn) {
  int threads = (int)std::max(1u, std::min(16u, std::thread::hardware_concurrency()));
  if (threads <= 1 || n < 8) { fn(0, n); return; }
  std::vector<std::thread> pool;
  int chunk = (n + threads - 1) / threads;
  for (int t = 0; t < threads; ++t) {
    int a = t * chunk, b = std::min(n, a + chunk);
    if (a >= b) break;
    pool.emplace_back(fn, a, b);
  }
  for (auto& th : pool) th.join();
}
}  // namespace

namespace sdf {
float noise(vec3 p) {
  int xi = (int)std::floor(p.x), yi = (int)std::floor(p.y), zi = (int)std::floor(p.z);
  float fx = p.x - xi, fy = p.y - yi, fz = p.z - zi;
  float ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy), uz = fz * fz * (3 - 2 * fz);
  auto h = [&](int a, int b, int c) { return hashf(a, b, c) * 2.0f - 1.0f; };
  float x00 = lerpf(h(xi, yi, zi), h(xi + 1, yi, zi), ux);
  float x10 = lerpf(h(xi, yi + 1, zi), h(xi + 1, yi + 1, zi), ux);
  float x01 = lerpf(h(xi, yi, zi + 1), h(xi + 1, yi, zi + 1), ux);
  float x11 = lerpf(h(xi, yi + 1, zi + 1), h(xi + 1, yi + 1, zi + 1), ux);
  return lerpf(lerpf(x00, x10, uy), lerpf(x01, x11, uy), uz);
}
float fbm(vec3 p, int oct) {
  float s = 0, a = 0.5f, n = 0;
  for (int i = 0; i < oct; ++i) { s += a * noise(p); n += a; a *= 0.5f; p = p * 2.03f + vec3{17.1f, 3.3f, 9.7f}; }
  return s / n;
}
}  // namespace sdf

SdfMesh surfaceNets(const SdfFn& f, vec3 bmin, vec3 bmax, float cell) {
  const int nx = (int)std::ceil((bmax.x - bmin.x) / cell) + 1;
  const int ny = (int)std::ceil((bmax.y - bmin.y) / cell) + 1;
  const int nz = (int)std::ceil((bmax.z - bmin.z) / cell) + 1;
  auto P = [&](int x, int y, int z) { return vec3{bmin.x + x * cell, bmin.y + y * cell, bmin.z + z * cell}; };
  auto I = [&](int x, int y, int z) { return ((size_t)z * ny + y) * nx + x; };

  // Coarse pass every 4 cells; fine samples are only evaluated near the surface.
  const int S = 4;
  const int qx = (nx - 1) / S + 2, qy = (ny - 1) / S + 2, qz = (nz - 1) / S + 2;
  std::vector<float> coarse((size_t)qx * qy * qz);
  auto Q = [&](int x, int y, int z) { return ((size_t)z * qy + y) * qx + x; };
  parallelFor(qz, [&](int z0, int z1) {
    for (int z = z0; z < z1; ++z)
      for (int y = 0; y < qy; ++y)
        for (int x = 0; x < qx; ++x) coarse[Q(x, y, z)] = f(P(x * S, y * S, z * S)).d;
  });
  const float near = cell * S * 1.8f;
  std::vector<float> d((size_t)nx * ny * nz);
  parallelFor(nz, [&](int z0, int z1) {
  for (int z = z0; z < z1; ++z)
    for (int y = 0; y < ny; ++y)
      for (int x = 0; x < nx; ++x) {
        int bx = x / S, by = y / S, bz = z / S;
        float fx = (x - bx * S) / (float)S, fy = (y - by * S) / (float)S, fz = (z - bz * S) / (float)S;
        float c[8];
        bool close = false;
        for (int k = 0; k < 8; ++k) {
          c[k] = coarse[Q(bx + (k & 1), by + ((k >> 1) & 1), bz + ((k >> 2) & 1))];
          if (std::fabs(c[k]) < near) close = true;
        }
        if (close) { d[I(x, y, z)] = f(P(x, y, z)).d; continue; }
        float x0 = lerpf(c[0], c[1], fx), x1 = lerpf(c[2], c[3], fx), x2 = lerpf(c[4], c[5], fx), x3 = lerpf(c[6], c[7], fx);
        d[I(x, y, z)] = lerpf(lerpf(x0, x1, fy), lerpf(x2, x3, fy), fz);
      }
  });

  // One vertex per cell that straddles the surface: average of edge crossings.
  const int cx = nx - 1, cy = ny - 1, cz = nz - 1;
  std::vector<int> cellVert((size_t)cx * cy * cz, -1);
  auto C = [&](int x, int y, int z) { return ((size_t)z * cy + y) * cx + x; };
  static const int corner[8][3] = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {1, 1, 0}, {0, 0, 1}, {1, 0, 1}, {0, 1, 1}, {1, 1, 1}};
  static const int edges[12][2] = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
  SdfMesh m;
  for (int z = 0; z < cz; ++z)
    for (int y = 0; y < cy; ++y)
      for (int x = 0; x < cx; ++x) {
        float v[8];
        int mask = 0;
        for (int k = 0; k < 8; ++k) {
          v[k] = d[I(x + corner[k][0], y + corner[k][1], z + corner[k][2])];
          if (v[k] < 0) mask |= 1 << k;
        }
        if (mask == 0 || mask == 255) continue;
        vec3 acc{0, 0, 0};
        int n = 0;
        for (auto& e : edges) {
          float a = v[e[0]], b = v[e[1]];
          if ((a < 0) == (b < 0)) continue;
          float t = a / (a - b);
          vec3 pa{(float)corner[e[0]][0], (float)corner[e[0]][1], (float)corner[e[0]][2]};
          vec3 pb{(float)corner[e[1]][0], (float)corner[e[1]][1], (float)corner[e[1]][2]};
          acc += lerp(pa, pb, t);
          ++n;
        }
        acc = acc * (1.0f / n);
        cellVert[C(x, y, z)] = (int)m.pos.size();
        m.pos.push_back(P(x, y, z) + acc * cell);
      }

  // Normals, regions and SDF ambient occlusion.
  const float e = cell * 0.5f;
  m.nrm.resize(m.pos.size());
  m.region.resize(m.pos.size());
  m.ao.resize(m.pos.size());
  parallelFor((int)m.pos.size(), [&](int i0, int i1) {
  for (int i = i0; i < i1; ++i) {
    vec3 p = m.pos[i];
    vec3 g{f(p + vec3{e, 0, 0}).d - f(p - vec3{e, 0, 0}).d, f(p + vec3{0, e, 0}).d - f(p - vec3{0, e, 0}).d,
           f(p + vec3{0, 0, e}).d - f(p - vec3{0, 0, e}).d};
    vec3 n = normalize(g);
    m.nrm[i] = n;
    m.region[i] = f(p).region;
    float occ = 0, w = 1.0f;
    for (int k = 1; k <= 4; ++k) {
      float h = 0.018f * k;
      occ += (h - std::min(f(p + n * h).d, h)) * w;
      w *= 0.6f;
    }
    m.ao[i] = clampf(1.0f - occ * 9.0f, 0.15f, 1.0f);
  }
  });

  // Quads across every sign-changing grid edge, oriented by the field gradient.
  auto emit = [&](int a, int b, int c, int dd, bool flip) {
    if (a < 0 || b < 0 || c < 0 || dd < 0) return;
    if (flip) std::swap(b, dd);
    m.idx.insert(m.idx.end(), {(uint32_t)a, (uint32_t)b, (uint32_t)c, (uint32_t)a, (uint32_t)c, (uint32_t)dd});
  };
  for (int z = 0; z < nz; ++z)
    for (int y = 0; y < ny; ++y)
      for (int x = 0; x < nx; ++x) {
        bool in0 = d[I(x, y, z)] < 0;
        if (x < cx && y > 0 && z > 0 && y < ny - 1 && z < nz - 1 && in0 != (d[I(x + 1, y, z)] < 0))
          emit(cellVert[C(x, y - 1, z - 1)], cellVert[C(x, y, z - 1)], cellVert[C(x, y, z)], cellVert[C(x, y - 1, z)], !in0);
        if (y < cy && x > 0 && z > 0 && x < nx - 1 && z < nz - 1 && in0 != (d[I(x, y + 1, z)] < 0))
          emit(cellVert[C(x - 1, y, z - 1)], cellVert[C(x - 1, y, z)], cellVert[C(x, y, z)], cellVert[C(x, y, z - 1)], !in0);
        if (z < cz && x > 0 && y > 0 && x < nx - 1 && y < ny - 1 && in0 != (d[I(x, y, z + 1)] < 0))
          emit(cellVert[C(x - 1, y - 1, z)], cellVert[C(x, y - 1, z)], cellVert[C(x, y, z)], cellVert[C(x - 1, y, z)], !in0);
      }
  // Make winding agree with the gradient (robust against convention mistakes).
  for (size_t t = 0; t + 2 < m.idx.size(); t += 3) {
    vec3 a = m.pos[m.idx[t]], b = m.pos[m.idx[t + 1]], c = m.pos[m.idx[t + 2]];
    vec3 fn = cross(b - a, c - a);
    vec3 avg = m.nrm[m.idx[t]] + m.nrm[m.idx[t + 1]] + m.nrm[m.idx[t + 2]];
    if (dot(fn, avg) < 0) std::swap(m.idx[t + 1], m.idx[t + 2]);
  }
  return m;
}
