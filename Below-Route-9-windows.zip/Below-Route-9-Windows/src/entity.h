// Entity AI. Stalkers (the Tenant, the Hound) share a perception-driven state
// machine with per-species parameters; the Grin has its own light-seeking logic.
#pragma once
#include "level.h"
#include "mathx.h"
#include <vector>

struct Perception {
  vec3 playerPos;
  float noiseRadius = 0;   // how far the player's last footstep carried
  float sightRange = 0;    // how far away the player can be seen right now
  bool flashlightOn = false;
  float playerLight = 1;   // baked light where the player stands
  bool hidden = false;     // in a locker, unseen
};

struct StalkerParams {
  float wanderSpeed = 1.25f, investigateSpeed = 2.4f, searchSpeed = 1.6f;
  float chaseBase = 3.2f, chaseMax = 4.5f, chaseAccel = 0.25f;
  float hearing = 1.0f;     // multiplier on the player's noise radius
  float sight = 1.0f;       // multiplier on sight range; 0 = blind
  float catchDist = 0.95f;
  float radius = 0.32f;
  float giveUp = 5.0f;      // seconds without contact before searching
  float stride = 1.7f;
  bool blind = false;
};

class Stalker {
 public:
  enum State { Dormant, Wander, Idle, Investigate, Chase, Search };

  StalkerParams P;
  State state = Dormant;
  vec3 pos{0, 0, 0};
  float yaw = 0, speed = 0, stateTime = 0, chaseTime = 0, twitch = 0, anim = 0;
  float hunt = 0;           // > 0: it knows exactly where you are (hunt / exit chase)
  float huntSpeed = 3.8f;
  int kind = 0;             // CreatureId
  int variant = 0;          // 1 = the Lifeguard (pale Tenant)

  struct Events { bool step = false; bool chaseStarted = false; bool caught = false; };

  void placeFar(const Level& L, vec3 playerPos, Rng& rng, int minTiles = 14, int maxTiles = 26);
  Events update(float dt, const Level& L, const Perception& p, Rng& rng);
  bool canSee(const Level& L, vec3 target, float range) const;
  bool active() const { return state != Dormant; }
  float alert() const { return state == Chase || hunt > 0 ? 1.0f : (state == Investigate ? 0.5f : 0.0f); }
  void startHunt(float seconds, float spd) { hunt = seconds; huntSpeed = spd; }

 private:
  vec3 goal_{0, 0, 0}, lastKnown_{0, 0, 0};
  float lostTime_ = 0, stepPhase_ = 0, idleFor_ = 0;
  void moveToward(const Level& L, vec3 target, float spd, float dt, bool direct);
  void pickWanderGoal(const Level& L, vec3 playerPos, Rng& rng, int radius);
  void setState(State s) { state = s; stateTime = 0; }
};

// The Grin lives in dark zones. It drifts toward a lit flashlight, freezes when
// you look at it with the light off, and never leaves the dark.
class Grin {
 public:
  vec3 pos{0, 0, 0}, home{0, 0, 0};
  float yaw = 0, speed = 0, anim = 0, twitch = 0, alert = 0;
  bool active = false;
  struct Events { bool noticed = false; bool caught = false; };
  Events update(float dt, const Level& L, const Perception& p, const std::vector<float>& lightState, vec3 camForward, Rng& rng);
};
