// Things that are probably nothing. Quiet, believable scares that come every minute or two:
//   - footsteps behind you that keep your pace and stop when you stop (and when you turn round)
//   - the ceiling lights going out one by one, coming toward you, then back on
//   - somebody standing at the far end of the hall, gone when you get close or look away
//   - knocking from inside the wall beside you
//   - two frames of a face inside a tracking glitch (once per level, at most)
#include <algorithm>
#include <cmath>
#include <cstdlib>

#include "audio.h"
#include "game.h"
#include "texgen.h"

namespace {
const vec4 kShadowLook[4] = {{0.012f, 0.011f, 0.011f, 0}, {0.006f, 0.006f, 0.006f, 0}, {0.01f, 0.01f, 0.012f, 0}, {0.008f, 0.008f, 0.009f, 0}};
enum Scare { SC_NONE = 0, SC_STEPS, SC_LIGHTS, SC_WATCHER, SC_KNOCK, SC_FACE };
}  // namespace

void Game::scaresReset() {
  scare_ = SC_NONE;
  scareT_ = 0;
  scareAt_ = rng_.range(40.0f, 75.0f);
  watcher_ = false;
  faceT_ = -1;
  faceDone_ = false;
  lightKill_.assign(level_.lights.size(), -1.0f);
}

void Game::scaresUpdate(float dt) {
  bool calm = !inStore() && levelIndex_ >= 0 && levelIndex_ != kChoiceLevel && hiding_ < 0 && !anyChasing() && rayState_ != 2 &&
              partySong_ <= 0 && !dropping_;
  vec3 f = forward();
  float yaw = std::atan2(-f.x, -f.z);
  if (scare_ == SC_NONE) {
    if (!calm) return;
    scareT_ += dt;
    if (scareT_ < scareAt_) return;
    scareT_ = 0;
    scareAt_ = rng_.range(55.0f, 110.0f);
    int pick = (int)(rng_.next() % 100);
    if (const char* e = std::getenv("BR9_SCARE")) { const int force[6] = {50, 20, 50, 70, 90, 5}; pick = force[std::atoi(e) % 6]; faceDone_ = false; }
    if (!faceDone_ && (playTime_ > 90.0f || std::getenv("BR9_SCARE")) && pick < 12) scare_ = SC_FACE;
    else if (pick < 38) scare_ = SC_STEPS;
    else if (pick < 60) scare_ = SC_LIGHTS;
    else if (pick < 82) scare_ = SC_WATCHER;
    else scare_ = SC_KNOCK;
    scareRun_ = 0;
    // set-up
    if (scare_ == SC_STEPS) { stepsYaw_ = yaw; stepsNext_ = 0; stepsQuiet_ = 0; }
    if (scare_ == SC_LIGHTS) {
      // every fixture within 26 m, farthest first: they go out one by one, toward you
      chaseOrder_.clear();
      std::vector<std::pair<float, int>> c;
      for (size_t i = 0; i < level_.lights.size(); ++i) {
        if (level_.lights[i].kind == 2) continue;
        vec3 d = level_.delta(pos_, level_.lights[i].pos);
        float dist = std::sqrt(d.x * d.x + d.z * d.z);
        if (dist < 26.0f) c.push_back({-dist, (int)i});
      }
      std::sort(c.begin(), c.end());
      for (auto& e : c) chaseOrder_.push_back(e.second);
      if (chaseOrder_.size() < 3) scare_ = SC_NONE;
    }
    if (scare_ == SC_WATCHER) {
      // the farthest point you can see straight ahead, 16-30 m away
      vec3 dir{f.x, 0, f.z};
      float dl = length(dir);
      if (dl < 0.1f) { scare_ = SC_NONE; return; }
      dir = dir * (1.0f / dl);
      float best = 0;
      for (float d = 16.0f; d <= 30.0f; d += 1.0f) {
        vec3 p = pos_ + dir * d;
        if (!level_.lineOfSight(pos_.x, pos_.z, p.x, p.z, true)) break;
        vec3 q = p;
        level_.collide(q, 0.35f);
        vec3 moved = level_.delta(p, q);
        if (moved.x * moved.x + moved.z * moved.z < 0.01f) best = d;
      }
      if (best < 16.0f) { scare_ = SC_NONE; return; }
      watcherPos_ = level_.wrap(pos_ + dir * best);
      watcher_ = true;
      watcherAway_ = 0;
    }
    if (scare_ == SC_KNOCK && A_) {
      float pan = rng_.range(-0.9f, 0.9f);
      A_->play(Sfx::Knock, 0.55f, pan, 0.9f);
    }
    if (scare_ == SC_FACE) { faceT_ = 0; faceDone_ = true; }
    return;
  }
  scareRun_ += dt;
  switch (scare_) {
    case SC_STEPS: {
      // footsteps a few metres behind, keeping your pace: only while you walk
      float spd = std::sqrt(vel_.x * vel_.x + vel_.z * vel_.z);
      if (std::fabs(std::remainder(yaw - stepsYaw_, 2.0f * kPi)) > 2.3f) {  // you turned round: nothing there
        scare_ = SC_NONE;
        fear_ = std::min(1.0f, fear_ + 0.25f);
        break;
      }
      if (spd > 0.6f) {
        stepsQuiet_ = 0;
        stepsNext_ -= dt;
        if (stepsNext_ <= 0) {
          stepsNext_ = 0.62f * (1.6f / std::max(1.2f, spd)) + rng_.range(-0.03f, 0.05f);
          if (A_) A_->play(Sfx::Footstep, 0.22f, rng_.range(-0.25f, 0.25f), 0.82f);
        }
      } else {
        stepsQuiet_ += dt;
        if (stepsQuiet_ > 0.4f && stepsQuiet_ - dt <= 0.4f && A_) A_->play(Sfx::Footstep, 0.2f, rng_.range(-0.2f, 0.2f), 0.8f);  // one more. then nothing
      }
      if (scareRun_ > 14.0f) scare_ = SC_NONE;
    } break;
    case SC_LIGHTS: {
      int n = (int)chaseOrder_.size();
      int on = (int)(scareRun_ / 0.32f);
      for (int k = 0; k < n && k <= on; ++k) {
        int li = chaseOrder_[k];
        if (li < (int)lightKill_.size() && lightKill_[li] < time_) {
          lightKill_[li] = time_ + (n - k) * 0.32f + 2.2f;  // everything stays dark together for a moment
          if (A_) {
            vec3 d = level_.delta(pos_, level_.lights[li].pos);
            float dist = std::sqrt(d.x * d.x + d.z * d.z);
            A_->play(Sfx::Brownout, clampf(1.0f - dist / 30.0f, 0.15f, 0.9f), 0, 1.0f + k * 0.01f);
          }
        }
      }
      if (scareRun_ > n * 0.32f + 3.0f) scare_ = SC_NONE;
    } break;
    case SC_WATCHER: {
      vec3 d = level_.delta(pos_, watcherPos_);
      float dist = std::sqrt(d.x * d.x + d.z * d.z);
      vec3 to = d * (1.0f / std::max(dist, 0.01f));
      float look = f.x * to.x + f.z * to.z;
      if (look < 0.75f) watcherAway_ += dt;
      bool gone = dist < 11.0f || scareRun_ > 9.0f || (watcherAway_ > 0.35f && look > 0.8f) ||
                  !level_.lineOfSight(pos_.x, pos_.z, watcherPos_.x, watcherPos_.z, true);
      if (gone) {
        watcher_ = false;
        scare_ = SC_NONE;
        if (look > 0.8f) brownout_ = std::max(brownout_, 0.5f);  // a flicker, and it's not there
      }
    } break;
    case SC_KNOCK:
      if (scareRun_ > 2.6f && scareRun_ - dt <= 2.6f && A_) A_->play(Sfx::Knock, 0.4f, rng_.range(-0.9f, 0.9f), 0.85f);
      if (scareRun_ > 4.0f) scare_ = SC_NONE;
      break;
    case SC_FACE:
      faceT_ += dt;
      if (faceT_ > 0.9f) { faceT_ = -1; scare_ = SC_NONE; }
      break;
    default: scare_ = SC_NONE; break;
  }
}

float Game::scareLight(int i, float s) const {
  if (i >= 0 && i < (int)lightKill_.size() && lightKill_[i] > time_) return 0.0f;
  return s;
}

float Game::scareStatic() const {
  if (faceT_ < 0) return 0.0f;
  return (faceT_ > 0.25f && faceT_ < 0.55f) ? 0.55f : 0.0f;  // the tracking glitch the face hides in
}

void Game::scaresDraw(Shader& S, vec3 cam) {
  if (!watcher_) return;
  vec3 p = near(watcherPos_, cam);
  p.y = level_.floorAt(p.x, p.z);
  vec3 d = cam - p;
  AnimInput in;
  in.time = time_;
  in.look = 0.25f;  // head a little to one side
  drawCreature(S, CR_HUMAN, p, std::atan2(-d.x, -d.z), in, 0, kShadowLook);  // facing you
}

void Game::scaresHUD() {
  // two frames of a face, mid-glitch
  if (faceT_ < 0.33f || faceT_ > 0.33f + 2.0f / 60.0f + 0.001f) return;
  if (!texFace_) texFace_ = makeTexture(texgen::faceFlash(256, 1313), false, false);
  float W = (float)R_->winW, H = (float)R_->winH;
  float sz = H * 0.9f;
  R_->image(texFace_, W * 0.5f - sz * 0.5f + (hashf((int)(time_ * 60.0f)) - 0.5f) * 30.0f, H * 0.05f, sz, sz, 0.55f);
}
