// The Poolrooms set pieces and the sun: spiral stairs climbing a tiled column up through a round
// hole in the ceiling, skylight wells, tunnel mouths half under the water, drains. And sunlight
// with a real shadow map, so it comes through the skylights and lands in patches on the tile.
#include <cmath>
#include <cstdio>

#include "game.h"
#include "texgen.h"

namespace {
mat4 orthoM(float l, float r, float b, float t, float n, float f) {
  mat4 m{};
  m.m[0] = 2 / (r - l); m.m[5] = 2 / (t - b); m.m[10] = -2 / (f - n);
  m.m[12] = -(r + l) / (r - l); m.m[13] = -(t + b) / (t - b); m.m[14] = -(f + n) / (f - n); m.m[15] = 1;
  return m;
}
vec3 xf(const mat4& m, vec3 p) {
  return {m.m[0] * p.x + m.m[4] * p.y + m.m[8] * p.z + m.m[12], m.m[1] * p.x + m.m[5] * p.y + m.m[9] * p.z + m.m[13],
          m.m[2] * p.x + m.m[6] * p.y + m.m[10] * p.z + m.m[14]};
}
mat4 basisQ(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}
// a quad with UVs in metres along its own edges
void quadM(Mesh& m, vec3 a, vec3 b, vec3 c, vec3 d, float ao = 1.0f) {
  vec3 n = normalize(cross(b - a, d - a));
  float w = length(b - a), h = length(d - a);
  float u0 = a.x + a.z, v0 = a.y;
  m.quad(a, b, c, d, n, {u0, v0}, {u0 + w, v0}, {u0 + w, v0 + h}, {u0, v0 + h}, ao, ao, ao, ao);
}
}  // namespace

void Game::buildPoolPieces() {
  stairSteps_.destroy(); stairCeil_.destroy(); stairShaft_.destroy();
  if (level_.stairwells.empty() && level_.tunnels.empty() && level_.drains.empty()) return;
  if (!texTunnel_) texTunnel_ = makeTexture(texgen::tunnelMouth(256), true, false);
  const float H = level_.wallH, top = H + 1.1f, Rhole = 1.75f, Rcol = 0.42f, Rout = 1.62f;
  const float y0 = -Level::kPoolDepth;
  Mesh steps, ceil, shaft;
  // the column
  const int N = 32;
  for (int k = 0; k < N; ++k) {
    float a0 = k * 2 * kPi / N, a1 = (k + 1) * 2 * kPi / N;
    vec3 n0{std::cos(a0), 0, std::sin(a0)}, n1{std::cos(a1), 0, std::sin(a1)};
    vec3 nn = normalize(n0 + n1);
    vec3 p0 = n0 * Rcol, p1 = n1 * Rcol;
    steps.quad({p1.x, y0, p1.z}, {p0.x, y0, p0.z}, {p0.x, top, p0.z}, {p1.x, top, p1.z}, nn, {a1 * Rcol, y0}, {a0 * Rcol, y0}, {a0 * Rcol, top},
               {a1 * Rcol, top}, 0.8f, 0.8f, 1, 1);
    // the shaft above the hole, facing in
    vec3 s0 = n0 * Rhole, s1 = n1 * Rhole;
    shaft.quad({s0.x, H, s0.z}, {s1.x, H, s1.z}, {s1.x, top, s1.z}, {s0.x, top, s0.z}, nn * -1.0f, {a0 * Rhole, H}, {a1 * Rhole, H}, {a1 * Rhole, top},
               {a0 * Rhole, top}, 0.75f, 0.75f, 1, 1);
    // ceiling ring: from the hole out to the square around it
    auto edge = [&](vec3 n) {  // where a ray from the centre leaves the 4x4 m square
      float t = 2.0f / std::max(std::fabs(n.x), std::fabs(n.z));
      return n * t;
    };
    vec3 e0 = edge(n0), e1 = edge(n1);
    ceil.quad({s1.x, H, s1.z}, {s0.x, H, s0.z}, {e0.x, H, e0.z}, {e1.x, H, e1.z}, {0, -1, 0}, {s1.x, s1.z}, {s0.x, s0.z}, {e0.x, e0.z}, {e1.x, e1.z},
              1, 1, 0.9f, 0.9f);
  }
  // the steps: one full turn and a bit, from the water up into the light
  const int S = 22;
  const float da = 0.31f, rise = (H + 0.7f) / S, th = 0.17f;
  for (int i = 0; i < S; ++i) {
    float a0 = i * da - 1.2f, a1 = a0 + da * 1.04f;
    float yt = -0.1f + rise * (i + 1), yb = yt - th;
    vec3 i0{std::cos(a0) * Rcol, 0, std::sin(a0) * Rcol}, i1{std::cos(a1) * Rcol, 0, std::sin(a1) * Rcol};
    vec3 o0{std::cos(a0) * Rout, 0, std::sin(a0) * Rout}, o1{std::cos(a1) * Rout, 0, std::sin(a1) * Rout};
    auto Y = [](vec3 p, float y) { return vec3{p.x, y, p.z}; };
    quadM(steps, Y(i0, yt), Y(o0, yt), Y(o1, yt), Y(i1, yt));          // tread
    quadM(steps, Y(i1, yb), Y(o1, yb), Y(o0, yb), Y(i0, yb), 0.7f);    // underside
    quadM(steps, Y(o0, yb), Y(o1, yb), Y(o1, yt), Y(o0, yt), 0.9f);    // outer edge
    quadM(steps, Y(i0, yb), Y(o0, yb), Y(o0, yt), Y(i0, yt), 0.85f);   // riser
    quadM(steps, Y(o1, yb), Y(i1, yb), Y(i1, yt), Y(o1, yt), 0.85f);   // back
  }
  stairSteps_.upload(steps);
  stairCeil_.upload(ceil);
  stairShaft_.upload(shaft);
}

void Game::drawPoolPieces(Shader& S, vec3 cam) {
  const float H = level_.wallH;
  S.set("uSkinned", 0);
  S.set("uUVScale", 1.0f);
  if (!level_.stairwells.empty() && stairSteps_.count) {
    glDisable(GL_CULL_FACE);
    for (const vec3& c0 : level_.stairwells) {
      vec3 c = near(c0, cam);
      if (std::fabs(c.x - cam.x) > 60 || std::fabs(c.z - cam.z) > 60) continue;
      S.set("uModel", translate(c));
      S.set("uMat", MAT_WALL);
      S.set("uRough", 0.18f);
      S.set("uBump", 0.004f);
      glBindTexture(GL_TEXTURE_2D, texWall_);
      stairSteps_.draw();
      stairShaft_.draw();
      S.set("uMat", MAT_CEIL);
      glBindTexture(GL_TEXTURE_2D, texCeil_);
      stairCeil_.draw();
      // the light at the top
      S.set("uMat", MAT_SCREEN);
      S.set("uEmissive", 3.2f);
      glBindTexture(GL_TEXTURE_2D, texWhite_);
      S.set("uModel", basisQ({3.6f, 0, 0}, {0, 0, 3.6f}, {0, -1, 0}, c + vec3{0, H + 1.09f, 0}));
      quad_.draw();
    }
    glEnable(GL_CULL_FACE);
  }
  // skylight wells: bright sky at the top of each shaft
  S.set("uMat", MAT_SCREEN);
  S.set("uEmissive", 3.0f);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  glDisable(GL_CULL_FACE);
  for (int z = 0; z < level_.H; ++z)
    for (int x = 0; x < level_.W; ++x) {
      if (!level_.isSky(x, z)) continue;
      vec3 c = near(level_.tileCenter(x, z, H + Level::kSkyWell - 0.01f), cam);
      if (std::fabs(c.x - cam.x) > 50 || std::fabs(c.z - cam.z) > 50) continue;
      S.set("uModel", basisQ({Level::kTile, 0, 0}, {0, 0, Level::kTile}, {0, -1, 0}, c));
      quad_.draw();
    }
  // tunnel mouths at the waterline, drains on the floor
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  S.set("uEmissive", 0.35f);
  glBindTexture(GL_TEXTURE_2D, texTunnel_ ? texTunnel_ : texWhite_);
  for (size_t i = 0; i < level_.tunnels.size(); ++i) {
    vec3 c = near(level_.tunnels[i], cam), n = level_.tunnelN[i];
    if (std::fabs(c.x - cam.x) > 45 || std::fabs(c.z - cam.z) > 45) continue;
    vec3 r = cross(vec3{0, 1, 0}, n);
    S.set("uModel", basisQ(r * 1.5f, {0, 1.5f, 0}, n, c + n * 0.004f));
    quad_.draw();
  }
  S.set("uEmissive", 0.18f);
  for (const vec3& d0 : level_.drains) {
    vec3 c = near(d0, cam);
    if (std::fabs(c.x - cam.x) > 40 || std::fabs(c.z - cam.z) > 40) continue;
    S.set("uModel", basisQ({0.55f, 0, 0}, {0, 0, 0.55f}, {0, 1, 0}, c));
    quad_.draw();
  }
  glDisable(GL_BLEND);
  glEnable(GL_CULL_FACE);
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
}

// Sun shadow map: the walls, ceilings, columns and stairs, from the sun's side, snapped to texels.
void Game::renderSun(vec3 camPos) {
  const Theme& th = level_.theme;
  sunOn_ = false;
  if (th.sun <= 0 || !R_->quality.shadowSize) return;
  vec3 sd = normalize(th.sunDir);
  vec3 up = std::fabs(sd.y) > 0.99f ? vec3{0, 0, 1} : vec3{0, 1, 0};
  mat4 V = lookAt(sd, {0, 0, 0}, up);
  vec3 c = xf(V, camPos);
  const float R = 26.0f, texel = 2 * R / Renderer::kSunSize;
  c.x = std::floor(c.x / texel) * texel;
  c.y = std::floor(c.y / texel) * texel;
  sunVP_ = orthoM(c.x - R, c.x + R, c.y - R, c.y + R, -c.z - 30.0f, -c.z + 30.0f) * V;
  if (!R_->beginSunShadow(sunVP_)) return;
  Shader& S = R_->shadow;
  for (ChunkGpu& ch : chunks_) {
    vec3 off = near(ch.center, camPos) - ch.center;
    vec3 d = ch.center + off - camPos;
    if (d.x * d.x + d.z * d.z > 40.0f * 40.0f) continue;
    S.set("uModel", translate(off));
    ch.walls.draw();
    ch.walls2.draw();
    ch.ceiling.draw();
    ch.ceiling2.draw();
  }
  for (const vec3& c0 : level_.stairwells) {
    S.set("uModel", translate(near(c0, camPos)));
    stairSteps_.draw();
    stairShaft_.draw();
    stairCeil_.draw();
  }
  S.set("uModel", mat4::identity());
  drawProps(S, camPos, 25.0f);
  drawCreatures(S, camPos);
  R_->endShadow();
  sunOn_ = true;
}
