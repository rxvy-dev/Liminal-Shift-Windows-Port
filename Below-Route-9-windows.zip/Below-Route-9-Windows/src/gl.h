// Minimal OpenGL 3.3 core loader. No system GL headers required:
// functions are resolved at runtime through SDL_GL_GetProcAddress.
#pragma once
#include <cstddef>
#include <cstdint>

// OpenGL entry points use the stdcall convention on 32-bit Windows (a no-op on x64 and elsewhere).
#ifndef GLAPIENTRY
#  ifdef _WIN32
#    define GLAPIENTRY __stdcall
#  else
#    define GLAPIENTRY
#  endif
#endif

typedef unsigned int GLenum;
typedef unsigned char GLboolean;
typedef unsigned int GLbitfield;
typedef int GLint;
typedef int GLsizei;
typedef unsigned int GLuint;
typedef float GLfloat;
typedef char GLchar;
typedef unsigned char GLubyte;
typedef std::ptrdiff_t GLsizeiptr;
typedef std::ptrdiff_t GLintptr;

#define GL_FALSE 0
#define GL_TRUE 1
#define GL_NO_ERROR 0
#define GL_DEPTH_BUFFER_BIT 0x00000100
#define GL_COLOR_BUFFER_BIT 0x00004000
#define GL_TRIANGLES 0x0004
#define GL_DEPTH_TEST 0x0B71
#define GL_CULL_FACE 0x0B44
#define GL_BLEND 0x0BE2
#define GL_BACK 0x0405
#define GL_LEQUAL 0x0203
#define GL_LESS 0x0201
#define GL_ONE 1
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE0 0x84C0
#define GL_TEXTURE1 0x84C1
#define GL_TEXTURE2 0x84C2
#define GL_TEXTURE3 0x84C3
#define GL_RED 0x1903
#define GL_RGB 0x1907
#define GL_RGBA 0x1908
#define GL_UNSIGNED_BYTE 0x1401
#define GL_UNSIGNED_INT 0x1405
#define GL_FLOAT 0x1406
#define GL_HALF_FLOAT 0x140B
#define GL_R8 0x8229
#define GL_R32F 0x822E
#define GL_RGBA8 0x8058
#define GL_RGBA16F 0x881A
#define GL_RGBA32F 0x8814
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_TEXTURE_MAX_LEVEL 0x813D
#define GL_TEXTURE_MAX_ANISOTROPY 0x84FE
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#define GL_REPEAT 0x2901
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_ARRAY_BUFFER 0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_STATIC_DRAW 0x88E4
#define GL_DYNAMIC_DRAW 0x88E8
#define GL_STREAM_DRAW 0x88E0
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_VERTEX_SHADER 0x8B31
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_FRAMEBUFFER 0x8D40
#define GL_RENDERBUFFER 0x8D41
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_DEPTH_ATTACHMENT 0x8D00
#define GL_DEPTH_COMPONENT24 0x81A6
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_VENDOR 0x1F00
#define GL_RENDERER 0x1F01
#define GL_VERSION 0x1F02
#define GL_EXTENSIONS 0x1F03
#define GL_NUM_EXTENSIONS 0x821D
#define GL_UNPACK_ALIGNMENT 0x0CF5
#define GL_PACK_ALIGNMENT 0x0D05
#define GL_NONE 0
#define GL_FRONT 0x0404
#define GL_DEPTH_COMPONENT 0x1902
#define GL_R16F 0x822D
#define GL_TEXTURE_COMPARE_MODE 0x884C
#define GL_TEXTURE_COMPARE_FUNC 0x884D
#define GL_COMPARE_REF_TO_TEXTURE 0x884E
#define GL_TEXTURE_BORDER_COLOR 0x1004
#define GL_CLAMP_TO_BORDER 0x812D
#define GL_POLYGON_OFFSET_FILL 0x8037
#define GL_TEXTURE4 0x84C4
#define GL_TEXTURE5 0x84C5
#define GL_TEXTURE6 0x84C6
#define GL_TEXTURE7 0x84C7

#define NOCLIP_GL_FUNCS \
  X(void, glViewport, (GLint, GLint, GLsizei, GLsizei)) \
  X(void, glClear, (GLbitfield)) \
  X(void, glClearColor, (GLfloat, GLfloat, GLfloat, GLfloat)) \
  X(void, glEnable, (GLenum)) \
  X(void, glDisable, (GLenum)) \
  X(void, glCullFace, (GLenum)) \
  X(void, glDepthFunc, (GLenum)) \
  X(void, glDepthMask, (GLboolean)) \
  X(void, glBlendFunc, (GLenum, GLenum)) \
  X(void, glBlendFuncSeparate, (GLenum, GLenum, GLenum, GLenum)) \
  X(const GLubyte*, glGetString, (GLenum)) \
  X(const GLubyte*, glGetStringi, (GLenum, GLuint)) \
  X(void, glGetIntegerv, (GLenum, GLint*)) \
  X(GLenum, glGetError, (void)) \
  X(void, glPixelStorei, (GLenum, GLint)) \
  X(void, glReadPixels, (GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void*)) \
  X(void, glGenTextures, (GLsizei, GLuint*)) \
  X(void, glDeleteTextures, (GLsizei, const GLuint*)) \
  X(void, glBindTexture, (GLenum, GLuint)) \
  X(void, glActiveTexture, (GLenum)) \
  X(void, glTexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*)) \
  X(void, glTexSubImage2D, (GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void*)) \
  X(void, glTexParameteri, (GLenum, GLenum, GLint)) \
  X(void, glTexParameterf, (GLenum, GLenum, GLfloat)) \
  X(void, glGenerateMipmap, (GLenum)) \
  X(GLuint, glCreateShader, (GLenum)) \
  X(void, glDeleteShader, (GLuint)) \
  X(void, glShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*)) \
  X(void, glCompileShader, (GLuint)) \
  X(void, glGetShaderiv, (GLuint, GLenum, GLint*)) \
  X(void, glGetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*)) \
  X(GLuint, glCreateProgram, (void)) \
  X(void, glAttachShader, (GLuint, GLuint)) \
  X(void, glBindAttribLocation, (GLuint, GLuint, const GLchar*)) \
  X(void, glLinkProgram, (GLuint)) \
  X(void, glGetProgramiv, (GLuint, GLenum, GLint*)) \
  X(void, glGetProgramInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*)) \
  X(void, glUseProgram, (GLuint)) \
  X(GLint, glGetUniformLocation, (GLuint, const GLchar*)) \
  X(void, glUniform1i, (GLint, GLint)) \
  X(void, glUniform1f, (GLint, GLfloat)) \
  X(void, glUniform2f, (GLint, GLfloat, GLfloat)) \
  X(void, glUniform3f, (GLint, GLfloat, GLfloat, GLfloat)) \
  X(void, glUniform4f, (GLint, GLfloat, GLfloat, GLfloat, GLfloat)) \
  X(void, glUniformMatrix4fv, (GLint, GLsizei, GLboolean, const GLfloat*)) \
  X(void, glUniform4fv, (GLint, GLsizei, const GLfloat*)) \
  X(void, glUniform1fv, (GLint, GLsizei, const GLfloat*)) \
  X(void, glDrawBuffer, (GLenum)) \
  X(void, glReadBuffer, (GLenum)) \
  X(void, glPolygonOffset, (GLfloat, GLfloat)) \
  X(void, glTexParameterfv, (GLenum, GLenum, const GLfloat*)) \
  X(void, glGenVertexArrays, (GLsizei, GLuint*)) \
  X(void, glDeleteVertexArrays, (GLsizei, const GLuint*)) \
  X(void, glBindVertexArray, (GLuint)) \
  X(void, glGenBuffers, (GLsizei, GLuint*)) \
  X(void, glDeleteBuffers, (GLsizei, const GLuint*)) \
  X(void, glBindBuffer, (GLenum, GLuint)) \
  X(void, glBufferData, (GLenum, GLsizeiptr, const void*, GLenum)) \
  X(void, glVertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*)) \
  X(void, glEnableVertexAttribArray, (GLuint)) \
  X(void, glDrawArrays, (GLenum, GLint, GLsizei)) \
  X(void, glDrawElements, (GLenum, GLsizei, GLenum, const void*)) \
  X(void, glGenFramebuffers, (GLsizei, GLuint*)) \
  X(void, glDeleteFramebuffers, (GLsizei, const GLuint*)) \
  X(void, glBindFramebuffer, (GLenum, GLuint)) \
  X(void, glFramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint)) \
  X(GLenum, glCheckFramebufferStatus, (GLenum)) \
  X(void, glGenRenderbuffers, (GLsizei, GLuint*)) \
  X(void, glDeleteRenderbuffers, (GLsizei, const GLuint*)) \
  X(void, glBindRenderbuffer, (GLenum, GLuint)) \
  X(void, glRenderbufferStorage, (GLenum, GLenum, GLsizei, GLsizei)) \
  X(void, glFramebufferRenderbuffer, (GLenum, GLenum, GLenum, GLuint))

#define X(ret, name, args) typedef ret (GLAPIENTRY *PFN_##name) args; extern PFN_##name name;
NOCLIP_GL_FUNCS
#undef X

namespace gl {
// Returns false and fills `missing` if a required function could not be resolved.
bool load(const char** missing);
bool hasExtension(const char* name);
}
