# NOCLIP — Lore Bible

Keep every note, tape and set dressing consistent with this file.

## The premise

Reality is rendered on demand. Wherever people stop paying attention (vacant floors,
closed malls, offices after hours) the world gets *cheap*. Behind the cheap parts is the
**Margin**: the space reality didn't bother to finish. Wanderers call it the Backrooms.
You enter it by "noclipping", slipping through a spot where the world is thin.

The Margin copies spaces that are forgotten. It is not evil. It is hungry for attention,
and the things inside it are what happens to attention left alone too long.

## The protagonist

**Dana Kerr**, a commercial building inspector, 1996. She is filming a vacant office floor
on a borrowed camcorder for an insurance report when she leans on a wall that isn't there.
The camcorder is the game's HUD: REC light, timestamp, battery.

Dana has a reason to keep going: her younger brother **Theo Kerr** disappeared in 1994 from
the same building during a night-shift security job. His handwriting is on the walls.

## Factions and people

- **The Survey**: a loose group of wanderers who map the levels and leave numbered
  survey markers (`S-0/114`). They are polite, tired and running out of paper.
- **Management**: never seen. Referenced in memos, work orders and signage that appear on
  their own. The Survey argues about whether Management exists.
- **Theo Kerr**: joined the Survey in 1994. His notes start hopeful and become strange.
  He believes the exit at the end (Level 15, the Archive) can send someone *home*.

## Entities

Entities are former wanderers who stayed too long and became part of a level's furniture.

- **The Tenant** (Level 0): very tall, stooped under the ceiling, long arms. It lives in
  the lights; fixtures dim and stutter when it is close. It hunts by sound and by light.
  It was the first Surveyor. Notes refer to it as "the landlord" before they knew better.
- **The Hound** (Level 0): a wanderer who crawled for so long they stopped standing. Eyeless,
  ribs through the skin, a jaw that hangs open. Clicks its tongue to hear the room. Blind, so
  the rule is simple: stop moving and it loses you.
- **The Grin** (Level 0 dark zones): nobody knows what it was. Soot that hangs in the air, two
  pale lights and far too many teeth. It is drawn to light in the dark, and it only moves
  when nobody is watching it.
- **The Lifeguard** (the Poolrooms): the Tenant's drowned cousin, pale and wet. It walks the
  pool edges and hears every splash. "The lifeguard is always on duty."
- Later levels: the Bellhop (Hotel), Mannequins (Mall), the Conductor (Subway),
  the Hall Monitor (School).

## Rules of the Margin

1. Almond water is safe. Nobody knows why.
2. Lights mean something is watching the space. Dead lights mean something stopped.
3. Running is loud. Everything here has been listening for a long time.
4. The exits are thin places. You hear them before you see them (radio static, a hum that
   changes pitch).
5. Writing things down keeps them real. The Survey's whole method is based on this.

## The plot (five acts)

1. **The Lobby (L0)**: Dana arrives, finds Theo's first notes, survives the Tenant, noclips out.
2. **The Survey (L1–L4)**: Dana meets the Survey's last camp. They ask her to carry their maps.
3. **The Descent (L5–L9)**: the levels get older. Theo's notes start addressing Dana by name,
   written *before* she arrived.
4. **The Unravelling (L10–L13)**: Dana realises the camcorder is recording things she didn't
   point it at. Management's memos mention "the inspector".
5. **The Archive (L14–L15)**: every tape ever recorded in the Margin. Theo is here, sort of.

## Endings

- **Exit**: Dana leaves alone through the true exit. The tape survives; Theo doesn't.
- **Tenancy**: Dana stays as the Archive's keeper so Theo can leave. The lights in the
  Lobby start working again.
- **Playback**: Dana plays the tape in the real world. People watch it. Attention flows
  into the Margin, and it starts to grow toward us. (Bad ending, maybe.)

## Levels in this build

| # | Level | Notes |
|---|---|---|
| 0 | The Lobby | 8: Theo, the Survey (Camp 3), Management. Teaches every rule |
| 1 | Habitable Zone | 4: a torn supply manifest signed by Theo; "something always comes when you get close" |
| 2 | Pipe Dreams | 3: "I think the whole place is one thing. I think it's awake." |
| 3 | The Poolrooms | 3: pool rules; the Lifeguard |
| 4 | Lights Out | 3: glow-paint arrows; Theo finds Dana's name in notes he didn't write |
| 5+ | Remixes | Survey stopped numbering; "trust the arrows" |

The Survey paints the route to each thin place in red (white in Pipe Dreams, black in the
Poolrooms, glowing green in Lights Out). Exact note text is in `src/theme.cpp`.

## The Theo Kerr mystery (v0.7)

The camcorder has always said OCT.24 1996. That's not a bug.

- **Theo Kerr** was the night clerk at Quik-Stop #114 on Route 9. He vanished on his shift on **October 24, 1996**. His MISSING poster is on the wall by the counter and in the back room. The odd customer near the end of Dana's shift mentions him: "The last clerk heard it too. Theo. Nice kid."
- **Level 0**: Theo's notes start as a clerk's survival guide ("If you work nights at the Quik-Stop...") and end with him going deeper: "tell my mom I didn't quit."
- **Level 1**: the Survey has noticed that every watch down here stopped on the night its owner fell, and every one of them says OCT 24 1996. "We all fell on the same night. Some of us fell thirty years apart." A red payphone rings in the wall. If you answer it, it's the store, and it's your own voice from tonight's shift asking who's breathing. Then everything on the level hears the phone.
- **Level 2**: Theo writes to Dana by name, a woman who wasn't born when he fell. "The store IS the thin place. It just looks like a store."
- **Level 3**: a clerk in a Quik-Stop vest stands across the water and watches you. It's you. Get close or stare at her and she's gone. The note nearby: "The ones that go back up aren't always the ones that fell."
- **Level 4**: Theo's last page: the store only stays open while someone is on the clock down here. "I covered for thirty years, Dana. Tonight it's your shift."
- **If you left Ray behind**, something wearing him waits in Lights Out. It's too tall, it calls your name, and when it runs it says what it thinks of you.
- **After every ending**: the tape itself. It was found sealed inside the basement wall in 2026. It's dated October 24, 1996. The store didn't open until 1999. No one named Dana ever worked there. The camera was still recording.
- **Afterwards**: the title screen isn't quite the same. BEGIN becomes CLOCK IN, and the title sometimes says something else.

Also: one locker, somewhere, is already occupied.

## The suit and the Survey (v0.8)

- At the bottom of the fall into Level 0 a yellow hazmat suit sits slumped on the carpet like a person. It's empty. Dana puts it on and wears it for the rest of the night: yellow sleeves, black gloves, the edge of the visor, her own breathing in the respirator. The suit's tag says **THRESHOLD SURVEY - UNIT 4**. It's still warm inside.
- On Levels 0 to 2, sometimes, two more suits walk away from you down a long hallway, dragging a red air hose behind them. Call out and they don't turn. Get close and they're gone between one flicker and the next.
- The clerk across the water on Level 3 is dressed like you are, whatever you're wearing.
- **The Tenant** wears the shredded remains of a red Quik-Stop polo with a name tag still pinned to it. The tag is too worn to read. Theo has been on the clock for thirty years.
- **The Hound** still has strips of denim on its back legs.
- **The Grin** sheds soot as it moves.


## Things you see (v0.9)

- **Level 0**: after you put on the suit, Theo walks ahead of you down a long hallway, flickering like bad tape. He stops, looks back, and tells you it's still 1996 down here. Then he's gone.
- **Level 0** also has **the Stilt**: a dried, dark thing on legs far too long and thin, with a seed-pod head and one pale wet spot. It stands very still, and then it doesn't.
- **Level 37**: Unit 3 floats face down in a pool near the route. Her last log entry: "I'm going to lie down in the water for a minute."
- **Level 188**: on the far balcony, a woman in a red Quik-Stop uniform is watching you. Every time you blink, she's closer. It's you.
- **Level Fun =)**: the Partygoers. Slow, yellow, smiling. Every so often it's somebody's birthday: the lights go party coloured, a detuned music box plays the song, and a whole party comes looking for the guest of honour. They don't look under tables. A banner on the wall says WELCOME BACK DANA. One of them is wearing a name tag that says HELLO MY NAME IS THEO.
- The thin places are taped off in blue now. The Survey did that.

## The three endings (v0.9)

At the end there are three slides in a wall.

- **Blue, CLOCKED OUT.** You go home and spend a night convincing yourself it wasn't real. Three nights later you go back to work, and there's already a woman behind the counter, wearing your name tag. She says there's a regular: someone in a yellow suit who stands in the rain outside the door at 3:14 every night, staring in. You look down. Yellow sleeves. You never took the suit off.
- **Red, WENT BACK.** You go back down for Ray and carry him out. His daughter runs to him, then stops. "That's not my dad." On his camcorder tape, Ray is still in the basement, begging you to come back. The thing you carried out parks his van in the lot and waves at you through the glass every night. He's a little taller every week.
- **Yellow, UNIT 4.** Three hazmat suits are waiting at the bottom. "Unit 4. She made it. Same as last time." The one in front takes off her hood, and it's you, thirty years older. Somebody has to work the night shift, because the store only stays open while one of you is down there. "And this time, don't take the yellow slide." Then: October 24, 1996, 9:00 PM. A new hire clocks in.
- If you carry Ray out without going back for him, you get **BROUGHT HIM HOME**.
