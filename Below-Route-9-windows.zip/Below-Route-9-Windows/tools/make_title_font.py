#!/usr/bin/env python3
"""Render VCR OSD Mono (Riciery Leal, free font) to an RLE alpha atlas: src/title_font.h.
Needs Pillow. Usage: python3 tools/make_title_font.py [path/to/font.ttf]"""
import sys
from PIL import Image, ImageDraw, ImageFont
path = sys.argv[1] if len(sys.argv) > 1 else "assets/fonts/VCR_OSD_MONO_1.001.ttf"
SIZE = 96
font = ImageFont.truetype(path, SIZE)
chars = "".join(chr(c) for c in range(32, 127))
pad, W = 6, 1024
cells, x, y, rowh = [], 0, 0, 0
for ch in chars:
    bb = font.getbbox(ch, anchor="ls") if ch != " " else (0, 0, 0, 0)
    cw, chh = bb[2] - bb[0] + pad * 2, bb[3] - bb[1] + pad * 2
    if x + cw > W: x, y, rowh = 0, y + rowh, 0
    cells.append((ch, x, y, cw, chh, bb)); x += cw; rowh = max(rowh, chh)
H = 1 << (y + rowh - 1).bit_length()
img = Image.new("L", (W, H), 0); d = ImageDraw.Draw(img); out = []
for ch, cx, cy, cw, chh, bb in cells:
    if ch != " ": d.text((cx + pad - bb[0], cy + pad - bb[1]), ch, font=font, fill=255, anchor="ls")
    out.append((ch, cx, cy, cw, chh, bb[0] - pad, bb[1] - pad, round(font.getlength(ch))))
px, rle, i = img.tobytes(), [], 0
while i < len(px):
    v, n = px[i], 1
    while i + n < len(px) and px[i + n] == v and n < 255: n += 1
    rle += [n, v]; i += n
L = ["// VCR OSD Mono by Riciery Leal (free font), rendered to an alpha atlas",
     "// by tools/make_title_font.py. Title cards and the camcorder on-screen display.", "#pragma once", "#include <cstdint>",
     f"constexpr int kTFontW = {W}, kTFontH = {H}, kTFontSize = {SIZE};",
     "struct TFontGlyph { char c; short x, y, w, h, ox, oy, adv; };", "static const TFontGlyph kTFontGlyphs[] = {"]
for g in out:
    c = g[0].replace("\\", "\\\\").replace("'", "\\'")
    L.append("  {'%s', %d, %d, %d, %d, %d, %d, %d}," % ((c,) + g[1:]))
L += ["};", "static const uint8_t kTFontRLE[] = {"]
L += ["  " + ",".join(str(v) for v in rle[k:k + 32]) + "," for k in range(0, len(rle), 32)]
L.append("};")
open("src/title_font.h", "w").write("\n".join(L) + "\n")
